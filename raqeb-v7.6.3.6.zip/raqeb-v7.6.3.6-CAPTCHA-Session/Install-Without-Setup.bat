@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "APPDIR=%LOCALAPPDATA%\Programs\aghrab"
set "STARTMENU=%APPDATA%\Microsoft\Windows\Start Menu\Programs"
set "DESKTOP=%USERPROFILE%\Desktop"
set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
echo =========================================
echo   RAQEB Sentinel Pro - Install / Update
echo =========================================
if not exist "%APPDIR%" mkdir "%APPDIR%"
copy /y "payload\ScreenshotTool.ps1" "%APPDIR%\ScreenshotTool.ps1" >nul
copy /y "payload\Start-AGHRAB.ps1" "%APPDIR%\Start-AGHRAB.ps1" >nul
copy /y "payload\Uninstall.ps1" "%APPDIR%\Uninstall.ps1" >nul
copy /y "payload\aghrab.ico" "%APPDIR%\aghrab.ico" >nul
copy /y "payload\aghrab-icon.png" "%APPDIR%\aghrab-icon.png" >nul
copy /y "payload\license-public-key.xml" "%APPDIR%\license-public-key.xml" >nul
if not exist "%APPDIR%\icons" mkdir "%APPDIR%\icons"
xcopy /e /i /y "payload\icons\*" "%APPDIR%\icons\" >nul
if exist "payload\AI" (if not exist "%APPDIR%\AI" mkdir "%APPDIR%\AI" & xcopy /e /i /d /y "payload\AI\*" "%APPDIR%\AI\" >nul)
del /q "%APPDIR%\Launch-ScreenshotTool.vbs" >nul 2>&1
if exist "%CSC%" (
 "%CSC%" /nologo /target:winexe /optimize+ /out:"%APPDIR%\RAQEB.exe" /win32icon:"payload\aghrab.ico" /reference:System.dll /reference:System.Windows.Forms.dll "RAQEB-Launcher.cs"
)
del /q "%DESKTOP%\AGHRAB Sentinel Pro.lnk" >nul 2>&1
del /q "%STARTMENU%\AGHRAB Sentinel Pro.lnk" >nul 2>&1
del /q "%DESKTOP%\RAQEB Sentinel Pro.lnk" >nul 2>&1
del /q "%STARTMENU%\RAQEB Sentinel Pro.lnk" >nul 2>&1
if exist "%APPDIR%\RAQEB.exe" (
 powershell.exe -NoProfile -ExecutionPolicy RemoteSigned -Command "$ws=New-Object -ComObject WScript.Shell;$d=[Environment]::GetFolderPath('Desktop')+'\RAQEB Sentinel Pro.lnk';$s=$ws.CreateShortcut($d);$s.TargetPath='%APPDIR%\RAQEB.exe';$s.WorkingDirectory='%APPDIR%';$s.IconLocation='%APPDIR%\aghrab.ico,0';$s.Save();$m=$env:APPDATA+'\Microsoft\Windows\Start Menu\Programs\RAQEB Sentinel Pro.lnk';$s2=$ws.CreateShortcut($m);$s2.TargetPath='%APPDIR%\RAQEB.exe';$s2.WorkingDirectory='%APPDIR%';$s2.IconLocation='%APPDIR%\aghrab.ico,0';$s2.Save()"
 start "" "%APPDIR%\RAQEB.exe"
) else (
 echo WARNING: Native launcher could not be compiled.
 start "" powershell.exe -NoProfile -ExecutionPolicy RemoteSigned -File "%APPDIR%\Start-AGHRAB.ps1"
)

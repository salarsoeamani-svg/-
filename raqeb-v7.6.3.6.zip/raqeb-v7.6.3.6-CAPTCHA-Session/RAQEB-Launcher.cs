using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;
internal static class RaqebLauncher {
 [STAThread] static void Main() {
  try {
   string baseDir=AppDomain.CurrentDomain.BaseDirectory;
   string script=Path.Combine(baseDir,"Start-AGHRAB.ps1");
   if(!File.Exists(script)){MessageBox.Show("RAQEB could not start.\r\n\r\nStart-AGHRAB.ps1 was not found.","RAQEB Startup Error",MessageBoxButtons.OK,MessageBoxIcon.Error);return;}
   string ps=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System),@"WindowsPowerShell\v1.0\powershell.exe");
   if(!File.Exists(ps)) ps="powershell.exe";
   ProcessStartInfo psi=new ProcessStartInfo();
   psi.FileName=ps;
   psi.Arguments="-NoProfile -ExecutionPolicy RemoteSigned -File \""+script+"\"";
   psi.WorkingDirectory=baseDir;
   psi.UseShellExecute=false;
   psi.CreateNoWindow=true;
   psi.WindowStyle=ProcessWindowStyle.Hidden;
   Process.Start(psi);
  } catch(Exception ex){MessageBox.Show("RAQEB could not start.\r\n\r\n"+ex.Message,"RAQEB Startup Error",MessageBoxButtons.OK,MessageBoxIcon.Error);}
 }
}

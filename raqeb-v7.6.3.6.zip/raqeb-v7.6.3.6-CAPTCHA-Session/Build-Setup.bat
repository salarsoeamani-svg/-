@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Build RAQEB Sentinel Pro Setup
echo =========================================
echo   RAQEB Sentinel Pro Setup Builder
echo =========================================
echo Payloads are standard .NET resources, not Base64 strings.
set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%CSC%" (echo ERROR: .NET Framework C# compiler not found.& pause & exit /b 1)
if exist "payload\RAQEB.exe" del /q "payload\RAQEB.exe"
if exist "RAQEB-Setup.exe" del /q "RAQEB-Setup.exe"
echo [1/2] Building native launcher...
"%CSC%" /nologo /target:winexe /optimize+ /out:"payload\RAQEB.exe" /win32icon:"payload\aghrab.ico" /reference:System.dll /reference:System.Windows.Forms.dll "RAQEB-Launcher.cs"
if errorlevel 1 (echo LAUNCHER BUILD FAILED.& pause & exit /b 1)
echo [2/2] Building installer...
"%CSC%" /nologo /target:winexe /optimize+ /out:"RAQEB-Setup.exe" /win32icon:"payload\aghrab.ico" /reference:System.dll /reference:System.Drawing.dll /reference:System.Windows.Forms.dll /reference:Microsoft.CSharp.dll /resource:"payload\ScreenshotTool.ps1",ScreenshotTool.ps1 /resource:"payload\Start-AGHRAB.ps1",Start-AGHRAB.ps1 /resource:"payload\RAQEB.exe",RAQEB.exe /resource:"payload\Uninstall.ps1",Uninstall.ps1 /resource:"payload\aghrab.ico",aghrab.ico /resource:"payload\aghrab-icon.png",aghrab-icon.png /resource:"payload\license-public-key.xml",license-public-key.xml "aghrab-Setup.cs"
if errorlevel 1 (echo SETUP BUILD FAILED.& pause & exit /b 1)
echo Setup created: %CD%\RAQEB-Setup.exe
echo Recommended: Security-Preflight-Defender.bat
pause

﻿$AppName = "RAQEB Sentinel Pro"
$AppId = "aghrab"
$AppDir = Join-Path $env:LOCALAPPDATA "Programs\aghrab"
$Desktop = [Environment]::GetFolderPath("Desktop")
$StartMenu = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs"

foreach ($shortcut in @(
    (Join-Path $Desktop "RAQEB Sentinel Pro.lnk"),
    (Join-Path $StartMenu "RAQEB Sentinel Pro.lnk"),
    (Join-Path $Desktop "AGHRAB Sentinel Pro.lnk"),
    (Join-Path $Desktop "aghrab.lnk"),
    (Join-Path $StartMenu "AGHRAB Sentinel Pro.lnk"),
    (Join-Path $StartMenu "aghrab.lnk")
)) {
    Remove-Item -LiteralPath $shortcut -Force -ErrorAction SilentlyContinue
}

Remove-Item `
    -LiteralPath "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\$AppId" `
    -Recurse `
    -Force `
    -ErrorAction SilentlyContinue

Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.MessageBox]::Show(
    "RAQEB Sentinel Pro was uninstalled.`r`n`r`n" +
    "Customer data was preserved:`r`n" +
    "- ELK profiles and dashboard definitions`r`n" +
    "- Application settings`r`n" +
    "- License / Trial state`r`n" +
    "- Security and health history`r`n" +
    "- Gallery files stored outside the application folder`r`n`r`n" +
    "A future installation can reuse the preserved configuration.",
    "RAQEB Uninstall",
    [System.Windows.Forms.MessageBoxButtons]::OK,
    [System.Windows.Forms.MessageBoxIcon]::Information
) | Out-Null

$cmd = 'ping 127.0.0.1 -n 3 >nul & rmdir /s /q "' + $AppDir + '"'
Start-Process -FilePath "cmd.exe" -WindowStyle Hidden -ArgumentList "/c",$cmd

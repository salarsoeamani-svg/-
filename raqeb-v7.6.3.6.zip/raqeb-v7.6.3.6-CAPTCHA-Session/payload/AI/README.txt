aghrab Built-in AI Pack

Expected files:

AI\runtime\llama-server.exe
AI\runtime\<the DLL files included with llama.cpp Windows CPU build>

AI\models\Qwen2.5-VL-3B-Instruct-Q4_K_M.gguf
AI\models\mmproj-Qwen2.5-VL-3B-Instruct-Q8_0.gguf

Recommended machine profile:
- Windows x64
- 16 GB RAM
- CPU mode
- No Python required

Use Prepare-AI-Pack.bat from the package root on a Windows PC with Internet access.
After it finishes, copy the whole aghrab folder to the offline target.

The AI model is not included in this small preview ZIP because the two model files
alone are about 2.8 GB.

﻿$ErrorActionPreference = "Stop"

$base = Split-Path -Parent $MyInvocation.MyCommand.Path
$app = Join-Path $base "ScreenshotTool.ps1"
$log = Join-Path $base "aghrab-startup-error.log"

function Write-StartupFailure {
    param(
        [string]$Message,
        [string]$Detail
    )

    $report = @(
        "RAQEB startup failed."
        ""
        "Time: " + (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
        "Message: " + $Message
        ""
        $Detail
    ) -join "`r`n"

    try {
        $report | Set-Content -LiteralPath $log -Encoding UTF8 -Force
    } catch {}

    try {
        Add-Type -AssemblyName System.Windows.Forms
        [System.Windows.Forms.MessageBox]::Show(
            "RAQEB could not start.`r`n`r`n" +
            $Message +
            "`r`n`r`nDiagnostic file:`r`n" +
            $log,
            "RAQEB Startup Error",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    } catch {}
}

try {
    if (Test-Path -LiteralPath $log -PathType Leaf) {
        Remove-Item -LiteralPath $log -Force -ErrorAction SilentlyContinue
    }

    if (-not (Test-Path -LiteralPath $app -PathType Leaf)) {
        throw "ScreenshotTool.ps1 was not found."
    }

    $tokens = $null
    $parseErrors = $null

    [void][System.Management.Automation.Language.Parser]::ParseFile(
        $app,
        [ref]$tokens,
        [ref]$parseErrors
    )

    if ($null -ne $parseErrors -and $parseErrors.Count -gt 0) {
        $max = [Math]::Min(8, $parseErrors.Count)
        $items = @()

        for ($i = 0; $i -lt $max; $i++) {
            $err = $parseErrors[$i]
            $items += (
                "Line " + [string]$err.Extent.StartLineNumber +
                ", Char " + [string]$err.Extent.StartColumnNumber +
                ": " + [string]$err.Message
            )
        }

        $firstParserError = [string]$items[0]

        Write-StartupFailure `
            -Message ("PowerShell syntax validation failed.`r`n" + $firstParserError) `
            -Detail ("PowerShell parser errors:`r`n" + ($items -join "`r`n"))

        exit 1
    }

    & $app
}
catch {
    $detail = @(
        "Category: " + [string]$_.CategoryInfo
        "Position: " + [string]$_.InvocationInfo.PositionMessage
        "Line: " + [string]$_.InvocationInfo.ScriptLineNumber
        "Offset: " + [string]$_.InvocationInfo.OffsetInLine
        ""
        "ScriptStackTrace:"
        [string]$_.ScriptStackTrace
    ) -join "`r`n"

    Write-StartupFailure `
        -Message ([string]$_.Exception.Message) `
        -Detail $detail
}

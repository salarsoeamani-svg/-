﻿
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# v7.0.4 compatibility:
# Use the native WinForms ProgressBar instead of compiling a custom C# control.
# This removes dependency on CodeDOM compiler references/versions.

[System.Windows.Forms.Application]::EnableVisualStyles()

$AppName = "RAQEB Sentinel Pro"
$AppVersion = "7.6.3.6"
$BaseDir = $PSScriptRoot

# Runtime state
$script:StopRequested = $false
$script:CurrentProcess = $null
$script:CsvReportPath = $null
$script:CaptureBusy = $false

# Automatic Capture / Health Center runtime state
$script:SchedulerBusy = $false
$script:SchedulerNextRun = $null
$script:SchedulerLastRun = $null
$script:SchedulerLastSummary = ""
$script:SchedulerLastSuccess = 0
$script:SchedulerLastPartial = 0
$script:SchedulerLastFailed = 0

# Health Center Dashboard Manager
$script:LoadingHealthManagerUi = $false
$script:HealthViewMode = "Cards"

# Field Intelligence editor state (saved inside each ELK profile)
$script:EditorFieldVerifyEnabled = $false
$script:EditorElasticsearchUrl = ""
$script:EditorFieldVerifyApiKeyProtected = ""
$script:EditorFieldVerifyTimeField = "@timestamp"
$script:EditorFieldVerifyWindowMinutes = 15
$script:EditorFieldVerifyIgnoreTls = $true
$script:LoadingElkProfileEditor = $false

# Live authenticated ELK/Kibana browser session.
# This is required for SSO/Keycloak environments where session cookies
# may not survive closing the interactive browser.
$script:ElkLivePort = 0
$script:ElkLiveProfileName = $null
$script:ElkLiveProcess = $null
$script:ElkLiveProfileDir = $null
$script:ElkLiveIsTemporaryProfile = $false
$script:ElkCaptchaPending = $false
$script:ElkCaptchaPendingMode = $null
$script:ElkCaptchaPendingProfileName = ""
$script:ElkCaptchaPendingDashboardName = ""
$script:ElkCaptchaPendingSince = $null
$script:SkipNextAutoLogin = $false

# Built-in local AI runtime state
$script:AiProcess = $null
$script:AiPort = 0
$script:AiBaseUrl = $null
$script:AiModelName = "Qwen2.5-VL-3B-Instruct Q4_K_M"
$script:AiIntegrityVerified = $false
$script:AiIntegrityLegacyWarningShown = $false

function Get-InstalledBrowserPath {
    $candidates = New-Object System.Collections.Generic.List[string]
    $pf = $env:ProgramFiles
    $pfx86 = ${env:ProgramFiles(x86)}
    $local = $env:LOCALAPPDATA

    if ($pf) {
        $candidates.Add((Join-Path $pf "Microsoft\Edge\Application\msedge.exe"))
        $candidates.Add((Join-Path $pf "Google\Chrome\Application\chrome.exe"))
        $candidates.Add((Join-Path $pf "BraveSoftware\Brave-Browser\Application\brave.exe"))
        $candidates.Add((Join-Path $pf "Chromium\Application\chrome.exe"))
    }
    if ($pfx86) {
        $candidates.Add((Join-Path $pfx86 "Microsoft\Edge\Application\msedge.exe"))
        $candidates.Add((Join-Path $pfx86 "Google\Chrome\Application\chrome.exe"))
        $candidates.Add((Join-Path $pfx86 "BraveSoftware\Brave-Browser\Application\brave.exe"))
        $candidates.Add((Join-Path $pfx86 "Chromium\Application\chrome.exe"))
    }
    if ($local) {
        $candidates.Add((Join-Path $local "Microsoft\Edge\Application\msedge.exe"))
        $candidates.Add((Join-Path $local "Google\Chrome\Application\chrome.exe"))
        $candidates.Add((Join-Path $local "BraveSoftware\Brave-Browser\Application\brave.exe"))
        $candidates.Add((Join-Path $local "Chromium\Application\chrome.exe"))
    }

    foreach ($path in $candidates) {
        if ($path -and (Test-Path -LiteralPath $path -PathType Leaf)) { return $path }
    }

    $registryKeys = @(
        "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe",
        "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe",
        "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe",
        "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe"
    )

    foreach ($key in $registryKeys) {
        try {
            if (Test-Path $key) {
                $value = (Get-Item $key).GetValue("")
                if ($value -and (Test-Path -LiteralPath $value)) { return $value }
            }
        } catch {}
    }

    foreach ($cmd in @("msedge.exe","chrome.exe","brave.exe","chromium.exe")) {
        try {
            $found = Get-Command $cmd -ErrorAction SilentlyContinue
            if ($found -and $found.Source -and (Test-Path $found.Source)) { return $found.Source }
        } catch {}
    }
    return $null
}

function Get-BrowserName([string]$path) {
    if ([string]::IsNullOrWhiteSpace($path)) { return "Unknown" }
    switch ([System.IO.Path]::GetFileName($path).ToLowerInvariant()) {
        "msedge.exe" { return "Microsoft Edge" }
        "chrome.exe" { return "Google Chrome / Chromium" }
        "brave.exe" { return "Brave" }
        default { return [System.IO.Path]::GetFileName($path) }
    }
}

function Safe-UrlFolderName([string]$url) {
    try {
        $uri = [System.Uri]$url
        $name = $uri.Scheme + "_" + $uri.Host

        if ($uri.Port -ne -1 -and $uri.Port -notin @(80,443)) {
            $name += "_" + $uri.Port
        }

        if ($uri.AbsolutePath -and $uri.AbsolutePath -ne "/") {
            $name += "_" + $uri.AbsolutePath.Trim("/")
        }

        if ($uri.Query) {
            $name += "_" + $uri.Query.TrimStart("?")
        }
    } catch {
        $name = $url
    }

    $name = $name -replace '[\\/:*?"<>|&=;%+# ]', '_'
    $name = $name -replace '_+', '_'
    $name = $name.Trim('_')

    if ([string]::IsNullOrWhiteSpace($name)) {
        $name = "url"
    }

    if ($name.Length -gt 110) {
        $sha = [System.Security.Cryptography.SHA256]::Create()
        try {
            $bytes = [System.Text.Encoding]::UTF8.GetBytes($url)
            $hashBytes = $sha.ComputeHash($bytes)
            $hash = ([System.BitConverter]::ToString($hashBytes)).Replace("-", "").Substring(0, 8)
        } finally {
            $sha.Dispose()
        }

        $name = $name.Substring(0, 100).TrimEnd("_") + "_" + $hash
    }

    return $name
}

function Write-CsvReportRow {
    param(
        [string]$Url,
        [string]$Status,
        [string]$ScreenshotPath,
        [string]$Browser,
        [string]$Detail
    )

    if ([string]::IsNullOrWhiteSpace($script:CsvReportPath)) {
        return
    }

    try {
        $row = [PSCustomObject]@{
            Timestamp      = (Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff")
            URL            = (Redact-SensitiveText -Text $Url)
            Status         = $Status
            ScreenshotPath = $ScreenshotPath
            Browser        = $Browser
            Detail         = (Redact-SensitiveText -Text $Detail)
        }

        if (Test-Path -LiteralPath $script:CsvReportPath) {
            $row | Export-Csv -LiteralPath $script:CsvReportPath -NoTypeInformation -Encoding UTF8 -Append
        } else {
            $row | Export-Csv -LiteralPath $script:CsvReportPath -NoTypeInformation -Encoding UTF8
        }
    } catch {
        try {
            $txtLog.AppendText("  WARNING -> CSV report could not be updated: $($_.Exception.Message)`r`n")
        } catch {}
    }
}


# ---------------- Full-page / Chrome DevTools helpers ----------------
$script:CdpMessageId = 0

function Get-FreeTcpPort {
    $listener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, 0)
    try {
        $listener.Start()
        return ([System.Net.IPEndPoint]$listener.LocalEndpoint).Port
    } finally {
        try { $listener.Stop() } catch {}
    }
}

function Wait-TaskResponsive {
    param(
        $Task,
        [int]$TimeoutMs = 30000
    )

    $sw = [System.Diagnostics.Stopwatch]::StartNew()

    while (-not $Task.IsCompleted) {
        [System.Windows.Forms.Application]::DoEvents()

        if ($script:StopRequested) {
            throw "Stopped by user"
        }

        if ($sw.ElapsedMilliseconds -ge $TimeoutMs) {
            throw "Operation timed out"
        }

        Start-Sleep -Milliseconds 40
    }

    if ($Task.IsCanceled) {
        throw "Operation was cancelled"
    }

    if ($Task.IsFaulted) {
        throw $Task.Exception.GetBaseException()
    }

    return $Task
}

function Receive-CdpMessage {
    param(
        [System.Net.WebSockets.ClientWebSocket]$WebSocket,
        [int]$TimeoutMs = 30000
    )

    $buffer = New-Object byte[] 65536
    $stream = New-Object System.IO.MemoryStream

    try {
        do {
            $segment = New-Object 'System.ArraySegment[byte]' -ArgumentList (,$buffer)
            $task = $WebSocket.ReceiveAsync(
                $segment,
                [System.Threading.CancellationToken]::None
            )

            [void](Wait-TaskResponsive -Task $task -TimeoutMs $TimeoutMs)
            $result = $task.Result

            if ($result.MessageType -eq [System.Net.WebSockets.WebSocketMessageType]::Close) {
                throw "Browser DevTools connection was closed"
            }

            $stream.Write($buffer, 0, $result.Count)
        } while (-not $result.EndOfMessage)

        return [System.Text.Encoding]::UTF8.GetString($stream.ToArray())
    } finally {
        $stream.Dispose()
    }
}

function Invoke-CdpCommand {
    param(
        [System.Net.WebSockets.ClientWebSocket]$WebSocket,
        [string]$Method,
        [hashtable]$Params = @{},
        [int]$TimeoutMs = 30000
    )

    $script:CdpMessageId++
    $id = $script:CdpMessageId

    $payload = @{
        id = $id
        method = $Method
        params = $Params
    } | ConvertTo-Json -Depth 20 -Compress

    $bytes = [System.Text.Encoding]::UTF8.GetBytes($payload)
    $segment = New-Object 'System.ArraySegment[byte]' -ArgumentList (,$bytes)

    $sendTask = $WebSocket.SendAsync(
        $segment,
        [System.Net.WebSockets.WebSocketMessageType]::Text,
        $true,
        [System.Threading.CancellationToken]::None
    )
    [void](Wait-TaskResponsive -Task $sendTask -TimeoutMs $TimeoutMs)

    while ($true) {
        $message = Receive-CdpMessage -WebSocket $WebSocket -TimeoutMs $TimeoutMs
        $obj = $message | ConvertFrom-Json

        if ($null -ne $obj.id -and [int]$obj.id -eq $id) {
            if ($null -ne $obj.error) {
                throw ("CDP error: " + ($obj.error | ConvertTo-Json -Compress))
            }
            return $obj
        }
    }
}

function Get-CdpPageTarget {
    param(
        [int]$Port,
        [int]$TimeoutMs = 30000
    )

    $sw = [System.Diagnostics.Stopwatch]::StartNew()

    while ($sw.ElapsedMilliseconds -lt $TimeoutMs) {
        [System.Windows.Forms.Application]::DoEvents()

        if ($script:StopRequested) {
            throw "Stopped by user"
        }

        try {
            $targets = Invoke-RestMethod -Uri ("http://127.0.0.1:{0}/json/list" -f $Port) -TimeoutSec 1
            $page = $targets |
                Where-Object { $_.type -eq "page" -and $_.webSocketDebuggerUrl } |
                Select-Object -First 1

            if ($page) {
                return $page
            }
        } catch {}

        Start-Sleep -Milliseconds 100
    }

    throw "Could not connect to browser DevTools"
}

function Capture-FullPageScreenshot {
    param(
        [string]$Browser,
        [string]$Url,
        [string]$File,
        [string]$ProfileDir,
        [int]$Width,
        [int]$Height,
        [bool]$IgnoreCertificateErrors,
        [int]$WaitAfterLoadMs,
        [int]$ScrollDelayMs,
        [int]$FinalSettleMs,
        [int]$TimeoutMs
    )

    $port = Get-FreeTcpPort

    $args = New-Object System.Collections.Generic.List[string]
    $args.Add("--headless=new")
    $args.Add("--disable-gpu")
    $args.Add("--hide-scrollbars")
    $args.Add("--no-first-run")
    $args.Add("--no-default-browser-check")
    $args.Add("--disable-extensions")
    $args.Add("--disable-background-networking")
    $args.Add("--disable-component-update")
    $args.Add("--remote-debugging-address=127.0.0.1")
    $args.Add("--remote-debugging-port=$port")
    $args.Add("--window-size=$Width,$Height")
    $args.Add('--user-data-dir="' + $ProfileDir + '"')

    if ($IgnoreCertificateErrors) {
        $args.Add("--ignore-certificate-errors")
        $args.Add("--allow-insecure-localhost")
    }

    $args.Add($Url)

    $ws = $null
    $p = $null

    try {
        $p = Start-Process -FilePath $Browser -ArgumentList $args.ToArray() -PassThru -WindowStyle Hidden
        $script:CurrentProcess = $p

        $target = Get-CdpPageTarget -Port $port -TimeoutMs $TimeoutMs

        $ws = New-Object System.Net.WebSockets.ClientWebSocket
        $connectTask = $ws.ConnectAsync(
            [System.Uri]$target.webSocketDebuggerUrl,
            [System.Threading.CancellationToken]::None
        )
        [void](Wait-TaskResponsive -Task $connectTask -TimeoutMs $TimeoutMs)

        [void](Invoke-CdpCommand -WebSocket $ws -Method "Page.enable" -Params @{} -TimeoutMs $TimeoutMs)
        [void](Invoke-CdpCommand -WebSocket $ws -Method "Runtime.enable" -Params @{} -TimeoutMs $TimeoutMs)

        $readyWatch = [System.Diagnostics.Stopwatch]::StartNew()
        while ($readyWatch.ElapsedMilliseconds -lt $TimeoutMs) {
            [System.Windows.Forms.Application]::DoEvents()

            if ($script:StopRequested) {
                throw "Stopped by user"
            }

            try {
                $ready = Invoke-CdpCommand -WebSocket $ws -Method "Runtime.evaluate" -Params @{
                    expression = "document.readyState"
                    returnByValue = $true
                } -TimeoutMs 3000

                if ($ready.result.result.value -eq "complete") {
                    break
                }
            } catch {}

            Start-Sleep -Milliseconds 120
        }

        # document.readyState can be complete while SPA/API content is still
        # rendering. Wait real time before auto-scroll.
        if ($WaitAfterLoadMs -gt 0) {
            $loadWait = [System.Diagnostics.Stopwatch]::StartNew()

            while ($loadWait.ElapsedMilliseconds -lt $WaitAfterLoadMs) {
                [System.Windows.Forms.Application]::DoEvents()

                if ($script:StopRequested) {
                    throw "Stopped by user"
                }

                Start-Sleep -Milliseconds 100
            }
        }

        $scrollScript = @'
(async () => {
    const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
    const scrollDelay = __SCROLL_DELAY__;
    const finalSettle = __FINAL_SETTLE__;
    let lastY = -1;
    let stableBottomCount = 0;

    for (let i = 0; i < 120; i++) {
        const doc = document.documentElement;
        const body = document.body;
        const total = Math.max(
            doc ? doc.scrollHeight : 0,
            body ? body.scrollHeight : 0
        );
        const maxY = Math.max(0, total - window.innerHeight);

        if (window.scrollY >= maxY - 5) {
            stableBottomCount++;
            await sleep(300);

            const newTotal = Math.max(
                document.documentElement ? document.documentElement.scrollHeight : 0,
                document.body ? document.body.scrollHeight : 0
            );
            const newMaxY = Math.max(0, newTotal - window.innerHeight);

            if (stableBottomCount >= 2 && newMaxY <= maxY + 5) {
                break;
            }
        } else {
            stableBottomCount = 0;
        }

        const step = Math.max(450, Math.floor(window.innerHeight * 0.85));
        window.scrollBy(0, step);
        await sleep(scrollDelay);

        if (window.scrollY === lastY && window.scrollY >= maxY - 5) {
            break;
        }

        lastY = window.scrollY;
    }

    await sleep(finalSettle);
    window.scrollTo(0, 0);
    await sleep(Math.max(500, Math.floor(finalSettle / 2)));

    return {
        width: Math.max(
            document.documentElement ? document.documentElement.scrollWidth : 0,
            document.body ? document.body.scrollWidth : 0
        ),
        height: Math.max(
            document.documentElement ? document.documentElement.scrollHeight : 0,
            document.body ? document.body.scrollHeight : 0
        )
    };
})()
'@

        $scrollScript = $scrollScript.Replace("__SCROLL_DELAY__", [string]$ScrollDelayMs)
        $scrollScript = $scrollScript.Replace("__FINAL_SETTLE__", [string]$FinalSettleMs)

        [void](Invoke-CdpCommand -WebSocket $ws -Method "Runtime.evaluate" -Params @{
            expression = $scrollScript
            awaitPromise = $true
            returnByValue = $true
        } -TimeoutMs $TimeoutMs)

        $metrics = Invoke-CdpCommand -WebSocket $ws -Method "Page.getLayoutMetrics" -Params @{} -TimeoutMs $TimeoutMs

        $reportedWidth = [Math]::Ceiling([double]$metrics.result.contentSize.width)
        $reportedHeight = [Math]::Ceiling([double]$metrics.result.contentSize.height)

        # Prevent off-screen/fixed elements from making an abnormally wide PNG.
        $contentWidth = $Width
        $contentHeight = $reportedHeight

        if ($contentHeight -lt $Height) { $contentHeight = $Height }
        if ($contentHeight -gt 50000) { $contentHeight = 50000 }

        $shot = Invoke-CdpCommand -WebSocket $ws -Method "Page.captureScreenshot" -Params @{
            format = "png"
            fromSurface = $true
            captureBeyondViewport = $true
            clip = @{
                x = 0
                y = 0
                width = $contentWidth
                height = $contentHeight
                scale = 1
            }
        } -TimeoutMs $TimeoutMs

        $data = [string]$shot.result.data

        if ([string]::IsNullOrWhiteSpace($data)) {
            throw "Browser returned an empty screenshot"
        }

        [System.IO.File]::WriteAllBytes(
            $File,
            [System.Convert]::FromBase64String($data)
        )

        return @{
            Width = $contentWidth
            Height = $contentHeight
        }
    } finally {
        if ($ws -ne $null) {
            try {
                if ($ws.State -eq [System.Net.WebSockets.WebSocketState]::Open) {
                    $closeTask = $ws.CloseAsync(
                        [System.Net.WebSockets.WebSocketCloseStatus]::NormalClosure,
                        "done",
                        [System.Threading.CancellationToken]::None
                    )
                    try { [void](Wait-TaskResponsive -Task $closeTask -TimeoutMs 1500) } catch {}
                }
            } catch {}

            try { $ws.Dispose() } catch {}
        }

        if ($p -ne $null) {
            try {
                if (-not $p.HasExited) {
                    $p.Kill()
                }
            } catch {}
        }

        $script:CurrentProcess = $null
    }
}


# ---------------- Live authenticated ELK browser session ----------------
function Wait-DevToolsActivePort {
    param(
        [string]$ProfileDir,
        [int]$TimeoutMs = 20000
    )

    $activePortFile = Join-Path $ProfileDir "DevToolsActivePort"
    $sw = [System.Diagnostics.Stopwatch]::StartNew()

    while ($sw.ElapsedMilliseconds -lt $TimeoutMs) {
        [System.Windows.Forms.Application]::DoEvents()

        if ($script:StopRequested) {
            throw "Stopped by user"
        }

        if (Test-Path -LiteralPath $activePortFile -PathType Leaf) {
            try {
                $lines = @(Get-Content -LiteralPath $activePortFile -ErrorAction Stop)

                if ($lines.Count -ge 1) {
                    $port = 0

                    if ([int]::TryParse([string]$lines[0], [ref]$port) -and $port -gt 0) {
                        $null = Get-CdpPageTarget -Port $port -TimeoutMs 3000
                        return $port
                    }
                }
            } catch {}
        }

        Start-Sleep -Milliseconds 100
    }

    throw "Browser started, but DevToolsActivePort was not created."
}

function Test-ElkLiveSession {
    param([string]$ProfileName)

    if ($script:ElkLivePort -le 0) {
        return $false
    }

    if ([string]::IsNullOrWhiteSpace($script:ElkLiveProfileName)) {
        return $false
    }

    if ($script:ElkLiveProfileName -ne $ProfileName) {
        return $false
    }

    try {
        $null = Get-CdpPageTarget -Port $script:ElkLivePort -TimeoutMs 1200
        return $true
    } catch {
        return $false
    }
}

function Close-ElkLiveSession {
    if ($script:ElkLivePort -gt 0) {
        $ws = $null

        try {
            $target = Get-CdpPageTarget -Port $script:ElkLivePort -TimeoutMs 1500

            $ws = New-Object System.Net.WebSockets.ClientWebSocket
            $connectTask = $ws.ConnectAsync(
                [System.Uri]$target.webSocketDebuggerUrl,
                [System.Threading.CancellationToken]::None
            )
            [void](Wait-TaskResponsive -Task $connectTask -TimeoutMs 2000)

            try {
                [void](Invoke-CdpCommand `
                    -WebSocket $ws `
                    -Method "Browser.close" `
                    -Params @{} `
                    -TimeoutMs 2000)
            } catch {}
        } catch {}

        if ($ws -ne $null) {
            try { $ws.Dispose() } catch {}
        }
    }

    if ($script:ElkLiveProcess -ne $null) {
        try {
            if (-not $script:ElkLiveProcess.HasExited) {
                $script:ElkLiveProcess.Kill()
            }
        } catch {}
    }

    $tempProfileDir = $script:ElkLiveProfileDir
    $wasTemporary = [bool]$script:ElkLiveIsTemporaryProfile

    $script:ElkLivePort = 0
    $script:ElkLiveProfileName = $null
    $script:ElkLiveProcess = $null
    $script:ElkLiveProfileDir = $null
    $script:ElkLiveIsTemporaryProfile = $false
    $script:ElkCaptchaPending = $false
    $script:ElkCaptchaPendingMode = $null
    $script:ElkCaptchaPendingProfileName = ""
    $script:ElkCaptchaPendingDashboardName = ""
    $script:ElkCaptchaPendingSince = $null
    $script:SkipNextAutoLogin = $false

    if ($wasTemporary -and -not [string]::IsNullOrWhiteSpace($tempProfileDir)) {
        try {
            Start-Sleep -Milliseconds 300
            Remove-Item -LiteralPath $tempProfileDir -Recurse -Force -ErrorAction SilentlyContinue
        } catch {}
    }
}

function Start-ElkLiveSession {
    param(
        [string]$Browser,
        $Profile
    )

    if (Test-ElkLiveSession -ProfileName ([string]$Profile.Name)) {
        return [PSCustomObject]@{
            Port = $script:ElkLivePort
            AlreadyRunning = $true
            ProfileDir = $script:ElkLiveProfileDir
        }
    }

    Close-ElkLiveSession

    # Persistent browser storage per ELK profile. Cookies/session are reused
    # until the target site expires them. CAPTCHA is never bypassed.
    $useTemporaryProfile = $false
    $profileDir = Get-ElkBrowserProfileDir -ProfileName ([string]$Profile.Name)

    $args = @(
        '--user-data-dir="' + $profileDir + '"',
        "--remote-debugging-address=127.0.0.1",
        "--remote-debugging-port=0",
        "--ignore-certificate-errors",
        "--allow-insecure-localhost",
        "--no-first-run",
        "--no-default-browser-check",
        "--disable-default-apps",
        "--disable-popup-blocking",
        "--new-window",
        [string]$Profile.KibanaUrl
    )

    $p = Start-Process `
        -FilePath $Browser `
        -ArgumentList $args `
        -PassThru

    try {
        $port = Wait-DevToolsActivePort -ProfileDir $profileDir -TimeoutMs 20000
    }
    catch {
        try {
            if ($p -and -not $p.HasExited) {
                $p.Kill()
            }
        } catch {}

        if ($useTemporaryProfile) {
            try {
                Remove-Item -LiteralPath $profileDir -Recurse -Force -ErrorAction SilentlyContinue
            } catch {}
        }

        throw (
            "Could not connect to browser DevTools. " +
            "Browser: " + $Browser + ". " +
            $_.Exception.Message
        )
    }

    $script:ElkLivePort = $port
    $script:ElkLiveProfileName = [string]$Profile.Name
    $script:ElkLiveProcess = $p
    $script:ElkLiveProfileDir = $profileDir
    $script:ElkLiveIsTemporaryProfile = $useTemporaryProfile

    Write-SecurityAudit `
        -Action "BROWSER_SESSION_OPEN" `
        -Detail ("Profile=" + [string]$Profile.Name + "; Local DevTools port=" + $port)

    return [PSCustomObject]@{
        Port = $port
        AlreadyRunning = $false
        ProfileDir = $profileDir
    }
}


function Open-ElkLiveWebSocket {
    param(
        [int]$Port,
        [int]$TimeoutMs = 10000
    )

    $target = Get-CdpPageTarget -Port $Port -TimeoutMs $TimeoutMs

    $ws = New-Object System.Net.WebSockets.ClientWebSocket
    $connectTask = $ws.ConnectAsync(
        [System.Uri]$target.webSocketDebuggerUrl,
        [System.Threading.CancellationToken]::None
    )
    [void](Wait-TaskResponsive -Task $connectTask -TimeoutMs $TimeoutMs)

    return $ws
}

function Wait-ElkDocumentReady {
    param(
        $WebSocket,
        [int]$TimeoutMs = 15000
    )

    [void](Invoke-CdpCommand -WebSocket $WebSocket -Method "Page.enable" -Params @{} -TimeoutMs $TimeoutMs)
    [void](Invoke-CdpCommand -WebSocket $WebSocket -Method "Runtime.enable" -Params @{} -TimeoutMs $TimeoutMs)

    $sw = [System.Diagnostics.Stopwatch]::StartNew()

    while ($sw.ElapsedMilliseconds -lt $TimeoutMs) {
        [System.Windows.Forms.Application]::DoEvents()

        try {
            $ready = Invoke-CdpCommand `
                -WebSocket $WebSocket `
                -Method "Runtime.evaluate" `
                -Params @{
                    expression = "document.readyState"
                    returnByValue = $true
                } `
                -TimeoutMs 3000

            if ($ready.result.result.value -eq "complete") {
                return
            }
        } catch {}

        Start-Sleep -Milliseconds 120
    }
}

function Invoke-ElkAutoLoginStep {
    param(
        [int]$Port,
        [string]$Username,
        [string]$Password,
        [bool]$CanSubmitCredentials = $true,
        [bool]$AllowCaptchaSubmit = $false,
        [int]$TimeoutMs = 12000
    )

    $ws = $null

    try {
        $ws = Open-ElkLiveWebSocket -Port $Port -TimeoutMs $TimeoutMs

        [void](Invoke-CdpCommand `
            -WebSocket $ws `
            -Method "Runtime.enable" `
            -Params @{} `
            -TimeoutMs $TimeoutMs)

        $usernameJson = $Username | ConvertTo-Json -Compress
        $passwordJson = $Password | ConvertTo-Json -Compress
        $canSubmitJson = $(if ($CanSubmitCredentials) { "true" } else { "false" })
        $allowCaptchaSubmitJson = $(if ($AllowCaptchaSubmit) { "true" } else { "false" })

        $js = @'
(() => {
  const USERNAME = __USERNAME__;
  const PASSWORD = __PASSWORD__;
  const CAN_SUBMIT = __CAN_SUBMIT__;
  const ALLOW_CAPTCHA_SUBMIT = __ALLOW_CAPTCHA_SUBMIT__;

  const norm = s => (s || '').replace(/\s+/g, ' ').trim().toLowerCase();
  const text = norm(document.body && document.body.innerText ? document.body.innerText : '');
  const href = location.href || '';
  const title = document.title || '';

  const visible = el => {
    if (!el) return false;
    const style = getComputedStyle(el);
    const r = el.getBoundingClientRect();
    return style.display !== 'none' &&
           style.visibility !== 'hidden' &&
           r.width > 0 &&
           r.height > 0;
  };

  const field = selectors => {
    for (const selector of selectors) {
      for (const el of Array.from(document.querySelectorAll(selector))) {
        if (visible(el)) return el;
      }
    }
    return null;
  };

  const userField = field([
    'input[name="username"]',
    '#username',
    'input[autocomplete="username"]',
    'input[name="email"]',
    'input[type="email"]'
  ]) || Array.from(document.querySelectorAll('input[type="text"]')).find(visible);

  const passField = field([
    'input[type="password"]',
    'input[name="password"]',
    '#password'
  ]);

  const captchaNode = document.querySelector(
    'iframe[src*="recaptcha" i],iframe[src*="hcaptcha" i],' +
    '.g-recaptcha,.h-captcha,' +
    'input[name*="captcha" i],input[id*="captcha" i],' +
    'img[src*="captcha" i],img[alt*="captcha" i],' +
    '[class*="captcha" i],[id*="captcha" i]'
  );

  const captchaDetected =
    !!captchaNode ||
    text.includes('captcha') ||
    text.includes('i am not a robot') ||
    text.includes('security code') ||
    text.includes('verification code');

  const errorNodes = Array.from(document.querySelectorAll(
    '[role="alert"],.alert-error,.alert-danger,.pf-m-danger,.pf-c-alert__title,' +
    '.kc-feedback-text,#input-error,.instruction.error,.error-message,' +
    '[aria-invalid="true"]'
  )).filter(visible);

  const feedback = norm(
    errorNodes.map(el =>
      el.innerText ||
      el.textContent ||
      el.getAttribute('aria-label') ||
      ''
    ).join(' ')
  );

  const combined = text + ' ' + feedback;

  const invalidPhrases = [
    'invalid username or password',
    'invalid user name or password',
    'invalid credentials',
    'incorrect username or password',
    'wrong username or password',
    'bad credentials',
    'authentication failed',
    'login failed',
    'sign in failed'
  ];

  const invalid = invalidPhrases.some(p => combined.includes(p));

  if (invalid) {
    return {
      ok: false,
      state: 'invalid-credentials',
      action: 'none',
      feedback,
      href,
      title
    };
  }

  const lowerHref = href.toLowerCase();
  const loginUrl =
    /\/login(\?|$)/.test(lowerHref) ||
    lowerHref.includes('/protocol/openid-connect/') ||
    lowerHref.includes('/auth/realms/');

  const welcomeToElastic = text.includes('welcome to elastic');
  const loginChoice = text.includes('log in with elasticsearch');

  if (!passField && !welcomeToElastic && !loginChoice && !loginUrl) {
    return {
      ok: true,
      state: 'authenticated',
      action: 'none',
      feedback,
      href,
      title
    };
  }

  const buttons = Array.from(
    document.querySelectorAll(
      'button,a,[role="button"],input[type="submit"],input[type="button"],' +
      '[data-test-subj*="saml" i],[data-test-subj*="oidc" i],[data-test-subj*="login" i]'
    )
  ).filter(visible);

  const labelOf = el => norm(
    (el && (
      el.innerText ||
      el.value ||
      el.getAttribute('aria-label') ||
      el.getAttribute('title') ||
      el.getAttribute('data-test-subj') ||
      ''
    )) || ''
  );

  const clickableAncestor = el => {
    if (!el) return null;
    if (el.matches && el.matches('button,a,[role="button"],input[type="submit"],input[type="button"]')) {
      return el;
    }

    let p = el.parentElement;
    for (let i = 0; p && i < 6; i++, p = p.parentElement) {
      if (
        (p.matches && p.matches('button,a,[role="button"]')) ||
        p.tabIndex >= 0 ||
        typeof p.onclick === 'function'
      ) {
        return p;
      }
    }
    return null;
  };

  const findProvider = phrases => {
    // First inspect real controls / Kibana provider controls.
    for (const phrase of phrases) {
      const hit = buttons.find(b => labelOf(b).includes(phrase));
      if (hit) return hit;
    }

    // Some Kibana themes render the provider name inside a nested child.
    // Walk visible text nodes and click the nearest clickable provider card.
    const visibleNodes = Array.from(document.querySelectorAll('body *')).filter(visible);
    for (const phrase of phrases) {
      const node = visibleNodes.find(el => labelOf(el) === phrase || labelOf(el).includes(phrase));
      const hit = clickableAncestor(node);
      if (hit) return hit;
    }

    return null;
  };

  if (!(userField && passField)) {
    // Kibana can render a provider-selection page like:
    //
    //   Keycloak
    //   [ Log in with Elasticsearch ]
    //
    // In that layout "Keycloak" is only the provider/group heading.
    // It is NOT the button that must be clicked. Previous builds could
    // mistake that heading/card for the SSO action and never leave this page.
    //
    // Therefore first prefer the explicit actionable login text.
    const elasticHit = findProvider([
      'log in with elasticsearch',
      'login with elasticsearch',
      'sign in with elasticsearch'
    ]);

    if (elasticHit) {
      try {
        elasticHit.scrollIntoView({ block: 'center', inline: 'center' });
      } catch {}

      const r = elasticHit.getBoundingClientRect();
      const x = r.left + (r.width / 2);
      const y = r.top + (r.height / 2);

      return {
        ok: false,
        state: 'provider-click-required',
        action: 'cdp-click-elasticsearch-login',
        clickX: x,
        clickY: y,
        feedback,
        href,
        title
      };
    }

    // If the page has a REAL clickable Keycloak/SSO control, use it.
    // For the word "keycloak", only inspect actual clickable controls;
    // do not walk generic body text because a non-clickable page heading
    // may also say Keycloak.
    const realKeycloakControl = buttons.find(b =>
      labelOf(b).includes('keycloak')
    );

    if (realKeycloakControl) {
      try {
        realKeycloakControl.scrollIntoView({ block: 'center', inline: 'center' });
      } catch {}

      const r = realKeycloakControl.getBoundingClientRect();

      return {
        ok: false,
        state: 'provider-click-required',
        action: 'cdp-click-keycloak-control',
        clickX: r.left + (r.width / 2),
        clickY: r.top + (r.height / 2),
        feedback,
        href,
        title
      };
    }

    // Other SSO labels are safe to resolve through nested provider-card text.
    const ssoHit = findProvider([
      'single sign-on',
      'single sign on',
      'sso',
      'saml',
      'openid',
      'oidc'
    ]);

    if (ssoHit) {
      try {
        ssoHit.scrollIntoView({ block: 'center', inline: 'center' });
      } catch {}

      const r = ssoHit.getBoundingClientRect();

      return {
        ok: false,
        state: 'provider-click-required',
        action: 'cdp-click-sso-provider',
        clickX: r.left + (r.width / 2),
        clickY: r.top + (r.height / 2),
        feedback,
        href,
        title
      };
    }

    return {
      ok: false,
      state: 'waiting-login-page',
      action: 'no-clickable-login-provider',
      feedback,
      href,
      title
    };
  }

  // CAPTCHA detected on the login form: fill credentials, but pause.
  if (captchaDetected && userField && passField) {
    const setCaptchaFieldValue = (el, value) => {
      const proto = Object.getPrototypeOf(el);
      const desc = Object.getOwnPropertyDescriptor(proto, 'value');
      if (desc && desc.set) desc.set.call(el, value); else el.value = value;
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
    };

    setCaptchaFieldValue(userField, USERNAME);
    setCaptchaFieldValue(passField, PASSWORD);

    if (!ALLOW_CAPTCHA_SUBMIT) {
      return {
        ok: false,
        state: 'captcha-required',
        action: 'paused-for-captcha',
        feedback,
        href,
        title
      };
    }

    try {
      passField.focus({ preventScroll: false });
      if (passField.setSelectionRange) {
        const end = String(passField.value || '').length;
        passField.setSelectionRange(end, end);
      }
    } catch {}

    return {
      ok:false,
      state:'submit-key-required',
      action:'cdp-enter-login-submit-after-captcha',
      feedback,
      href,
      title
    };
  }

  // Credentials have already been submitted once.
  // Do NOT submit again: report that the login form is still present.
  if (!CAN_SUBMIT) {
    return {
      ok: false,
      state: 'login-form-present',
      action: 'none',
      feedback,
      href,
      title
    };
  }

  const setValue = (el, value) => {
    const proto = Object.getPrototypeOf(el);
    const desc = Object.getOwnPropertyDescriptor(proto, 'value');

    if (desc && desc.set) {
      desc.set.call(el, value);
    } else {
      el.value = value;
    }

    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  };

  setValue(userField, USERNAME);
  setValue(passField, PASSWORD);

  // Keycloak reliably submits the form when Enter is pressed while the
  // password field has focus. This is more robust than a coordinate click
  // when Windows DPI scaling / browser zoom / page hit-testing differs.
  try {
    passField.focus({ preventScroll: false });
    if (passField.setSelectionRange) {
      const end = String(passField.value || '').length;
      passField.setSelectionRange(end, end);
    }
  } catch {}

  return {
    ok: false,
    state: 'submit-key-required',
    action: 'cdp-enter-login-submit',
    feedback,
    href,
    title
  };
})()
'@

        $js = $js.Replace("__USERNAME__", $usernameJson)
        $js = $js.Replace("__PASSWORD__", $passwordJson)
        $js = $js.Replace("__CAN_SUBMIT__", $canSubmitJson)
        $js = $js.Replace("__ALLOW_CAPTCHA_SUBMIT__", $allowCaptchaSubmitJson)

        $result = Invoke-CdpCommand `
            -WebSocket $ws `
            -Method "Runtime.evaluate" `
            -Params @{
                expression = $js
                returnByValue = $true
            } `
            -TimeoutMs $TimeoutMs

        $value = $result.result.result.value

        # Synthetic HTMLElement.click() is not reliable for some Kibana/EUI
        # provider cards. Use Chrome DevTools Protocol Input events so the page
        # receives a real trusted mouse click at the center of the control.
        if (
            $null -ne $value -and
            [string]$value.state -in @("provider-click-required","submit-click-required") -and
            $null -ne $value.clickX -and
            $null -ne $value.clickY
        ) {
            $x = [double]$value.clickX
            $y = [double]$value.clickY

            [void](Invoke-CdpCommand `
                -WebSocket $ws `
                -Method "Input.dispatchMouseEvent" `
                -Params @{
                    type = "mouseMoved"
                    x = $x
                    y = $y
                } `
                -TimeoutMs 3000)

            [void](Invoke-CdpCommand `
                -WebSocket $ws `
                -Method "Input.dispatchMouseEvent" `
                -Params @{
                    type = "mousePressed"
                    x = $x
                    y = $y
                    button = "left"
                    clickCount = 1
                } `
                -TimeoutMs 3000)

            [void](Invoke-CdpCommand `
                -WebSocket $ws `
                -Method "Input.dispatchMouseEvent" `
                -Params @{
                    type = "mouseReleased"
                    x = $x
                    y = $y
                    button = "left"
                    clickCount = 1
                } `
                -TimeoutMs 3000)

            if ([string]$value.state -eq "submit-click-required") {
                $value.state = "submitted"
            }
            else {
                $value.state = "redirecting"
            }

            $value.action = ([string]$value.action + "-dispatched")
        }

        if (
            $null -ne $value -and
            [string]$value.state -eq "submit-key-required"
        ) {
            # Real trusted Enter key sent through Chrome DevTools Protocol.
            # The password field was focused inside the page immediately before
            # returning submit-key-required.
            [void](Invoke-CdpCommand `
                -WebSocket $ws `
                -Method "Input.dispatchKeyEvent" `
                -Params @{
                    type = "rawKeyDown"
                    key = "Enter"
                    code = "Enter"
                    windowsVirtualKeyCode = 13
                    nativeVirtualKeyCode = 13
                } `
                -TimeoutMs 3000)

            [void](Invoke-CdpCommand `
                -WebSocket $ws `
                -Method "Input.dispatchKeyEvent" `
                -Params @{
                    type = "char"
                    text = "`r"
                    key = "Enter"
                    code = "Enter"
                    windowsVirtualKeyCode = 13
                    nativeVirtualKeyCode = 13
                } `
                -TimeoutMs 3000)

            [void](Invoke-CdpCommand `
                -WebSocket $ws `
                -Method "Input.dispatchKeyEvent" `
                -Params @{
                    type = "keyUp"
                    key = "Enter"
                    code = "Enter"
                    windowsVirtualKeyCode = 13
                    nativeVirtualKeyCode = 13
                } `
                -TimeoutMs 3000)

            $value.state = "submitted"
            $value.action = ([string]$value.action + "-dispatched")
        }

        return $value
    }
    finally {
        if ($ws -ne $null) {
            try { $ws.Dispose() } catch {}
        }
    }
}

function Ensure-ElkAutoLogin {
    param(
        [int]$Port,
        $Profile,
        [int]$TimeoutMs = 90000,
        [string]$UsernameOverride = "",
        [string]$PasswordOverride = "",
        [switch]$ResumeAfterCaptcha
    )

    $username = $UsernameOverride
    $password = $PasswordOverride

    if ([string]::IsNullOrWhiteSpace($username) -and $null -ne $Profile.Username) {
        $username = [string]$Profile.Username
    }

    if ([string]::IsNullOrWhiteSpace($password)) {
        $password = Get-ElkProfileCredential `
            -Profile $Profile `
            -AllowEditorFallback
    }

    if ([string]::IsNullOrWhiteSpace($username)) {
        throw "Auto Login Username is empty."
    }

    if ([string]::IsNullOrWhiteSpace($password)) {
        throw "Auto Login Password is empty."
    }

    $initialWs = $null

    try {
        $initialWs = Open-ElkLiveWebSocket -Port $Port -TimeoutMs 15000

        try {
            [void](Invoke-CdpCommand `
                -WebSocket $initialWs `
                -Method "Page.enable" `
                -Params @{} `
                -TimeoutMs 5000)
        } catch {}

        try {
            [void](Invoke-CdpCommand `
                -WebSocket $initialWs `
                -Method "Page.navigate" `
                -Params @{ url = [string]$Profile.KibanaUrl } `
                -TimeoutMs 10000)
        }
        catch {
            if (
                $_.Exception.Message -notmatch 'navigated or closed' -and
                $_.Exception.Message -notmatch 'WebSocket'
            ) {
                throw
            }
        }
    }
    finally {
        if ($initialWs -ne $null) {
            try { $initialWs.Dispose() } catch {}
        }
    }

    Start-Sleep -Milliseconds 800

    $watch = [System.Diagnostics.Stopwatch]::StartNew()
    $lastState = "starting"
    $lastHref = ""
    $lastFeedback = ""
    $redirectCount = 0
    $credentialsSubmitted = $false
    $postSubmitLoginFormChecks = 0
    $captchaSubmitUsed = $false
    $lastLoggedAction = ""

    while ($watch.ElapsedMilliseconds -lt $TimeoutMs) {
        [System.Windows.Forms.Application]::DoEvents()

        if ($script:StopRequested) {
            throw "Stopped by user"
        }

        try {
            $step = Invoke-ElkAutoLoginStep `
                -Port $Port `
                -Username $username `
                -Password $password `
                -CanSubmitCredentials (-not $credentialsSubmitted) `
                -AllowCaptchaSubmit ($ResumeAfterCaptcha -and -not $captchaSubmitUsed) `
                -TimeoutMs 12000

            if ($null -ne $step) {
                if ($null -ne $step.state) {
                    $lastState = [string]$step.state
                }

                if ($null -ne $step.href) {
                    $lastHref = [string]$step.href
                }

                if ($null -ne $step.feedback) {
                    $lastFeedback = [string]$step.feedback
                }

                if ($null -ne $step.action) {
                    $actionText = [string]$step.action
                    if (
                        -not [string]::IsNullOrWhiteSpace($actionText) -and
                        $actionText -ne "none" -and
                        $actionText -ne $lastLoggedAction
                    ) {
                        $lastLoggedAction = $actionText
                        try {
                            if ($null -ne $txtElkLog) {
                                $txtElkLog.AppendText(("Auto Login -> " + $actionText + "`r`n"))
                            }
                        } catch {}
                        try {
                            if ($null -ne $txtSchedulerLog) {
                                Write-SchedulerLog ("Auto Login -> " + $actionText)
                            }
                        } catch {}
                    }
                }

                if ($step.ok) {
                    Start-Sleep -Milliseconds 600

                    return [PSCustomObject]@{
                        ok = $true
                        state = "authenticated"
                        href = $lastHref
                        redirects = $redirectCount
                    }
                }

                if ($lastState -eq "invalid-credentials") {
                    throw "AUTO_LOGIN_BAD_CREDENTIALS"
                }

                if ($lastState -eq "captcha-required") {
                    throw "AUTO_LOGIN_CAPTCHA_REQUIRED"
                }

                if ($lastState -eq "submitted") {
                    if ($ResumeAfterCaptcha) { $captchaSubmitUsed = $true }
                    # Never submit this username/password more than once.
                    $credentialsSubmitted = $true
                    $postSubmitLoginFormChecks = 0
                    $redirectCount++
                    Start-Sleep -Milliseconds 900
                    continue
                }

                if ($lastState -eq "login-form-present" -and $credentialsSubmitted) {
                    $postSubmitLoginFormChecks++

                    # Keycloak may briefly repaint the form while redirecting,
                    # so allow a few checks. If the login form remains, treat
                    # the first credential submission as failed.
                    if (
                        -not [string]::IsNullOrWhiteSpace($lastFeedback) -or
                        $postSubmitLoginFormChecks -ge 7
                    ) {
                        throw "AUTO_LOGIN_BAD_CREDENTIALS"
                    }

                    Start-Sleep -Milliseconds 700
                    continue
                }

                if ($lastState -eq "redirecting") {
                    $redirectCount++
                    Start-Sleep -Milliseconds 1300
                    continue
                }
            }
        }
        catch {
            $message = $_.Exception.Message

            if ($message -eq "AUTO_LOGIN_BAD_CREDENTIALS") {
                throw "Auto Login failed: Username or Password is incorrect. Login was attempted only once to protect the account from lockout."
            }

            if ($message -eq "AUTO_LOGIN_CAPTCHA_REQUIRED") {
                throw "CAPTCHA_REQUIRED"
            }

            if (
                $message -match 'Inspected target navigated or closed' -or
                $message -match 'WebSocket' -or
                $message -match 'closed without completing the close handshake' -or
                $message -match 'Cannot access a disposed object'
            ) {
                $redirectCount++
                Start-Sleep -Milliseconds 900
                continue
            }

            throw
        }

        Start-Sleep -Milliseconds 500
    }

    throw (
        "Auto Login timed out. Last state: " +
        $lastState +
        $(if ($lastLoggedAction) { " | Last action: " + $lastLoggedAction } else { "" }) +
        $(if ($lastHref) { " | " + $lastHref } else { "" })
    )
}

function Capture-FullPageScreenshotFromLiveSession {
    param(
        [int]$Port,
        [string]$Url,
        [string]$File,
        [int]$Width,
        [int]$Height,
        [int]$WaitAfterLoadMs,
        [int]$ScrollDelayMs,
        [int]$FinalSettleMs,
        [int]$TimeoutMs
    )

    $ws = $null

    try {
        $target = Get-CdpPageTarget -Port $Port -TimeoutMs $TimeoutMs

        $ws = New-Object System.Net.WebSockets.ClientWebSocket
        $connectTask = $ws.ConnectAsync(
            [System.Uri]$target.webSocketDebuggerUrl,
            [System.Threading.CancellationToken]::None
        )
        [void](Wait-TaskResponsive -Task $connectTask -TimeoutMs $TimeoutMs)

        [void](Invoke-CdpCommand `
            -WebSocket $ws `
            -Method "Page.enable" `
            -Params @{} `
            -TimeoutMs $TimeoutMs)

        [void](Invoke-CdpCommand `
            -WebSocket $ws `
            -Method "Runtime.enable" `
            -Params @{} `
            -TimeoutMs $TimeoutMs)

        # Keep dashboard captures consistent regardless of the visible
        # browser window size.
        try {
            [void](Invoke-CdpCommand `
                -WebSocket $ws `
                -Method "Emulation.setDeviceMetricsOverride" `
                -Params @{
                    width = $Width
                    height = $Height
                    deviceScaleFactor = 1
                    mobile = $false
                } `
                -TimeoutMs 5000)
        } catch {}

        [void](Invoke-CdpCommand `
            -WebSocket $ws `
            -Method "Page.navigate" `
            -Params @{ url = $Url } `
            -TimeoutMs $TimeoutMs)

        $readyWatch = [System.Diagnostics.Stopwatch]::StartNew()

        while ($readyWatch.ElapsedMilliseconds -lt $TimeoutMs) {
            [System.Windows.Forms.Application]::DoEvents()

            if ($script:StopRequested) {
                throw "Stopped by user"
            }

            try {
                $ready = Invoke-CdpCommand `
                    -WebSocket $ws `
                    -Method "Runtime.evaluate" `
                    -Params @{
                        expression = "document.readyState"
                        returnByValue = $true
                    } `
                    -TimeoutMs 3000

                if ($ready.result.result.value -eq "complete") {
                    break
                }
            } catch {}

            Start-Sleep -Milliseconds 120
        }

        # Kibana is an SPA; HTML can be ready while panels are still loading.
        if ($WaitAfterLoadMs -gt 0) {
            $loadWait = [System.Diagnostics.Stopwatch]::StartNew()

            while ($loadWait.ElapsedMilliseconds -lt $WaitAfterLoadMs) {
                [System.Windows.Forms.Application]::DoEvents()

                if ($script:StopRequested) {
                    throw "Stopped by user"
                }

                Start-Sleep -Milliseconds 100
            }
        }

        # Detect the exact failure the user hit: navigation was redirected
        # back to Elastic/Keycloak login instead of the dashboard.
        try {
            $pageState = Invoke-CdpCommand `
                -WebSocket $ws `
                -Method "Runtime.evaluate" `
                -Params @{
                    expression = @"
(() => ({
  href: location.href,
  title: document.title || '',
  text: (document.body && document.body.innerText ? document.body.innerText : '').slice(0,4000)
}))()
"@
                    returnByValue = $true
                } `
                -TimeoutMs 5000

            $state = $pageState.result.result.value
            $bodyText = [string]$state.text
            $currentHref = [string]$state.href

            if (
                $bodyText -match 'Welcome to Elastic' -or
                (
                    $bodyText -match 'Keycloak' -and
                    $bodyText -match 'Log in with Elasticsearch'
                )
            ) {
                throw "Kibana authentication page detected. Login in the aghrab Login Browser and KEEP that browser open while Capture All Dashboards runs."
            }

            if (
                $currentHref -match '/login(\?|$)' -or
                $currentHref -match '/security/login'
            ) {
                throw "Kibana login redirect detected. The live browser session is not authenticated."
            }
        } catch {
            if (
                $_.Exception.Message -match 'authentication page detected' -or
                $_.Exception.Message -match 'login redirect detected'
            ) {
                throw
            }
        }

        $scrollScript = @'
(async () => {
    const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
    const scrollDelay = __SCROLL_DELAY__;
    const finalSettle = __FINAL_SETTLE__;
    let lastY = -1;
    let stableBottomCount = 0;

    for (let i = 0; i < 120; i++) {
        const doc = document.documentElement;
        const body = document.body;
        const total = Math.max(
            doc ? doc.scrollHeight : 0,
            body ? body.scrollHeight : 0
        );
        const maxY = Math.max(0, total - window.innerHeight);

        if (window.scrollY >= maxY - 5) {
            stableBottomCount++;
            await sleep(300);

            const newTotal = Math.max(
                document.documentElement ? document.documentElement.scrollHeight : 0,
                document.body ? document.body.scrollHeight : 0
            );
            const newMaxY = Math.max(0, newTotal - window.innerHeight);

            if (stableBottomCount >= 2 && newMaxY <= maxY + 5) {
                break;
            }
        } else {
            stableBottomCount = 0;
        }

        const step = Math.max(450, Math.floor(window.innerHeight * 0.85));
        window.scrollBy(0, step);
        await sleep(scrollDelay);

        if (window.scrollY === lastY && window.scrollY >= maxY - 5) {
            break;
        }

        lastY = window.scrollY;
    }

    await sleep(finalSettle);
    window.scrollTo(0, 0);
    await sleep(Math.max(500, Math.floor(finalSettle / 2)));

    return {
        width: Math.max(
            document.documentElement ? document.documentElement.scrollWidth : 0,
            document.body ? document.body.scrollWidth : 0
        ),
        height: Math.max(
            document.documentElement ? document.documentElement.scrollHeight : 0,
            document.body ? document.body.scrollHeight : 0
        )
    };
})()
'@

        $scrollScript = $scrollScript.Replace(
            "__SCROLL_DELAY__",
            [string]$ScrollDelayMs
        )
        $scrollScript = $scrollScript.Replace(
            "__FINAL_SETTLE__",
            [string]$FinalSettleMs
        )

        [void](Invoke-CdpCommand `
            -WebSocket $ws `
            -Method "Runtime.evaluate" `
            -Params @{
                expression = $scrollScript
                awaitPromise = $true
                returnByValue = $true
            } `
            -TimeoutMs $TimeoutMs)

        $metrics = Invoke-CdpCommand `
            -WebSocket $ws `
            -Method "Page.getLayoutMetrics" `
            -Params @{} `
            -TimeoutMs $TimeoutMs

        # Kibana dashboards can report an oversized horizontal contentSize
        # because of off-screen/fixed UI elements. Capturing that width creates
        # a large black/empty area on the right. For ELK Dashboard capture we
        # always keep the horizontal canvas equal to the configured viewport
        # and only extend vertically.
        $reportedWidth = [Math]::Ceiling(
            [double]$metrics.result.contentSize.width
        )
        $reportedHeight = [Math]::Ceiling(
            [double]$metrics.result.contentSize.height
        )

        $contentWidth = $Width
        $contentHeight = $reportedHeight

        if ($contentHeight -lt $Height) {
            $contentHeight = $Height
        }

        # Defensive limits against broken layout metrics.
        if ($contentHeight -gt 50000) {
            $contentHeight = 50000
        }

        $shot = Invoke-CdpCommand `
            -WebSocket $ws `
            -Method "Page.captureScreenshot" `
            -Params @{
                format = "png"
                fromSurface = $true
                captureBeyondViewport = $true
                clip = @{
                    x = 0
                    y = 0
                    width = $contentWidth
                    height = $contentHeight
                    scale = 1
                }
            } `
            -TimeoutMs $TimeoutMs

        $data = [string]$shot.result.data

        if ([string]::IsNullOrWhiteSpace($data)) {
            throw "Browser returned an empty screenshot"
        }

        [System.IO.File]::WriteAllBytes(
            $File,
            [System.Convert]::FromBase64String($data)
        )

        return @{
            Width = $contentWidth
            Height = $contentHeight
        }
    }
    finally {
        if ($ws -ne $null) {
            try {
                if ($ws.State -eq [System.Net.WebSockets.WebSocketState]::Open) {
                    $closeTask = $ws.CloseAsync(
                        [System.Net.WebSockets.WebSocketCloseStatus]::NormalClosure,
                        "done",
                        [System.Threading.CancellationToken]::None
                    )

                    try {
                        [void](Wait-TaskResponsive `
                            -Task $closeTask `
                            -TimeoutMs 1500)
                    } catch {}
                }
            } catch {}

            try {
                $ws.Dispose()
            } catch {}
        }

        # Important: DO NOT close the browser. It owns the authenticated
        # Keycloak/Kibana session used for every dashboard in this run.
    }
}


# ---------------- Retention helpers ----------------
function Apply-RetentionPolicy {
    param(
        [string]$AlbumPath,
        [int]$KeepDays,
        [int]$MaxPerAlbum
    )

    $removedByAge = 0
    $removedByLimit = 0

    if ([string]::IsNullOrWhiteSpace($AlbumPath) -or -not (Test-Path -LiteralPath $AlbumPath -PathType Container)) {
        return [PSCustomObject]@{
            RemovedByAge = 0
            RemovedByLimit = 0
            Remaining = 0
        }
    }

    # 0 means disabled / unlimited.
    if ($KeepDays -gt 0) {
        $cutoff = (Get-Date).AddDays(-$KeepDays)

        $oldFiles = Get-ChildItem -LiteralPath $AlbumPath -File -Filter *.png -ErrorAction SilentlyContinue |
                    Where-Object { $_.LastWriteTime -lt $cutoff }

        foreach ($file in $oldFiles) {
            try {
                Remove-Item -LiteralPath $file.FullName -Force -ErrorAction Stop
                $removedByAge++
            } catch {}
        }
    }

    $remainingFiles = @(
        Get-ChildItem -LiteralPath $AlbumPath -File -Filter *.png -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending
    )

    if ($MaxPerAlbum -gt 0 -and $remainingFiles.Count -gt $MaxPerAlbum) {
        $extraFiles = $remainingFiles | Select-Object -Skip $MaxPerAlbum

        foreach ($file in $extraFiles) {
            try {
                Remove-Item -LiteralPath $file.FullName -Force -ErrorAction Stop
                $removedByLimit++
            } catch {}
        }
    }

    $finalCount = @(
        Get-ChildItem -LiteralPath $AlbumPath -File -Filter *.png -ErrorAction SilentlyContinue
    ).Count

    return [PSCustomObject]@{
        RemovedByAge = $removedByAge
        RemovedByLimit = $removedByLimit
        Remaining = $finalCount
    }
}

function Get-AlbumRetentionConfigPath {
    param([string]$AlbumPath)
    return (Join-Path $AlbumPath ".raghib-retention.json")
}

function Get-AlbumRetentionPolicy {
    param([string]$AlbumPath)

    $defaultKeepDays = 30
    $defaultMaxImages = 500

    $configPath = Get-AlbumRetentionConfigPath -AlbumPath $AlbumPath

    if (Test-Path -LiteralPath $configPath -PathType Leaf) {
        try {
            $cfg = Get-Content -LiteralPath $configPath -Raw -Encoding UTF8 | ConvertFrom-Json

            $keepDays = $defaultKeepDays
            $maxImages = $defaultMaxImages

            if ($null -ne $cfg.KeepDays) {
                $keepDays = [Math]::Max(0, [int]$cfg.KeepDays)
            }

            if ($null -ne $cfg.MaxPerAlbum) {
                $maxImages = [Math]::Max(0, [int]$cfg.MaxPerAlbum)
            }

            return [PSCustomObject]@{
                KeepDays = $keepDays
                MaxPerAlbum = $maxImages
                ConfigPath = $configPath
                IsCustom = $true
            }
        } catch {}
    }

    return [PSCustomObject]@{
        KeepDays = $defaultKeepDays
        MaxPerAlbum = $defaultMaxImages
        ConfigPath = $configPath
        IsCustom = $false
    }
}

function Save-AlbumRetentionPolicy {
    param(
        [string]$AlbumPath,
        [int]$KeepDays,
        [int]$MaxPerAlbum
    )

    if ([string]::IsNullOrWhiteSpace($AlbumPath) -or -not (Test-Path -LiteralPath $AlbumPath -PathType Container)) {
        throw "Album folder does not exist."
    }

    $configPath = Get-AlbumRetentionConfigPath -AlbumPath $AlbumPath

    $config = [PSCustomObject]@{
        KeepDays = [Math]::Max(0, $KeepDays)
        MaxPerAlbum = [Math]::Max(0, $MaxPerAlbum)
        Updated = (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
    }

    $config | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $configPath -Encoding UTF8

    try {
        $item = Get-Item -LiteralPath $configPath -Force
        $item.Attributes = $item.Attributes -bor [System.IO.FileAttributes]::Hidden
    } catch {}

    return Get-AlbumRetentionPolicy -AlbumPath $AlbumPath
}

function Ensure-AlbumRetentionPolicy {
    param([string]$AlbumPath)

    $policy = Get-AlbumRetentionPolicy -AlbumPath $AlbumPath

    if (-not $policy.IsCustom) {
        try {
            $policy = Save-AlbumRetentionPolicy `
                -AlbumPath $AlbumPath `
                -KeepDays $policy.KeepDays `
                -MaxPerAlbum $policy.MaxPerAlbum
        } catch {}
    }

    return $policy
}

function Apply-AlbumSavedRetentionPolicy {
    param([string]$AlbumPath)

    $policy = Ensure-AlbumRetentionPolicy -AlbumPath $AlbumPath

    $result = Apply-RetentionPolicy `
        -AlbumPath $AlbumPath `
        -KeepDays ([int]$policy.KeepDays) `
        -MaxPerAlbum ([int]$policy.MaxPerAlbum)

    return [PSCustomObject]@{
        KeepDays = $policy.KeepDays
        MaxPerAlbum = $policy.MaxPerAlbum
        RemovedByAge = $result.RemovedByAge
        RemovedByLimit = $result.RemovedByLimit
        Remaining = $result.Remaining
    }
}

function Apply-RetentionToAllAlbums {
    param([string]$OutputRoot)

    $ageTotal = 0
    $limitTotal = 0
    $albumsChecked = 0

    if ([string]::IsNullOrWhiteSpace($OutputRoot) -or -not (Test-Path -LiteralPath $OutputRoot -PathType Container)) {
        return [PSCustomObject]@{
            AlbumsChecked = 0
            RemovedByAge = 0
            RemovedByLimit = 0
        }
    }

    $albums = Get-ChildItem -LiteralPath $OutputRoot -Directory -ErrorAction SilentlyContinue

    foreach ($album in $albums) {
        $result = Apply-AlbumSavedRetentionPolicy -AlbumPath $album.FullName

        $albumsChecked++
        $ageTotal += $result.RemovedByAge
        $limitTotal += $result.RemovedByLimit
    }

    return [PSCustomObject]@{
        AlbumsChecked = $albumsChecked
        RemovedByAge = $ageTotal
        RemovedByLimit = $limitTotal
    }
}


# ---------------- ELK Profile helpers ----------------
$script:AghrabConfigDir = Join-Path $env:APPDATA "aghrab"
$script:ElkProfilesFile = Join-Path $script:AghrabConfigDir "elk-profiles.json"
$script:ElkProfiles = @()
$script:EditingElkProfileName = $null


# ---------------- Security / audit helpers ----------------
$script:SecurityAuditFile = Join-Path $script:AghrabConfigDir "security-audit.log"
$script:IntegrityBaselineFile = Join-Path $script:AghrabConfigDir "security-integrity-baseline.json"
$script:LastIntegrityStatus = "Not checked"
$script:LastIntegrityDetail = "Run Security Check to verify important files."

function Redact-SensitiveText {
    param([string]$Text)

    if ([string]::IsNullOrEmpty($Text)) {
        return $Text
    }

    $value = [string]$Text

    # Common secret formats in text/log output.
    $value = $value -replace '(?i)(password|passwd|pwd)\s*[:=]\s*[^;\s,&]+', '$1=***REDACTED***'
    $value = $value -replace '(?i)(authorization\s*:\s*bearer\s+)[^\s\r\n]+', '$1***REDACTED***'
    $value = $value -replace '(?i)((?:cookie|set-cookie|token|api[-_ ]?key)\s*[:=]\s*)[^\r\n]+', '$1***REDACTED***'
    $value = $value -replace '(?i)([?&](?:access_token|token|api_key|apikey)=)[^&\s]+', '$1***REDACTED***'

    return $value
}

function Write-SecurityAudit {
    param(
        [string]$Action,
        [string]$Detail = ""
    )

    try {
        New-Item -ItemType Directory -Force -Path $script:AghrabConfigDir | Out-Null

        $safeAction = Redact-SensitiveText -Text $Action
        $safeDetail = Redact-SensitiveText -Text $Detail
        $line = (
            (Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff") +
            " | " + $safeAction +
            $(if ([string]::IsNullOrWhiteSpace($safeDetail)) { "" } else { " | " + $safeDetail })
        )

        Add-Content -LiteralPath $script:SecurityAuditFile -Value $line -Encoding UTF8
    }
    catch {}
}

function Get-SecurityFolderStats {
    param([string]$Path)

    if ([string]::IsNullOrWhiteSpace($Path) -or -not (Test-Path -LiteralPath $Path -PathType Container)) {
        return [PSCustomObject]@{ Files = 0; Bytes = 0L; Directories = 0 }
    }

    $files = @(Get-ChildItem -LiteralPath $Path -File -Recurse -ErrorAction SilentlyContinue)
    $dirs = @(Get-ChildItem -LiteralPath $Path -Directory -ErrorAction SilentlyContinue)
    $bytes = 0L

    foreach ($f in $files) {
        try { $bytes += [long]$f.Length } catch {}
    }

    return [PSCustomObject]@{
        Files = $files.Count
        Bytes = $bytes
        Directories = $dirs.Count
    }
}

function Clear-AghrabSavedSessions {
    Close-ElkLiveSession

    $targets = @(
        (Join-Path $script:AghrabConfigDir "browser-profiles"),
        (Join-Path $script:AghrabConfigDir "auto-login-sessions")
    )

    $removed = 0
    foreach ($target in $targets) {
        if (Test-Path -LiteralPath $target -PathType Container) {
            try {
                $count = @(Get-ChildItem -LiteralPath $target -Directory -ErrorAction SilentlyContinue).Count
                Remove-Item -LiteralPath $target -Recurse -Force -ErrorAction Stop
                $removed += $count
            }
            catch {
                throw "Could not clear saved browser sessions: $($_.Exception.Message)"
            }
        }
    }

    Write-SecurityAudit -Action "SESSION_CLEAR" -Detail ("Saved browser sessions cleared. Folders: " + $removed)
    return $removed
}

function Clear-AghrabAiCache {
    $paths = Get-AiPaths
    New-Item -ItemType Directory -Force -Path $paths.CacheDir | Out-Null

    $files = @(Get-ChildItem -LiteralPath $paths.CacheDir -File -Recurse -ErrorAction SilentlyContinue)
    $count = $files.Count

    foreach ($file in $files) {
        try { Remove-Item -LiteralPath $file.FullName -Force -ErrorAction SilentlyContinue } catch {}
    }

    # Remove empty sub-directories as well, but keep the cache root.
    try {
        Get-ChildItem -LiteralPath $paths.CacheDir -Directory -Recurse -ErrorAction SilentlyContinue |
            Sort-Object FullName -Descending |
            Remove-Item -Force -Recurse -ErrorAction SilentlyContinue
    }
    catch {}

    Write-SecurityAudit -Action "AI_CACHE_CLEAR" -Detail ("Temporary AI cache cleared. Files: " + $count)
    return $count
}

function Get-AghrabIntegrityTargets {
    $paths = Get-AiPaths
    $targets = New-Object System.Collections.Generic.List[object]

    $scriptFile = Join-Path $BaseDir "ScreenshotTool.ps1"
    if (Test-Path -LiteralPath $scriptFile -PathType Leaf) {
        $targets.Add([PSCustomObject]@{ Name="ScreenshotTool.ps1"; Path=$scriptFile; Mode="Baseline"; Expected="" })
    }

    if (Test-Path -LiteralPath $paths.Model -PathType Leaf) {
        $targets.Add([PSCustomObject]@{
            Name="Qwen2.5-VL-3B model"
            Path=$paths.Model
            Mode="Expected"
            Expected="d02fe9b69ad8cadbbd228e387667af66612c44bed29ffc8eb1e7caf9ac486c12"
        })
    }

    if (Test-Path -LiteralPath $paths.Mmproj -PathType Leaf) {
        $targets.Add([PSCustomObject]@{
            Name="Qwen2.5-VL mmproj"
            Path=$paths.Mmproj
            Mode="Expected"
            Expected="980c9b2f78c04e6cff93d277ada09e768394f112d75db3b4e9dea8a69f9fb904"
        })
    }

    # Runtime manifest is written only after the pinned official llama.cpp ZIP
    # passes SHA256 validation in Prepare-AI-Pack.ps1.
    $runtimeManifest = Join-Path $paths.RuntimeDir "runtime-sha256.json"
    if (Test-Path -LiteralPath $runtimeManifest -PathType Leaf) {
        try {
            $manifest = Get-Content -LiteralPath $runtimeManifest -Raw -Encoding UTF8 | ConvertFrom-Json -ErrorAction Stop
            if ([string]$manifest.format -eq "RAQEB-AI-RUNTIME-MANIFEST" -and
                ([string]$manifest.source_archive_sha256).ToLowerInvariant() -eq "917f39c076402c421224824607397af20f53625a60defc20e8dd22446bf4c5d7") {
                foreach ($item in @($manifest.files)) {
                    $name = [string]$item.name
                    $expected = ([string]$item.sha256).ToLowerInvariant()
                    if (-not [string]::IsNullOrWhiteSpace($name) -and $expected -match '^[0-9a-f]{64}$') {
                        $runtimePath = Join-Path $paths.RuntimeDir $name
                        if (Test-Path -LiteralPath $runtimePath -PathType Leaf) {
                            $targets.Add([PSCustomObject]@{ Name=("AI runtime: " + $name); Path=$runtimePath; Mode="Expected"; Expected=$expected })
                        }
                    }
                }
            }
        } catch {}
    }

    return $targets.ToArray()
}

function Invoke-AghrabIntegrityCheck {
    $targets = @(Get-AghrabIntegrityTargets)
    $results = New-Object System.Collections.Generic.List[object]
    $baseline = $null
    $baselineNeedsCreate = $false

    try {
        if (Test-Path -LiteralPath $script:IntegrityBaselineFile -PathType Leaf) {
            $baseline = Get-Content -LiteralPath $script:IntegrityBaselineFile -Raw -Encoding UTF8 | ConvertFrom-Json
        }
    }
    catch {
        $baseline = $null
    }

    if ($null -eq $baseline -or [string]$baseline.Version -ne $AppVersion) {
        $baselineNeedsCreate = $true
        $baseline = [PSCustomObject]@{
            Version = $AppVersion
            Created = (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
            Hashes = [PSCustomObject]@{}
        }
    }

    $baselineMap = @{}
    try {
        foreach ($prop in $baseline.Hashes.PSObject.Properties) {
            $baselineMap[$prop.Name] = [string]$prop.Value
        }
    }
    catch {}

    foreach ($target in $targets) {
        [System.Windows.Forms.Application]::DoEvents()
        $hash = ""
        $state = "UNKNOWN"
        $detail = ""

        try {
            $hash = (Get-FileHash -LiteralPath $target.Path -Algorithm SHA256 -ErrorAction Stop).Hash.ToLowerInvariant()

            if ($target.Mode -eq "Expected") {
                if ($hash -eq ([string]$target.Expected).ToLowerInvariant()) {
                    $state = "OK"
                    $detail = "Known SHA256 verified"
                }
                else {
                    $state = "CHANGED"
                    $detail = "SHA256 does not match expected model hash"
                }
            }
            else {
                if ($baselineNeedsCreate -or -not $baselineMap.ContainsKey($target.Name)) {
                    $baselineMap[$target.Name] = $hash
                    $state = "BASELINE"
                    $detail = "Baseline created for v$AppVersion"
                }
                elseif ($hash -eq ([string]$baselineMap[$target.Name]).ToLowerInvariant()) {
                    $state = "OK"
                    $detail = "Matches trusted v$AppVersion baseline"
                }
                else {
                    $state = "CHANGED"
                    $detail = "File changed since trusted v$AppVersion baseline"
                }
            }
        }
        catch {
            $state = "ERROR"
            $detail = $_.Exception.Message
        }

        $results.Add([PSCustomObject]@{
            Name = $target.Name
            State = $state
            Detail = $detail
            Hash = $hash
        })
    }

    if ($baselineNeedsCreate -or ($results | Where-Object { $_.State -eq "BASELINE" })) {
        try {
            New-Item -ItemType Directory -Force -Path $script:AghrabConfigDir | Out-Null
            $hashObj = [PSCustomObject]@{}
            foreach ($key in $baselineMap.Keys) {
                $hashObj | Add-Member -NotePropertyName $key -NotePropertyValue $baselineMap[$key] -Force
            }

            [PSCustomObject]@{
                Version = $AppVersion
                Created = (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
                Hashes = $hashObj
            } | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $script:IntegrityBaselineFile -Encoding UTF8 -Force
        }
        catch {}
    }

    $changed = @($results | Where-Object { $_.State -in @("CHANGED","ERROR") }).Count
    $baselineCount = @($results | Where-Object { $_.State -eq "BASELINE" }).Count

    if ($changed -gt 0) {
        $script:LastIntegrityStatus = "Attention"
        $script:LastIntegrityDetail = "$changed integrity issue(s) detected."
    }
    elseif ($baselineCount -gt 0) {
        $script:LastIntegrityStatus = "Baseline created"
        $script:LastIntegrityDetail = "Trusted baseline created for RAQEB Sentinel v$AppVersion."
    }
    elseif ($targets.Count -eq 0) {
        $script:LastIntegrityStatus = "No files found"
        $script:LastIntegrityDetail = "No integrity targets are currently installed."
    }
    else {
        $script:LastIntegrityStatus = "Verified"
        $script:LastIntegrityDetail = "All available integrity targets passed."
    }

    Write-SecurityAudit -Action "INTEGRITY_CHECK" -Detail ($script:LastIntegrityStatus + ". " + $script:LastIntegrityDetail)

    return [PSCustomObject]@{
        Status = $script:LastIntegrityStatus
        Detail = $script:LastIntegrityDetail
        Results = $results.ToArray()
    }
}

function Convert-SecureStringToPlainText {
    param([System.Security.SecureString]$SecureString)

    if ($null -eq $SecureString) { return "" }

    $ptr = [IntPtr]::Zero
    try {
        $ptr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecureString)
        return [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)
    }
    finally {
        if ($ptr -ne [IntPtr]::Zero) {
            [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr)
        }
    }
}

function Get-LegacyProtectedDataTypes {
    # Older RAQEB builds used the .NET ProtectedData API directly.
    # Resolve it dynamically so WinForms events never fail just because
    # System.Security was not preloaded by Windows PowerShell.
    try { Add-Type -AssemblyName System.Security -ErrorAction Stop } catch {}

    $protectedDataType = $null
    $scopeType = $null

    foreach ($assembly in [AppDomain]::CurrentDomain.GetAssemblies()) {
        if ($null -eq $protectedDataType) {
            try {
                $protectedDataType = $assembly.GetType(
                    "System.Security.Cryptography.ProtectedData",
                    $false,
                    $false
                )
            } catch {}
        }

        if ($null -eq $scopeType) {
            try {
                $scopeType = $assembly.GetType(
                    "System.Security.Cryptography.DataProtectionScope",
                    $false,
                    $false
                )
            } catch {}
        }

        if ($null -ne $protectedDataType -and $null -ne $scopeType) { break }
    }

    return [PSCustomObject]@{
        ProtectedData = $protectedDataType
        Scope = $scopeType
    }
}

function Unprotect-LegacyAghrabDpapi {
    param([string]$ProtectedBase64)

    try {
        $types = Get-LegacyProtectedDataTypes
        if ($null -eq $types.ProtectedData -or $null -eq $types.Scope) {
            return ""
        }

        $bytes = [System.Convert]::FromBase64String($ProtectedBase64)
        $scope = [System.Enum]::Parse($types.Scope, "CurrentUser")

        $method = @(
            $types.ProtectedData.GetMethods() |
            Where-Object {
                $_.Name -eq "Unprotect" -and
                $_.IsStatic -and
                $_.GetParameters().Count -eq 3
            }
        ) | Select-Object -First 1

        if ($null -eq $method) { return "" }

        $args = New-Object 'System.Object[]' 3
        $args[0] = $bytes
        $args[1] = $null
        $args[2] = $scope

        $plain = $method.Invoke($null, $args)
        if ($null -eq $plain) { return "" }

        return [System.Text.Encoding]::UTF8.GetString([byte[]]$plain)
    }
    catch {
        return ""
    }
}

function Protect-SecretForCurrentUser {
    param([string]$PlainText)

    if ([string]::IsNullOrWhiteSpace($PlainText)) {
        return ""
    }

    try {
        # In Windows PowerShell, ConvertFrom-SecureString without -Key
        # uses Windows DPAPI tied to the current Windows user.
        $secure = ConvertTo-SecureString -String $PlainText -AsPlainText -Force
        $encrypted = ConvertFrom-SecureString -SecureString $secure

        if ([string]::IsNullOrWhiteSpace($encrypted)) {
            throw "Windows DPAPI returned an empty encrypted value."
        }

        return "PSDPAPI:" + $encrypted
    }
    catch {
        throw ("Could not protect Auto Login password for the current Windows user: " + $_.Exception.Message)
    }
}

function Unprotect-SecretForCurrentUser {
    param([string]$ProtectedBase64)

    if ([string]::IsNullOrWhiteSpace($ProtectedBase64)) {
        return ""
    }

    try {
        if ($ProtectedBase64.StartsWith("PSDPAPI:", [System.StringComparison]::OrdinalIgnoreCase)) {
            $payload = $ProtectedBase64.Substring(8)
            if ([string]::IsNullOrWhiteSpace($payload)) { return "" }

            $secure = ConvertTo-SecureString -String $payload
            return Convert-SecureStringToPlainText -SecureString $secure
        }

        # Compatibility with older RAQEB credentials.
        return Unprotect-LegacyAghrabDpapi -ProtectedBase64 $ProtectedBase64
    }
    catch {
        # This function is called by UI selection/change events.
        # A credential problem must never crash the WinForms application.
        return ""
    }
}


function Get-ElkCredentialStoreDir {
    $dir = Join-Path $script:AghrabConfigDir "credentials"
    try { New-Item -ItemType Directory -Force -Path $dir | Out-Null } catch {}
    return $dir
}

function Get-ElkCredentialFilePath {
    param([string]$ProfileName)

    $safe = Get-SafeFolderComponent -Name $ProfileName
    return (Join-Path (Get-ElkCredentialStoreDir) ($safe + ".cred"))
}

function Save-ElkProfileCredential {
    param(
        [string]$ProfileName,
        [string]$PlainText
    )

    if ([string]::IsNullOrWhiteSpace($ProfileName) -or
        [string]::IsNullOrWhiteSpace($PlainText)) {
        return ""
    }

    $protected = Protect-SecretForCurrentUser -PlainText $PlainText
    if ([string]::IsNullOrWhiteSpace($protected)) {
        throw "Encrypted credential is empty."
    }

    $path = Get-ElkCredentialFilePath -ProfileName $ProfileName
    Set-Content -LiteralPath $path -Value $protected -Encoding UTF8 -Force
    return $protected
}

function Get-ElkProfileCredential {
    param(
        $Profile,
        [switch]$AllowEditorFallback
    )

    if ($null -eq $Profile) {
        return ""
    }

    # 1) Profile JSON value.
    $stored = [string]$Profile.PasswordProtected
    if (-not [string]::IsNullOrWhiteSpace($stored)) {
        $plain = Unprotect-SecretForCurrentUser -ProtectedBase64 $stored
        if (-not [string]::IsNullOrWhiteSpace($plain)) {
            return $plain
        }
    }

    # 2) Dedicated per-profile credential file.
    try {
        $path = Get-ElkCredentialFilePath -ProfileName ([string]$Profile.Name)
        if (Test-Path -LiteralPath $path -PathType Leaf) {
            $fileValue = (Get-Content -LiteralPath $path -Raw -Encoding UTF8).Trim()
            if (-not [string]::IsNullOrWhiteSpace($fileValue)) {
                $plain = Unprotect-SecretForCurrentUser -ProtectedBase64 $fileValue
                if (-not [string]::IsNullOrWhiteSpace($plain)) {
                    return $plain
                }
            }
        }
    }
    catch {}

    # 3) Current editor value for Run Now / same-session workflows.
    if ($AllowEditorFallback) {
        try {
            if (
                $null -ne $txtElkAuthPassword -and
                -not [string]::IsNullOrWhiteSpace($txtElkAuthPassword.Text) -and
                [string]$script:EditingElkProfileName -eq [string]$Profile.Name
            ) {
                return [string]$txtElkAuthPassword.Text
            }
        }
        catch {}
    }

    return ""
}

function Get-SafeFolderComponent {
    param([string]$Name)

    $safe = $Name -replace '[\\/:*?"<>|]', '_'
    $safe = $safe -replace '\s+', ' '
    $safe = $safe.Trim().TrimEnd('.')

    if ([string]::IsNullOrWhiteSpace($safe)) {
        $safe = "item"
    }

    if ($safe.Length -gt 120) {
        $safe = $safe.Substring(0,120).Trim()
    }

    return $safe
}

function New-DefaultElkProfile {
    return [PSCustomObject]@{
        Name = "ELK Production"
        KibanaUrl = "https://10.10.10.20:5601"
        WaitAfterLoad = 12
        ScrollDelay = 1200
        FinalSettle = 5
        Timeout = 60
        AutoLoginEnabled = $false
        Username = ""
        PasswordProtected = ""

        # Optional Fast Field Verification.
        FieldVerifyEnabled = $false
        ElasticsearchUrl = ""
        FieldVerifyApiKeyProtected = ""
        FieldVerifyTimeField = "@timestamp"
        FieldVerifyWindowMinutes = 15
        FieldVerifyIgnoreTls = $true

        Dashboards = @()
    }
}

function Load-ElkProfiles {
    try {
        New-Item -ItemType Directory -Force -Path $script:AghrabConfigDir | Out-Null

        if (Test-Path -LiteralPath $script:ElkProfilesFile -PathType Leaf) {
            $raw = Get-Content -LiteralPath $script:ElkProfilesFile -Raw -Encoding UTF8 | ConvertFrom-Json

            if ($null -eq $raw) {
                $script:ElkProfiles = @()
            }
            else {
                $script:ElkProfiles = @($raw)
            }

            foreach ($p in @($script:ElkProfiles)) {
                if ($null -eq $p.AutoLoginEnabled) { $p | Add-Member -NotePropertyName AutoLoginEnabled -NotePropertyValue $false -Force }
                if ($null -eq $p.Username) { $p | Add-Member -NotePropertyName Username -NotePropertyValue "" -Force }
                if ($null -eq $p.PasswordProtected) { $p | Add-Member -NotePropertyName PasswordProtected -NotePropertyValue "" -Force }

                if ($null -eq $p.FieldVerifyEnabled) { $p | Add-Member -NotePropertyName FieldVerifyEnabled -NotePropertyValue $false -Force }
                if ($null -eq $p.ElasticsearchUrl) { $p | Add-Member -NotePropertyName ElasticsearchUrl -NotePropertyValue "" -Force }
                if ($null -eq $p.FieldVerifyApiKeyProtected) { $p | Add-Member -NotePropertyName FieldVerifyApiKeyProtected -NotePropertyValue "" -Force }
                if ($null -eq $p.FieldVerifyTimeField) { $p | Add-Member -NotePropertyName FieldVerifyTimeField -NotePropertyValue "@timestamp" -Force }
                if ($null -eq $p.FieldVerifyWindowMinutes) { $p | Add-Member -NotePropertyName FieldVerifyWindowMinutes -NotePropertyValue 15 -Force }
                if ($null -eq $p.FieldVerifyIgnoreTls) { $p | Add-Member -NotePropertyName FieldVerifyIgnoreTls -NotePropertyValue $true -Force }

                foreach ($d in @($p.Dashboards)) {
                    if ($null -eq $d.IndexPattern) { $d | Add-Member -NotePropertyName IndexPattern -NotePropertyValue "" -Force }
                    if ($null -eq $d.ExpectedFields) { $d | Add-Member -NotePropertyName ExpectedFields -NotePropertyValue "" -Force }
                }
            }
        }
        else {
            $script:ElkProfiles = @(New-DefaultElkProfile)
            Save-ElkProfiles
        }
    }
    catch {
        $script:ElkProfiles = @(New-DefaultElkProfile)
    }

    if ($script:ElkProfiles.Count -eq 0) {
        $script:ElkProfiles = @(New-DefaultElkProfile)
        Save-ElkProfiles
    }
}

function Save-ElkProfiles {
    New-Item -ItemType Directory -Force -Path $script:AghrabConfigDir | Out-Null
    @($script:ElkProfiles) |
        ConvertTo-Json -Depth 10 |
        Set-Content -LiteralPath $script:ElkProfilesFile -Encoding UTF8

    Write-SecurityAudit -Action "PROFILE_SAVE" -Detail ("ELK profiles saved. Count: " + @($script:ElkProfiles).Count)
}

# ---------------- Portable Profile / Dashboard Transfer ----------------
function Get-AghrabUniqueImportedName {
    param(
        [string]$BaseName,
        [string[]]$ExistingNames
    )

    $base = $BaseName
    if ([string]::IsNullOrWhiteSpace($base)) {
        $base = "Imported Item"
    }

    if ($ExistingNames -notcontains $base) {
        return $base
    }

    $candidate = $base + " (Imported)"
    if ($ExistingNames -notcontains $candidate) {
        return $candidate
    }

    for ($i = 2; $i -lt 1000; $i++) {
        $candidate = $base + " (Imported " + $i + ")"
        if ($ExistingNames -notcontains $candidate) {
            return $candidate
        }
    }

    return (
        $base + " (Imported " +
        (Get-Date -Format "yyyyMMddHHmmss") +
        ")"
    )
}

function ConvertTo-AghrabPortableDashboard {
    param($Dashboard)

    if ($null -eq $Dashboard) {
        return $null
    }

    return [PSCustomObject][ordered]@{
        Name = [string]$Dashboard.Name
        TimeRange = $(if ([string]::IsNullOrWhiteSpace([string]$Dashboard.TimeRange)) {
            "Dashboard default"
        } else {
            [string]$Dashboard.TimeRange
        })
        Url = [string]$Dashboard.Url
        IndexPattern = [string]$Dashboard.IndexPattern
        ExpectedFields = [string]$Dashboard.ExpectedFields
    }
}

function ConvertFrom-AghrabPortableDashboard {
    param($Dashboard)

    if ($null -eq $Dashboard) {
        return $null
    }

    $name = ([string]$Dashboard.Name).Trim()
    $url = ([string]$Dashboard.Url).Trim()

    if ([string]::IsNullOrWhiteSpace($name)) {
        throw "Imported dashboard is missing a name."
    }

    if ([string]::IsNullOrWhiteSpace($url)) {
        throw "Imported dashboard '$name' is missing a URL or relative path."
    }

    return [PSCustomObject]@{
        Name = $name
        TimeRange = $(if ([string]::IsNullOrWhiteSpace([string]$Dashboard.TimeRange)) {
            "Dashboard default"
        } else {
            [string]$Dashboard.TimeRange
        })
        Url = $url
        IndexPattern = [string]$Dashboard.IndexPattern
        ExpectedFields = [string]$Dashboard.ExpectedFields
    }
}

function ConvertTo-AghrabPortableProfile {
    param($Profile)

    if ($null -eq $Profile) {
        return $null
    }

    $dashboards = @()
    foreach ($dashboard in @($Profile.Dashboards)) {
        $portable = ConvertTo-AghrabPortableDashboard -Dashboard $dashboard
        if ($null -ne $portable) {
            $dashboards += $portable
        }
    }

    # Credentials are intentionally excluded because they are DPAPI-bound to
    # the source Windows user/machine and must never travel in a portable file.
    return [PSCustomObject][ordered]@{
        Name = [string]$Profile.Name
        KibanaUrl = [string]$Profile.KibanaUrl
        WaitAfterLoad = [int]$Profile.WaitAfterLoad
        ScrollDelay = [int]$Profile.ScrollDelay
        FinalSettle = [int]$Profile.FinalSettle
        Timeout = [int]$Profile.Timeout

        AutoLoginWasEnabled = [bool]$Profile.AutoLoginEnabled
        Username = [string]$Profile.Username

        FieldVerificationWasEnabled = [bool]$Profile.FieldVerifyEnabled
        ElasticsearchUrl = [string]$Profile.ElasticsearchUrl
        FieldVerifyTimeField = $(if ([string]::IsNullOrWhiteSpace([string]$Profile.FieldVerifyTimeField)) {
            "@timestamp"
        } else {
            [string]$Profile.FieldVerifyTimeField
        })
        FieldVerifyWindowMinutes = $(try {
            [int]$Profile.FieldVerifyWindowMinutes
        } catch {
            15
        })
        FieldVerifyIgnoreTls = $(if ($null -eq $Profile.FieldVerifyIgnoreTls) {
            $true
        } else {
            [bool]$Profile.FieldVerifyIgnoreTls
        })

        Dashboards = @($dashboards)
    }
}

function ConvertFrom-AghrabPortableProfile {
    param($Profile)

    if ($null -eq $Profile) {
        return $null
    }

    $name = ([string]$Profile.Name).Trim()
    $kibana = ([string]$Profile.KibanaUrl).Trim()

    if ([string]::IsNullOrWhiteSpace($name)) {
        throw "Imported profile is missing a name."
    }

    if ([string]::IsNullOrWhiteSpace($kibana)) {
        throw "Imported profile '$name' is missing the Kibana URL."
    }

    $dashboards = @()
    foreach ($dashboard in @($Profile.Dashboards)) {
        $dashboards += ConvertFrom-AghrabPortableDashboard -Dashboard $dashboard
    }

    return [PSCustomObject]@{
        Name = $name
        KibanaUrl = $kibana
        WaitAfterLoad = $(try {
            [Math]::Min(60,[Math]::Max(0,[int]$Profile.WaitAfterLoad))
        } catch {
            12
        })
        ScrollDelay = $(try {
            [Math]::Min(5000,[Math]::Max(100,[int]$Profile.ScrollDelay))
        } catch {
            1200
        })
        FinalSettle = $(try {
            [Math]::Min(30,[Math]::Max(0,[int]$Profile.FinalSettle))
        } catch {
            5
        })
        Timeout = $(try {
            [Math]::Min(180,[Math]::Max(10,[int]$Profile.Timeout))
        } catch {
            60
        })

        # Portable import never activates secret-dependent features.
        AutoLoginEnabled = $false
        Username = [string]$Profile.Username
        PasswordProtected = ""

        FieldVerifyEnabled = $false
        ElasticsearchUrl = [string]$Profile.ElasticsearchUrl
        FieldVerifyApiKeyProtected = ""
        FieldVerifyTimeField = $(if ([string]::IsNullOrWhiteSpace([string]$Profile.FieldVerifyTimeField)) {
            "@timestamp"
        } else {
            [string]$Profile.FieldVerifyTimeField
        })
        FieldVerifyWindowMinutes = $(try {
            [Math]::Min(1440,[Math]::Max(1,[int]$Profile.FieldVerifyWindowMinutes))
        } catch {
            15
        })
        FieldVerifyIgnoreTls = $(if ($null -eq $Profile.FieldVerifyIgnoreTls) {
            $true
        } else {
            [bool]$Profile.FieldVerifyIgnoreTls
        })

        Dashboards = @($dashboards)
    }
}

function New-AghrabTransferDocument {
    param(
        [ValidateSet("profile","profiles","dashboard","dashboards")]
        [string]$Kind,
        $Payload
    )

    return [PSCustomObject][ordered]@{
        product = "AGHRAB Sentinel Pro"
        format = "AGHRAB-PORTABLE-TRANSFER"
        format_version = 1
        kind = $Kind
        exported_at = (Get-Date).ToString("o")
        source_version = $AppVersion
        security = [PSCustomObject][ordered]@{
            credentials_included = $false
            api_keys_included = $false
            browser_sessions_included = $false
        }
        payload = $Payload
    }
}

function Export-AghrabSelectedProfile {
    param([string]$ProfileName)

    if ([string]::IsNullOrWhiteSpace($ProfileName)) {
        throw "Select a profile to export."
    }

    $profile = Get-ElkProfileByName -Name $ProfileName
    if ($null -eq $profile) {
        throw "Selected profile could not be found."
    }

    $save = New-Object System.Windows.Forms.SaveFileDialog
    $save.Title = "Export RAQEB Profile"
    $save.Filter = "RAQEB Profile (*.aghrab-profile.json)|*.aghrab-profile.json|JSON (*.json)|*.json"
    $safeName = Get-SafeFolderComponent -Name ([string]$profile.Name)
    $save.FileName = $safeName + ".aghrab-profile.json"

    if ($save.ShowDialog($form) -ne [System.Windows.Forms.DialogResult]::OK) {
        return $null
    }

    $doc = New-AghrabTransferDocument `
        -Kind "profile" `
        -Payload (ConvertTo-AghrabPortableProfile -Profile $profile)

    $doc |
        ConvertTo-Json -Depth 15 |
        Set-Content -LiteralPath $save.FileName -Encoding UTF8 -Force

    Write-SecurityAudit `
        -Action "PROFILE_EXPORT" `
        -Detail ("Portable profile exported: " + [string]$profile.Name)

    return $save.FileName
}

function Export-AghrabAllProfiles {
    $profiles = @()
    foreach ($profile in @($script:ElkProfiles | Sort-Object Name)) {
        $profiles += ConvertTo-AghrabPortableProfile -Profile $profile
    }

    $save = New-Object System.Windows.Forms.SaveFileDialog
    $save.Title = "Export All RAQEB Profiles"
    $save.Filter = "RAQEB Profiles (*.aghrab-profiles.json)|*.aghrab-profiles.json|JSON (*.json)|*.json"
    $save.FileName = "RAQEB-Profiles-" + (Get-Date -Format "yyyyMMdd-HHmmss") + ".aghrab-profiles.json"

    if ($save.ShowDialog($form) -ne [System.Windows.Forms.DialogResult]::OK) {
        return $null
    }

    $doc = New-AghrabTransferDocument `
        -Kind "profiles" `
        -Payload @($profiles)

    $doc |
        ConvertTo-Json -Depth 15 |
        Set-Content -LiteralPath $save.FileName -Encoding UTF8 -Force

    Write-SecurityAudit `
        -Action "PROFILES_EXPORT" `
        -Detail ("Portable profiles exported. Count: " + [string]$profiles.Count)

    return $save.FileName
}

function Import-AghrabProfiles {
    $open = New-Object System.Windows.Forms.OpenFileDialog
    $open.Title = "Import RAQEB Profile(s)"
    $open.Filter = "RAQEB Profile Files (*.json)|*.json"
    $open.Multiselect = $false

    if ($open.ShowDialog($form) -ne [System.Windows.Forms.DialogResult]::OK) {
        return $null
    }

    $raw = Get-Content -LiteralPath $open.FileName -Raw -Encoding UTF8
    $doc = $raw | ConvertFrom-Json -ErrorAction Stop

    if ([string]$doc.product -ne "AGHRAB Sentinel Pro" -or
        [string]$doc.format -ne "AGHRAB-PORTABLE-TRANSFER" -or
        [int]$doc.format_version -ne 1) {
        throw "This is not a supported RAQEB portable transfer file."
    }

    if ([string]$doc.kind -notin @("profile","profiles")) {
        throw "This transfer file does not contain profile data."
    }

    $incoming = @()
    if ([string]$doc.kind -eq "profile") {
        $incoming = @($doc.payload)
    }
    else {
        $incoming = @($doc.payload)
    }

    if ($incoming.Count -eq 0) {
        throw "No profiles were found in the transfer file."
    }

    $importedNames = @()

    foreach ($sourceProfile in $incoming) {
        $profile = ConvertFrom-AghrabPortableProfile -Profile $sourceProfile

        $existingNames = @(
            $script:ElkProfiles |
            ForEach-Object { [string]$_.Name }
        )

        $profile.Name = Get-AghrabUniqueImportedName `
            -BaseName ([string]$profile.Name) `
            -ExistingNames $existingNames

        $script:ElkProfiles += $profile
        $importedNames += [string]$profile.Name
    }

    Save-ElkProfiles
    Refresh-ElkProfileList
    Refresh-SchedulerProfiles
    Refresh-HealthManagerProfiles

    if ($importedNames.Count -gt 0) {
        for ($i = 0; $i -lt $lstElkProfiles.Items.Count; $i++) {
            if ([string]$lstElkProfiles.Items[$i] -eq [string]$importedNames[0]) {
                $lstElkProfiles.SelectedIndex = $i
                break
            }
        }
    }

    Write-SecurityAudit `
        -Action "PROFILES_IMPORT" `
        -Detail ("Portable profiles imported. Count: " + [string]$importedNames.Count)

    return @($importedNames)
}

function Export-AghrabSelectedDashboard {
    param(
        [string]$ProfileName,
        [string]$DashboardName
    )

    if ([string]::IsNullOrWhiteSpace($ProfileName)) {
        throw "Select the source profile."
    }

    if ([string]::IsNullOrWhiteSpace($DashboardName)) {
        throw "Select a dashboard to export."
    }

    $profile = Get-ElkProfileByName -Name $ProfileName
    if ($null -eq $profile) {
        throw "Source profile could not be found."
    }

    $dashboard = @(
        @($profile.Dashboards) |
        Where-Object { [string]$_.Name -eq $DashboardName }
    ) | Select-Object -First 1

    if ($null -eq $dashboard) {
        throw "Selected dashboard could not be found in the source profile."
    }

    $save = New-Object System.Windows.Forms.SaveFileDialog
    $save.Title = "Export RAQEB Dashboard"
    $save.Filter = "RAQEB Dashboard (*.aghrab-dashboard.json)|*.aghrab-dashboard.json|JSON (*.json)|*.json"
    $save.FileName = (
        (Get-SafeFolderComponent -Name ([string]$dashboard.Name)) +
        ".aghrab-dashboard.json"
    )

    if ($save.ShowDialog($form) -ne [System.Windows.Forms.DialogResult]::OK) {
        return $null
    }

    $doc = New-AghrabTransferDocument `
        -Kind "dashboard" `
        -Payload (ConvertTo-AghrabPortableDashboard -Dashboard $dashboard)

    $doc |
        ConvertTo-Json -Depth 10 |
        Set-Content -LiteralPath $save.FileName -Encoding UTF8 -Force

    Write-SecurityAudit `
        -Action "DASHBOARD_EXPORT" `
        -Detail (
            "Portable dashboard exported from profile '" +
            $ProfileName +
            "': " +
            [string]$dashboard.Name
        )

    return $save.FileName
}

function Export-AghrabSelectedDashboards {
    param(
        [string]$ProfileName,
        [string[]]$DashboardNames
    )

    if ([string]::IsNullOrWhiteSpace($ProfileName)) {
        throw "Select the source profile."
    }

    $names = @(
        $DashboardNames |
        Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) } |
        Select-Object -Unique
    )

    if ($names.Count -eq 0) {
        throw "Select at least one dashboard."
    }

    $profile = Get-ElkProfileByName -Name $ProfileName
    if ($null -eq $profile) {
        throw "Source profile could not be found."
    }

    $selected = @()
    foreach ($name in $names) {
        $dashboard = @(
            @($profile.Dashboards) |
            Where-Object { [string]$_.Name -eq [string]$name }
        ) | Select-Object -First 1

        if ($null -ne $dashboard) {
            $portable = ConvertTo-AghrabPortableDashboard -Dashboard $dashboard
            if ($null -ne $portable) {
                $selected += $portable
            }
        }
    }

    if ($selected.Count -eq 0) {
        throw "None of the selected dashboards could be found."
    }

    $save = New-Object System.Windows.Forms.SaveFileDialog
    $save.Title = "Export Selected RAQEB Dashboards"
    $save.Filter = "RAQEB Dashboards (*.aghrab-dashboards.json)|*.aghrab-dashboards.json|JSON (*.json)|*.json"

    $safeProfile = Get-SafeFolderComponent -Name $ProfileName
    $save.FileName = (
        $safeProfile +
        "-Selected-Dashboards-" +
        (Get-Date -Format "yyyyMMdd-HHmmss") +
        ".aghrab-dashboards.json"
    )

    if ($save.ShowDialog($form) -ne [System.Windows.Forms.DialogResult]::OK) {
        return $null
    }

    $payload = [PSCustomObject][ordered]@{
        source_profile = $ProfileName
        dashboards = @($selected)
    }

    $doc = New-AghrabTransferDocument `
        -Kind "dashboards" `
        -Payload $payload

    $doc |
        ConvertTo-Json -Depth 15 |
        Set-Content -LiteralPath $save.FileName -Encoding UTF8 -Force

    Write-SecurityAudit `
        -Action "DASHBOARDS_EXPORT_SELECTED" `
        -Detail (
            "Selected dashboards exported from profile '" +
            $ProfileName +
            "'. Count: " +
            [string]$selected.Count
        )

    return [PSCustomObject]@{
        Path = $save.FileName
        Count = $selected.Count
    }
}

function Export-AghrabAllDashboards {
    param(
        [string]$ProfileName
    )

    if ([string]::IsNullOrWhiteSpace($ProfileName)) {
        throw "Select the source profile."
    }

    $profile = Get-ElkProfileByName -Name $ProfileName
    if ($null -eq $profile) {
        throw "Source profile could not be found."
    }

    $dashboards = @()
    foreach ($dashboard in @($profile.Dashboards)) {
        $portable = ConvertTo-AghrabPortableDashboard -Dashboard $dashboard
        if ($null -ne $portable) {
            $dashboards += $portable
        }
    }

    if ($dashboards.Count -eq 0) {
        throw "The selected profile does not contain any dashboards."
    }

    $save = New-Object System.Windows.Forms.SaveFileDialog
    $save.Title = "Export All RAQEB Dashboards"
    $save.Filter = "RAQEB Dashboards (*.aghrab-dashboards.json)|*.aghrab-dashboards.json|JSON (*.json)|*.json"
    $safeProfile = Get-SafeFolderComponent -Name $ProfileName
    $save.FileName = (
        $safeProfile +
        "-Dashboards-" +
        (Get-Date -Format "yyyyMMdd-HHmmss") +
        ".aghrab-dashboards.json"
    )

    if ($save.ShowDialog($form) -ne [System.Windows.Forms.DialogResult]::OK) {
        return $null
    }

    $payload = [PSCustomObject][ordered]@{
        source_profile = $ProfileName
        dashboards = @($dashboards)
    }

    $doc = New-AghrabTransferDocument `
        -Kind "dashboards" `
        -Payload $payload

    $doc |
        ConvertTo-Json -Depth 15 |
        Set-Content -LiteralPath $save.FileName -Encoding UTF8 -Force

    Write-SecurityAudit `
        -Action "DASHBOARDS_EXPORT" `
        -Detail (
            "Portable dashboards exported from profile '" +
            $ProfileName +
            "'. Count: " +
            [string]$dashboards.Count
        )

    return $save.FileName
}

function Import-AghrabDashboard {
    param(
        [string]$DestinationProfileName
    )

    if ([string]::IsNullOrWhiteSpace($DestinationProfileName)) {
        throw "Select the destination ELK profile."
    }

    $profileName = $DestinationProfileName.Trim()
    $profile = Get-ElkProfileByName -Name $profileName
    if ($null -eq $profile) {
        throw "Destination profile could not be found."
    }

    $open = New-Object System.Windows.Forms.OpenFileDialog
    $open.Title = "Import RAQEB Dashboard(s)"
    $open.Filter = "RAQEB Dashboard Files (*.json)|*.json"
    $open.Multiselect = $false

    if ($open.ShowDialog($form) -ne [System.Windows.Forms.DialogResult]::OK) {
        return $null
    }

    $raw = Get-Content -LiteralPath $open.FileName -Raw -Encoding UTF8
    $doc = $raw | ConvertFrom-Json -ErrorAction Stop

    if ([string]$doc.product -ne "AGHRAB Sentinel Pro" -or
        [string]$doc.format -ne "AGHRAB-PORTABLE-TRANSFER" -or
        [int]$doc.format_version -ne 1 -or
        [string]$doc.kind -notin @("dashboard","dashboards")) {
        throw "This is not a supported RAQEB dashboard transfer file."
    }

    $incoming = @()

    if ([string]$doc.kind -eq "dashboard") {
        $incoming = @($doc.payload)
    }
    else {
        $incoming = @($doc.payload.dashboards)
    }

    if ($incoming.Count -eq 0) {
        throw "No dashboards were found in the transfer file."
    }

    $importedNames = @()
    $currentDashboards = @($profile.Dashboards)

    foreach ($sourceDashboard in $incoming) {
        $dashboard = ConvertFrom-AghrabPortableDashboard -Dashboard $sourceDashboard

        $existingNames = @(
            @($currentDashboards) |
            ForEach-Object { [string]$_.Name }
        )

        $dashboard.Name = Get-AghrabUniqueImportedName `
            -BaseName ([string]$dashboard.Name) `
            -ExistingNames $existingNames

        $currentDashboards += $dashboard
        $importedNames += [string]$dashboard.Name
    }

    $profile.Dashboards = @($currentDashboards)
    Save-ElkProfiles

    # Keep main editor aligned with explicit destination profile.
    for ($i = 0; $i -lt $lstElkProfiles.Items.Count; $i++) {
        if ([string]$lstElkProfiles.Items[$i] -eq $profileName) {
            $lstElkProfiles.SelectedIndex = $i
            break
        }
    }

    Load-ElkProfileEditor -ProfileName $profileName
    Refresh-HealthManagerProfiles
    Refresh-HealthCenter

    Write-SecurityAudit `
        -Action "DASHBOARD_IMPORT" `
        -Detail (
            "Portable dashboard(s) imported to profile '" +
            $profileName +
            "'. Count: " +
            [string]$importedNames.Count
        )

    return [PSCustomObject]@{
        ProfileName = $profileName
        Count = $importedNames.Count
        DashboardNames = @($importedNames)
    }
}

function Show-AghrabTransferCenter {
    $palette = Get-AghrabPalette -Theme $script:CurrentTheme

    $dialog = New-Object System.Windows.Forms.Form
    $dialog.Text = "RAQEB Import / Export Center"
    $dialog.StartPosition = "CenterParent"
    $dialog.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
    $dialog.MaximizeBox = $false
    $dialog.MinimizeBox = $false
    $dialog.ShowIcon = $false
    $dialog.ClientSize = New-Object System.Drawing.Size(720,780)
    $dialog.Font = New-Object System.Drawing.Font("Segoe UI",9)
    $dialog.BackColor = $palette.Background
    $dialog.ForeColor = $palette.Text

    $title = New-Object System.Windows.Forms.Label
    $title.Text = "Portable Transfer Center"
    $title.Font = New-Object System.Drawing.Font(
        "Segoe UI Semibold",
        17,
        [System.Drawing.FontStyle]::Bold
    )
    $title.Location = New-Object System.Drawing.Point(26,18)
    $title.Size = New-Object System.Drawing.Size(650,36)
    $dialog.Controls.Add($title)

    $sub = New-Object System.Windows.Forms.Label
    $sub.Text = "Move RAQEB ELK profiles and dashboards safely between systems."
    $sub.Location = New-Object System.Drawing.Point(28,58)
    $sub.Size = New-Object System.Drawing.Size(640,28)
    $sub.ForeColor = $palette.Muted
    $dialog.Controls.Add($sub)

    $securityPanel = New-Object System.Windows.Forms.Panel
    $securityPanel.Location = New-Object System.Drawing.Point(26,94)
    $securityPanel.Size = New-Object System.Drawing.Size(668,74)
    $securityPanel.BackColor = $palette.Surface2
    Set-RoundedControlRegion -Control $securityPanel -Radius 10
    $dialog.Controls.Add($securityPanel)

    $securityTitle = New-Object System.Windows.Forms.Label
    $securityTitle.Text = "PORTABLE & SAFE"
    $securityTitle.Font = New-Object System.Drawing.Font("Segoe UI Semibold",8.5)
    $securityTitle.Location = New-Object System.Drawing.Point(14,10)
    $securityTitle.Size = New-Object System.Drawing.Size(160,20)
    $securityTitle.ForeColor = $palette.Accent
    $securityPanel.Controls.Add($securityTitle)

    $securityText = New-Object System.Windows.Forms.Label
    $securityText.Text = "Passwords, Elasticsearch API Keys, DPAPI credentials, cookies and browser sessions are never exported. Re-enter credentials on the destination system."
    $securityText.Location = New-Object System.Drawing.Point(14,32)
    $securityText.Size = New-Object System.Drawing.Size(635,34)
    $securityText.ForeColor = $palette.Muted
    $securityPanel.Controls.Add($securityText)

    # ---------------- PROFILE TRANSFER ----------------
    $profilePanel = New-Object System.Windows.Forms.Panel
    $profilePanel.Location = New-Object System.Drawing.Point(26,184)
    $profilePanel.Size = New-Object System.Drawing.Size(668,190)
    $profilePanel.BackColor = $palette.Surface
    Set-RoundedControlRegion -Control $profilePanel -Radius 10
    $dialog.Controls.Add($profilePanel)

    $lblProfileSection = New-Object System.Windows.Forms.Label
    $lblProfileSection.Text = "PROFILE TRANSFER"
    $lblProfileSection.Font = New-Object System.Drawing.Font(
        "Segoe UI Semibold",
        9.5,
        [System.Drawing.FontStyle]::Bold
    )
    $lblProfileSection.Location = New-Object System.Drawing.Point(16,12)
    $lblProfileSection.Size = New-Object System.Drawing.Size(200,22)
    $lblProfileSection.ForeColor = $palette.Accent
    $profilePanel.Controls.Add($lblProfileSection)

    $lblProfileSource = New-Object System.Windows.Forms.Label
    $lblProfileSource.Text = "Profile:"
    $lblProfileSource.Location = New-Object System.Drawing.Point(16,46)
    $lblProfileSource.Size = New-Object System.Drawing.Size(70,24)
    $lblProfileSource.ForeColor = $palette.Muted
    $profilePanel.Controls.Add($lblProfileSource)

    $cmbProfileSource = New-Object System.Windows.Forms.ComboBox
    $cmbProfileSource.Location = New-Object System.Drawing.Point(90,42)
    $cmbProfileSource.Size = New-Object System.Drawing.Size(330,28)
    $cmbProfileSource.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
    $profilePanel.Controls.Add($cmbProfileSource)

    foreach ($profile in @($script:ElkProfiles | Sort-Object Name)) {
        [void]$cmbProfileSource.Items.Add([string]$profile.Name)
    }

    if ($null -ne $lstElkProfiles.SelectedItem -and
        $cmbProfileSource.Items.Contains([string]$lstElkProfiles.SelectedItem)) {
        $cmbProfileSource.SelectedItem = [string]$lstElkProfiles.SelectedItem
    }
    elseif ($cmbProfileSource.Items.Count -gt 0) {
        $cmbProfileSource.SelectedIndex = 0
    }

    $btnExportProfile = New-Object System.Windows.Forms.Button
    $btnExportProfile.Text = "Export Profile"
    $btnExportProfile.Location = New-Object System.Drawing.Point(16,88)
    $btnExportProfile.Size = New-Object System.Drawing.Size(190,38)
    Style-PrimaryButton $btnExportProfile
    $profilePanel.Controls.Add($btnExportProfile)

    $btnExportAllProfiles = New-Object System.Windows.Forms.Button
    $btnExportAllProfiles.Text = "Export All Profiles"
    $btnExportAllProfiles.Location = New-Object System.Drawing.Point(218,88)
    $btnExportAllProfiles.Size = New-Object System.Drawing.Size(190,38)
    Style-SecondaryButton $btnExportAllProfiles
    $profilePanel.Controls.Add($btnExportAllProfiles)

    $btnImportProfiles = New-Object System.Windows.Forms.Button
    $btnImportProfiles.Text = "Import Profile(s)"
    $btnImportProfiles.Location = New-Object System.Drawing.Point(420,88)
    $btnImportProfiles.Size = New-Object System.Drawing.Size(190,38)
    Style-SecondaryButton $btnImportProfiles
    $profilePanel.Controls.Add($btnImportProfiles)

    $lblProfileNote = New-Object System.Windows.Forms.Label
    $lblProfileNote.Text = "A profile export includes all dashboards inside that profile. Credentials are excluded."
    $lblProfileNote.Location = New-Object System.Drawing.Point(16,142)
    $lblProfileNote.Size = New-Object System.Drawing.Size(620,30)
    $lblProfileNote.ForeColor = $palette.Muted
    $profilePanel.Controls.Add($lblProfileNote)

    if ($cmbProfileSource.Items.Count -eq 0) {
        $btnExportProfile.Enabled = $false
        $btnExportAllProfiles.Enabled = $false
    }

    # ---------------- DASHBOARD TRANSFER ----------------
    $dashboardPanel = New-Object System.Windows.Forms.Panel
    $dashboardPanel.Location = New-Object System.Drawing.Point(26,390)
    $dashboardPanel.Size = New-Object System.Drawing.Size(668,315)
    $dashboardPanel.BackColor = $palette.Surface
    Set-RoundedControlRegion -Control $dashboardPanel -Radius 10
    $dialog.Controls.Add($dashboardPanel)

    $lblDashboardSection = New-Object System.Windows.Forms.Label
    $lblDashboardSection.Text = "DASHBOARD TRANSFER"
    $lblDashboardSection.Font = New-Object System.Drawing.Font(
        "Segoe UI Semibold",
        9.5,
        [System.Drawing.FontStyle]::Bold
    )
    $lblDashboardSection.Location = New-Object System.Drawing.Point(16,12)
    $lblDashboardSection.Size = New-Object System.Drawing.Size(220,22)
    $lblDashboardSection.ForeColor = $palette.Accent
    $dashboardPanel.Controls.Add($lblDashboardSection)

    $lblDashboardSourceProfile = New-Object System.Windows.Forms.Label
    $lblDashboardSourceProfile.Text = "Source Profile:"
    $lblDashboardSourceProfile.Location = New-Object System.Drawing.Point(16,46)
    $lblDashboardSourceProfile.Size = New-Object System.Drawing.Size(100,24)
    $lblDashboardSourceProfile.ForeColor = $palette.Muted
    $dashboardPanel.Controls.Add($lblDashboardSourceProfile)

    $cmbDashboardSourceProfile = New-Object System.Windows.Forms.ComboBox
    $cmbDashboardSourceProfile.Location = New-Object System.Drawing.Point(120,42)
    $cmbDashboardSourceProfile.Size = New-Object System.Drawing.Size(250,28)
    $cmbDashboardSourceProfile.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
    $dashboardPanel.Controls.Add($cmbDashboardSourceProfile)

    foreach ($profile in @($script:ElkProfiles | Sort-Object Name)) {
        [void]$cmbDashboardSourceProfile.Items.Add([string]$profile.Name)
    }

    if ($null -ne $lstElkProfiles.SelectedItem -and
        $cmbDashboardSourceProfile.Items.Contains([string]$lstElkProfiles.SelectedItem)) {
        $cmbDashboardSourceProfile.SelectedItem = [string]$lstElkProfiles.SelectedItem
    }
    elseif ($cmbDashboardSourceProfile.Items.Count -gt 0) {
        $cmbDashboardSourceProfile.SelectedIndex = 0
    }

    $lblDashboardList = New-Object System.Windows.Forms.Label
    $lblDashboardList.Text = "Dashboards:"
    $lblDashboardList.Location = New-Object System.Drawing.Point(16,82)
    $lblDashboardList.Size = New-Object System.Drawing.Size(90,24)
    $lblDashboardList.ForeColor = $palette.Muted
    $dashboardPanel.Controls.Add($lblDashboardList)

    $clbDashboards = New-Object System.Windows.Forms.CheckedListBox
    $clbDashboards.Location = New-Object System.Drawing.Point(120,80)
    $clbDashboards.Size = New-Object System.Drawing.Size(530,92)
    $clbDashboards.CheckOnClick = $true
    $clbDashboards.IntegralHeight = $false
    $clbDashboards.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
    $clbDashboards.BackColor = $palette.Input
    $clbDashboards.ForeColor = $palette.Text
    $dashboardPanel.Controls.Add($clbDashboards)

    $btnSelectAllDashboards = New-Object System.Windows.Forms.Button
    $btnSelectAllDashboards.Text = "Select All"
    $btnSelectAllDashboards.Location = New-Object System.Drawing.Point(16,116)
    $btnSelectAllDashboards.Size = New-Object System.Drawing.Size(92,26)
    Style-SecondaryButton $btnSelectAllDashboards
    $dashboardPanel.Controls.Add($btnSelectAllDashboards)

    $btnClearDashboardSelection = New-Object System.Windows.Forms.Button
    $btnClearDashboardSelection.Text = "Clear"
    $btnClearDashboardSelection.Location = New-Object System.Drawing.Point(16,148)
    $btnClearDashboardSelection.Size = New-Object System.Drawing.Size(92,26)
    Style-SecondaryButton $btnClearDashboardSelection
    $dashboardPanel.Controls.Add($btnClearDashboardSelection)

    $btnExportSelectedDashboards = New-Object System.Windows.Forms.Button
    $btnExportSelectedDashboards.Text = "Export Selected Dashboards"
    $btnExportSelectedDashboards.Location = New-Object System.Drawing.Point(120,184)
    $btnExportSelectedDashboards.Size = New-Object System.Drawing.Size(250,38)
    Style-PrimaryButton $btnExportSelectedDashboards
    $dashboardPanel.Controls.Add($btnExportSelectedDashboards)

    $btnExportAllDashboards = New-Object System.Windows.Forms.Button
    $btnExportAllDashboards.Text = "Export All Dashboards"
    $btnExportAllDashboards.Location = New-Object System.Drawing.Point(382,184)
    $btnExportAllDashboards.Size = New-Object System.Drawing.Size(268,38)
    Style-SecondaryButton $btnExportAllDashboards
    $dashboardPanel.Controls.Add($btnExportAllDashboards)

    $divider = New-Object System.Windows.Forms.Panel
    $divider.Location = New-Object System.Drawing.Point(16,236)
    $divider.Size = New-Object System.Drawing.Size(634,1)
    $divider.BackColor = $palette.BorderSoft
    $dashboardPanel.Controls.Add($divider)

    $lblDestinationProfile = New-Object System.Windows.Forms.Label
    $lblDestinationProfile.Text = "Destination Profile:"
    $lblDestinationProfile.Location = New-Object System.Drawing.Point(16,260)
    $lblDestinationProfile.Size = New-Object System.Drawing.Size(125,24)
    $lblDestinationProfile.ForeColor = $palette.Muted
    $dashboardPanel.Controls.Add($lblDestinationProfile)

    $cmbDestinationProfile = New-Object System.Windows.Forms.ComboBox
    $cmbDestinationProfile.Location = New-Object System.Drawing.Point(145,256)
    $cmbDestinationProfile.Size = New-Object System.Drawing.Size(285,28)
    $cmbDestinationProfile.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
    $dashboardPanel.Controls.Add($cmbDestinationProfile)

    foreach ($profile in @($script:ElkProfiles | Sort-Object Name)) {
        [void]$cmbDestinationProfile.Items.Add([string]$profile.Name)
    }

    if ($cmbDestinationProfile.Items.Count -gt 0) {
        if ($null -ne $lstElkProfiles.SelectedItem -and
            $cmbDestinationProfile.Items.Contains([string]$lstElkProfiles.SelectedItem)) {
            $cmbDestinationProfile.SelectedItem = [string]$lstElkProfiles.SelectedItem
        }
        else {
            $cmbDestinationProfile.SelectedIndex = 0
        }
    }

    $btnImportDashboard = New-Object System.Windows.Forms.Button
    $btnImportDashboard.Text = "Import Dashboard(s)"
    $btnImportDashboard.Location = New-Object System.Drawing.Point(446,254)
    $btnImportDashboard.Size = New-Object System.Drawing.Size(204,34)
    Style-PrimaryButton $btnImportDashboard
    $dashboardPanel.Controls.Add($btnImportDashboard)

    $refreshDashboardList = {
        $clbDashboards.Items.Clear()

        if ($null -eq $cmbDashboardSourceProfile.SelectedItem) {
            $btnExportSelectedDashboards.Enabled = $false
            $btnExportAllDashboards.Enabled = $false
            $btnSelectAllDashboards.Enabled = $false
            $btnClearDashboardSelection.Enabled = $false
            return
        }

        $p = Get-ElkProfileByName -Name ([string]$cmbDashboardSourceProfile.SelectedItem)

        if ($null -ne $p) {
            foreach ($d in @($p.Dashboards | Sort-Object Name)) {
                [void]$clbDashboards.Items.Add([string]$d.Name,$false)
            }
        }

        $hasDashboards = ($clbDashboards.Items.Count -gt 0)
        $btnExportSelectedDashboards.Enabled = $hasDashboards
        $btnExportAllDashboards.Enabled = $hasDashboards
        $btnSelectAllDashboards.Enabled = $hasDashboards
        $btnClearDashboardSelection.Enabled = $hasDashboards
    }

    $cmbDashboardSourceProfile.Add_SelectedIndexChanged($refreshDashboardList)
    & $refreshDashboardList

    if ($cmbDestinationProfile.Items.Count -eq 0) {
        $btnImportDashboard.Enabled = $false
    }

    # ---------------- Footer ----------------
    $status = New-Object System.Windows.Forms.Label
    $status.Text = "Ready"
    $status.Location = New-Object System.Drawing.Point(28,720)
    $status.Size = New-Object System.Drawing.Size(470,26)
    $status.ForeColor = $palette.Muted
    $dialog.Controls.Add($status)

    $conflict = New-Object System.Windows.Forms.Label
    $conflict.Text = "Existing items are never overwritten. Name conflicts create a new '(Imported)' copy."
    $conflict.Location = New-Object System.Drawing.Point(28,749)
    $conflict.Size = New-Object System.Drawing.Size(520,24)
    $conflict.ForeColor = $palette.Muted
    $dialog.Controls.Add($conflict)

    $btnClose = New-Object System.Windows.Forms.Button
    $btnClose.Text = "Close"
    $btnClose.Location = New-Object System.Drawing.Point(586,738)
    $btnClose.Size = New-Object System.Drawing.Size(108,32)
    Style-SecondaryButton $btnClose
    $dialog.Controls.Add($btnClose)

    $btnExportProfile.Add_Click({
        try {
            if ($null -eq $cmbProfileSource.SelectedItem) {
                throw "Select a profile to export."
            }

            $path = Export-AghrabSelectedProfile `
                -ProfileName ([string]$cmbProfileSource.SelectedItem)

            if (-not [string]::IsNullOrWhiteSpace([string]$path)) {
                $status.Text = "Profile exported successfully."
                $status.ForeColor = $palette.Success
            }
        }
        catch {
            $status.Text = $_.Exception.Message
            $status.ForeColor = $palette.Warning
        }
    })

    $btnExportAllProfiles.Add_Click({
        try {
            $path = Export-AghrabAllProfiles
            if (-not [string]::IsNullOrWhiteSpace([string]$path)) {
                $status.Text = "All profiles exported successfully."
                $status.ForeColor = $palette.Success
            }
        }
        catch {
            $status.Text = $_.Exception.Message
            $status.ForeColor = $palette.Warning
        }
    })

    $btnImportProfiles.Add_Click({
        try {
            $names = @(Import-AghrabProfiles)

            if ($names.Count -gt 0) {
                $status.Text = (
                    "Imported " +
                    [string]$names.Count +
                    " profile(s). Re-enter passwords/API Keys."
                )
                $status.ForeColor = $palette.Success

                foreach ($combo in @(
                    $cmbProfileSource,
                    $cmbDashboardSourceProfile,
                    $cmbDestinationProfile
                )) {
                    $combo.Items.Clear()

                    foreach ($profile in @($script:ElkProfiles | Sort-Object Name)) {
                        [void]$combo.Items.Add([string]$profile.Name)
                    }

                    if ($combo.Items.Count -gt 0) {
                        $combo.SelectedIndex = 0
                    }
                }

                & $refreshDashboardList

                $btnExportProfile.Enabled = ($cmbProfileSource.Items.Count -gt 0)
                $btnExportAllProfiles.Enabled = ($cmbProfileSource.Items.Count -gt 0)
                $btnImportDashboard.Enabled = ($cmbDestinationProfile.Items.Count -gt 0)
            }
        }
        catch {
            $status.Text = $_.Exception.Message
            $status.ForeColor = $palette.Warning
        }
    })

    $btnSelectAllDashboards.Add_Click({
        for ($i = 0; $i -lt $clbDashboards.Items.Count; $i++) {
            $clbDashboards.SetItemChecked($i,$true)
        }
    })

    $btnClearDashboardSelection.Add_Click({
        for ($i = 0; $i -lt $clbDashboards.Items.Count; $i++) {
            $clbDashboards.SetItemChecked($i,$false)
        }
    })

    $btnExportSelectedDashboards.Add_Click({
        try {
            if ($null -eq $cmbDashboardSourceProfile.SelectedItem) {
                throw "Select the source profile."
            }

            $selectedNames = @()
            foreach ($item in $clbDashboards.CheckedItems) {
                $selectedNames += [string]$item
            }

            if ($selectedNames.Count -eq 0) {
                throw "Select at least one dashboard from the checklist."
            }

            $result = Export-AghrabSelectedDashboards `
                -ProfileName ([string]$cmbDashboardSourceProfile.SelectedItem) `
                -DashboardNames $selectedNames

            if ($null -ne $result) {
                $status.Text = (
                    "Exported " +
                    [string]$result.Count +
                    " selected dashboard(s)."
                )
                $status.ForeColor = $palette.Success
            }
        }
        catch {
            $status.Text = $_.Exception.Message
            $status.ForeColor = $palette.Warning
        }
    })

    $btnExportAllDashboards.Add_Click({
        try {
            if ($null -eq $cmbDashboardSourceProfile.SelectedItem) {
                throw "Select the source profile."
            }

            $path = Export-AghrabAllDashboards `
                -ProfileName ([string]$cmbDashboardSourceProfile.SelectedItem)

            if (-not [string]::IsNullOrWhiteSpace([string]$path)) {
                $status.Text = "All dashboards from the selected profile were exported."
                $status.ForeColor = $palette.Success
            }
        }
        catch {
            $status.Text = $_.Exception.Message
            $status.ForeColor = $palette.Warning
        }
    })

    $btnImportDashboard.Add_Click({
        try {
            if ($null -eq $cmbDestinationProfile.SelectedItem) {
                throw "Select the destination ELK profile."
            }

            $result = Import-AghrabDashboard `
                -DestinationProfileName ([string]$cmbDestinationProfile.SelectedItem)

            if ($null -ne $result) {
                $status.Text = (
                    "Imported " +
                    [string]$result.Count +
                    " dashboard(s) into '" +
                    [string]$result.ProfileName +
                    "'."
                )
                $status.ForeColor = $palette.Success

                & $refreshDashboardList
            }
        }
        catch {
            $status.Text = $_.Exception.Message
            $status.ForeColor = $palette.Warning
        }
    })

    $btnClose.Add_Click({ $dialog.Close() })

    [void]$dialog.ShowDialog($form)
}


function Get-ElkProfileByName {
    param([string]$Name)

    return @(
        $script:ElkProfiles |
        Where-Object { $_.Name -eq $Name }
    ) | Select-Object -First 1
}

function Get-ElkBrowserProfileDir {
    param([string]$ProfileName)

    $safe = Get-SafeFolderComponent -Name $ProfileName
    $dir = Join-Path $script:AghrabConfigDir ("browser-profiles\" + $safe)
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
    return $dir
}

function Resolve-ElkDashboardUrl {
    param(
        [string]$KibanaUrl,
        [string]$DashboardUrl
    )

    $dash = $DashboardUrl.Trim()

    if ($dash.StartsWith("http://") -or $dash.StartsWith("https://")) {
        return $dash
    }

    return $KibanaUrl.TrimEnd("/") + "/" + $dash.TrimStart("/")
}


function Get-ElkTimeRangePresets {
    return @(
        "Dashboard default",
        "Last 15 minutes",
        "Last 30 minutes",
        "Last 1 hour",
        "Last 4 hours",
        "Last 12 hours",
        "Last 24 hours",
        "Last 7 days",
        "Last 30 days"
    )
}

function Get-ElkTimeRangeInfo {
    param([string]$Label)

    switch ($Label) {
        "Last 15 minutes" {
            return [PSCustomObject]@{ Label="Last 15 minutes"; From="now-15m"; To="now"; Suffix="15M" }
        }
        "Last 30 minutes" {
            return [PSCustomObject]@{ Label="Last 30 minutes"; From="now-30m"; To="now"; Suffix="30M" }
        }
        "Last 1 hour" {
            return [PSCustomObject]@{ Label="Last 1 hour"; From="now-1h"; To="now"; Suffix="1H" }
        }
        "Last 4 hours" {
            return [PSCustomObject]@{ Label="Last 4 hours"; From="now-4h"; To="now"; Suffix="4H" }
        }
        "Last 12 hours" {
            return [PSCustomObject]@{ Label="Last 12 hours"; From="now-12h"; To="now"; Suffix="12H" }
        }
        "Last 24 hours" {
            return [PSCustomObject]@{ Label="Last 24 hours"; From="now-24h"; To="now"; Suffix="24H" }
        }
        "Last 7 days" {
            return [PSCustomObject]@{ Label="Last 7 days"; From="now-7d"; To="now"; Suffix="7D" }
        }
        "Last 30 days" {
            return [PSCustomObject]@{ Label="Last 30 days"; From="now-30d"; To="now"; Suffix="30D" }
        }
        default {
            return [PSCustomObject]@{ Label="Dashboard default"; From=$null; To=$null; Suffix="" }
        }
    }
}

function Normalize-ElkTimeRangeLabel {
    param([string]$Label)

    foreach ($preset in Get-ElkTimeRangePresets) {
        if ($preset -eq $Label) {
            return $preset
        }
    }

    return "Dashboard default"
}

function Apply-ElkTimeRangeToUrl {
    param(
        [string]$Url,
        [string]$TimeRange
    )

    $info = Get-ElkTimeRangeInfo -Label $TimeRange

    if ([string]::IsNullOrWhiteSpace([string]$info.From)) {
        return $Url
    }

    $timeRison = "time:(from:$($info.From),to:$($info.To))"
    $globalState = "($timeRison)"

    # Preserve existing Kibana global filters / refresh settings where possible.
    # We decode the existing _g RISON object, replace only the time object,
    # then URI-encode it again.
    $gMatch = [regex]::Match($Url, '([?&])_g=([^&]*)')

    if ($gMatch.Success) {
        $separator = $gMatch.Groups[1].Value
        $encodedValue = $gMatch.Groups[2].Value

        try {
            $decodedValue = [System.Uri]::UnescapeDataString($encodedValue)

            if ($decodedValue -match 'time:\([^)]*\)') {
                $decodedValue = [regex]::Replace(
                    $decodedValue,
                    'time:\([^)]*\)',
                    $timeRison,
                    1
                )
            }
            elseif ($decodedValue.StartsWith("(") -and $decodedValue.EndsWith(")")) {
                $inside = $decodedValue.Substring(1, $decodedValue.Length - 2)

                if ([string]::IsNullOrWhiteSpace($inside)) {
                    $decodedValue = "($timeRison)"
                }
                else {
                    $decodedValue = "(" + $inside.TrimEnd(",") + "," + $timeRison + ")"
                }
            }
            else {
                $decodedValue = $globalState
            }

            $newEncodedValue = [System.Uri]::EscapeDataString($decodedValue)
            $replacement = $separator + "_g=" + $newEncodedValue

            return (
                $Url.Substring(0, $gMatch.Index) +
                $replacement +
                $Url.Substring($gMatch.Index + $gMatch.Length)
            )
        }
        catch {
            # Fall back to replacing the _g object entirely.
            $newEncodedValue = [System.Uri]::EscapeDataString($globalState)
            $replacement = $separator + "_g=" + $newEncodedValue

            return (
                $Url.Substring(0, $gMatch.Index) +
                $replacement +
                $Url.Substring($gMatch.Index + $gMatch.Length)
            )
        }
    }

    $encodedGlobalState = [System.Uri]::EscapeDataString($globalState)

    # Kibana dashboard state normally lives after the # route.
    if ($Url.Contains("#")) {
        $hashIndex = $Url.IndexOf("#")
        $afterHash = $Url.Substring($hashIndex + 1)

        if ($afterHash.Contains("?")) {
            return $Url + "&_g=" + $encodedGlobalState
        }

        return $Url + "?_g=" + $encodedGlobalState
    }

    if ($Url.Contains("?")) {
        return $Url + "&_g=" + $encodedGlobalState
    }

    return $Url + "?_g=" + $encodedGlobalState
}

function Test-ElkSchedulerCaptchaPending {
    return (
        $script:ElkCaptchaPending -and
        [string]$script:ElkCaptchaPendingMode -in @(
            "scheduler",
            "scheduler-recheck"
        )
    )
}

function Set-ElkCaptchaPending {
    param(
        [string]$Mode,
        [string]$ProfileName = "",
        [string]$DashboardName = ""
    )

    if ([string]::IsNullOrWhiteSpace($ProfileName)) {
        $ProfileName = [string]$script:ElkLiveProfileName
    }

    $script:ElkCaptchaPending = $true
    $script:ElkCaptchaPendingMode = $Mode
    $script:ElkCaptchaPendingProfileName = $ProfileName
    $script:ElkCaptchaPendingDashboardName = $DashboardName
    $script:ElkCaptchaPendingSince = Get-Date

    if ($null -ne $btnElkContinueCaptcha) {
        $btnElkContinueCaptcha.Enabled = $true
    }

    if ($null -ne $lblElkSessionStatus) {
        $lblElkSessionStatus.Text = "CAPTCHA: MANUAL ACTION REQUIRED"
        $lblElkSessionStatus.ForeColor = [System.Drawing.Color]::DarkOrange
    }

    if ($null -ne $txtElkLog) {
        $txtElkLog.AppendText(
            "CAPTCHA detected -> RAQEB paused. Solve it manually in the open browser, then click Continue CAPTCHA.`r`n"
        )
    }

    if ($Mode -in @("scheduler","scheduler-recheck")) {
        $script:SchedulerNextRun = $null

        try {
            Write-SchedulerLog (
                "CAPTCHA DETECTED -> Automatic Capture PAUSED. Profile='" +
                $ProfileName + "'" +
                $(if ([string]::IsNullOrWhiteSpace($DashboardName)) {
                    ""
                } else {
                    "; Dashboard='" + $DashboardName + "'"
                }) +
                ". Solve CAPTCHA in the open browser and click Continue CAPTCHA."
            )
        }
        catch {}

        try { Update-SchedulerStateUi } catch {}
        try { Update-HeaderStatus } catch {}
    }

    try {
        Write-SecurityAudit `
            -Action "CAPTCHA_MANUAL_REQUIRED" `
            -Detail (
                "Mode=" + $Mode +
                "; Profile=" + $ProfileName +
                $(if ([string]::IsNullOrWhiteSpace($DashboardName)) {
                    ""
                } else {
                    "; Dashboard=" + $DashboardName
                })
            )
    }
    catch {}

    try {
        $notify = Ensure-HealthNotifyIcon
        if ($null -ne $notify) {
            $notify.BalloonTipTitle = "RAQEB - CAPTCHA Required"
            $notify.BalloonTipText = "Automation is paused. Solve the CAPTCHA in the open browser, then click Continue CAPTCHA in RAQEB."
            $notify.BalloonTipIcon = [System.Windows.Forms.ToolTipIcon]::Warning
            $notify.ShowBalloonTip(7000)
        }
    }
    catch {}

    try {
        $form.WindowState = [System.Windows.Forms.FormWindowState]::Normal
        $form.Show()
        $form.Activate()
        $form.BringToFront()
    }
    catch {}

    [System.Windows.Forms.MessageBox]::Show(
        $form,
        (
            "CAPTCHA detected.`r`n`r`n" +
            "RAQEB PAUSED the login/capture. CAPTCHA is not solved automatically.`r`n`r`n" +
            "1. Solve the CAPTCHA manually in the browser that is already open.`r`n" +
            "2. Do NOT close that browser.`r`n" +
            "3. Return to RAQEB and click Continue CAPTCHA.`r`n`r`n" +
            "RAQEB will reuse the authenticated session while it remains valid."
        ),
        "RAQEB - Manual CAPTCHA Required",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Information
    ) | Out-Null
}

function Clear-ElkCaptchaPending {
    $script:ElkCaptchaPending = $false
    $script:ElkCaptchaPendingMode = $null
    $script:ElkCaptchaPendingProfileName = ""
    $script:ElkCaptchaPendingDashboardName = ""
    $script:ElkCaptchaPendingSince = $null

    if ($null -ne $btnElkContinueCaptcha) {
        $btnElkContinueCaptcha.Enabled = $false
    }

    try { Update-SchedulerStateUi } catch {}
    try { Update-HeaderStatus } catch {}
}

function Test-ElkAutoLoginFields {
    param([switch]$ShowMessage)

    if (-not $chkElkAutoLogin.Checked) {
        return $true
    }

    $username = $txtElkAuthUser.Text.Trim()
    $password = $txtElkAuthPassword.Text

    if ([string]::IsNullOrWhiteSpace($username)) {
        $tabs.SelectedTab = $tabElk
        $txtElkAuthUser.Focus()

        if ($ShowMessage) {
            [System.Windows.Forms.MessageBox]::Show(
                "Auto Login is enabled, but Username is empty.",
                "aghrab"
            )
        }

        return $false
    }

    if ([string]::IsNullOrWhiteSpace($password)) {
        $tabs.SelectedTab = $tabElk
        $txtElkAuthPassword.Focus()

        if ($ShowMessage) {
            [System.Windows.Forms.MessageBox]::Show(
                "Auto Login is enabled, but Password is empty.",
                "aghrab"
            )
        }

        return $false
    }

    return $true
}

function Update-ElkAuthUiState {
    if ($null -eq $chkElkAutoLogin) {
        return
    }

    $enabled = [bool]$chkElkAutoLogin.Checked

    $txtElkAuthUser.Enabled = $enabled
    $txtElkAuthPassword.Enabled = $enabled
    $btnElkTestLogin.Enabled = $enabled

    if ($enabled) {
        $grpElkAuth.ForeColor = $Navy
    }
    else {
        $grpElkAuth.ForeColor = [System.Drawing.Color]::DimGray
    }
}

function Refresh-ElkProfileList {
    $current = $null
    if ($lstElkProfiles.SelectedItem) {
        $current = $lstElkProfiles.SelectedItem.ToString()
    }

    $lstElkProfiles.Items.Clear()

    foreach ($profile in @($script:ElkProfiles | Sort-Object Name)) {
        [void]$lstElkProfiles.Items.Add([string]$profile.Name)
    }

    if ($lstElkProfiles.Items.Count -gt 0) {
        $targetIndex = 0

        if ($current) {
            for ($i = 0; $i -lt $lstElkProfiles.Items.Count; $i++) {
                if ($lstElkProfiles.Items[$i].ToString() -eq $current) {
                    $targetIndex = $i
                    break
                }
            }
        }

        $lstElkProfiles.SelectedIndex = $targetIndex
    }
}

function Clear-ElkProfileEditor {
    $script:EditingElkProfileName = $null
    $txtElkProfileName.Text = ""
    $txtElkKibanaUrl.Text = ""
    $numElkWait.Value = 12
    $numElkScrollDelay.Value = 1200
    $numElkFinalSettle.Value = 5
    $numElkTimeout.Value = 60
    $chkElkAutoLogin.Checked = $false
    $txtElkAuthUser.Text = ""
    $txtElkAuthPassword.Text = ""

    $script:EditorFieldVerifyEnabled = $false
    $script:EditorElasticsearchUrl = ""
    $script:EditorFieldVerifyApiKeyProtected = ""
    $script:EditorFieldVerifyTimeField = "@timestamp"
    $script:EditorFieldVerifyWindowMinutes = 15
    $script:EditorFieldVerifyIgnoreTls = $true

    $lvElkDashboards.Items.Clear()
    $txtElkDashboardName.Text = ""
    $txtElkDashboardUrl.Text = ""
    if ($null -ne $txtElkDashboardIndex) { $txtElkDashboardIndex.Text = "" }
    if ($null -ne $txtElkExpectedFields) { $txtElkExpectedFields.Text = "" }
    $cmbElkTimeRange.SelectedItem = "Last 1 hour"
    Update-ElkAuthUiState
}

function Load-ElkProfileEditor {
    param([string]$ProfileName)

    $profile = Get-ElkProfileByName -Name $ProfileName
    if (-not $profile) {
        return
    }

    $script:LoadingElkProfileEditor = $true
    $script:EditingElkProfileName = [string]$profile.Name
    $txtElkProfileName.Text = [string]$profile.Name
    $txtElkKibanaUrl.Text = [string]$profile.KibanaUrl

    $script:EditorFieldVerifyEnabled = [bool]$profile.FieldVerifyEnabled
    $script:EditorElasticsearchUrl = [string]$profile.ElasticsearchUrl
    $script:EditorFieldVerifyApiKeyProtected = [string]$profile.FieldVerifyApiKeyProtected
    $script:EditorFieldVerifyTimeField = $(if ([string]::IsNullOrWhiteSpace([string]$profile.FieldVerifyTimeField)) { "@timestamp" } else { [string]$profile.FieldVerifyTimeField })
    try {
        $script:EditorFieldVerifyWindowMinutes = [Math]::Min(1440,[Math]::Max(1,[int]$profile.FieldVerifyWindowMinutes))
    } catch {
        $script:EditorFieldVerifyWindowMinutes = 15
    }
    $script:EditorFieldVerifyIgnoreTls = $(if ($null -eq $profile.FieldVerifyIgnoreTls) { $true } else { [bool]$profile.FieldVerifyIgnoreTls })

    if ($null -ne $profile.WaitAfterLoad) {
        $numElkWait.Value = [Math]::Min([decimal]60,[Math]::Max([decimal]0,[decimal]$profile.WaitAfterLoad))
    }

    if ($null -ne $profile.ScrollDelay) {
        $numElkScrollDelay.Value = [Math]::Min([decimal]5000,[Math]::Max([decimal]100,[decimal]$profile.ScrollDelay))
    }

    if ($null -ne $profile.FinalSettle) {
        $numElkFinalSettle.Value = [Math]::Min([decimal]30,[Math]::Max([decimal]0,[decimal]$profile.FinalSettle))
    }

    if ($null -ne $profile.Timeout) {
        $numElkTimeout.Value = [Math]::Min([decimal]180,[Math]::Max([decimal]10,[decimal]$profile.Timeout))
    }

    $lvElkDashboards.Items.Clear()

    foreach ($dashboard in @($profile.Dashboards)) {
        $timeRange = "Dashboard default"

        if ($null -ne $dashboard.TimeRange) {
            $timeRange = Normalize-ElkTimeRangeLabel -Label ([string]$dashboard.TimeRange)
        }

        $item = New-Object System.Windows.Forms.ListViewItem([string]$dashboard.Name)
        [void]$item.SubItems.Add($timeRange)
        [void]$item.SubItems.Add([string]$dashboard.Url)
        [void]$item.SubItems.Add([string]$dashboard.IndexPattern)
        [void]$item.SubItems.Add([string]$dashboard.ExpectedFields)
        [void]$lvElkDashboards.Items.Add($item)
    }

    $chkElkAutoLogin.Checked = $false
    if ($null -ne $profile.AutoLoginEnabled) {
        $chkElkAutoLogin.Checked = [bool]$profile.AutoLoginEnabled
    }

    $txtElkAuthUser.Text = ""
    if ($null -ne $profile.Username) {
        $txtElkAuthUser.Text = [string]$profile.Username
    }

    $txtElkAuthPassword.Text = ""
    try {
        $loadedPassword = Get-ElkProfileCredential -Profile $profile
        if (-not [string]::IsNullOrWhiteSpace($loadedPassword)) {
            $txtElkAuthPassword.Text = $loadedPassword
        }
    }
    catch {}

    $txtElkDashboardName.Text = ""
    $txtElkDashboardUrl.Text = ""
    $txtElkDashboardIndex.Text = ""
    $txtElkExpectedFields.Text = ""
    $cmbElkTimeRange.SelectedItem = "Last 1 hour"
    Update-ElkAuthUiState
    $script:LoadingElkProfileEditor = $false
}

function Get-ElkDashboardsFromEditor {
    $dashboards = @()

    foreach ($item in $lvElkDashboards.Items) {
        $dashboards += [PSCustomObject]@{
            Name = [string]$item.Text
            TimeRange = [string]$item.SubItems[1].Text
            Url = [string]$item.SubItems[2].Text
            IndexPattern = $(if ($item.SubItems.Count -gt 3) { [string]$item.SubItems[3].Text } else { "" })
            ExpectedFields = $(if ($item.SubItems.Count -gt 4) { [string]$item.SubItems[4].Text } else { "" })
        }
    }

    return @($dashboards)
}

function Save-CurrentElkProfile {
    param([switch]$Silent)

    $name = $txtElkProfileName.Text.Trim()
    $kibana = $txtElkKibanaUrl.Text.Trim()

    if ([string]::IsNullOrWhiteSpace($name)) {
        if (-not $Silent) {
            [System.Windows.Forms.MessageBox]::Show("Profile name is required.","aghrab")
        }
        return $null
    }

    if ([string]::IsNullOrWhiteSpace($kibana)) {
        if (-not $Silent) {
            [System.Windows.Forms.MessageBox]::Show("Kibana URL is required.","aghrab")
        }
        return $null
    }

    if (-not ($kibana.StartsWith("http://") -or $kibana.StartsWith("https://"))) {
        $kibana = "https://" + $kibana
        $txtElkKibanaUrl.Text = $kibana
    }

    $autoLoginEnabled = [bool]$chkElkAutoLogin.Checked
    $username = $txtElkAuthUser.Text.Trim()
    $passwordPlain = $txtElkAuthPassword.Text

    if ($autoLoginEnabled -and -not (Test-ElkAutoLoginFields -ShowMessage:(!$Silent))) {
        return $null
    }

    $passwordProtected = ""

    if (-not [string]::IsNullOrWhiteSpace($passwordPlain)) {
        # Save to both locations:
        # - profile JSON for backward compatibility
        # - dedicated credential file for reliability
        $passwordProtected = Save-ElkProfileCredential `
            -ProfileName $name `
            -PlainText $passwordPlain
    }
    else {
        # IMPORTANT:
        # Several actions call Save-CurrentElkProfile -Silent.
        # A blank textbox must NOT erase a credential that was already saved.
        $existing = $null
        if (-not [string]::IsNullOrWhiteSpace([string]$script:EditingElkProfileName)) {
            $existing = Get-ElkProfileByName -Name ([string]$script:EditingElkProfileName)
        }
        if ($null -eq $existing) {
            $existing = Get-ElkProfileByName -Name $name
        }

        if ($null -ne $existing -and
            -not [string]::IsNullOrWhiteSpace([string]$existing.PasswordProtected)) {
            $passwordProtected = [string]$existing.PasswordProtected
        }
        else {
            # If JSON was empty but a dedicated credential file exists,
            # preserve/recreate the JSON value from that credential.
            try {
                $existingPlain = Get-ElkProfileCredential -Profile $existing
                if (-not [string]::IsNullOrWhiteSpace($existingPlain)) {
                    $passwordProtected = Protect-SecretForCurrentUser -PlainText $existingPlain
                }
            }
            catch {}
        }
    }

    $profile = [PSCustomObject]@{
        Name = $name
        KibanaUrl = $kibana
        WaitAfterLoad = [int]$numElkWait.Value
        ScrollDelay = [int]$numElkScrollDelay.Value
        FinalSettle = [int]$numElkFinalSettle.Value
        Timeout = [int]$numElkTimeout.Value
        AutoLoginEnabled = $autoLoginEnabled
        Username = $username
        PasswordProtected = $passwordProtected

        FieldVerifyEnabled = [bool]$script:EditorFieldVerifyEnabled
        ElasticsearchUrl = [string]$script:EditorElasticsearchUrl
        FieldVerifyApiKeyProtected = [string]$script:EditorFieldVerifyApiKeyProtected
        FieldVerifyTimeField = [string]$script:EditorFieldVerifyTimeField
        FieldVerifyWindowMinutes = [int]$script:EditorFieldVerifyWindowMinutes
        FieldVerifyIgnoreTls = [bool]$script:EditorFieldVerifyIgnoreTls

        Dashboards = @(Get-ElkDashboardsFromEditor)
    }

    $removeNames = @($name)
    if ($script:EditingElkProfileName) {
        $removeNames += $script:EditingElkProfileName
    }

    $script:ElkProfiles = @(
        $script:ElkProfiles |
        Where-Object { $removeNames -notcontains $_.Name }
    )

    $script:ElkProfiles += $profile
    Save-ElkProfiles
    $script:EditingElkProfileName = $name

    Refresh-ElkProfileList

    # Refresh-ElkProfileList can reload the editor. Keep the password that the
    # user just entered visible in the current process; only the encrypted copy
    # is written to disk.
    if ($autoLoginEnabled -and -not [string]::IsNullOrWhiteSpace($passwordPlain)) {
        $txtElkAuthPassword.Text = $passwordPlain
    }

    for ($i = 0; $i -lt $lstElkProfiles.Items.Count; $i++) {
        if ($lstElkProfiles.Items[$i].ToString() -eq $name) {
            $lstElkProfiles.SelectedIndex = $i
            break
        }
    }

    try {
        if ($null -ne $cmbSchedulerProfile) {
            Refresh-SchedulerProfiles
            Update-SchedulerStateUi
        }
    }
    catch {}

    if (-not $Silent) {
        [System.Windows.Forms.MessageBox]::Show("Profile saved.","aghrab")
    }

    return $profile
}

function Get-SelectedElkDashboardItem {
    if ($lvElkDashboards.SelectedItems.Count -eq 0) {
        return $null
    }

    return $lvElkDashboards.SelectedItems[0]
}

function Capture-ElkDashboard {
    param(
        $Profile,
        $Dashboard,
        [string]$Browser,
        [string]$OutputRoot,
        [int]$LiveCdpPort = 0
    )

    $url = Resolve-ElkDashboardUrl `
        -KibanaUrl ([string]$Profile.KibanaUrl) `
        -DashboardUrl ([string]$Dashboard.Url)

    $timeRange = "Dashboard default"
    if ($null -ne $Dashboard.TimeRange) {
        $timeRange = Normalize-ElkTimeRangeLabel -Label ([string]$Dashboard.TimeRange)
    }

    $url = Apply-ElkTimeRangeToUrl `
        -Url $url `
        -TimeRange $timeRange

    $timeInfo = Get-ElkTimeRangeInfo -Label $timeRange
    $albumLabel = ([string]$Profile.Name) + " - " + ([string]$Dashboard.Name)

    if (-not [string]::IsNullOrWhiteSpace([string]$timeInfo.Suffix)) {
        $albumLabel += " - " + [string]$timeInfo.Suffix
    }

    $albumName = Get-SafeFolderComponent -Name $albumLabel
    $albumPath = Join-Path $OutputRoot $albumName
    New-Item -ItemType Directory -Force -Path $albumPath | Out-Null
    [void](Ensure-AlbumRetentionPolicy -AlbumPath $albumPath)

    $timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss-fff"
    $file = Join-Path $albumPath ($timestamp + ".png")

    if ($LiveCdpPort -gt 0) {
        $dimensions = Capture-FullPageScreenshotFromLiveSession `
            -Port $LiveCdpPort `
            -Url $url `
            -File $file `
            -Width 1920 `
            -Height 1080 `
            -WaitAfterLoadMs ([int]$Profile.WaitAfterLoad * 1000) `
            -ScrollDelayMs ([int]$Profile.ScrollDelay) `
            -FinalSettleMs ([int]$Profile.FinalSettle * 1000) `
            -TimeoutMs ([int]$Profile.Timeout * 1000)
    }
    else {
        $profileDir = Get-ElkBrowserProfileDir -ProfileName ([string]$Profile.Name)

        $dimensions = Capture-FullPageScreenshot `
            -Browser $Browser `
            -Url $url `
            -File $file `
            -ProfileDir $profileDir `
            -Width 1920 `
            -Height 1080 `
            -IgnoreCertificateErrors $true `
            -WaitAfterLoadMs ([int]$Profile.WaitAfterLoad * 1000) `
            -ScrollDelayMs ([int]$Profile.ScrollDelay) `
            -FinalSettleMs ([int]$Profile.FinalSettle * 1000) `
            -TimeoutMs ([int]$Profile.Timeout * 1000)
    }

    if (-not (Test-Path -LiteralPath $file -PathType Leaf)) {
        throw "Screenshot file was not created."
    }

    $retention = Apply-AlbumSavedRetentionPolicy -AlbumPath $albumPath

    return [PSCustomObject]@{
        Url = $url
        File = $file
        Album = $albumName
        TimeRange = $timeRange
        Width = $dimensions.Width
        Height = $dimensions.Height
        RemovedByAge = $retention.RemovedByAge
        RemovedByLimit = $retention.RemovedByLimit
    }
}


# ---------------- Built-in local AI helpers ----------------
function Get-AiPaths {
    $aiRoot = Join-Path $BaseDir "AI"

    return [PSCustomObject]@{
        Root = $aiRoot
        RuntimeDir = Join-Path $aiRoot "runtime"
        ModelsDir = Join-Path $aiRoot "models"
        LogsDir = Join-Path $aiRoot "logs"
        CacheDir = Join-Path $aiRoot "cache"
        Server = Join-Path (Join-Path $aiRoot "runtime") "llama-server.exe"
        Model = Join-Path (Join-Path $aiRoot "models") "Qwen2.5-VL-3B-Instruct-Q4_K_M.gguf"
        Mmproj = Join-Path (Join-Path $aiRoot "models") "mmproj-Qwen2.5-VL-3B-Instruct-Q8_0.gguf"
    }
}

function Test-AiPackInstalled {
    $p = Get-AiPaths

    return (
        (Test-Path -LiteralPath $p.Server -PathType Leaf) -and
        (Test-Path -LiteralPath $p.Model -PathType Leaf) -and
        (Test-Path -LiteralPath $p.Mmproj -PathType Leaf)
    )
}

function Test-AiServerReady {
    if ([string]::IsNullOrWhiteSpace($script:AiBaseUrl)) {
        return $false
    }

    try {
        $null = Invoke-RestMethod `
            -Uri ($script:AiBaseUrl + "/health") `
            -Method Get `
            -TimeoutSec 2

        return $true
    }
    catch {
        return $false
    }
}

function Update-AnalyzeAiVisual {
    if ($null -eq $panelAnalyzeAiState -or $null -eq $lblAiStatus) { return }

    try {
        $p = Get-AghrabPalette -Theme $script:CurrentTheme
        $source = [string]$lblAiStatus.Text

        if ($source -match "Status:\s*Ready") {
            $v = Get-HealthStatusVisual -Status "Healthy" -Theme $script:CurrentTheme
        }
        elseif ($source -match "Installed / Stopped") {
            $v = Get-HealthStatusVisual -Status "Warning" -Theme $script:CurrentTheme
        }
        elseif ($source -match "not installed") {
            $v = Get-HealthStatusVisual -Status "Critical" -Theme $script:CurrentTheme
        }
        else {
            $v = Get-HealthStatusVisual -Status "Unknown" -Theme $script:CurrentTheme
        }

        $panelAnalyzeAiState.BackColor = $v.Back
        $lblAiStatus.ForeColor = $v.Fore
        $lblAnalyzeAiStateTitle.ForeColor = $p.Muted
        Set-RoundedControlRegion -Control $panelAnalyzeAiState -Radius 10
    }
    catch {}
}

function Update-AiStatus {
    if ($null -eq $lblAiStatus) {
        return
    }

    if (Test-AiServerReady) {
        $lblAiStatus.Text = Convert-AghrabUiText -Text "Status: Ready" -Language $script:CurrentLanguage
        $lblAiStatus.ForeColor = [System.Drawing.Color]::DarkGreen
        try { Update-AnalyzeAiVisual } catch {}
        try { Update-HeaderStatus } catch {}
        return
    }

    if (Test-AiPackInstalled) {
        $lblAiStatus.Text = Convert-AghrabUiText -Text "Status: Installed / Stopped" -Language $script:CurrentLanguage
        $lblAiStatus.ForeColor = [System.Drawing.Color]::DarkOrange
        try { Update-AnalyzeAiVisual } catch {}
        try { Update-HeaderStatus } catch {}
        return
    }

    $lblAiStatus.Text = Convert-AghrabUiText -Text "Status: AI Pack not installed" -Language $script:CurrentLanguage
    $lblAiStatus.ForeColor = [System.Drawing.Color]::DarkRed
    try { Update-AnalyzeAiVisual } catch {}
    try { Update-HeaderStatus } catch {}
}

function Stop-BuiltInAi {
    $wasRunning = ($script:AiProcess -ne $null -or -not [string]::IsNullOrWhiteSpace($script:AiBaseUrl))

    if ($script:AiProcess -ne $null) {
        try {
            if (-not $script:AiProcess.HasExited) {
                try { $script:AiProcess.Kill() } catch {}
                try { $script:AiProcess.WaitForExit(2500) } catch {}
            }
        } catch {}
    }

    $script:AiProcess = $null
    $script:AiPort = 0
    $script:AiBaseUrl = $null

    if ($null -ne $txtAiResult) {
        $txtAiResult.AppendText("AI server stopped.`r`n")
    }

    Update-AiStatus

    if ($wasRunning) {
        Write-SecurityAudit -Action "AI_STOP" -Detail "Local AI server stopped."
    }
}

function Test-RaqebAiPackIntegrity {
    $paths = Get-AiPaths
    if ($script:AiIntegrityVerified) {
        return [PSCustomObject]@{ Ok=$true; Mode="Verified"; Detail="Already verified in this session." }
    }
    try {
        if (-not (Test-Path -LiteralPath $paths.Server -PathType Leaf) -or
            -not (Test-Path -LiteralPath $paths.Model -PathType Leaf) -or
            -not (Test-Path -LiteralPath $paths.Mmproj -PathType Leaf)) {
            return [PSCustomObject]@{ Ok=$false; Mode="Missing"; Detail="One or more AI Pack files are missing." }
        }
        $modelHash = (Get-FileHash -LiteralPath $paths.Model -Algorithm SHA256 -ErrorAction Stop).Hash.ToLowerInvariant()
        if ($modelHash -ne "d02fe9b69ad8cadbbd228e387667af66612c44bed29ffc8eb1e7caf9ac486c12") {
            return [PSCustomObject]@{ Ok=$false; Mode="Changed"; Detail="Qwen model SHA256 does not match the pinned upstream hash." }
        }
        $mmprojHash = (Get-FileHash -LiteralPath $paths.Mmproj -Algorithm SHA256 -ErrorAction Stop).Hash.ToLowerInvariant()
        if ($mmprojHash -ne "980c9b2f78c04e6cff93d277ada09e768394f112d75db3b4e9dea8a69f9fb904") {
            return [PSCustomObject]@{ Ok=$false; Mode="Changed"; Detail="Qwen multimodal projector SHA256 does not match the pinned upstream hash." }
        }
        $manifestPath = Join-Path $paths.RuntimeDir "runtime-sha256.json"
        if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) {
            return [PSCustomObject]@{ Ok=$true; Mode="Legacy"; Detail="AI runtime manifest is missing. Re-run Prepare-AI-Pack.bat for full runtime verification." }
        }
        $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json -ErrorAction Stop
        if ([string]$manifest.format -ne "RAQEB-AI-RUNTIME-MANIFEST") {
            return [PSCustomObject]@{ Ok=$false; Mode="Changed"; Detail="AI runtime manifest format is invalid." }
        }
        if (([string]$manifest.source_archive_sha256).ToLowerInvariant() -ne "917f39c076402c421224824607397af20f53625a60defc20e8dd22446bf4c5d7") {
            return [PSCustomObject]@{ Ok=$false; Mode="Changed"; Detail="AI runtime manifest is not tied to the pinned llama.cpp archive." }
        }
        $checked = 0
        foreach ($item in @($manifest.files)) {
            $name = [string]$item.name
            $expected = ([string]$item.sha256).ToLowerInvariant()
            if ([string]::IsNullOrWhiteSpace($name) -or $expected -notmatch '^[0-9a-f]{64}$') { continue }
            $file = Join-Path $paths.RuntimeDir $name
            if (-not (Test-Path -LiteralPath $file -PathType Leaf)) {
                return [PSCustomObject]@{ Ok=$false; Mode="Changed"; Detail=("Missing AI runtime file: " + $name) }
            }
            $actual = (Get-FileHash -LiteralPath $file -Algorithm SHA256 -ErrorAction Stop).Hash.ToLowerInvariant()
            if ($actual -ne $expected) {
                return [PSCustomObject]@{ Ok=$false; Mode="Changed"; Detail=("AI runtime SHA256 mismatch: " + $name) }
            }
            $checked++
        }
        if ($checked -lt 1) {
            return [PSCustomObject]@{ Ok=$false; Mode="Changed"; Detail="AI runtime manifest contains no verifiable files." }
        }
        $script:AiIntegrityVerified = $true
        return [PSCustomObject]@{ Ok=$true; Mode="Verified"; Detail=("AI model, mmproj and " + $checked + " runtime file(s) passed SHA256 verification.") }
    } catch {
        return [PSCustomObject]@{ Ok=$false; Mode="Error"; Detail=$_.Exception.Message }
    }
}

function Start-BuiltInAi {
    if (-not (Test-AghrabCommercialFeatureAccess -Feature "AI")) {
        Show-AghrabLicenseRestriction -FeatureName "Local AI"
        return $false
    }

    if (Test-AiServerReady) {
        Update-AiStatus
        return $true
    }

    $paths = Get-AiPaths

    if (-not (Test-AiPackInstalled)) {
        throw (
            "Built-in AI Pack is not installed.`r`n`r`n" +
            "Run Prepare-AI-Pack.bat on an Internet-connected Windows PC, " +
            "then copy the complete RAQEB folder to the offline machine."
        )
    }

    if ($null -ne $txtAiResult) {
        $txtAiResult.AppendText("Verifying AI Pack SHA256 integrity...`r`n")
    }

    $aiIntegrity = Test-RaqebAiPackIntegrity
    if (-not [bool]$aiIntegrity.Ok) {
        Write-SecurityAudit -Action "AI_INTEGRITY_BLOCK" -Detail ([string]$aiIntegrity.Detail)
        throw (
            "AI Pack integrity verification failed.`r`n`r`n" +
            [string]$aiIntegrity.Detail + "`r`n`r`n" +
            "Re-run Prepare-AI-Pack.bat from the trusted RAQEB package."
        )
    }

    if ([string]$aiIntegrity.Mode -eq "Legacy") {
        Write-SecurityAudit -Action "AI_INTEGRITY_LEGACY" -Detail ([string]$aiIntegrity.Detail)
        if (-not $script:AiIntegrityLegacyWarningShown) {
            $script:AiIntegrityLegacyWarningShown = $true
            if ($null -ne $txtAiResult) {
                $txtAiResult.AppendText(
                    "Security note: legacy AI runtime detected. Model hashes are verified, " +
                    "but the runtime manifest is missing. Re-run Prepare-AI-Pack.bat for full verification.`r`n"
                )
            }
        }
    }
    else {
        Write-SecurityAudit -Action "AI_INTEGRITY_OK" -Detail ([string]$aiIntegrity.Detail)
        if ($null -ne $txtAiResult) { $txtAiResult.AppendText(([string]$aiIntegrity.Detail + "`r`n")) }
    }

    New-Item -ItemType Directory -Force -Path $paths.LogsDir | Out-Null
    New-Item -ItemType Directory -Force -Path $paths.CacheDir | Out-Null

    $port = Get-FreeTcpPort
    $threads = [Math]::Max(
        2,
        [Math]::Min(8, [Environment]::ProcessorCount)
    )

    $stdoutLog = Join-Path $paths.LogsDir "llama-server.stdout.log"
    $stderrLog = Join-Path $paths.LogsDir "llama-server.stderr.log"

    try { Remove-Item -LiteralPath $stdoutLog -Force -ErrorAction SilentlyContinue } catch {}
    try { Remove-Item -LiteralPath $stderrLog -Force -ErrorAction SilentlyContinue } catch {}

    # Keep llama-server startup as close as possible to the command that was
    # verified manually with llama-cli.exe on the same machine/model/mmproj.
    # Avoid optional tuning flags until the multimodal server is proven stable.
    $args = @(
        "-m", '"' + $paths.Model + '"',
        "--mmproj", '"' + $paths.Mmproj + '"',
        "--no-mmproj-offload",
        "-c", "2048",
        "-ngl", "0",
        "--host", "127.0.0.1",
        "--port", "$port"
    )

    if ($null -ne $txtAiResult) {
        $txtAiResult.AppendText(
            "Starting built-in AI with verified minimal Vision server command...`r`n" +
            "Model: Qwen2.5-VL-3B Q4_K_M`r`n" +
            "Context: 8192 | GPU layers: 0 | Vision offload: disabled`r`n" +
            "Model load can take 10-90 seconds on CPU.`r`n"
        )
    }

    # The exact command below was manually verified in CMD on the same
    # machine/model/mmproj. Execute it through a generated CMD wrapper so
    # Windows PowerShell cannot re-quote the argument list differently.
    $wrapperPath = Join-Path $paths.LogsDir "start-llama-server.cmd"

    $serverCommand = (
        '"' + $paths.Server + '"' +
        ' -m "' + $paths.Model + '"' +
        ' --mmproj "' + $paths.Mmproj + '"' +
        ' --no-mmproj-offload' +
        ' -c 8192' +
        ' -ngl 0' +
        ' --media-path "' + $paths.CacheDir + '"' +
        ' --host 127.0.0.1' +
        ' --port ' + $port
    )

    $wrapper = @(
        '@echo off',
        'cd /d "' + $paths.RuntimeDir + '"',
        $serverCommand,
        'exit /b %ERRORLEVEL%'
    )

    $wrapper | Set-Content `
        -LiteralPath $wrapperPath `
        -Encoding ASCII `
        -Force

    if ($null -ne $txtAiResult) {
        $txtAiResult.AppendText(
            "Server command (CMD wrapper):`r`n" +
            $serverCommand + "`r`n`r`n"
        )
    }

    $process = Start-Process `
        -FilePath "cmd.exe" `
        -ArgumentList @("/d", "/c", ('"' + $wrapperPath + '"')) `
        -WorkingDirectory $paths.RuntimeDir `
        -WindowStyle Hidden `
        -RedirectStandardOutput $stdoutLog `
        -RedirectStandardError $stderrLog `
        -PassThru

    $script:AiProcess = $process
    $script:AiPort = $port
    $script:AiBaseUrl = "http://127.0.0.1:$port"

    $watch = [System.Diagnostics.Stopwatch]::StartNew()

    while ($watch.Elapsed.TotalSeconds -lt 180) {
        [System.Windows.Forms.Application]::DoEvents()

        if ($process.HasExited) {
            $detailParts = @()

            try {
                if (Test-Path -LiteralPath $stderrLog) {
                    $stderrLines = @(
                        Get-Content -LiteralPath $stderrLog -Tail 80 -ErrorAction SilentlyContinue
                    )

                    if ($stderrLines.Count -gt 0) {
                        $detailParts += "----- stderr -----"
                        $detailParts += $stderrLines
                    }
                }
            } catch {}

            try {
                if (Test-Path -LiteralPath $stdoutLog) {
                    $stdoutLines = @(
                        Get-Content -LiteralPath $stdoutLog -Tail 80 -ErrorAction SilentlyContinue
                    )

                    if ($stdoutLines.Count -gt 0) {
                        $detailParts += "----- stdout -----"
                        $detailParts += $stdoutLines
                    }
                }
            } catch {}

            $exitCode = $null
            try { $exitCode = $process.ExitCode } catch {}

            $detail = ($detailParts -join "`r`n")

            Stop-BuiltInAi

            throw (
                "AI server exited while loading the model." +
                $(if ($null -ne $exitCode) { " Exit code: " + $exitCode + "." } else { "" }) +
                "`r`nWrapper: " + $wrapperPath +
                $(if ($detail) { "`r`n`r`n" + $detail } else { "" })
            )
        }

        if (Test-AiServerReady) {
            Update-AiStatus

            if ($null -ne $txtAiResult) {
                $txtAiResult.AppendText(
                    "AI Ready -> " + $script:AiBaseUrl + "`r`n"
                )
            }

            Write-SecurityAudit -Action "AI_START" -Detail ("Local AI ready on 127.0.0.1:" + $port)
            return $true
        }

        Start-Sleep -Milliseconds 500
    }

    Stop-BuiltInAi
    throw "AI server start timed out after 180 seconds."
}

function Convert-ImageToAiTempJpeg {
    param(
        [string]$Path,
        [int]$MaxWidth = 1600,
        [int]$MaxHeight = 2200
    )

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "Image not found: $Path"
    }

    $paths = Get-AiPaths
    $cacheDir = $paths.CacheDir
    New-Item -ItemType Directory -Force -Path $cacheDir | Out-Null

    $bytes = [System.IO.File]::ReadAllBytes($Path)
    $inputStream = New-Object System.IO.MemoryStream(,$bytes)
    $source = [System.Drawing.Image]::FromStream($inputStream)

    try {
        $scaleW = $MaxWidth / [double]$source.Width
        $scaleH = $MaxHeight / [double]$source.Height
        $scale = [Math]::Min(1.0, [Math]::Min($scaleW, $scaleH))

        $newWidth = [Math]::Max(1, [int][Math]::Round($source.Width * $scale))
        $newHeight = [Math]::Max(1, [int][Math]::Round($source.Height * $scale))

        $bmp = New-Object System.Drawing.Bitmap($newWidth, $newHeight)
        $g = [System.Drawing.Graphics]::FromImage($bmp)

        try {
            $g.Clear([System.Drawing.Color]::White)
            $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
            $g.DrawImage(
                $source,
                (New-Object System.Drawing.Rectangle(0,0,$newWidth,$newHeight))
            )
        }
        finally {
            $g.Dispose()
        }

        $name = (
            "ai-" +
            (Get-Date -Format "yyyyMMdd-HHmmss-fff") +
            "-" +
            [Guid]::NewGuid().ToString("N").Substring(0,8) +
            ".jpg"
        )

        $outPath = Join-Path $cacheDir $name

        try {
            $bmp.Save($outPath, [System.Drawing.Imaging.ImageFormat]::Jpeg)
        }
        finally {
            $bmp.Dispose()
        }

        return $outPath
    }
    finally {
        $source.Dispose()
        $inputStream.Dispose()
    }
}

function Get-AiHttpErrorDetail {
    param($ErrorRecord)

    $detail = ""

    try {
        $response = $ErrorRecord.Exception.Response
        if ($null -ne $response) {
            $stream = $response.GetResponseStream()
            if ($null -ne $stream) {
                $reader = New-Object System.IO.StreamReader($stream)
                try { $detail = $reader.ReadToEnd() }
                finally {
                    $reader.Dispose()
                    $stream.Dispose()
                }
            }
        }
    }
    catch {}

    return $detail
}

function Invoke-AiVisionRequest {
    param(
        [string]$Prompt,
        [string[]]$ImagePaths
    )

    if (-not (Test-AiServerReady)) {
        [void](Start-BuiltInAi)
    }

    $tempFiles = @()

    try {
        $content = @()
        $content += @{ type = "text"; text = $Prompt }

        foreach ($imagePath in $ImagePaths) {
            $tempPath = Convert-ImageToAiTempJpeg -Path $imagePath
            $tempFiles += $tempPath

            $mediaName = [System.IO.Path]::GetFileName($tempPath)
            $mediaUrl = "file://" + $mediaName

            $content += @{
                type = "image_url"
                image_url = @{
                    url = $mediaUrl
                }
            }
        }

        $bodyObject = @{
            model = "local-qwen2.5-vl-3b"
            temperature = 0.1
            max_tokens = 900
            messages = @(
                @{
                    role = "user"
                    content = $content
                }
            )
        }

        $body = $bodyObject | ConvertTo-Json -Depth 20 -Compress

        if ($null -ne $txtAiResult) {
            $txtAiResult.AppendText("Sending vision request via file:// media path...`r`n")
        }

        try {
            $response = Invoke-RestMethod `
                -Uri ($script:AiBaseUrl + "/v1/chat/completions") `
                -Method Post `
                -ContentType "application/json; charset=utf-8" `
                -Body $body `
                -TimeoutSec 300
        }
        catch {
            $serverDetail = Get-AiHttpErrorDetail -ErrorRecord $_
            $message = "AI HTTP request failed: " + $_.Exception.Message

            if (-not [string]::IsNullOrWhiteSpace($serverDetail)) {
                $message += "`r`n`r`nServer response:`r`n" + $serverDetail
            }

            try {
                $paths = Get-AiPaths
                $stderrLog = Join-Path $paths.LogsDir "llama-server.stderr.log"

                if (Test-Path -LiteralPath $stderrLog -PathType Leaf) {
                    $tail = @(
                        Get-Content -LiteralPath $stderrLog -Tail 40 -ErrorAction SilentlyContinue
                    )

                    if ($tail.Count -gt 0) {
                        $message += (
                            "`r`n`r`nllama-server log tail:`r`n" +
                            ($tail -join "`r`n")
                        )
                    }
                }
            } catch {}

            throw $message
        }

        if ($null -eq $response -or $null -eq $response.choices -or $response.choices.Count -eq 0) {
            throw "AI returned an empty response."
        }

        $message = [string]$response.choices[0].message.content
        if ([string]::IsNullOrWhiteSpace($message)) {
            throw "AI returned no analysis text."
        }

        return $message.Trim()
    }
    finally {
        foreach ($tempFile in $tempFiles) {
            try { Remove-Item -LiteralPath $tempFile -Force -ErrorAction SilentlyContinue } catch {}
        }
    }
}


function Get-SelectedAnalyzeFiles {
    param([int]$Count = 2)

    if (-not $cmbAnalyzeAlbum.SelectedItem) {
        throw "Select an album first."
    }

    $albumName = $cmbAnalyzeAlbum.SelectedItem.ToString()
    $albumPath = Join-Path (Get-OutputRoot) $albumName

    $files = @(
        Get-ChildItem -LiteralPath $albumPath -File -Filter *.png -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending |
        Select-Object -First $Count
    )

    return @($files)
}


function ConvertFrom-AiJsonResponse {
    param([string]$Text)

    if ([string]::IsNullOrWhiteSpace($Text)) {
        throw "AI returned an empty structured response."
    }

    $clean = $Text.Trim()

    # Remove common Markdown JSON fences.
    $clean = $clean -replace '^\s*```(?:json)?\s*', ''
    $clean = $clean -replace '\s*```\s*$', ''

    # If the model added a short preface/suffix, keep only the JSON object.
    $firstBrace = $clean.IndexOf('{')
    $lastBrace = $clean.LastIndexOf('}')

    if ($firstBrace -ge 0 -and $lastBrace -gt $firstBrace) {
        $clean = $clean.Substring($firstBrace, $lastBrace - $firstBrace + 1)
    }

    try {
        return ($clean | ConvertFrom-Json -ErrorAction Stop)
    }
    catch {
        throw (
            "AI returned a response that could not be parsed as JSON.`r`n`r`n" +
            "Raw response:`r`n" + $Text
        )
    }
}

function Convert-AiCountText {
    param($Value)

    if ($null -eq $Value) {
        return "Unknown"
    }

    try {
        $n = [int]$Value
        if ($n -lt 0) {
            return "Unknown"
        }
        return [string]$n
    }
    catch {
        return "Unknown"
    }
}

function Convert-AiBoolText {
    param($Value)

    if ($null -eq $Value) {
        return "Unknown"
    }

    try {
        if ([bool]$Value) {
            return "YES"
        }
        return "NO"
    }
    catch {
        return "Unknown"
    }
}

function Get-AiStringArray {
    param($Value)

    if ($null -eq $Value) {
        return @()
    }

    if ($Value -is [System.Array]) {
        return @($Value | ForEach-Object { [string]$_ } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    }

    $single = [string]$Value
    if ([string]::IsNullOrWhiteSpace($single)) {
        return @()
    }

    return @($single)
}

function Get-SocStatusRank {
    param([string]$Status)

    switch -Regex ($Status) {
        '^Critical$' { return 3 }
        '^Warning$'  { return 2 }
        '^Normal$'   { return 1 }
        default      { return 0 }
    }
}

function Get-SocStatusByRank {
    param([int]$Rank)

    if ($Rank -ge 3) { return "Critical" }
    if ($Rank -eq 2) { return "Warning" }
    return "Normal"
}


function Get-NoDataPanelItems {
    param($Result)

    $items = New-Object System.Collections.Generic.List[object]

    if ($null -eq $Result) {
        return @()
    }

    try {
        foreach ($panel in @($Result.no_data_panels)) {
            if ($null -eq $panel) {
                continue
            }

            $title = [string]$panel.title
            $evidence = [string]$panel.evidence

            if ([string]::IsNullOrWhiteSpace($title)) {
                $title = "Unreadable panel"
            }

            $items.Add([PSCustomObject]@{
                title = $title.Trim()
                evidence = $evidence
            })
        }
    }
    catch {}

    return @($items)
}

function Apply-SocHealthRules {
    param($Result)

    $status = [string]$Result.overall_status
    $rank = Get-SocStatusRank -Status $status

    if ($rank -eq 0) {
        $rank = 1
    }

    $dashboardLoaded = $null
    if ($null -ne $Result.dashboard_loaded) {
        $dashboardLoaded = [bool]$Result.dashboard_loaded
    }

    $loginDetected = $false
    if ($null -ne $Result.login_page_detected) {
        $loginDetected = [bool]$Result.login_page_detected
    }

    $visibleErrors = -1
    try { $visibleErrors = [int]$Result.visible_errors } catch {}

    $emptyPanels = -1
    try { $emptyPanels = [int]$Result.empty_panels } catch {}

    $panelsWithData = -1
    try { $panelsWithData = [int]$Result.panels_with_data } catch {}

    $noDataPanels = @(Get-NoDataPanelItems -Result $Result)

    if ($noDataPanels.Count -gt 0) {
        $Result.empty_panels = $noDataPanels.Count
        $emptyPanels = $noDataPanels.Count
    }

    $findings = @(Get-AiStringArray -Value $Result.findings)
    $security = @(Get-AiStringArray -Value $Result.security_observations)

    $allText = (($findings + $security) -join " ").ToLowerInvariant()

    $allPanelsNoData = (
        $allText -match 'all panels.*no results' -or
        $allText -match 'all panels.*no data' -or
        $allText -match 'all visible panels.*empty' -or
        $allText -match 'all.*no results found'
    )

    $somePanelsNoData = (
        $allText -match 'no results found' -or
        $allText -match 'empty panel' -or
        $allText -match 'no data'
    )

    # If AI says all panels have no results, Empty Panels = 0 is contradictory.
    # If exact count is unknown, show Unknown (-1) rather than a false zero.
    if ($allPanelsNoData -and $emptyPanels -eq 0) {
        $Result.empty_panels = -1
        $emptyPanels = -1
    }

    if ($allPanelsNoData) {
        $Result.panels_with_data = 0
        $panelsWithData = 0
    }

    if ($loginDetected -or ($dashboardLoaded -eq $false)) {
        $rank = [Math]::Max($rank, 3)
    }
    elseif (($visibleErrors -gt 0) -or ($emptyPanels -gt 0) -or $somePanelsNoData) {
        $rank = [Math]::Max($rank, 2)
    }

    if ($allPanelsNoData) {
        $rank = [Math]::Max($rank, 2)
    }

    $Result.overall_status = Get-SocStatusByRank -Rank $rank

    # "No results" is dashboard/data health, not a security observation.
    if ($allPanelsNoData -or ($panelsWithData -eq 0)) {
        $cleanSecurity = New-Object System.Collections.Generic.List[string]

        foreach ($item in $security) {
            $lower = ([string]$item).ToLowerInvariant()

            if (
                $lower -notmatch 'no results' -and
                $lower -notmatch 'no data' -and
                $lower -notmatch 'empty panel'
            ) {
                $cleanSecurity.Add([string]$item)
            }
        }

        if ($cleanSecurity.Count -eq 0) {
            $cleanSecurity.Add(
                "No security conclusion can be made because no event data is visibly available."
            )
        }

        $Result.security_observations = @($cleanSecurity)
    }

    if ($allPanelsNoData -or (($panelsWithData -eq 0) -and $somePanelsNoData)) {
        $Result.possible_causes = @(
            "No events in the selected time range",
            "Dashboard filters or query conditions exclude the events",
            "Data ingestion or pipeline has stopped or is delayed",
            "Expected Elasticsearch index/data stream has no recent documents"
        )

        $Result.recommended_actions = @(
            "Open Discover and check the same time range",
            "Check the timestamp of the latest ingested document",
            "Review dashboard filters and the selected time range",
            "Verify the expected index/data stream and ingestion pipeline"
        )

        $Result.summary = (
            "The dashboard is loaded, but no visible event data is present. " +
            "Possible causes include the selected time range, dashboard filters, " +
            "or an ingestion/data-availability issue."
        )
    }

    return $Result
}

function Set-AiSocHeader {
    param(
        [string]$Status = "-",
        $DashboardLoaded = $null,
        $EmptyPanels = $null,
        $VisibleErrors = $null,
        $PanelsWithData = $null,
        [string]$Confidence = "-"
    )

    if ($null -eq $lblAiSocStatus) {
        return
    }

    $palette = Get-AghrabPalette -Theme $script:CurrentTheme
    $statusText = $Status.ToUpperInvariant()

    $statusVisual = Get-HealthStatusVisual -Status "Unknown" -Theme $script:CurrentTheme
    if ($Status -eq "Normal") {
        $statusVisual = Get-HealthStatusVisual -Status "Healthy" -Theme $script:CurrentTheme
    }
    elseif ($Status -eq "Warning") {
        $statusVisual = Get-HealthStatusVisual -Status "Warning" -Theme $script:CurrentTheme
    }
    elseif ($Status -eq "Critical") {
        $statusVisual = Get-HealthStatusVisual -Status "Critical" -Theme $script:CurrentTheme
    }

    $lblAiSocStatus.Text = Convert-AghrabUiText -Text $statusText -Language $script:CurrentLanguage
    $lblAiSocStatus.ForeColor = $statusVisual.Fore
    $cardAiSocStatus.BackColor = $statusVisual.Back

    $loadedText = Convert-AiBoolText -Value $DashboardLoaded
    $lblAiSocLoaded.Text = Convert-AghrabUiText -Text $loadedText -Language $script:CurrentLanguage
    $loadedVisual = Get-HealthStatusVisual -Status "Unknown" -Theme $script:CurrentTheme
    if ($loadedText -eq "YES") {
        $loadedVisual = Get-HealthStatusVisual -Status "Healthy" -Theme $script:CurrentTheme
    }
    elseif ($loadedText -eq "NO") {
        $loadedVisual = Get-HealthStatusVisual -Status "Critical" -Theme $script:CurrentTheme
    }
    $lblAiSocLoaded.ForeColor = $loadedVisual.Fore
    $cardAiSocLoaded.BackColor = $loadedVisual.Back

    $emptyText = Convert-AiCountText -Value $EmptyPanels
    $lblAiSocEmpty.Text = $emptyText
    $emptyVisual = Get-HealthStatusVisual -Status "Unknown" -Theme $script:CurrentTheme
    try {
        if ([int]$EmptyPanels -eq 0) {
            $emptyVisual = Get-HealthStatusVisual -Status "Healthy" -Theme $script:CurrentTheme
        }
        elseif ([int]$EmptyPanels -gt 0) {
            $emptyVisual = Get-HealthStatusVisual -Status "Warning" -Theme $script:CurrentTheme
        }
    } catch {}
    $lblAiSocEmpty.ForeColor = $emptyVisual.Fore
    $cardAiSocEmpty.BackColor = $emptyVisual.Back

    $dataText = Convert-AiCountText -Value $PanelsWithData
    $lblAiSocData.Text = $dataText
    $dataVisual = Get-HealthStatusVisual -Status "Total" -Theme $script:CurrentTheme
    $lblAiSocData.ForeColor = $dataVisual.Fore
    $cardAiSocData.BackColor = $dataVisual.Back

    $errorText = Convert-AiCountText -Value $VisibleErrors
    $lblAiSocErrors.Text = $errorText
    $errorVisual = Get-HealthStatusVisual -Status "Unknown" -Theme $script:CurrentTheme
    try {
        if ([int]$VisibleErrors -eq 0) {
            $errorVisual = Get-HealthStatusVisual -Status "Healthy" -Theme $script:CurrentTheme
        }
        elseif ([int]$VisibleErrors -gt 0) {
            $errorVisual = Get-HealthStatusVisual -Status "Critical" -Theme $script:CurrentTheme
        }
    } catch {}
    $lblAiSocErrors.ForeColor = $errorVisual.Fore
    $cardAiSocErrors.BackColor = $errorVisual.Back

    if ([string]::IsNullOrWhiteSpace($Confidence)) { $Confidence = "-" }
    $lblAiSocConfidence.Text = Convert-AghrabUiText -Text ($Confidence.ToUpperInvariant()) -Language $script:CurrentLanguage
    $confVisual = Get-HealthStatusVisual -Status "Total" -Theme $script:CurrentTheme
    $lblAiSocConfidence.ForeColor = $confVisual.Fore
    $cardAiSocConfidence.BackColor = $confVisual.Back

    foreach ($metricCard in @(
        $cardAiSocStatus,$cardAiSocLoaded,$cardAiSocEmpty,
        $cardAiSocData,$cardAiSocErrors,$cardAiSocConfidence
    )) {
        if ($null -ne $metricCard) {
            Set-RoundedControlRegion -Control $metricCard -Radius 9
        }
    }
}


function Format-SocAnalysisResult {
    param($Result)

    $lines = New-Object System.Collections.Generic.List[string]

    $lines.Add("OVERALL STATUS: " + [string]$Result.overall_status)
    $lines.Add("")

    $lines.Add("DASHBOARD HEALTH")
    $lines.Add("  Dashboard Loaded : " + (Convert-AiBoolText -Value $Result.dashboard_loaded))
    $lines.Add("  Login Page       : " + (Convert-AiBoolText -Value $Result.login_page_detected))
    $lines.Add("  Visible Errors   : " + (Convert-AiCountText -Value $Result.visible_errors))
    $lines.Add("  Empty Panels     : " + (Convert-AiCountText -Value $Result.empty_panels))
    $lines.Add("  Panels With Data : " + (Convert-AiCountText -Value $Result.panels_with_data))
    $lines.Add("")

    $noDataPanels = @(Get-NoDataPanelItems -Result $Result)
    if ($noDataPanels.Count -gt 0) {
        $lines.Add("NO DATA PANELS")
        $counter = 0

        foreach ($panel in $noDataPanels) {
            $counter++
            $lines.Add(("  {0}. {1}" -f $counter, [string]$panel.title))

            if (-not [string]::IsNullOrWhiteSpace([string]$panel.evidence)) {
                $lines.Add("     Evidence: " + ([string]$panel.evidence).Trim())
            }
        }

        $lines.Add("")
    }

    $findings = @(Get-AiStringArray -Value $Result.findings)
    if ($findings.Count -gt 0) {
        $lines.Add("FINDINGS")
        foreach ($item in $findings) {
            $lines.Add("  - " + $item)
        }
        $lines.Add("")
    }

    $security = @(Get-AiStringArray -Value $Result.security_observations)
    if ($security.Count -gt 0) {
        $lines.Add("SECURITY OBSERVATIONS")
        foreach ($item in $security) {
            $lines.Add("  - " + $item)
        }
        $lines.Add("")
    }

    $causes = @(Get-AiStringArray -Value $Result.possible_causes)
    if ($causes.Count -gt 0) {
        $lines.Add("POSSIBLE CAUSES")
        foreach ($item in $causes) {
            $lines.Add("  - " + $item)
        }
        $lines.Add("")
    }

    $actions = @(Get-AiStringArray -Value $Result.recommended_actions)
    if ($actions.Count -gt 0) {
        $lines.Add("RECOMMENDED ACTION")
        foreach ($item in $actions) {
            $lines.Add("  - " + $item)
        }
        $lines.Add("")
    }

    $summary = [string]$Result.summary
    if (-not [string]::IsNullOrWhiteSpace($summary)) {
        $lines.Add("SUMMARY")
        $lines.Add("  " + $summary.Trim())
        $lines.Add("")
    }

    $confidence = [string]$Result.confidence
    if (-not [string]::IsNullOrWhiteSpace($confidence)) {
        $lines.Add("AI CONFIDENCE: " + $confidence.ToUpperInvariant())
    }

    return ($lines -join "`r`n")
}

function Format-SocCompareResult {
    param(
        $Result,
        $Pixel
    )

    $lines = New-Object System.Collections.Generic.List[string]

    $lines.Add(
        "PIXEL CHANGE: " +
        [string]$Pixel.ChangePercent +
        "% | " +
        [string]$Pixel.Level
    )
    $lines.Add("OVERALL CHANGE: " + [string]$Result.overall_change)
    $lines.Add("")

    $important = @(Get-AiStringArray -Value $Result.important_changes)
    if ($important.Count -gt 0) {
        $lines.Add("IMPORTANT CHANGES")
        foreach ($item in $important) {
            $lines.Add("  - " + $item)
        }
        $lines.Add("")
    }

    $issues = @(Get-AiStringArray -Value $Result.dashboard_issues)
    if ($issues.Count -gt 0) {
        $lines.Add("DASHBOARD ISSUES")
        foreach ($item in $issues) {
            $lines.Add("  - " + $item)
        }
        $lines.Add("")
    }

    $security = @(Get-AiStringArray -Value $Result.security_relevant_changes)
    if ($security.Count -gt 0) {
        $lines.Add("SECURITY-RELEVANT CHANGES")
        foreach ($item in $security) {
            $lines.Add("  - " + $item)
        }
        $lines.Add("")
    }

    $actions = @(Get-AiStringArray -Value $Result.recommended_actions)
    if ($actions.Count -gt 0) {
        $lines.Add("RECOMMENDED ACTION")
        foreach ($item in $actions) {
            $lines.Add("  - " + $item)
        }
        $lines.Add("")
    }

    if (-not [string]::IsNullOrWhiteSpace([string]$Result.summary)) {
        $lines.Add("SUMMARY")
        $lines.Add("  " + [string]$Result.summary)
    }

    return ($lines -join "`r`n")
}


function Update-NoDataInspector {
    param(
        $Result = $null,
        [string]$State = ""
    )

    if ($null -eq $lstNoDataPanels -or $null -eq $lblNoDataCount) {
        return
    }

    $lstNoDataPanels.Items.Clear()

    if ($State -eq "Analyzing") {
        $lblNoDataCount.Text = "Count: ..."
        [void]$lstNoDataPanels.Items.Add("Scanning dashboard panels...")
        return
    }

    if ($State -eq "Error") {
        $lblNoDataCount.Text = "Count: -"
        [void]$lstNoDataPanels.Items.Add("Analysis unavailable")
        return
    }

    if ($null -eq $Result) {
        $lblNoDataCount.Text = "Count: -"
        [void]$lstNoDataPanels.Items.Add("Run AI Analyze Latest")
        return
    }

    $items = @(Get-NoDataPanelItems -Result $Result)

    if ($items.Count -gt 0) {
        $lblNoDataCount.Text = "Count: " + $items.Count
        $n = 0

        foreach ($panel in $items) {
            $n++
            [void]$lstNoDataPanels.Items.Add(
                ("{0}. {1}" -f $n, [string]$panel.title)
            )
        }

        return
    }

    $fallback = -1
    try { $fallback = [int]$Result.empty_panels } catch {}

    if ($fallback -eq 0) {
        $lblNoDataCount.Text = "Count: 0"
        [void]$lstNoDataPanels.Items.Add("No empty panels detected")
    }
    elseif ($fallback -gt 0) {
        $lblNoDataCount.Text = "Count: " + $fallback
        [void]$lstNoDataPanels.Items.Add("Empty panel title could not be read")
    }
    else {
        $lblNoDataCount.Text = "Count: Unknown"
        [void]$lstNoDataPanels.Items.Add("Panel status is uncertain")
    }
}

function Invoke-AiAnalyzeLatest {
    if (-not (Test-AghrabCommercialFeatureAccess -Feature "AI")) {
        Show-AghrabLicenseRestriction -FeatureName "AI Analyze Latest"
        return
    }

    try {
        $files = @(Get-SelectedAnalyzeFiles -Count 1)

        if ($files.Count -lt 1) {
            throw "No screenshot is available in the selected album."
        }

        Set-AiSocHeader
        Update-NoDataInspector -State "Analyzing"
        $txtAiResult.Clear()
        $txtAiResult.AppendText("AI is analyzing the latest screenshot...`r`n")
        $form.Refresh()

        $prompt = @"
You are a vision analyst for a SOC dashboard monitoring tool.
Analyze ONLY what is visibly supported by this screenshot. Do not invent text, counts, alerts, values, or panel names.

SPECIAL TASK - NO DATA PANEL DETECTION:
- Scan the whole dashboard from left to right and top to bottom.
- Identify dashboard panels/visualizations that visibly show:
  "No results", "No results found", "No data", or an obviously empty result state.
- For each such panel, read its exact visible panel title.
- Put those panels in no_data_panels.
- If a panel is empty but its title cannot be read reliably, use "Unreadable panel".
- Do NOT include loading/spinner panels as no-data.
- A legitimate metric value of 0 is DATA, not NO_DATA.
- Never invent a title that is not visibly readable.
- empty_panels must equal the number of entries in no_data_panels when those entries are reliable.
- If you can see empty panels but cannot reliably enumerate them, set empty_panels to -1 and return only the panel titles you can read.
- If one or more empty/no-data panels are visible, overall_status must be at least Warning.

General rules:
- Login/authentication page instead of the expected dashboard = Critical.
- Fatal dashboard load/error state = Critical.
- If exact counts are uncertain, use -1 instead of guessing.
- Do not claim ingestion failure as fact; list it only as a possible cause.
- Security observations are for visible security evidence only.

Return ONLY valid JSON. No Markdown and no text outside the JSON.

Use exactly this schema:
{
  "overall_status": "Normal|Warning|Critical",
  "dashboard_loaded": true,
  "login_page_detected": false,
  "visible_errors": 0,
  "empty_panels": 0,
  "panels_with_data": 0,
  "no_data_panels": [
    {
      "title": "exact visible panel title",
      "evidence": "short visible reason"
    }
  ],
  "findings": ["..."],
  "security_observations": ["..."],
  "possible_causes": ["..."],
  "recommended_actions": ["..."],
  "summary": "...",
  "confidence": "high|medium|low"
}
"@

        $answer = Invoke-AiVisionRequest `
            -Prompt $prompt `
            -ImagePaths @($files[0].FullName)

        $result = ConvertFrom-AiJsonResponse -Text $answer
        $result = Apply-SocHealthRules -Result $result

        Set-AiSocHeader `
            -Status ([string]$result.overall_status) `
            -DashboardLoaded $result.dashboard_loaded `
            -EmptyPanels $result.empty_panels `
            -VisibleErrors $result.visible_errors `
            -PanelsWithData $result.panels_with_data `
            -Confidence ([string]$result.confidence)

        Update-NoDataInspector -Result $result
        $txtAiResult.Text = Format-SocAnalysisResult -Result $result
    }
    catch {
        Set-AiSocHeader
        Update-NoDataInspector -State "Error"
        $txtAiResult.Text = "AI analysis failed:`r`n" + $_.Exception.Message
    }
    finally {
        Update-AiStatus
    }
}

function Invoke-AiCompareLastTwo {
    if (-not (Test-AghrabCommercialFeatureAccess -Feature "AI")) {
        Show-AghrabLicenseRestriction -FeatureName "AI Compare Last 2"
        return
    }

    try {
        $files = @(Get-SelectedAnalyzeFiles -Count 2)

        if ($files.Count -lt 2) {
            throw "At least two screenshots are required for AI comparison."
        }

        $afterFile = $files[0]
        $beforeFile = $files[1]

        $pixel = Compare-Screenshots `
            -BeforePath $beforeFile.FullName `
            -AfterPath $afterFile.FullName `
            -Threshold ([int]$numAnalyzeThreshold.Value)

        Set-AiSocHeader
        $txtAiResult.Clear()
        $txtAiResult.AppendText(
            "AI is comparing the last two screenshots...`r`n" +
            "Pixel change: $($pixel.ChangePercent)% ($($pixel.Level))`r`n`r`n"
        )
        $form.Refresh()

        $prompt = @"
You are comparing two screenshots from the same SOC/security monitoring dashboard.

Image 1 is BEFORE.
Image 2 is AFTER.

Independent pixel analysis:
Change percent: $($pixel.ChangePercent)%
Change level: $($pixel.Level)

Analyze only visibly supported differences.
Do not invent exact values that cannot be clearly read.
Do not claim a security incident merely because a chart changed.
Distinguish dashboard/data-quality issues from security-relevant changes.

Return ONLY valid JSON, with no Markdown or extra text.

Use exactly this schema:
{
  "overall_change": "Low|Medium|High",
  "important_changes": ["..."],
  "dashboard_issues": ["..."],
  "security_relevant_changes": ["..."],
  "recommended_actions": ["..."],
  "summary": "...",
  "confidence": "high|medium|low"
}
"@

        $answer = Invoke-AiVisionRequest `
            -Prompt $prompt `
            -ImagePaths @(
                $beforeFile.FullName,
                $afterFile.FullName
            )

        $result = ConvertFrom-AiJsonResponse -Text $answer
        $txtAiResult.Text = Format-SocCompareResult -Result $result -Pixel $pixel

        $changeStatus = [string]$result.overall_change
        $headerStatus = "Normal"
        if ($changeStatus -eq "Medium") {
            $headerStatus = "Warning"
        }
        elseif ($changeStatus -eq "High") {
            $headerStatus = "Critical"
        }

        Set-AiSocHeader `
            -Status $headerStatus `
            -Confidence ([string]$result.confidence)

        $lblAiSocStatus.Text = Convert-AghrabUiText -Text ($changeStatus.ToUpperInvariant()) -Language $script:CurrentLanguage
    }
    catch {
        Set-AiSocHeader
        $txtAiResult.Text = "AI comparison failed:`r`n" + $_.Exception.Message
    }
    finally {
        Update-AiStatus
    }
}



# ---------------- App Settings ----------------
$script:AghrabSettingsPath = Join-Path $script:AghrabConfigDir "settings.json"
$script:CurrentTheme = "Light"

# ---------------- Commercial License ----------------
$script:AghrabLicenseDir = Join-Path $script:AghrabConfigDir "license"
$script:AghrabLicensePath = Join-Path $script:AghrabLicenseDir "aghrab.lic"
$script:AghrabLicensePublicKeyPath = Join-Path $BaseDir "license-public-key.xml"
$script:AghrabTrialDays = 7
$script:AghrabTrialFile = Join-Path $script:AghrabConfigDir "trial-state.dat"
$script:AghrabTrialLocalDir = Join-Path $env:LOCALAPPDATA "aghrab"
$script:AghrabTrialLocalFile = Join-Path $script:AghrabTrialLocalDir "trial-state.dat"
$script:AghrabTrialRegistryPath = "HKCU:\Software\AGHRAB\SentinelPro"
$script:AghrabTrialRegistryValue = "TrialState"
$script:LastEntitlementStatus = ""

function Get-AghrabMachineId {
    $raw = ""

    try {
        $raw = [string](
            Get-ItemProperty `
                -Path "HKLM:\SOFTWARE\Microsoft\Cryptography" `
                -Name "MachineGuid" `
                -ErrorAction Stop
        ).MachineGuid
    }
    catch {}

    if ([string]::IsNullOrWhiteSpace($raw)) {
        $raw = [Environment]::MachineName
    }

    $raw = ($raw.Trim() + "|" + [Environment]::MachineName).ToUpperInvariant()

    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($raw)
        $hash = $sha.ComputeHash($bytes)
        $hex = [System.BitConverter]::ToString($hash).Replace("-","")
        $short = $hex.Substring(0,16)

        return (
            "AGH-" +
            $short.Substring(0,4) + "-" +
            $short.Substring(4,4) + "-" +
            $short.Substring(8,4) + "-" +
            $short.Substring(12,4)
        )
    }
    finally {
        $sha.Dispose()
    }
}

function ConvertFrom-AghrabTrialProtectedValue {
    param([string]$ProtectedValue)

    if ([string]::IsNullOrWhiteSpace($ProtectedValue)) {
        return $null
    }

    try {
        $plain = Unprotect-SecretForCurrentUser -ProtectedBase64 $ProtectedValue.Trim()
        if ([string]::IsNullOrWhiteSpace($plain)) {
            return $null
        }

        $record = $plain | ConvertFrom-Json -ErrorAction Stop

        if ([string]$record.version -ne "1") {
            return $null
        }

        if ([string]::IsNullOrWhiteSpace([string]$record.machine_id) -or
            [string]::IsNullOrWhiteSpace([string]$record.start_utc) -or
            [string]::IsNullOrWhiteSpace([string]$record.last_seen_utc)) {
            return $null
        }

        return $record
    }
    catch {
        return $null
    }
}

function Save-AghrabTrialRecord {
    param(
        [DateTime]$StartUtc,
        [DateTime]$LastSeenUtc,
        [string]$MachineId
    )

    $record = [PSCustomObject][ordered]@{
        version = "1"
        machine_id = $MachineId
        start_utc = $StartUtc.ToUniversalTime().ToString("o")
        last_seen_utc = $LastSeenUtc.ToUniversalTime().ToString("o")
    }

    $plain = $record | ConvertTo-Json -Compress
    $protected = Protect-SecretForCurrentUser -PlainText $plain

    if ([string]::IsNullOrWhiteSpace($protected)) {
        throw "Could not protect the local trial state."
    }

    $saved = 0

    try {
        New-Item -ItemType Directory -Force -Path $script:AghrabConfigDir | Out-Null
        Set-Content `
            -LiteralPath $script:AghrabTrialFile `
            -Value $protected `
            -Encoding UTF8 `
            -Force
        $saved++
    }
    catch {}

    try {
        New-Item -ItemType Directory -Force -Path $script:AghrabTrialLocalDir | Out-Null
        Set-Content `
            -LiteralPath $script:AghrabTrialLocalFile `
            -Value $protected `
            -Encoding UTF8 `
            -Force
        $saved++
    }
    catch {}

    try {
        New-Item -Path $script:AghrabTrialRegistryPath -Force | Out-Null
        New-ItemProperty `
            -Path $script:AghrabTrialRegistryPath `
            -Name $script:AghrabTrialRegistryValue `
            -Value $protected `
            -PropertyType String `
            -Force | Out-Null
        $saved++
    }
    catch {}

    if ($saved -eq 0) {
        throw "RAQEB could not persist the local trial state."
    }

    return $record
}

function Get-AghrabTrialState {
    $machineId = Get-AghrabMachineId
    $nowUtc = (Get-Date).ToUniversalTime()
    $protectedValues = @()
    $storeWasPresent = $false

    foreach ($path in @(
        $script:AghrabTrialFile,
        $script:AghrabTrialLocalFile
    )) {
        try {
            if (Test-Path -LiteralPath $path -PathType Leaf) {
                $storeWasPresent = $true
                $v = (Get-Content -LiteralPath $path -Raw -Encoding UTF8).Trim()
                if (-not [string]::IsNullOrWhiteSpace($v)) {
                    $protectedValues += $v
                }
            }
        }
        catch {}
    }

    try {
        if (Test-Path -LiteralPath $script:AghrabTrialRegistryPath) {
            $reg = Get-ItemProperty `
                -Path $script:AghrabTrialRegistryPath `
                -Name $script:AghrabTrialRegistryValue `
                -ErrorAction SilentlyContinue

            if ($null -ne $reg) {
                $storeWasPresent = $true
                $v = [string]$reg.$($script:AghrabTrialRegistryValue)
                if (-not [string]::IsNullOrWhiteSpace($v)) {
                    $protectedValues += $v
                }
            }
        }
    }
    catch {}

    $records = @()
    foreach ($value in @($protectedValues | Select-Object -Unique)) {
        $record = ConvertFrom-AghrabTrialProtectedValue -ProtectedValue $value
        if ($null -ne $record) {
            $records += $record
        }
    }

    if ($records.Count -eq 0) {
        if ($storeWasPresent) {
            return [PSCustomObject]@{
                Status = "TRIAL INVALID"
                Customer = "Evaluation"
                Edition = "7-Day Full Trial"
                LicenseId = "TRIAL"
                Issued = "-"
                Expires = "-"
                DaysRemaining = "0"
                MachineId = $machineId
                Detail = "Trial state could not be validated. Activation is required."
                TrialStartUtc = ""
                TrialEndUtc = ""
            }
        }

        try {
            $newRecord = Save-AghrabTrialRecord `
                -StartUtc $nowUtc `
                -LastSeenUtc $nowUtc `
                -MachineId $machineId

            $records = @($newRecord)
        }
        catch {
            return [PSCustomObject]@{
                Status = "TRIAL INVALID"
                Customer = "Evaluation"
                Edition = "7-Day Full Trial"
                LicenseId = "TRIAL"
                Issued = "-"
                Expires = "-"
                DaysRemaining = "0"
                MachineId = $machineId
                Detail = "Trial state could not be created. Activation is required."
                TrialStartUtc = ""
                TrialEndUtc = ""
            }
        }
    }

    $startDates = @()
    $lastDates = @()

    foreach ($record in $records) {
        if (
            ([string]$record.machine_id).Trim().ToUpperInvariant() -ne
            $machineId.Trim().ToUpperInvariant()
        ) {
            return [PSCustomObject]@{
                Status = "TRIAL INVALID"
                Customer = "Evaluation"
                Edition = "7-Day Full Trial"
                LicenseId = "TRIAL"
                Issued = "-"
                Expires = "-"
                DaysRemaining = "0"
                MachineId = $machineId
                Detail = "Trial state belongs to another Machine ID."
                TrialStartUtc = ""
                TrialEndUtc = ""
            }
        }

        try {
            $startDates += [DateTime]::Parse(
                [string]$record.start_utc,
                [System.Globalization.CultureInfo]::InvariantCulture,
                [System.Globalization.DateTimeStyles]::RoundtripKind
            ).ToUniversalTime()

            $lastDates += [DateTime]::Parse(
                [string]$record.last_seen_utc,
                [System.Globalization.CultureInfo]::InvariantCulture,
                [System.Globalization.DateTimeStyles]::RoundtripKind
            ).ToUniversalTime()
        }
        catch {}
    }

    if ($startDates.Count -eq 0 -or $lastDates.Count -eq 0) {
        return [PSCustomObject]@{
            Status = "TRIAL INVALID"
            Customer = "Evaluation"
            Edition = "7-Day Full Trial"
            LicenseId = "TRIAL"
            Issued = "-"
            Expires = "-"
            DaysRemaining = "0"
            MachineId = $machineId
            Detail = "Trial dates are invalid. Activation is required."
            TrialStartUtc = ""
            TrialEndUtc = ""
        }
    }

    # Use the most restrictive merged state:
    # earliest start + latest last-seen from all surviving stores.
    $startUtc = @($startDates | Sort-Object)[0]
    $lastSeenUtc = @($lastDates | Sort-Object -Descending)[0]

    # Detect significant rollback. A small tolerance avoids false positives
    # caused by clock synchronization adjustments.
    if ($nowUtc -lt $lastSeenUtc.AddMinutes(-5)) {
        return [PSCustomObject]@{
            Status = "TRIAL INVALID"
            Customer = "Evaluation"
            Edition = "7-Day Full Trial"
            LicenseId = "TRIAL"
            Issued = $startUtc.ToLocalTime().ToString("yyyy-MM-dd HH:mm")
            Expires = $startUtc.AddDays($script:AghrabTrialDays).ToLocalTime().ToString("yyyy-MM-dd HH:mm")
            DaysRemaining = "0"
            MachineId = $machineId
            Detail = "System clock rollback was detected. Activation is required."
            TrialStartUtc = $startUtc.ToString("o")
            TrialEndUtc = $startUtc.AddDays($script:AghrabTrialDays).ToString("o")
        }
    }

    if ($startUtc -gt $nowUtc.AddMinutes(5)) {
        return [PSCustomObject]@{
            Status = "TRIAL INVALID"
            Customer = "Evaluation"
            Edition = "7-Day Full Trial"
            LicenseId = "TRIAL"
            Issued = "-"
            Expires = "-"
            DaysRemaining = "0"
            MachineId = $machineId
            Detail = "Trial start time is invalid. Activation is required."
            TrialStartUtc = ""
            TrialEndUtc = ""
        }
    }

    $endUtc = $startUtc.AddDays($script:AghrabTrialDays)
    $remaining = $endUtc - $nowUtc
    $daysRemaining = [int][Math]::Ceiling([Math]::Max(0,$remaining.TotalDays))

    if ($nowUtc -ge $endUtc) {
        return [PSCustomObject]@{
            Status = "TRIAL EXPIRED"
            Customer = "Evaluation"
            Edition = "7-Day Full Trial"
            LicenseId = "TRIAL"
            Issued = $startUtc.ToLocalTime().ToString("yyyy-MM-dd HH:mm")
            Expires = $endUtc.ToLocalTime().ToString("yyyy-MM-dd HH:mm")
            DaysRemaining = "0"
            MachineId = $machineId
            Detail = "The 7-day full trial has expired. Activate a Professional license to unlock RAQEB."
            TrialStartUtc = $startUtc.ToString("o")
            TrialEndUtc = $endUtc.ToString("o")
        }
    }

    # Refresh last-seen and repair a missing file/registry mirror.
    try {
        $effectiveLastSeen = $lastSeenUtc
        if ($nowUtc -gt $effectiveLastSeen) {
            $effectiveLastSeen = $nowUtc
        }

        [void](Save-AghrabTrialRecord `
            -StartUtc $startUtc `
            -LastSeenUtc $effectiveLastSeen `
            -MachineId $machineId)
    }
    catch {}

    return [PSCustomObject]@{
        Status = "TRIAL"
        Customer = "Evaluation"
        Edition = "7-Day Full Trial"
        LicenseId = "TRIAL"
        Issued = $startUtc.ToLocalTime().ToString("yyyy-MM-dd HH:mm")
        Expires = $endUtc.ToLocalTime().ToString("yyyy-MM-dd HH:mm")
        DaysRemaining = [string]$daysRemaining
        MachineId = $machineId
        Detail = (
            "Full 7-day evaluation is active. " +
            [string]$daysRemaining +
            " day(s) remaining."
        )
        TrialStartUtc = $startUtc.ToString("o")
        TrialEndUtc = $endUtc.ToString("o")
    }
}

function Get-AghrabLicenseCanonicalString {
    param($Data)

    return (
        "product=" + [string]$Data.product + "`n" +
        "license_id=" + [string]$Data.license_id + "`n" +
        "customer=" + [string]$Data.customer + "`n" +
        "edition=" + [string]$Data.edition + "`n" +
        "issued=" + [string]$Data.issued + "`n" +
        "expires=" + [string]$Data.expires + "`n" +
        "machine_id=" + [string]$Data.machine_id
    )
}

function Test-AghrabLicenseSignature {
    param($Document)

    try {
        if ($null -eq $Document -or $null -eq $Document.license) {
            return $false
        }

        if ([string]::IsNullOrWhiteSpace([string]$Document.signature)) {
            return $false
        }

        if (-not (Test-Path -LiteralPath $script:AghrabLicensePublicKeyPath -PathType Leaf)) {
            return $false
        }

        $publicXml = Get-Content `
            -LiteralPath $script:AghrabLicensePublicKeyPath `
            -Raw `
            -Encoding UTF8

        $canonical = Get-AghrabLicenseCanonicalString -Data $Document.license
        $dataBytes = [System.Text.Encoding]::UTF8.GetBytes($canonical)
        $signatureBytes = [Convert]::FromBase64String([string]$Document.signature)

        $rsa = New-Object System.Security.Cryptography.RSACryptoServiceProvider
        try {
            $rsa.PersistKeyInCsp = $false
            $rsa.FromXmlString($publicXml)
            $sha256Oid = [System.Security.Cryptography.CryptoConfig]::MapNameToOID("SHA256")
            return $rsa.VerifyData($dataBytes, $sha256Oid, $signatureBytes)
        }
        finally {
            $rsa.Dispose()
        }
    }
    catch {
        return $false
    }
}

function Get-AghrabLicenseState {
    $machineId = Get-AghrabMachineId

    # Always establish/read the local trial state on application use.
    # This prevents uninstall/reinstall from creating a fresh trial after a
    # Professional license later expires.
    $trialState = Get-AghrabTrialState

    $state = [PSCustomObject]@{
        Status = "UNLICENSED"
        Customer = "-"
        Edition = "-"
        LicenseId = "-"
        Issued = "-"
        Expires = "-"
        DaysRemaining = "-"
        MachineId = $machineId
        Detail = "No license file has been imported."
        Path = $script:AghrabLicensePath
    }

    if (-not (Test-Path -LiteralPath $script:AghrabLicensePath -PathType Leaf)) {
        return $trialState
    }

    try {
        $raw = Get-Content `
            -LiteralPath $script:AghrabLicensePath `
            -Raw `
            -Encoding UTF8

        $document = $raw | ConvertFrom-Json -ErrorAction Stop

        if ([string]$document.algorithm -ne "RSA-SHA256") {
            if ([string]$trialState.Status -eq "TRIAL") {
                $trialState.Detail = "Full trial is active; imported license uses an unsupported algorithm."
                return $trialState
            }

            $state.Status = "INVALID"
            $state.Detail = "Unsupported license algorithm."
            return $state
        }

        if (-not (Test-AghrabLicenseSignature -Document $document)) {
            if ([string]$trialState.Status -eq "TRIAL") {
                $trialState.Detail = "Full trial is active; imported license signature is invalid."
                return $trialState
            }

            $state.Status = "INVALID"
            $state.Detail = "Digital signature verification failed."
            return $state
        }

        $data = $document.license

        $state.Customer = [string]$data.customer
        $state.Edition = [string]$data.edition
        $state.LicenseId = [string]$data.license_id
        $state.Issued = [string]$data.issued
        $state.Expires = [string]$data.expires

        if ([string]$data.product -ne "AGHRAB Sentinel Pro") {
            if ([string]$trialState.Status -eq "TRIAL") {
                $trialState.Detail = "Full trial is active; imported license is for another product."
                return $trialState
            }

            $state.Status = "INVALID"
            $state.Detail = "License is for another product."
            return $state
        }

        $licensedMachine = ([string]$data.machine_id).Trim().ToUpperInvariant()
        if (
            $licensedMachine -ne "*" -and
            $licensedMachine -ne $machineId.ToUpperInvariant()
        ) {
            if ([string]$trialState.Status -eq "TRIAL") {
                $trialState.Detail = "Full trial is active; imported license belongs to another Machine ID."
                return $trialState
            }

            $state.Status = "MACHINE MISMATCH"
            $state.Detail = "This license belongs to another Machine ID."
            return $state
        }

        if ([string]$data.expires -eq "PERPETUAL") {
            $state.Status = "LICENSED"
            $state.DaysRemaining = "Perpetual"
            $state.Detail = "Valid signed perpetual license."
            return $state
        }

        try {
            $expiry = [DateTime]::ParseExact(
                [string]$data.expires,
                "yyyy-MM-dd",
                [System.Globalization.CultureInfo]::InvariantCulture
            )
        }
        catch {
            if ([string]$trialState.Status -eq "TRIAL") {
                $trialState.Detail = "Full trial is active; imported license expiration date is invalid."
                return $trialState
            }

            $state.Status = "INVALID"
            $state.Detail = "Invalid expiration date."
            return $state
        }

        $remaining = [int](($expiry.Date - (Get-Date).Date).TotalDays)
        $state.DaysRemaining = [string]$remaining

        if ($remaining -lt 0) {
            $state.Status = "EXPIRED"
            $state.Detail = "The Professional license has expired."
            return $state
        }

        $state.Status = "LICENSED"
        $state.Detail = "Valid signed Professional license."
        return $state
    }
    catch {
        if ([string]$trialState.Status -eq "TRIAL") {
            $trialState.Detail = "Full trial is active; imported license could not be read."
            return $trialState
        }

        $state.Status = "INVALID"
        $state.Detail = "Could not read license file."
        return $state
    }
}

function Import-AghrabLicense {
    param([string]$SourcePath)

    if (-not (Test-Path -LiteralPath $SourcePath -PathType Leaf)) {
        throw "License file was not found."
    }

    $raw = Get-Content -LiteralPath $SourcePath -Raw -Encoding UTF8
    $document = $raw | ConvertFrom-Json -ErrorAction Stop

    if (-not (Test-AghrabLicenseSignature -Document $document)) {
        throw "Invalid license signature."
    }

    New-Item -ItemType Directory -Path $script:AghrabLicenseDir -Force |
        Out-Null

    Copy-Item `
        -LiteralPath $SourcePath `
        -Destination $script:AghrabLicensePath `
        -Force

    return Get-AghrabLicenseState
}

function Test-AghrabFullAccess {
    try {
        $state = Get-AghrabLicenseState
        return (
            [string]$state.Status -eq "LICENSED" -or
            [string]$state.Status -eq "TRIAL"
        )
    }
    catch {
        return $false
    }
}

function Test-AghrabCommercialFeatureAccess {
    param(
        [ValidateSet("AI","AutomaticCapture")]
        [string]$Feature
    )

    return (Test-AghrabFullAccess)
}

function Get-AghrabLicenseAccessText {
    param($State)

    if ($null -eq $State) {
        return "LOCKED"
    }

    if ([string]$State.Status -eq "LICENSED") {
        return "FULL ACCESS - PROFESSIONAL"
    }

    if ([string]$State.Status -eq "TRIAL") {
        return (
            "FULL ACCESS - 7-DAY TRIAL | " +
            [string]$State.DaysRemaining +
            " day(s) left"
        )
    }

    return "LOCKED - Gallery + License + Support only"
}

function Show-AghrabLicenseRestriction {
    param(
        [string]$FeatureName
    )

    $state = Get-AghrabLicenseState

    $reason = [string]$state.Status
    if ($reason -eq "TRIAL EXPIRED") {
        $reason = "The 7-day full trial has expired."
    }
    elseif ($reason -eq "TRIAL INVALID") {
        $reason = [string]$state.Detail
    }
    elseif ($reason -eq "EXPIRED") {
        $reason = "The Professional license has expired."
    }
    elseif ($reason -eq "MACHINE MISMATCH") {
        $reason = "The license belongs to another machine."
    }
    elseif ($reason -eq "INVALID") {
        $reason = "The installed license is invalid."
    }

    [System.Windows.Forms.MessageBox]::Show(
        $form,
        (
            $FeatureName + " is locked.`r`n`r`n" +
            $reason + "`r`n`r`n" +
            "Gallery remains available. Open Settings to activate a Professional license."
        ),
        "RAQEB Sentinel Pro - Activation Required",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Warning
    ) | Out-Null
}

function Test-AghrabUiPageAllowed {
    param($Page)

    if (Test-AghrabFullAccess) {
        return $true
    }

    if ($null -ne $tabGallery -and $Page -eq $tabGallery) {
        return $true
    }

    if ($null -ne $tabSettings -and $Page -eq $tabSettings) {
        return $true
    }

    return $false
}

function Apply-AghrabLicenseEnforcement {
    try {
        $state = Get-AghrabLicenseState
        $fullAccess = (
            [string]$state.Status -eq "LICENSED" -or
            [string]$state.Status -eq "TRIAL"
        )

        # All operational workspaces are fully available during the 7-day
        # trial or with a Professional license. After expiry, only Gallery and
        # Settings (License + Product/Support) remain reachable.
        foreach ($button in @(
            $btnNavHealth,
            $btnNavElk,
            $btnNavScheduler,
            $btnNavAnalyze,
            $btnNavSecurity
        )) {
            if ($null -ne $button) {
                $button.Enabled = $fullAccess
            }
        }

        if ($null -ne $btnNavGallery) {
            $btnNavGallery.Enabled = $true
        }

        if ($null -ne $btnNavSettings) {
            $btnNavSettings.Enabled = $true
        }

        foreach ($page in @(
            $tabHealth,
            $tabElk,
            $tabScheduler,
            $tabAnalyze,
            $tabSecurity
        )) {
            if ($null -ne $page) {
                $page.Enabled = $fullAccess
            }
        }

        if ($null -ne $tabCapture) {
            $tabCapture.Enabled = $fullAccess
        }

        if ($null -ne $tabGallery) {
            $tabGallery.Enabled = $true
        }

        if ($null -ne $tabSettings) {
            $tabSettings.Enabled = $true
        }

        # Settings is retained so activation and support still work.
        # Operational Settings groups are locked after trial expiry.
        if ($null -ne $grpAppearance) {
            # Language selection remains available even after Trial expiry.
            $grpAppearance.Enabled = $true

            foreach ($themeControl in @(
                $cmbThemeMode,
                $lblThemeMode,
                $lblThemePreview,
                $panelThemePreview,
                $btnApplyTheme
            )) {
                if ($null -ne $themeControl) {
                    $themeControl.Enabled = $fullAccess
                }
            }

            if ($null -ne $cmbLanguage) {
                $cmbLanguage.Enabled = $true
            }
            if ($null -ne $lblLanguage) {
                $lblLanguage.Enabled = $true
            }
            if ($null -ne $btnSaveTheme) {
                $btnSaveTheme.Enabled = $true
            }
        }
        if ($null -ne $grpHealthAlerts) {
            $grpHealthAlerts.Enabled = $fullAccess
        }
        if ($null -ne $grpAppInfo) {
            $grpAppInfo.Enabled = $true
        }
        if ($null -ne $grpLicense) {
            $grpLicense.Enabled = $true
        }

        foreach ($control in @(
            $btnAnalyzeAiLatest,
            $btnAnalyzeAiCompare,
            $btnAiStart,
            $btnAiLatest,
            $btnAiCompare,
            $btnSchedulerRunNow,
            $btnSchedulerSave,
            $chkSchedulerEnabled
        )) {
            if ($null -ne $control) {
                $control.Enabled = $fullAccess
            }
        }

        if (-not $fullAccess) {
            if ($null -ne $chkSchedulerEnabled -and $chkSchedulerEnabled.Checked) {
                $script:LoadingSchedulerUi = $true
                try {
                    $chkSchedulerEnabled.Checked = $false
                    $script:SchedulerNextRun = $null
                }
                finally {
                    $script:LoadingSchedulerUi = $false
                }
            }

            try {
                if (
                    $null -ne $tabs -and
                    $tabs.SelectedTab -ne $tabGallery -and
                    $tabs.SelectedTab -ne $tabSettings
                ) {
                    $tabs.SelectedTab = $tabGallery
                }
            }
            catch {}
        }

        if ($null -ne $lblLicenseAccessValue) {
            $lblLicenseAccessValue.Text = Convert-AghrabUiText -Text (Get-AghrabLicenseAccessText -State $state) -Language $script:CurrentLanguage
        }

        $script:LastEntitlementStatus = [string]$state.Status

        try { Update-SidebarNavigation } catch {}

        return $fullAccess
    }
    catch {
        return $false
    }
}


function Update-AghrabLicenseUi {
    try {
        $state = Get-AghrabLicenseState
        $palette = Get-AghrabPalette -Theme $script:CurrentTheme

        if ($null -ne $lblLicenseStatusValue) {
            $lblLicenseStatusValue.Text = Convert-AghrabUiText -Text ([string]$state.Status) -Language $script:CurrentLanguage

            if ([string]$state.Status -eq "LICENSED") {
                $lblLicenseStatusValue.ForeColor = $palette.Success
            }
            elseif ([string]$state.Status -eq "TRIAL") {
                $lblLicenseStatusValue.ForeColor = $palette.Accent
            }
            elseif (
                [string]$state.Status -eq "TRIAL EXPIRED" -or
                [string]$state.Status -eq "EXPIRED"
            ) {
                $lblLicenseStatusValue.ForeColor = $palette.Danger
            }
            else {
                $lblLicenseStatusValue.ForeColor = $palette.Warning
            }
        }

        if ($null -ne $lblLicenseCustomerValue) {
            $lblLicenseCustomerValue.Text = [string]$state.Customer
        }
        if ($null -ne $lblLicenseEditionValue) {
            $lblLicenseEditionValue.Text = [string]$state.Edition
        }
        if ($null -ne $lblLicenseIdValue) {
            $lblLicenseIdValue.Text = [string]$state.LicenseId
        }
        if ($null -ne $lblLicenseExpiryValue) {
            $lblLicenseExpiryValue.Text = [string]$state.Expires
        }
        if ($null -ne $lblLicenseDaysValue) {
            $lblLicenseDaysValue.Text = [string]$state.DaysRemaining
        }
        if ($null -ne $txtLicenseMachineId) {
            $txtLicenseMachineId.Text = [string]$state.MachineId
        }

        $detail = [string]$state.Detail

        if ([string]$state.Status -eq "TRIAL") {
            $detail = (
                "7-day Full Trial is active. All RAQEB features are unlocked. " +
                [string]$state.DaysRemaining +
                " day(s) remaining."
            )
        }
        elseif (
            [string]$state.Status -eq "LICENSED" -and
            [string]$state.Expires -ne "PERPETUAL"
        ) {
            $days = 999999
            try { $days = [int]$state.DaysRemaining } catch {}

            if ($days -le 30) {
                $detail = (
                    "Professional license expires in " +
                    [string]$days +
                    " day(s). Renewal is recommended."
                )
            }
        }

        if ($null -ne $lblLicenseDetail) {
            $lblLicenseDetail.Text = Convert-AghrabUiText -Text $detail -Language $script:CurrentLanguage
            $lblLicenseDetail.ForeColor = $(
                if ([string]$state.Status -eq "LICENSED") {
                    $palette.Muted
                }
                elseif ([string]$state.Status -eq "TRIAL") {
                    $palette.Accent
                }
                elseif (
                    [string]$state.Status -eq "TRIAL EXPIRED" -or
                    [string]$state.Status -eq "EXPIRED"
                ) {
                    $palette.Danger
                }
                else {
                    $palette.Warning
                }
            )
        }

        if ($null -ne $lblLicenseAccessValue) {
            $lblLicenseAccessValue.Text = Get-AghrabLicenseAccessText -State $state
            $lblLicenseAccessValue.ForeColor = $(
                if ([string]$state.Status -eq "LICENSED") {
                    $palette.Success
                }
                elseif ([string]$state.Status -eq "TRIAL") {
                    $palette.Accent
                }
                else {
                    $palette.Warning
                }
            )
        }

        if ($null -ne $verLabel) {
            $verLabel.Text = "v$AppVersion"
            $verLabel.ForeColor = $palette.Muted
        }

        if ($null -ne $lblHeaderLicenseStatus) {
            $lblHeaderLicenseStatus.Text = Convert-AghrabUiText -Text ([string]$state.Status) -Language $script:CurrentLanguage

            if ([string]$state.Status -eq "LICENSED") {
                $lblHeaderLicenseStatus.BackColor = $palette.Success
                $lblHeaderLicenseStatus.ForeColor = [System.Drawing.Color]::White
            }
            elseif ([string]$state.Status -eq "TRIAL") {
                $lblHeaderLicenseStatus.BackColor = $palette.Accent
                $lblHeaderLicenseStatus.ForeColor = [System.Drawing.Color]::White
            }
            elseif (
                [string]$state.Status -eq "TRIAL EXPIRED" -or
                [string]$state.Status -eq "EXPIRED"
            ) {
                $lblHeaderLicenseStatus.BackColor = $palette.Danger
                $lblHeaderLicenseStatus.ForeColor = [System.Drawing.Color]::White
            }
            elseif ([string]$state.Status -eq "UNLICENSED") {
                $lblHeaderLicenseStatus.BackColor = $palette.Surface2
                $lblHeaderLicenseStatus.ForeColor = $palette.Muted
            }
            else {
                $lblHeaderLicenseStatus.BackColor = $palette.Warning
                $lblHeaderLicenseStatus.ForeColor = [System.Drawing.Color]::White
            }

            Set-RoundedControlRegion -Control $lblHeaderLicenseStatus -Radius 9
        }

        if ($null -ne $lblHeaderLicenseDays) {
            if ([string]$state.Status -eq "TRIAL") {
                $lblHeaderLicenseDays.Text = (
                    [string]$state.DaysRemaining +
                    " days left | Full Trial"
                )
                $lblHeaderLicenseDays.ForeColor = $palette.Accent
            }
            elseif (
                [string]$state.Status -eq "LICENSED" -and
                [string]$state.Expires -eq "PERPETUAL"
            ) {
                $lblHeaderLicenseDays.Text = "Perpetual license"
                $lblHeaderLicenseDays.ForeColor = $palette.Success
            }
            elseif (
                [string]$state.Status -eq "LICENSED" -and
                -not [string]::IsNullOrWhiteSpace([string]$state.DaysRemaining)
            ) {
                $lblHeaderLicenseDays.Text = (
                    [string]$state.DaysRemaining + " days left"
                )
                $lblHeaderLicenseDays.ForeColor = $palette.Success
            }
            elseif ([string]$state.Status -eq "TRIAL EXPIRED") {
                $lblHeaderLicenseDays.Text = "Activate to unlock"
                $lblHeaderLicenseDays.ForeColor = $palette.Danger
            }
            elseif ([string]$state.Status -eq "TRIAL INVALID") {
                $lblHeaderLicenseDays.Text = "Activation required"
                $lblHeaderLicenseDays.ForeColor = $palette.Warning
            }
            elseif ([string]$state.Status -eq "EXPIRED") {
                $lblHeaderLicenseDays.Text = "License expired"
                $lblHeaderLicenseDays.ForeColor = $palette.Danger
            }
            elseif ([string]$state.Status -eq "MACHINE MISMATCH") {
                $lblHeaderLicenseDays.Text = "Machine mismatch"
                $lblHeaderLicenseDays.ForeColor = $palette.Warning
            }
            elseif ([string]$state.Status -eq "INVALID") {
                $lblHeaderLicenseDays.Text = "Invalid license"
                $lblHeaderLicenseDays.ForeColor = $palette.Warning
            }
            else {
                $lblHeaderLicenseDays.Text = "Activation required"
                $lblHeaderLicenseDays.ForeColor = $palette.Muted
            }
        }

        if ($null -ne $lblHeaderLicenseDays) {
            $lblHeaderLicenseDays.Text = Convert-AghrabUiText `
                -Text ([string]$lblHeaderLicenseDays.Text) `
                -Language $script:CurrentLanguage
        }

        [void](Apply-AghrabLicenseEnforcement)
        return $state
    }
    catch {
        return $null
    }
}

# Health Status Alerts
$script:HealthAlertsEnabled = $false
$script:HealthAlertWarning = $true
$script:HealthAlertCritical = $true
$script:HealthAlertRecovery = $true
$script:HealthNotifyIcon = $null
$script:LastHealthAlertProfile = ""
$script:LastHealthAlertDashboard = ""

function Get-AghrabSettings {
    $defaults = [PSCustomObject]@{
        Theme = "Light"
        Language = "English"
        PersianFont = "Tahoma"
        HealthAlertsEnabled = $false
        HealthAlertWarning = $true
        HealthAlertCritical = $true
        HealthAlertRecovery = $true
    }

    if (-not (Test-Path -LiteralPath $script:AghrabSettingsPath -PathType Leaf)) {
        return $defaults
    }

    try {
        $raw = Get-Content -LiteralPath $script:AghrabSettingsPath -Raw -ErrorAction Stop
        $obj = $raw | ConvertFrom-Json -ErrorAction Stop

        if ($null -eq $obj.Theme -or [string]::IsNullOrWhiteSpace([string]$obj.Theme)) {
            $obj | Add-Member -NotePropertyName Theme -NotePropertyValue "Light" -Force
        }
        if (
            $null -eq $obj.Language -or
            [string]::IsNullOrWhiteSpace([string]$obj.Language) -or
            [string]$obj.Language -notin @("English","Persian")
        ) {
            $obj | Add-Member -NotePropertyName Language -NotePropertyValue "English" -Force
        }
        if (
            $null -eq $obj.PersianFont -or
            [string]::IsNullOrWhiteSpace([string]$obj.PersianFont) -or
            [string]$obj.PersianFont -notin @("Tahoma","B Koodak")
        ) {
            $obj | Add-Member -NotePropertyName PersianFont -NotePropertyValue "Tahoma" -Force
        }
        if ($null -eq $obj.HealthAlertsEnabled) {
            $obj | Add-Member -NotePropertyName HealthAlertsEnabled -NotePropertyValue $false -Force
        }
        if ($null -eq $obj.HealthAlertWarning) {
            $obj | Add-Member -NotePropertyName HealthAlertWarning -NotePropertyValue $true -Force
        }
        if ($null -eq $obj.HealthAlertCritical) {
            $obj | Add-Member -NotePropertyName HealthAlertCritical -NotePropertyValue $true -Force
        }
        if ($null -eq $obj.HealthAlertRecovery) {
            $obj | Add-Member -NotePropertyName HealthAlertRecovery -NotePropertyValue $true -Force
        }

        return $obj
    }
    catch {
        return $defaults
    }
}

function Save-AghrabSettings {
    param(
        [string]$Theme,
        [string]$Language,
        [string]$PersianFont
    )

    if ([string]::IsNullOrWhiteSpace($Theme)) {
        $Theme = "Light"
    }

    if ([string]::IsNullOrWhiteSpace($Language)) {
        $Language = [string]$script:CurrentLanguage
    }
    if ($Language -notin @("English","Persian")) {
        $Language = "English"
    }

    if ([string]::IsNullOrWhiteSpace($PersianFont)) {
        $PersianFont = [string]$script:CurrentPersianFont
    }
    if ($PersianFont -notin @("Tahoma","B Koodak")) {
        $PersianFont = "Tahoma"
    }

    $obj = [PSCustomObject]@{
        Theme = $Theme
        Language = $Language
        PersianFont = $PersianFont
        HealthAlertsEnabled = [bool]$script:HealthAlertsEnabled
        HealthAlertWarning = [bool]$script:HealthAlertWarning
        HealthAlertCritical = [bool]$script:HealthAlertCritical
        HealthAlertRecovery = [bool]$script:HealthAlertRecovery
    }

    $obj | ConvertTo-Json -Depth 5 | Set-Content `
        -LiteralPath $script:AghrabSettingsPath `
        -Encoding UTF8 `
        -Force
}


# ---------------- Operations / Health / Scheduler ----------------
$script:SchedulerSettingsPath = Join-Path $script:AghrabConfigDir "automatic-capture.json"

function Get-HealthDataDir {
    $root = ""
    try { $root = Get-OutputRoot } catch {}

    if ([string]::IsNullOrWhiteSpace($root)) {
        $root = Join-Path ([Environment]::GetFolderPath("Desktop")) "aghrab"
    }

    $dir = Join-Path $root "_AGHRAB_Health"
    try { New-Item -ItemType Directory -Force -Path $dir | Out-Null } catch {}
    return $dir
}

function Get-HealthStatusFile {
    return (Join-Path (Get-HealthDataDir) "HealthStatus.json")
}

function Get-HealthHistoryFile {
    return (Join-Path (Get-HealthDataDir) "HealthHistory-v6.1.csv")
}

function Get-AutomaticCaptureLogFile {
    return (Join-Path (Get-HealthDataDir) "AutomaticCapture.log")
}

function Write-SchedulerLog {
    param([string]$Message)

    $line = (Get-Date -Format "yyyy-MM-dd HH:mm:ss") + "  " + $Message

    try {
        $path = Get-AutomaticCaptureLogFile
        Add-Content -LiteralPath $path -Value $line -Encoding UTF8
    }
    catch {}

    if ($null -ne $txtSchedulerLog) {
        try {
            $txtSchedulerLog.AppendText($line + "`r`n")
            $txtSchedulerLog.SelectionStart = $txtSchedulerLog.TextLength
            $txtSchedulerLog.ScrollToCaret()
        }
        catch {}
    }
}


function Ensure-HealthNotifyIcon {
    if ($null -ne $script:HealthNotifyIcon) {
        return $script:HealthNotifyIcon
    }

    try {
        $icon = New-Object System.Windows.Forms.NotifyIcon
        $icon.Text = "RAQEB Sentinel Pro"
        $icon.Visible = $true

        try {
            if ($null -ne $form -and $null -ne $form.Icon) {
                $icon.Icon = $form.Icon
            }
            else {
                $icon.Icon = [System.Drawing.SystemIcons]::Information
            }
        }
        catch {
            $icon.Icon = [System.Drawing.SystemIcons]::Information
        }

        $icon.Add_BalloonTipClicked({
            try {
                if ($null -ne $form) {
                    $form.Show()
                    $form.WindowState = [System.Windows.Forms.FormWindowState]::Normal
                    $form.Activate()
                }

                if ($null -ne $tabHealth) {
                    $tabs.SelectedTab = $tabHealth
                    Update-SidebarNavigation
                    Refresh-HealthCenter
                }

                if (
                    -not [string]::IsNullOrWhiteSpace($script:LastHealthAlertProfile) -and
                    -not [string]::IsNullOrWhiteSpace($script:LastHealthAlertDashboard)
                ) {
                    Select-HealthRecordInTable `
                        -Profile $script:LastHealthAlertProfile `
                        -Dashboard $script:LastHealthAlertDashboard
                }
            }
            catch {}
        })

        $script:HealthNotifyIcon = $icon
        return $script:HealthNotifyIcon
    }
    catch {
        return $null
    }
}

function Show-HealthStatusAlert {
    param(
        [string]$Profile,
        [string]$Dashboard,
        [string]$PreviousStatus,
        [string]$NewStatus,
        [int]$NoDataCount = -1,
        [string]$Correlation = ""
    )

    if (-not $script:HealthAlertsEnabled) {
        return
    }

    $shouldNotify = $false
    $kind = [System.Windows.Forms.ToolTipIcon]::Info
    $title = "RAQEB Health"

    if ($NewStatus -eq "Critical" -and $script:HealthAlertCritical) {
        $shouldNotify = $true
        $kind = [System.Windows.Forms.ToolTipIcon]::Error
        $title = "RAQEB - Critical Dashboard"
    }
    elseif ($NewStatus -eq "Warning" -and $script:HealthAlertWarning) {
        $shouldNotify = $true
        $kind = [System.Windows.Forms.ToolTipIcon]::Warning
        $title = "RAQEB - Dashboard Warning"
    }
    elseif (
        $NewStatus -eq "Healthy" -and
        $PreviousStatus -in @("Warning","Critical") -and
        $script:HealthAlertRecovery
    ) {
        $shouldNotify = $true
        $kind = [System.Windows.Forms.ToolTipIcon]::Info
        $title = "RAQEB - Dashboard Recovered"
    }

    if (-not $shouldNotify) {
        return
    }

    $script:LastHealthAlertProfile = $Profile
    $script:LastHealthAlertDashboard = $Dashboard

    $parts = New-Object System.Collections.Generic.List[string]
    $parts.Add($Dashboard + "  |  " + $PreviousStatus + " -> " + $NewStatus)

    if ($NoDataCount -ge 0) {
        $parts.Add("No Data panels: " + $NoDataCount)
    }

    if (-not [string]::IsNullOrWhiteSpace($Correlation)) {
        $parts.Add("Correlation: " + $Correlation)
    }

    $parts.Add("Profile: " + $Profile)
    $message = ($parts -join "`r`n")

    # Keep balloon text compact on older Windows NotifyIcon implementations.
    if ($message.Length -gt 240) {
        $message = $message.Substring(0,237) + "..."
    }

    $notify = Ensure-HealthNotifyIcon
    if ($null -ne $notify) {
        try {
            $notify.BalloonTipTitle = $title
            $notify.BalloonTipText = $message
            $notify.BalloonTipIcon = $kind
            $notify.ShowBalloonTip(5000)
        }
        catch {}
    }

    try {
        Write-SchedulerLog (
            "HEALTH ALERT | " +
            $Dashboard + " | " +
            $PreviousStatus + " -> " + $NewStatus +
            $(if (-not [string]::IsNullOrWhiteSpace($Correlation)) { " | " + $Correlation } else { "" })
        )
    }
    catch {}
}

function Test-HealthAlertNotification {
    if (-not $script:HealthAlertsEnabled) {
        [System.Windows.Forms.MessageBox]::Show(
            $form,
            "Health Alerts are disabled. Enable them first.",
            "RAQEB Sentinel Pro",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        )
        return
    }

    $notify = Ensure-HealthNotifyIcon
    if ($null -eq $notify) {
        [System.Windows.Forms.MessageBox]::Show(
            $form,
            "Windows notification could not be initialized.",
            "RAQEB Sentinel Pro",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Warning
        )
        return
    }

    try {
        $notify.BalloonTipTitle = "RAQEB - Health Alert Test"
        $notify.BalloonTipText = "Desktop Health Alerts are working."
        $notify.BalloonTipIcon = [System.Windows.Forms.ToolTipIcon]::Info
        $notify.ShowBalloonTip(5000)
    }
    catch {}
}

function Get-HealthRecords {
    $file = Get-HealthStatusFile

    if (-not (Test-Path -LiteralPath $file -PathType Leaf)) {
        return @()
    }

    try {
        $raw = Get-Content -LiteralPath $file -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($null -eq $raw) { return @() }
        return @($raw)
    }
    catch {
        return @()
    }
}

function Save-HealthRecords {
    param($Records)

    $file = Get-HealthStatusFile
    @($Records) |
        ConvertTo-Json -Depth 10 |
        Set-Content -LiteralPath $file -Encoding UTF8 -Force
}

function Write-HealthHistoryRow {
    param($Record)

    try {
        $file = Get-HealthHistoryFile
        $noDataText = ""
        if ($null -ne $Record.NoDataPanels) {
            $noDataText = (@($Record.NoDataPanels) -join " | ")
        }

        $row = [PSCustomObject]@{
            Time = [string]$Record.LastCheck
            Profile = [string]$Record.Profile
            Dashboard = [string]$Record.Dashboard
            Status = [string]$Record.Status
            NoDataPanels = [string]$Record.NoDataCount
            NoDataPanelNames = $noDataText
            Errors = [string]$Record.Errors
            Confidence = [string]$Record.Confidence
            FieldState = [string]$Record.FieldState
            FieldSummary = [string]$Record.FieldSummary
            Correlation = [string]$Record.Correlation
            VerificationIndex = [string]$Record.VerificationIndex
            VerificationWindow = [string]$Record.VerificationWindow
            Screenshot = [string]$Record.Screenshot
            Message = [string]$Record.Message
        }

        if (Test-Path -LiteralPath $file -PathType Leaf) {
            $row | Export-Csv -LiteralPath $file -Append -NoTypeInformation -Encoding UTF8
        }
        else {
            $row | Export-Csv -LiteralPath $file -NoTypeInformation -Encoding UTF8
        }
    }
    catch {}
}

function Set-HealthRecord {
    param(
        [string]$Profile,
        [string]$Dashboard,
        [string]$Status,
        [int]$NoDataCount = -1,
        [string[]]$NoDataPanels = @(),
        [int]$Errors = 0,
        [string]$Confidence = "",
        [string]$Message = "",
        [string]$Screenshot = "",
        [string]$FieldState = "Not checked",
        [object[]]$FieldResults = @(),
        [string]$FieldSummary = "Not checked",
        [string]$Correlation = "Visual-only",
        [string]$CorrelationMessage = "",
        [string]$VerificationIndex = "",
        [int]$VerificationWindow = 0
    )

    if ([string]::IsNullOrWhiteSpace($Profile) -or [string]::IsNullOrWhiteSpace($Dashboard)) {
        return
    }

    if ($Status -notin @("Healthy","Warning","Critical","Unknown")) {
        $Status = "Unknown"
    }

    $existingRecord = @(
        Get-HealthRecords |
        Where-Object {
            ([string]$_.Profile -eq $Profile) -and
            ([string]$_.Dashboard -eq $Dashboard)
        }
    ) | Select-Object -First 1

    $previousStatus = ""
    if ($null -ne $existingRecord) {
        $previousStatus = [string]$existingRecord.Status
    }

    $nowText = Get-Date -Format "yyyy-MM-dd HH:mm:ss"

    $record = [PSCustomObject]@{
        Profile = $Profile
        Dashboard = $Dashboard
        Status = $Status
        LastCheck = $nowText
        NoDataCount = $NoDataCount
        NoDataPanels = @($NoDataPanels)
        Errors = $Errors
        Confidence = $Confidence
        Message = $Message
        Screenshot = $Screenshot

        FieldState = $FieldState
        FieldResults = @($FieldResults)
        FieldSummary = $FieldSummary
        Correlation = $Correlation
        CorrelationMessage = $CorrelationMessage
        VerificationIndex = $VerificationIndex
        VerificationWindow = $VerificationWindow
    }

    $records = @(
        Get-HealthRecords |
        Where-Object {
            -not (
                ([string]$_.Profile -eq $Profile) -and
                ([string]$_.Dashboard -eq $Dashboard)
            )
        }
    )

    $records += $record
    Save-HealthRecords -Records $records
    Write-HealthHistoryRow -Record $record

    # Alert only on a meaningful status change. This prevents notification spam
    # when the same Warning/Critical condition remains across multiple cycles.
    $statusChanged = (
        [string]::IsNullOrWhiteSpace($previousStatus) -or
        $previousStatus -ne $Status
    )

    if ($statusChanged) {
        Show-HealthStatusAlert `
            -Profile $Profile `
            -Dashboard $Dashboard `
            -PreviousStatus $(if ([string]::IsNullOrWhiteSpace($previousStatus)) { "Unknown" } else { $previousStatus }) `
            -NewStatus $Status `
            -NoDataCount $NoDataCount `
            -Correlation $Correlation
    }

    if ($null -ne $lvHealth) {
        try { Refresh-HealthCenter } catch {}
    }
}

function Get-HealthInventory {
    $saved = @(Get-HealthRecords)
    $inventory = @()

    foreach ($profile in @($script:ElkProfiles)) {
        foreach ($dashboard in @($profile.Dashboards)) {
            $name = [string]$dashboard.Name
            if ([string]::IsNullOrWhiteSpace($name)) { continue }

            $existing = @(
                $saved |
                Where-Object {
                    ([string]$_.Profile -eq [string]$profile.Name) -and
                    ([string]$_.Dashboard -eq $name)
                }
            ) | Select-Object -First 1

            if ($null -ne $existing) {
                $inventory += $existing
            }
            else {
                $inventory += [PSCustomObject]@{
                    Profile = [string]$profile.Name
                    Dashboard = $name
                    Status = "Unknown"
                    LastCheck = "-"
                    NoDataCount = -1
                    NoDataPanels = @()
                    Errors = 0
                    Confidence = ""
                    Message = "Not checked yet."
                    Screenshot = ""
                    FieldState = "Not checked"
                    FieldResults = @()
                    FieldSummary = "Not checked"
                    Correlation = "Not checked"
                    CorrelationMessage = ""
                    VerificationIndex = ""
                    VerificationWindow = 0
                }
            }
        }
    }

    return @($inventory)
}

function Get-HealthStatusRank {
    param([string]$Status)

    switch ($Status) {
        "Critical" { return 1 }
        "Warning" { return 2 }
        "Unknown" { return 3 }
        "Healthy" { return 4 }
        default { return 5 }
    }
}

function Convert-HealthCountText {
    param($Value)

    try {
        $n = [int]$Value
        if ($n -lt 0) { return "-" }
        return [string]$n
    }
    catch {
        return "-"
    }
}

function Get-HealthCorrelationFriendlyText {
    param([string]$Correlation)

    switch ($Correlation) {
        "DATA-SIDE SIGNAL" {
            return "Likely data-side issue. Empty dashboard panel(s) and expected fields also have no recent data. Check source logs, ingestion, parsing and mapping."
        }
        "DASHBOARD-SIDE SIGNAL" {
            return "Data exists in Elasticsearch, but the screenshot still has empty panel(s). Check Data View, KQL/filter, visualization and dashboard time range."
        }
        "FIELD GAP" {
            return "Some expected fields have no recent data. Check whether those fields are parsed, mapped and populated by the source."
        }
        "FIELDS ACTIVE" {
            return "Expected fields have recent data in Elasticsearch."
        }
        "VERIFY ERROR" {
            return "Field Verification could not complete. Check Elasticsearch URL, API Key, TLS setting and index permissions."
        }
        "VERIFY OFF" {
            return "Field Verification is disabled for this profile."
        }
        "FIELDS NOT SET" {
            return "No Expected Fields are configured for this dashboard."
        }
        "INDEX NOT SET" {
            return "No ES Index / Data Stream is configured for this dashboard."
        }
        "VERIFY NOT READY" {
            return "Field Verification is not ready. Check the profile-level Elasticsearch settings."
        }
        "Visual-only" {
            return "Only screenshot / AI health was evaluated. Elasticsearch field verification was not used."
        }
        "Not checked" {
            return "This dashboard has not been checked yet."
        }
        default {
            if ([string]::IsNullOrWhiteSpace($Correlation)) {
                return "No correlation result is available yet."
            }
            return $Correlation
        }
    }
}

function Get-HealthCorrelationShortText {
    param([string]$Correlation)

    switch ($Correlation) {
        "DATA-SIDE SIGNAL" { return "Data-side issue" }
        "DASHBOARD-SIDE SIGNAL" { return "Dashboard-side" }
        "FIELD GAP" { return "Field gap" }
        "FIELDS ACTIVE" { return "Fields active" }
        "VERIFY ERROR" { return "Verify error" }
        "VERIFY OFF" { return "Verify off" }
        "FIELDS NOT SET" { return "Fields not set" }
        "INDEX NOT SET" { return "Index not set" }
        "VERIFY NOT READY" { return "Verify not ready" }
        "Visual-only" { return "Visual only" }
        "Not checked" { return "Not checked" }
        default {
            if ([string]::IsNullOrWhiteSpace($Correlation)) { return "-" }
            return $Correlation
        }
    }
}


function Show-SelectedHealthDetail {
    if ($null -eq $lvHealth -or $lvHealth.SelectedItems.Count -eq 0) {
        if ($null -ne $lblHealthDetailTitle) { $lblHealthDetailTitle.Text = Convert-AghrabUiText -Text "Select a dashboard" -Language $script:CurrentLanguage }
        if ($null -ne $lblHealthDetailStatus) { $lblHealthDetailStatus.Text = "Status: -" }
        if ($null -ne $lblHealthDetailMeta) { $lblHealthDetailMeta.Text = "" }
        if ($null -ne $txtHealthNoData) { $txtHealthNoData.Text = Convert-AghrabUiText -Text "No Data panels will appear here." -Language $script:CurrentLanguage }
        if ($null -ne $txtHealthFields) { $txtHealthFields.Text = Convert-AghrabUiText -Text "Select a checked dashboard to see Elasticsearch field verification." -Language $script:CurrentLanguage }
        if ($null -ne $txtHealthDiagnosis) { $txtHealthDiagnosis.Text = Convert-AghrabUiText -Text "RAQEB will explain whether the issue looks data-side or dashboard-side." -Language $script:CurrentLanguage }
        if ($null -ne $lblHealthDetailMessage) { $lblHealthDetailMessage.Text = "" }
        return
    }

    $record = $lvHealth.SelectedItems[0].Tag
    if ($null -eq $record) { return }

    $palette = Get-AghrabPalette -Theme $script:CurrentTheme
    $status = [string]$record.Status

    $lblHealthDetailTitle.Text = [string]$record.Dashboard
    $lblHealthDetailStatus.Text = "Status: " + $status
    $lblHealthDetailStatus.ForeColor = $(
        if ($status -eq "Healthy") { $palette.Success }
        elseif ($status -eq "Warning") { $palette.Warning }
        elseif ($status -eq "Critical") { $palette.Danger }
        else { $palette.Muted }
    )

    $lblHealthDetailMeta.Text =
        "Profile: " + [string]$record.Profile +
        "   |   Last Check: " + [string]$record.LastCheck +
        "   |   Confidence: " + $(if ([string]::IsNullOrWhiteSpace([string]$record.Confidence)) { "-" } else { [string]$record.Confidence })

    $panels = @($record.NoDataPanels)
    if ($panels.Count -gt 0) {
        $txtHealthNoData.Text = (($panels | ForEach-Object { "• " + [string]$_ }) -join "`r`n")
    }
    else {
        $txtHealthNoData.Text = $(if ([int]$record.NoDataCount -eq 0) { "No empty panels detected." } else { "No Data panel names are not available." })
    }

    $fieldLines = @()

    $verifyState = [string]$record.FieldState
    if ([string]::IsNullOrWhiteSpace($verifyState)) { $verifyState = "Not checked" }

    $verifyIndex = [string]$record.VerificationIndex
    if ([string]::IsNullOrWhiteSpace($verifyIndex)) { $verifyIndex = "-" }

    $verifyWindow = "-"
    try {
        if ([int]$record.VerificationWindow -gt 0) {
            $verifyWindow = ([string][int]$record.VerificationWindow) + " min"
        }
    } catch {}

    $fieldLines += ("Verification: " + $verifyState)
    $fieldLines += ("Index: " + $verifyIndex + "   |   Window: " + $verifyWindow)

    foreach ($fr in @($record.FieldResults)) {
        $count = 0
        try { $count = [long]$fr.Count } catch {}

        $marker = "[?]"
        if ([string]$fr.State -eq "Active") {
            $marker = "[OK]"
        }
        elseif ([string]$fr.State -eq "No recent data") {
            $marker = "[NO DATA]"
        }

        $fieldLines += (
            $marker + " " +
            [string]$fr.Field +
            "  —  " +
            [string]$fr.State +
            " (" + [string]$count + ")"
        )
    }

    if (@($record.FieldResults).Count -eq 0 -and
        -not [string]::IsNullOrWhiteSpace([string]$record.FieldSummary)) {
        $fieldLines += [string]$record.FieldSummary
    }

    $txtHealthFields.Text = ($fieldLines -join "`r`n")

    $correlation = [string]$record.Correlation
    $friendly = Get-HealthCorrelationFriendlyText -Correlation $correlation

    $diagnosisLines = @()
    $diagnosisLines += ("Result: " + $(if ([string]::IsNullOrWhiteSpace($correlation)) { "-" } else { $correlation }))
    $diagnosisLines += $friendly

    if (-not [string]::IsNullOrWhiteSpace([string]$record.CorrelationMessage) -and
        [string]$record.CorrelationMessage -ne $friendly) {
        $diagnosisLines += ("Technical detail: " + [string]$record.CorrelationMessage)
    }

    if (-not [string]::IsNullOrWhiteSpace([string]$record.Message)) {
        $diagnosisLines += ("Visual AI: " + [string]$record.Message)
    }

    $txtHealthDiagnosis.Text = ($diagnosisLines -join "`r`n").Trim()

    $lblHealthDetailMessage.Text = ""
}



function Get-AghrabHealthAllProfilesText {
    if ($script:CurrentLanguage -eq "Persian") { return "همه پروفایل‌ها" }
    return "All Profiles"
}

function Get-AghrabHealthAllStatusesText {
    if ($script:CurrentLanguage -eq "Persian") { return "همه وضعیت‌ها" }
    return "All Statuses"
}

function Convert-AghrabHealthStatusToCanonical {
    param([string]$Status)
    switch ($Status) {
        "سالم" { return "Healthy" }
        "هشدار" { return "Warning" }
        "بحرانی" { return "Critical" }
        "نامشخص" { return "Unknown" }
        default { return $Status }
    }
}

function Convert-AghrabHealthStatusToDisplay {
    param([string]$Status)
    return Convert-AghrabUiText `
        -Text (Convert-AghrabHealthStatusToCanonical -Status $Status) `
        -Language $script:CurrentLanguage
}

function Refresh-AghrabHealthStatusFilterLanguage {
    if ($null -eq $cmbHealthStatus) { return }

    $selected = [string]$cmbHealthStatus.SelectedItem
    $canonical = Convert-AghrabHealthStatusToCanonical -Status $selected

    $script:LoadingHealthManagerUi = $true
    try {
        $cmbHealthStatus.Items.Clear()
        [void]$cmbHealthStatus.Items.Add((Get-AghrabHealthAllStatusesText))
        foreach ($status in @("Healthy","Warning","Critical","Unknown")) {
            [void]$cmbHealthStatus.Items.Add(
                (Convert-AghrabHealthStatusToDisplay -Status $status)
            )
        }

        if ($selected -in @("","All Statuses","همه وضعیت‌ها")) {
            $cmbHealthStatus.SelectedIndex = 0
        }
        else {
            $display = Convert-AghrabHealthStatusToDisplay -Status $canonical
            if ($cmbHealthStatus.Items.Contains($display)) {
                $cmbHealthStatus.SelectedItem = $display
            }
            else {
                $cmbHealthStatus.SelectedIndex = 0
            }
        }
    }
    finally {
        $script:LoadingHealthManagerUi = $false
    }
}

function Refresh-HealthManagerProfiles {
    if ($null -eq $cmbHealthProfile) { return }

    $current = [string]$cmbHealthProfile.SelectedItem

    $script:LoadingHealthManagerUi = $true
    try {
        $cmbHealthProfile.Items.Clear()
        [void]$cmbHealthProfile.Items.Add((Get-AghrabHealthAllProfilesText))

        foreach ($profile in @($script:ElkProfiles | Sort-Object Name)) {
            [void]$cmbHealthProfile.Items.Add([string]$profile.Name)
        }

        if (
            -not [string]::IsNullOrWhiteSpace($current) -and
            $cmbHealthProfile.Items.Contains($current)
        ) {
            $cmbHealthProfile.SelectedItem = $current
        }
        else {
            $cmbHealthProfile.SelectedItem = (Get-AghrabHealthAllProfilesText)
        }
    }
    finally {
        $script:LoadingHealthManagerUi = $false
    }
}

function Get-FilteredHealthInventory {
    $records = @(Get-HealthInventory)
    $profileFilter = "All Profiles"
    $statusFilter = "All Statuses"
    $searchText = ""

    if ($null -ne $cmbHealthProfile -and $null -ne $cmbHealthProfile.SelectedItem) {
        $profileFilter = [string]$cmbHealthProfile.SelectedItem
    }

    if ($null -ne $cmbHealthStatus -and $null -ne $cmbHealthStatus.SelectedItem) {
        $statusFilter = [string]$cmbHealthStatus.SelectedItem
    }

    if ($profileFilter -eq "همه پروفایل‌ها") {
        $profileFilter = "All Profiles"
    }
    if ($statusFilter -eq "همه وضعیت‌ها") {
        $statusFilter = "All Statuses"
    }
    $statusFilter = Convert-AghrabHealthStatusToCanonical -Status $statusFilter

    if ($null -ne $txtHealthSearch) {
        $searchText = $txtHealthSearch.Text.Trim()
    }

    if (
        -not [string]::IsNullOrWhiteSpace($profileFilter) -and
        $profileFilter -ne "All Profiles"
    ) {
        $records = @(
            $records |
            Where-Object { [string]$_.Profile -eq $profileFilter }
        )
    }

    if (
        -not [string]::IsNullOrWhiteSpace($statusFilter) -and
        $statusFilter -ne "All Statuses"
    ) {
        $records = @(
            $records |
            Where-Object { [string]$_.Status -eq $statusFilter }
        )
    }

    if (-not [string]::IsNullOrWhiteSpace($searchText)) {
        $needle = $searchText.ToLowerInvariant()

        $records = @(
            $records |
            Where-Object {
                ([string]$_.Dashboard).ToLowerInvariant().Contains($needle) -or
                ([string]$_.Profile).ToLowerInvariant().Contains($needle) -or
                ([string]$_.Status).ToLowerInvariant().Contains($needle) -or
                ([string]$_.FieldSummary).ToLowerInvariant().Contains($needle) -or
                ([string]$_.Correlation).ToLowerInvariant().Contains($needle) -or
                ([string]$_.VerificationIndex).ToLowerInvariant().Contains($needle)
            }
        )
    }

    return @($records)
}

function Sync-HealthDashboardInventory {
    param([switch]$ShowMessage)

    # Explicit Sync reloads saved ELK Profiles from disk. New dashboards become
    # UNKNOWN automatically. Deleted dashboards are pruned from HealthStatus.
    Load-ElkProfiles
    Refresh-ElkProfileList
    Refresh-SchedulerProfiles
    Refresh-HealthManagerProfiles

    $valid = @{}
    foreach ($profile in @($script:ElkProfiles)) {
        foreach ($dashboard in @($profile.Dashboards)) {
            $key = ([string]$profile.Name) + "`u001f" + ([string]$dashboard.Name)
            $valid[$key] = $true
        }
    }

    $saved = @(Get-HealthRecords)
    $kept = @(
        $saved |
        Where-Object {
            $key = ([string]$_.Profile) + "`u001f" + ([string]$_.Dashboard)
            $valid.ContainsKey($key)
        }
    )

    if ($kept.Count -ne $saved.Count) {
        Save-HealthRecords -Records $kept
    }

    Refresh-HealthCenter

    if ($ShowMessage) {
        $configuredCount = 0
        foreach ($profile in @($script:ElkProfiles)) {
            $configuredCount += @($profile.Dashboards).Count
        }

        [System.Windows.Forms.MessageBox]::Show(
            $form,
            "Dashboard inventory synchronized.`r`n`r`nConfigured dashboards: $configuredCount",
            "RAQEB Sentinel Pro",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        )
    }
}

function Open-HealthDashboardManager {
    $profileName = ""
    if ($null -ne $cmbHealthProfile -and $null -ne $cmbHealthProfile.SelectedItem) {
        $profileName = [string]$cmbHealthProfile.SelectedItem
    }

    $tabs.SelectedTab = $tabElk
    Update-SidebarNavigation

    if (
        -not [string]::IsNullOrWhiteSpace($profileName) -and
        $profileName -ne "All Profiles"
    ) {
        for ($i = 0; $i -lt $lstElkProfiles.Items.Count; $i++) {
            if ([string]$lstElkProfiles.Items[$i] -eq $profileName) {
                $lstElkProfiles.SelectedIndex = $i
                break
            }
        }
    }
}

function Set-HealthViewMode {
    param([ValidateSet("Cards","Table")][string]$Mode)

    $script:HealthViewMode = $Mode

    if ($Mode -eq "Cards") {
        $flowHealthCards.Visible = $true
        $lvHealth.Visible = $false
        $btnHealthViewMode.Text = "Table View"
    }
    else {
        $flowHealthCards.Visible = $false
        $lvHealth.Visible = $true
        $btnHealthViewMode.Text = "Card View"
    }
}

function Invoke-HealthDashboardRecheck {
    param(
        [string]$ProfileName,
        [string]$DashboardName
    )

    if ([string]::IsNullOrWhiteSpace($ProfileName) -or
        [string]::IsNullOrWhiteSpace($DashboardName)) {
        return
    }

    if ($script:SchedulerBusy -or $script:CaptureBusy) {
        [System.Windows.Forms.MessageBox]::Show(
            $form,
            "Another capture is already running.",
            "RAQEB Sentinel Pro"
        )
        return
    }

    if (-not $cmbSchedulerProfile.Items.Contains($ProfileName)) {
        Refresh-SchedulerProfiles
    }

    if ($cmbSchedulerProfile.Items.Contains($ProfileName)) {
        $cmbSchedulerProfile.SelectedItem = $ProfileName
    }

    $tabs.SelectedTab = $tabHealth
    Update-SidebarNavigation

    Invoke-AutomaticCaptureCycle `
        -Interactive `
        -DashboardName $DashboardName
}

function Open-HealthRecordScreenshot {
    param($Record)

    if ($null -eq $Record) { return }

    $path = [string]$Record.Screenshot
    if (-not [string]::IsNullOrWhiteSpace($path) -and (Test-Path -LiteralPath $path -PathType Leaf)) {
        Start-Process $path
    }
    else {
        [System.Windows.Forms.MessageBox]::Show(
            $form,
            "No screenshot is available for this dashboard.",
            "RAQEB Sentinel Pro"
        )
    }
}

function Select-HealthRecordInTable {
    param(
        [string]$Profile,
        [string]$Dashboard
    )

    if ($null -eq $lvHealth) { return }

    foreach ($item in $lvHealth.Items) {
        $record = $item.Tag
        if (
            $null -ne $record -and
            [string]$record.Profile -eq $Profile -and
            [string]$record.Dashboard -eq $Dashboard
        ) {
            $item.Selected = $true
            $item.Focused = $true
            $item.EnsureVisible()
            Show-SelectedHealthDetail
            return
        }
    }
}


function Get-DashboardHealthHistory {
    param(
        [string]$ProfileName,
        [string]$DashboardName,
        [int]$Limit = 100
    )

    $file = Get-HealthHistoryFile
    if (-not (Test-Path -LiteralPath $file -PathType Leaf)) {
        return @()
    }

    try {
        $rows = @(
            Import-Csv -LiteralPath $file -Encoding UTF8 |
            Where-Object {
                [string]$_.Profile -eq $ProfileName -and
                [string]$_.Dashboard -eq $DashboardName
            }
        )

        if ($rows.Count -eq 0) {
            return @()
        }

        # CSV is append-only. Reverse to show newest checks first.
        [array]::Reverse($rows)

        if ($Limit -gt 0 -and $rows.Count -gt $Limit) {
            return @($rows | Select-Object -First $Limit)
        }

        return @($rows)
    }
    catch {
        return @()
    }
}

function Show-DashboardHealthHistory {
    param(
        [string]$ProfileName,
        [string]$DashboardName
    )

    if ([string]::IsNullOrWhiteSpace($ProfileName) -or
        [string]::IsNullOrWhiteSpace($DashboardName)) {
        return
    }

    $rows = @(Get-DashboardHealthHistory `
        -ProfileName $ProfileName `
        -DashboardName $DashboardName `
        -Limit 100)

    $palette = Get-AghrabPalette -Theme $script:CurrentTheme

    $dialog = New-Object System.Windows.Forms.Form
    $dialog.Text = "RAQEB Dashboard Health History"
    $dialog.StartPosition = "CenterParent"
    $dialog.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::Sizable
    $dialog.MinimumSize = New-Object System.Drawing.Size(900,570)
    $dialog.Size = New-Object System.Drawing.Size(1040,650)
    $dialog.Font = New-Object System.Drawing.Font("Segoe UI",9)
    $dialog.BackColor = $palette.Background
    $dialog.ForeColor = $palette.Text

    $title = New-Object System.Windows.Forms.Label
    $title.Text = $DashboardName
    $title.Font = New-Object System.Drawing.Font("Segoe UI Semibold",16,[System.Drawing.FontStyle]::Bold)
    $title.Location = New-Object System.Drawing.Point(22,18)
    $title.Size = New-Object System.Drawing.Size(620,32)
    $dialog.Controls.Add($title)

    $sub = New-Object System.Windows.Forms.Label
    $sub.Text = "Profile: " + $ProfileName + "   |   Last 100 health checks"
    $sub.Location = New-Object System.Drawing.Point(24,52)
    $sub.Size = New-Object System.Drawing.Size(700,22)
    $sub.ForeColor = $palette.Muted
    $dialog.Controls.Add($sub)

    $healthy = @($rows | Where-Object { $_.Status -eq "Healthy" }).Count
    $warning = @($rows | Where-Object { $_.Status -eq "Warning" }).Count
    $critical = @($rows | Where-Object { $_.Status -eq "Critical" }).Count
    $unknown = @($rows | Where-Object { $_.Status -eq "Unknown" }).Count

    function Add-HistoryMetric {
        param(
            [int]$Left,
            [string]$Name,
            [string]$Value,
            [System.Drawing.Color]$ValueColor
        )

        $panel = New-Object System.Windows.Forms.Panel
        $panel.Location = New-Object System.Drawing.Point($Left,88)
        $panel.Size = New-Object System.Drawing.Size(176,74)
        $panel.BackColor = $palette.Surface
        $panel.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
        $dialog.Controls.Add($panel)

        $v = New-Object System.Windows.Forms.Label
        $v.Text = $Value
        $v.Font = New-Object System.Drawing.Font("Segoe UI Semibold",18,[System.Drawing.FontStyle]::Bold)
        $v.Location = New-Object System.Drawing.Point(12,8)
        $v.Size = New-Object System.Drawing.Size(145,30)
        $v.ForeColor = $ValueColor
        $panel.Controls.Add($v)

        $n = New-Object System.Windows.Forms.Label
        $n.Text = $Name
        $n.Location = New-Object System.Drawing.Point(13,44)
        $n.Size = New-Object System.Drawing.Size(145,20)
        $n.ForeColor = $palette.Muted
        $panel.Controls.Add($n)
    }

    Add-HistoryMetric -Left 24  -Name "Checks"   -Value ([string]$rows.Count) -ValueColor $palette.Accent
    Add-HistoryMetric -Left 210 -Name "Healthy"  -Value ([string]$healthy)    -ValueColor $palette.Success
    Add-HistoryMetric -Left 396 -Name "Warning"  -Value ([string]$warning)    -ValueColor $palette.Warning
    Add-HistoryMetric -Left 582 -Name "Critical" -Value ([string]$critical)   -ValueColor $palette.Danger
    Add-HistoryMetric -Left 768 -Name "Unknown"  -Value ([string]$unknown)    -ValueColor $palette.Muted

    $lv = New-Object System.Windows.Forms.ListView
    $lv.Location = New-Object System.Drawing.Point(24,180)
    $lv.Size = New-Object System.Drawing.Size(975,355)
    $lv.Anchor = "Top,Bottom,Left,Right"
    $lv.View = [System.Windows.Forms.View]::Details
    $lv.FullRowSelect = $true
    $lv.MultiSelect = $false
    $lv.HideSelection = $false
    $lv.GridLines = $false
    $lv.BackColor = $palette.Input
    $lv.ForeColor = $palette.Text

    [void]$lv.Columns.Add("Time",145)
    [void]$lv.Columns.Add("Status",85)
    [void]$lv.Columns.Add("No Data",70)
    [void]$lv.Columns.Add("Errors",60)
    [void]$lv.Columns.Add("Field Health",145)
    [void]$lv.Columns.Add("Correlation",160)
    [void]$lv.Columns.Add("Confidence",95)
    [void]$lv.Columns.Add("Message",200)

    foreach ($row in $rows) {
        $item = New-Object System.Windows.Forms.ListViewItem([string]$row.Time)
        [void]$item.SubItems.Add([string]$row.Status)
        [void]$item.SubItems.Add([string]$row.NoDataPanels)
        [void]$item.SubItems.Add([string]$row.Errors)
        [void]$item.SubItems.Add([string]$row.FieldSummary)
        [void]$item.SubItems.Add([string]$row.Correlation)
        [void]$item.SubItems.Add([string]$row.Confidence)
        [void]$item.SubItems.Add([string]$row.Message)
        $item.Tag = $row
        [void]$lv.Items.Add($item)
    }

    $dialog.Controls.Add($lv)

    if ($rows.Count -eq 0) {
        $empty = New-Object System.Windows.Forms.Label
        $empty.Text = "No health history has been recorded for this dashboard yet."
        $empty.Font = New-Object System.Drawing.Font("Segoe UI Semibold",10)
        $empty.Location = New-Object System.Drawing.Point(40,205)
        $empty.Size = New-Object System.Drawing.Size(540,28)
        $empty.ForeColor = $palette.Muted
        $empty.BackColor = $palette.Input
        $empty.BringToFront()
        $dialog.Controls.Add($empty)
    }

    $btnOpenShot = New-Object System.Windows.Forms.Button
    $btnOpenShot.Text = "Open Screenshot"
    $btnOpenShot.Location = New-Object System.Drawing.Point(24,552)
    $btnOpenShot.Size = New-Object System.Drawing.Size(130,34)
    $btnOpenShot.Anchor = "Bottom,Left"
    Style-SecondaryButton $btnOpenShot
    $dialog.Controls.Add($btnOpenShot)

    $btnCsv = New-Object System.Windows.Forms.Button
    $btnCsv.Text = "Open Full CSV"
    $btnCsv.Location = New-Object System.Drawing.Point(164,552)
    $btnCsv.Size = New-Object System.Drawing.Size(120,34)
    $btnCsv.Anchor = "Bottom,Left"
    Style-SecondaryButton $btnCsv
    $dialog.Controls.Add($btnCsv)

    $btnClose = New-Object System.Windows.Forms.Button
    $btnClose.Text = "Close"
    $btnClose.Location = New-Object System.Drawing.Point(899,552)
    $btnClose.Size = New-Object System.Drawing.Size(100,34)
    $btnClose.Anchor = "Bottom,Right"
    Style-PrimaryButton $btnClose
    $dialog.Controls.Add($btnClose)

    $btnOpenShot.Add_Click({
        if ($lv.SelectedItems.Count -eq 0) {
            [System.Windows.Forms.MessageBox]::Show(
                $dialog,
                "Select a history row first.",
                "RAQEB Sentinel Pro"
            )
            return
        }

        $row = $lv.SelectedItems[0].Tag
        $shot = [string]$row.Screenshot

        if (-not [string]::IsNullOrWhiteSpace($shot) -and
            (Test-Path -LiteralPath $shot -PathType Leaf)) {
            Start-Process $shot
        }
        else {
            [System.Windows.Forms.MessageBox]::Show(
                $dialog,
                "Screenshot for this history row is not available.",
                "RAQEB Sentinel Pro"
            )
        }
    })

    $btnCsv.Add_Click({
        $file = Get-HealthHistoryFile
        if (Test-Path -LiteralPath $file -PathType Leaf) {
            Start-Process $file
        }
    })

    $btnClose.Add_Click({ $dialog.Close() })

    $lv.Add_DoubleClick({
        if ($lv.SelectedItems.Count -gt 0) {
            $row = $lv.SelectedItems[0].Tag
            $shot = [string]$row.Screenshot
            if (-not [string]::IsNullOrWhiteSpace($shot) -and
                (Test-Path -LiteralPath $shot -PathType Leaf)) {
                Start-Process $shot
            }
        }
    })

    [void]$dialog.ShowDialog($form)
}

function Refresh-HealthDashboardCards {
    param($Records)

    if ($null -eq $flowHealthCards) { return }

    $flowHealthCards.SuspendLayout()
    try {
        $flowHealthCards.Controls.Clear()
        $palette = Get-AghrabPalette -Theme $script:CurrentTheme

        foreach ($record in @($Records)) {
            $status = [string]$record.Status
            $visual = Get-HealthStatusVisual -Status $status -Theme $script:CurrentTheme
            $statusColor = $visual.Fore

            $card = New-Object System.Windows.Forms.Panel
            $card.Size = New-Object System.Drawing.Size(286,134)
            $card.Margin = New-Object System.Windows.Forms.Padding(0,0,12,12)
            $card.BackColor = $visual.Back
            $card.BorderStyle = [System.Windows.Forms.BorderStyle]::None
            Set-RoundedControlRegion -Control $card -Radius 11

            $statusBorder = $visual.Border
            $card.Add_Paint(({
                param($sender,$e)
                $pen = New-Object System.Drawing.Pen($statusBorder,1)
                try {
                    $e.Graphics.DrawRectangle(
                        $pen,
                        0,0,
                        [Math]::Max(0,$sender.ClientSize.Width-1),
                        [Math]::Max(0,$sender.ClientSize.Height-1)
                    )
                }
                finally {
                    $pen.Dispose()
                }
            }).GetNewClosure())

            $stripe = New-Object System.Windows.Forms.Panel
            $stripe.Location = New-Object System.Drawing.Point(0,0)
            $stripe.Size = New-Object System.Drawing.Size(6,134)
            $stripe.BackColor = $statusColor
            $card.Controls.Add($stripe)

            $lblName = New-Object System.Windows.Forms.Label
            $lblName.Text = [string]$record.Dashboard
            $lblName.Font = New-Object System.Drawing.Font("Segoe UI Semibold",10,[System.Drawing.FontStyle]::Bold)
            $lblName.Location = New-Object System.Drawing.Point(15,9)
            $lblName.Size = New-Object System.Drawing.Size(157,22)
            $lblName.ForeColor = $palette.Text
            $card.Controls.Add($lblName)

            $statusPill = New-Object System.Windows.Forms.Panel
            $statusPill.Location = New-Object System.Drawing.Point(177,7)
            $statusPill.Size = New-Object System.Drawing.Size(96,26)
            $statusPill.BackColor = $visual.Badge
            Set-RoundedControlRegion -Control $statusPill -Radius 13
            $card.Controls.Add($statusPill)

            $statusDot = New-Object System.Windows.Forms.Panel
            $statusDot.Location = New-Object System.Drawing.Point(10,8)
            $statusDot.Size = New-Object System.Drawing.Size(8,8)
            $statusDot.BackColor = $statusColor
            Set-RoundedControlRegion -Control $statusDot -Radius 4
            $statusPill.Controls.Add($statusDot)

            $lblStatus = New-Object System.Windows.Forms.Label
            $lblStatus.Text = Convert-AghrabUiText -Text ($status.ToUpperInvariant()) -Language $script:CurrentLanguage
            $lblStatus.Font = New-Object System.Drawing.Font("Segoe UI Semibold",7.7,[System.Drawing.FontStyle]::Bold)
            $lblStatus.Location = New-Object System.Drawing.Point(22,3)
            $lblStatus.Size = New-Object System.Drawing.Size(67,20)
            $lblStatus.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
            $lblStatus.ForeColor = $statusColor
            $statusPill.Controls.Add($lblStatus)

            $lblProfile = New-Object System.Windows.Forms.Label
            $lblProfile.Text = Convert-AghrabUiText -Text ("Profile: " + [string]$record.Profile) -Language $script:CurrentLanguage
            $lblProfile.Location = New-Object System.Drawing.Point(15,34)
            $lblProfile.Size = New-Object System.Drawing.Size(170,18)
            $lblProfile.ForeColor = $palette.Muted
            $card.Controls.Add($lblProfile)

            $confidence = [string]$record.Confidence
            if (
                -not [string]::IsNullOrWhiteSpace($confidence) -and
                $confidence -notmatch "unavailable|unknown|not checked"
            ) {
                $lblAiBadge = New-Object System.Windows.Forms.Label
                $lblAiBadge.Text = "AI"
                $lblAiBadge.Font = New-Object System.Drawing.Font("Segoe UI Semibold",8,[System.Drawing.FontStyle]::Bold)
                $lblAiBadge.Location = New-Object System.Drawing.Point(238,34)
                $lblAiBadge.Size = New-Object System.Drawing.Size(34,18)
                $lblAiBadge.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
                $lblAiBadge.ForeColor = $palette.Accent
                $lblAiBadge.BackColor = $visual.Badge
                $card.Controls.Add($lblAiBadge)
            }

            $noDataText = Convert-HealthCountText -Value $record.NoDataCount
            $fieldText = Get-HealthCorrelationShortText -Correlation ([string]$record.Correlation)

            $badgeNoData = New-Object System.Windows.Forms.Panel
            $badgeNoData.Location = New-Object System.Drawing.Point(15,56)
            $badgeNoData.Size = New-Object System.Drawing.Size(92,24)
            $badgeNoData.BackColor = $visual.Badge
            Set-RoundedControlRegion -Control $badgeNoData -Radius 7
            $card.Controls.Add($badgeNoData)

            $lblNoData = New-Object System.Windows.Forms.Label
            $lblNoData.Text = Convert-AghrabUiText -Text ("No Data  " + $noDataText) -Language $script:CurrentLanguage
            $lblNoData.Dock = [System.Windows.Forms.DockStyle]::Fill
            $lblNoData.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
            $lblNoData.Font = New-Object System.Drawing.Font("Segoe UI Semibold",8)
            $lblNoData.ForeColor = $(if ($noDataText -ne "-" -and $noDataText -ne "0") { $palette.Warning } else { $palette.Muted })
            $badgeNoData.Controls.Add($lblNoData)

            $badgeFields = New-Object System.Windows.Forms.Panel
            $badgeFields.Location = New-Object System.Drawing.Point(113,56)
            $badgeFields.Size = New-Object System.Drawing.Size(160,24)
            $badgeFields.BackColor = $visual.Badge
            Set-RoundedControlRegion -Control $badgeFields -Radius 7
            $card.Controls.Add($badgeFields)

            $lblFields = New-Object System.Windows.Forms.Label
            $lblFields.Text = Convert-AghrabUiText -Text ("Verify  " + (Convert-AghrabUiText -Text $fieldText -Language $script:CurrentLanguage)) -Language $script:CurrentLanguage
            $lblFields.Dock = [System.Windows.Forms.DockStyle]::Fill
            $lblFields.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
            $lblFields.Font = New-Object System.Drawing.Font("Segoe UI Semibold",8)
            $lblFields.ForeColor = $palette.Muted
            $badgeFields.Controls.Add($lblFields)

            $lblLast = New-Object System.Windows.Forms.Label
            $lblLast.Text = Convert-AghrabUiText -Text ("Last check: " + [string]$record.LastCheck) -Language $script:CurrentLanguage
            $lblLast.Location = New-Object System.Drawing.Point(15,83)
            $lblLast.Size = New-Object System.Drawing.Size(258,17)
            $lblLast.ForeColor = $palette.Muted
            $card.Controls.Add($lblLast)

            $btnDetails = New-Object System.Windows.Forms.Button
            $btnDetails.Text = Convert-AghrabUiText -Text "Details" -Language $script:CurrentLanguage
            $btnDetails.Location = New-Object System.Drawing.Point(12,104)
            $btnDetails.Size = New-Object System.Drawing.Size(58,26)
            Style-SecondaryButton $btnDetails
            $card.Controls.Add($btnDetails)

            $btnHistory = New-Object System.Windows.Forms.Button
            $btnHistory.Text = Convert-AghrabUiText -Text "History" -Language $script:CurrentLanguage
            $btnHistory.Location = New-Object System.Drawing.Point(74,104)
            $btnHistory.Size = New-Object System.Drawing.Size(58,26)
            Style-SecondaryButton $btnHistory
            $card.Controls.Add($btnHistory)

            $btnRecheck = New-Object System.Windows.Forms.Button
            $btnRecheck.Text = Convert-AghrabUiText -Text "Recheck" -Language $script:CurrentLanguage
            $btnRecheck.Location = New-Object System.Drawing.Point(136,104)
            $btnRecheck.Size = New-Object System.Drawing.Size(76,26)
            Style-PrimaryButton $btnRecheck
            $card.Controls.Add($btnRecheck)

            $btnOpen = New-Object System.Windows.Forms.Button
            $btnOpen.Text = Convert-AghrabUiText -Text "Shot" -Language $script:CurrentLanguage
            $btnOpen.Location = New-Object System.Drawing.Point(216,104)
            $btnOpen.Size = New-Object System.Drawing.Size(56,26)
            Style-SecondaryButton $btnOpen
            $card.Controls.Add($btnOpen)

            $recordCopy = $record
            $profileCopy = [string]$record.Profile
            $dashboardCopy = [string]$record.Dashboard

            $btnDetails.Add_Click(({ Select-HealthRecordInTable -Profile $profileCopy -Dashboard $dashboardCopy }).GetNewClosure())
            $btnHistory.Add_Click(({ Show-DashboardHealthHistory -ProfileName $profileCopy -DashboardName $dashboardCopy }).GetNewClosure())
            $btnRecheck.Add_Click(({ Invoke-HealthDashboardRecheck -ProfileName $profileCopy -DashboardName $dashboardCopy }).GetNewClosure())
            $btnOpen.Add_Click(({ Open-HealthRecordScreenshot -Record $recordCopy }).GetNewClosure())

            [void]$flowHealthCards.Controls.Add($card)
        }

        if (@($Records).Count -eq 0) {
            $emptyPanel = New-Object System.Windows.Forms.Panel
            $emptyPanel.Size = New-Object System.Drawing.Size(880,112)
            $emptyPanel.Margin = New-Object System.Windows.Forms.Padding(8,24,0,0)
            $emptyPanel.BackColor = $palette.Surface
            Initialize-AghrabCard -Card $emptyPanel

            $emptyIcon = New-Object System.Windows.Forms.PictureBox
            $emptyIcon.Location = New-Object System.Drawing.Point(32,35)
            $emptyIcon.Size = New-Object System.Drawing.Size(32,32)
            $emptyIcon.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::CenterImage
            $emptyIcon.Image = Get-AghrabIconImage -Kind "health" -FallbackColor $palette.Muted -Size 28
            $emptyPanel.Controls.Add($emptyIcon)

            $emptyTitle = New-Object System.Windows.Forms.Label
            $emptyTitle.Text = "No dashboards to show"
            $emptyTitle.Font = New-Object System.Drawing.Font("Segoe UI Semibold",11,[System.Drawing.FontStyle]::Bold)
            $emptyTitle.Location = New-Object System.Drawing.Point(90,28)
            $emptyTitle.Size = New-Object System.Drawing.Size(300,24)
            $emptyTitle.ForeColor = $palette.Text
            $emptyPanel.Controls.Add($emptyTitle)

            $emptyText = New-Object System.Windows.Forms.Label
            $emptyText.Text = "Add dashboards in ELK Profiles or change the current filters."
            $emptyText.Location = New-Object System.Drawing.Point(91,56)
            $emptyText.Size = New-Object System.Drawing.Size(520,22)
            $emptyText.ForeColor = $palette.Muted
            $emptyPanel.Controls.Add($emptyText)

            [void]$flowHealthCards.Controls.Add($emptyPanel)
        }
    }
    finally {
        $flowHealthCards.ResumeLayout()
    }
}

function Refresh-HealthCenter {
    if ($null -eq $lvHealth) { return }

    $allItems = @(Get-HealthInventory)

    $items = @(
        Get-FilteredHealthInventory |
        Sort-Object @{Expression={ Get-HealthStatusRank -Status ([string]$_.Status) }}, Profile, Dashboard
    )

    $healthy = @($items | Where-Object { $_.Status -eq "Healthy" }).Count
    $warning = @($items | Where-Object { $_.Status -eq "Warning" }).Count
    $critical = @($items | Where-Object { $_.Status -eq "Critical" }).Count
    $unknown = @($items | Where-Object { $_.Status -eq "Unknown" }).Count

    $lblHealthTotalValue.Text = [string]$items.Count
    $lblHealthHealthyValue.Text = [string]$healthy
    $lblHealthWarningValue.Text = [string]$warning
    $lblHealthCriticalValue.Text = [string]$critical
    $lblHealthUnknownValue.Text = [string]$unknown

    $palette = Get-AghrabPalette -Theme $script:CurrentTheme
    $visualTotal = Get-HealthStatusVisual -Status "Total" -Theme $script:CurrentTheme
    $visualHealthy = Get-HealthStatusVisual -Status "Healthy" -Theme $script:CurrentTheme
    $visualWarning = Get-HealthStatusVisual -Status "Warning" -Theme $script:CurrentTheme
    $visualCritical = Get-HealthStatusVisual -Status "Critical" -Theme $script:CurrentTheme
    $visualUnknown = Get-HealthStatusVisual -Status "Unknown" -Theme $script:CurrentTheme

    $cardHealthTotal.BackColor = $visualTotal.Back
    $cardHealthHealthy.BackColor = $visualHealthy.Back
    $cardHealthWarning.BackColor = $visualWarning.Back
    $cardHealthCritical.BackColor = $visualCritical.Back
    $cardHealthUnknown.BackColor = $visualUnknown.Back

    $lblHealthTotalValue.ForeColor = $visualTotal.Fore
    $lblHealthHealthyValue.ForeColor = $visualHealthy.Fore
    $lblHealthWarningValue.ForeColor = $visualWarning.Fore
    $lblHealthCriticalValue.ForeColor = $visualCritical.Fore
    $lblHealthUnknownValue.ForeColor = $visualUnknown.Fore

    foreach ($pic in @($lblHealthTotalIcon,$lblHealthHealthyIcon,$lblHealthWarningIcon,$lblHealthCriticalIcon,$lblHealthUnknownIcon)) {
        try {
            if ($null -ne $pic.Image) {
                $old = $pic.Image
                $pic.Image = $null
                $old.Dispose()
            }
        }
        catch {}
    }

    $lblHealthTotalIcon.Image = Get-AghrabIconImage -Kind "status-total" -FallbackColor $visualTotal.Fore -Size 24
    $lblHealthHealthyIcon.Image = Get-AghrabIconImage -Kind "status-healthy" -FallbackColor $visualHealthy.Fore -Size 24
    $lblHealthWarningIcon.Image = Get-AghrabIconImage -Kind "status-warning" -FallbackColor $visualWarning.Fore -Size 24
    $lblHealthCriticalIcon.Image = Get-AghrabIconImage -Kind "status-critical" -FallbackColor $visualCritical.Fore -Size 24
    $lblHealthUnknownIcon.Image = Get-AghrabIconImage -Kind "status-unknown" -FallbackColor $visualUnknown.Fore -Size 24

    $barHealthTotal.BackColor = $visualTotal.Fore
    $barHealthHealthy.BackColor = $visualHealthy.Fore
    $barHealthWarning.BackColor = $visualWarning.Fore
    $barHealthCritical.BackColor = $visualCritical.Fore
    $barHealthUnknown.BackColor = $visualUnknown.Fore

    Refresh-HealthDashboardCards -Records $items

    $lvHealth.BeginUpdate()
    try {
        $lvHealth.Items.Clear()

        foreach ($record in $items) {
            $item = New-Object System.Windows.Forms.ListViewItem([string]$record.Status)
            [void]$item.SubItems.Add([string]$record.Dashboard)
            [void]$item.SubItems.Add([string]$record.Profile)
            [void]$item.SubItems.Add([string]$record.LastCheck)
            [void]$item.SubItems.Add((Convert-HealthCountText -Value $record.NoDataCount))
            [void]$item.SubItems.Add((Convert-HealthCountText -Value $record.Errors))
            [void]$item.SubItems.Add([string]$record.FieldSummary)
            [void]$item.SubItems.Add([string]$record.Confidence)
            $item.Tag = $record
            [void]$lvHealth.Items.Add($item)
        }
    }
    finally {
        $lvHealth.EndUpdate()
    }

    $lblHealthLastUpdated.Text = "Updated: " + (Get-Date -Format "HH:mm:ss")

    if ($null -ne $lblHealthShowing) {
        $lblHealthShowing.Text = "Showing " + $items.Count + " of " + $allItems.Count
    }

    try { Update-HeaderStatus } catch {}

    Show-SelectedHealthDetail
    $lvHealth.Invalidate()
}

function Get-AutomaticCaptureSettings {
    $defaults = [PSCustomObject]@{
        Enabled = $false
        ProfileName = ""
        IntervalMinutes = 30
        RunAi = $true
        LastRun = ""
        LastSuccess = 0
        LastPartial = 0
        LastFailed = 0
    }

    if (-not (Test-Path -LiteralPath $script:SchedulerSettingsPath -PathType Leaf)) {
        return $defaults
    }

    try {
        $obj = Get-Content -LiteralPath $script:SchedulerSettingsPath -Raw -Encoding UTF8 | ConvertFrom-Json

        if ($null -eq $obj.Enabled) { $obj | Add-Member Enabled $false -Force }
        if ($null -eq $obj.ProfileName) { $obj | Add-Member ProfileName "" -Force }
        if ($null -eq $obj.IntervalMinutes) { $obj | Add-Member IntervalMinutes 30 -Force }
        if ($null -eq $obj.RunAi) { $obj | Add-Member RunAi $true -Force }
        if ($null -eq $obj.LastRun) { $obj | Add-Member LastRun "" -Force }
        if ($null -eq $obj.LastSuccess) { $obj | Add-Member LastSuccess 0 -Force }
        if ($null -eq $obj.LastPartial) { $obj | Add-Member LastPartial 0 -Force }
        if ($null -eq $obj.LastFailed) { $obj | Add-Member LastFailed 0 -Force }

        return $obj
    }
    catch {
        return $defaults
    }
}

function Save-AutomaticCaptureSettings {
    param(
        [bool]$Enabled,
        [string]$ProfileName,
        [int]$IntervalMinutes,
        [bool]$RunAi,
        [string]$LastRun = "",
        [int]$LastSuccess = 0,
        [int]$LastPartial = 0,
        [int]$LastFailed = 0
    )

    if ($IntervalMinutes -lt 1) { $IntervalMinutes = 1 }

    $obj = [PSCustomObject]@{
        Enabled = $Enabled
        ProfileName = $ProfileName
        IntervalMinutes = $IntervalMinutes
        RunAi = $RunAi
        LastRun = $LastRun
        LastSuccess = $LastSuccess
        LastPartial = $LastPartial
        LastFailed = $LastFailed
    }

    $obj | ConvertTo-Json -Depth 5 |
        Set-Content -LiteralPath $script:SchedulerSettingsPath -Encoding UTF8 -Force
}

function Refresh-SchedulerProfiles {
    if ($null -eq $cmbSchedulerProfile) { return }

    $current = [string]$cmbSchedulerProfile.SelectedItem
    $cmbSchedulerProfile.Items.Clear()

    foreach ($profile in @($script:ElkProfiles | Sort-Object Name)) {
        [void]$cmbSchedulerProfile.Items.Add([string]$profile.Name)
    }

    if (-not [string]::IsNullOrWhiteSpace($current) -and $cmbSchedulerProfile.Items.Contains($current)) {
        $cmbSchedulerProfile.SelectedItem = $current
    }
    elseif ($cmbSchedulerProfile.Items.Count -gt 0) {
        $cmbSchedulerProfile.SelectedIndex = 0
    }
}


function Get-SchedulerCredentialState {
    param([string]$ProfileName)

    $profile = Get-ElkProfileByName -Name $ProfileName
    if ($null -eq $profile) {
        return [PSCustomObject]@{
            Ready=$false
            AutoLoginState="PROFILE NOT FOUND"
            CredentialState="UNKNOWN"
            State="PROFILE NOT FOUND"
            Detail="Selected ELK profile was not found."
        }
    }

    $autoLoginEnabled = [bool]$profile.AutoLoginEnabled

    $plain = ""
    try {
        $plain = Get-ElkProfileCredential `
            -Profile $profile `
            -AllowEditorFallback
    }
    catch {
        $plain = ""
    }

    $credentialState = "SAVED"
    if ([string]::IsNullOrWhiteSpace([string]$profile.Username)) {
        $credentialState = "USERNAME MISSING"
    }
    elseif ([string]::IsNullOrWhiteSpace($plain)) {
        $credentialState = "PASSWORD NOT SAVED"
    }

    $ready = (
        $autoLoginEnabled -and
        $credentialState -eq "SAVED"
    )

    $detail = ""
    if (-not $autoLoginEnabled) {
        $detail = "Auto Login is disabled for profile '" + [string]$profile.Name + "'. Enable it in ELK Profiles and save the profile."
    }
    elseif ($credentialState -eq "USERNAME MISSING") {
        $detail = "Username is not saved in the selected ELK profile."
    }
    elseif ($credentialState -eq "PASSWORD NOT SAVED") {
        $detail = "No usable Auto Login password was found. Enter it in ELK Profiles, Save Profile, then Test Auto Login."
    }
    else {
        $detail = "Auto Login is enabled and credentials are securely stored for the current Windows user."
    }

    return [PSCustomObject]@{
        Ready=$ready
        AutoLoginState=$(if ($autoLoginEnabled) { "ENABLED" } else { "DISABLED" })
        CredentialState=$credentialState
        State=$(if ($ready) { "READY" } elseif (-not $autoLoginEnabled) { "AUTO LOGIN OFF" } else { $credentialState })
        Detail=$detail
    }
}

function Update-SchedulerStateUi {
    if ($null -eq $lblSchedulerLastValue) { return }

    $palette = Get-AghrabPalette -Theme $script:CurrentTheme
    $enabled = [bool]$chkSchedulerEnabled.Checked

    $lblSchedulerLastValue.Text = $(if ($null -eq $script:SchedulerLastRun) { "-" } else { $script:SchedulerLastRun.ToString("MM-dd HH:mm:ss") })

    if (Test-ElkSchedulerCaptchaPending) {
        $lblSchedulerNextValue.Text = "PAUSED"
        $lblSchedulerNextValue.ForeColor = $palette.Warning
    }
    else {
        $lblSchedulerNextValue.Text = $(if ($null -eq $script:SchedulerNextRun -or -not $enabled) { "-" } else { $script:SchedulerNextRun.ToString("MM-dd HH:mm:ss") })
        $lblSchedulerNextValue.ForeColor = $palette.Text
    }

    $lblSchedulerSuccessValue.Text = [string]$script:SchedulerLastSuccess
    $lblSchedulerPartialValue.Text = [string]$script:SchedulerLastPartial
    $lblSchedulerFailedValue.Text = [string]$script:SchedulerLastFailed

    $lblSchedulerSuccessValue.ForeColor = $palette.Success
    $lblSchedulerPartialValue.ForeColor = $palette.Warning
    $lblSchedulerFailedValue.ForeColor = $palette.Danger

    $aiState = "OFF"
    if ($chkSchedulerAi.Checked) {
        if (Test-AiServerReady) {
            $aiState = "READY"
            $lblSchedulerAiValue.ForeColor = $palette.Success
        }
        elseif (Test-AiPackInstalled) {
            $aiState = "STOPPED"
            $lblSchedulerAiValue.ForeColor = $palette.Warning
        }
        else {
            $aiState = "NOT INSTALLED"
            $lblSchedulerAiValue.ForeColor = $palette.Danger
        }
    }
    else {
        $lblSchedulerAiValue.ForeColor = $palette.Muted
    }
    $lblSchedulerAiValue.Text = $aiState

    if ($null -ne $txtSchedulerOutput) {
        try { $txtSchedulerOutput.Text = Get-OutputRoot } catch {}
    }

    if (Test-ElkSchedulerCaptchaPending) {
        $lblSchedulerOnOff.Text = "Automatic Capture PAUSED - CAPTCHA"
        $lblSchedulerOnOff.ForeColor = $palette.Warning
    }
    elseif ($script:SchedulerBusy) {
        $lblSchedulerOnOff.Text = "Automatic Capture is RUNNING"
        $lblSchedulerOnOff.ForeColor = $palette.Accent
    }
    elseif ($enabled) {
        $lblSchedulerOnOff.Text = "Automatic Capture is ON"
        $lblSchedulerOnOff.ForeColor = $palette.Success
    }
    else {
        $lblSchedulerOnOff.Text = "Automatic Capture is OFF"
        $lblSchedulerOnOff.ForeColor = $palette.Muted
    }

    if ($null -ne $lblSchedulerCredentialValue) {
        try {
            $selectedProfileName = [string]$cmbSchedulerProfile.SelectedItem
            $cred = Get-SchedulerCredentialState -ProfileName $selectedProfileName

            $lblSchedulerCredential.Text = "Auto Login / Credentials:"
            $lblSchedulerCredentialValue.Text = (
                [string]$cred.AutoLoginState +
                "  |  " +
                [string]$cred.CredentialState
            )

            $lblSchedulerCredentialValue.ForeColor = $(if ($cred.Ready) { $palette.Success } else { $palette.Warning })
            $lblSchedulerCredentialHint.Text = "Profile: " + $selectedProfileName + " | " + [string]$cred.Detail
        }
        catch {
            $lblSchedulerCredentialValue.Text = "CHECK ERROR"
            $lblSchedulerCredentialValue.ForeColor = $palette.Warning
            $lblSchedulerCredentialHint.Text = "Could not read Auto Login state."
        }
    }

    try { Update-HeaderStatus } catch {}
}

function Save-SchedulerFromUi {
    if ($null -eq $chkSchedulerEnabled) { return }

    if (
        $chkSchedulerEnabled.Checked -and
        -not (Test-AghrabCommercialFeatureAccess -Feature "AutomaticCapture")
    ) {
        $script:LoadingSchedulerUi = $true
        try { $chkSchedulerEnabled.Checked = $false } finally { $script:LoadingSchedulerUi = $false }
        Show-AghrabLicenseRestriction -FeatureName "Automatic Capture"
    }

    $profileName = [string]$cmbSchedulerProfile.SelectedItem
    $interval = [int]$numSchedulerInterval.Value
    $runAi = [bool]$chkSchedulerAi.Checked
    $last = $(if ($null -eq $script:SchedulerLastRun) { "" } else { $script:SchedulerLastRun.ToString("o") })

    Save-AutomaticCaptureSettings `
        -Enabled ([bool]$chkSchedulerEnabled.Checked) `
        -ProfileName $profileName `
        -IntervalMinutes $interval `
        -RunAi $runAi `
        -LastRun $last `
        -LastSuccess ([int]$script:SchedulerLastSuccess) `
        -LastPartial ([int]$script:SchedulerLastPartial) `
        -LastFailed ([int]$script:SchedulerLastFailed)

    if ($chkSchedulerEnabled.Checked) {
        $script:SchedulerNextRun = (Get-Date).AddMinutes($interval)
    }
    else {
        $script:SchedulerNextRun = $null
    }

    Write-SchedulerLog ("Schedule saved. Enabled=" + [bool]$chkSchedulerEnabled.Checked + "; Profile=" + $profileName + "; Interval=" + $interval + "m; AI=" + $runAi)
    Update-SchedulerStateUi
}

function Load-SchedulerUi {
    if ($null -eq $chkSchedulerEnabled) { return }

    Refresh-SchedulerProfiles
    $settings = Get-AutomaticCaptureSettings

    $script:LoadingSchedulerUi = $true
    try {
        $chkSchedulerEnabled.Checked = [bool]$settings.Enabled

        if (-not [string]::IsNullOrWhiteSpace([string]$settings.ProfileName) -and $cmbSchedulerProfile.Items.Contains([string]$settings.ProfileName)) {
            $cmbSchedulerProfile.SelectedItem = [string]$settings.ProfileName
        }

        $interval = 30
        try { $interval = [int]$settings.IntervalMinutes } catch {}
        $interval = [Math]::Min(1440,[Math]::Max(1,$interval))
        $numSchedulerInterval.Value = $interval
        $chkSchedulerAi.Checked = [bool]$settings.RunAi

        try { $script:SchedulerLastSuccess = [int]$settings.LastSuccess } catch { $script:SchedulerLastSuccess = 0 }
        try { $script:SchedulerLastPartial = [int]$settings.LastPartial } catch { $script:SchedulerLastPartial = 0 }
        try { $script:SchedulerLastFailed = [int]$settings.LastFailed } catch { $script:SchedulerLastFailed = 0 }

        $script:SchedulerLastRun = $null
        if (-not [string]::IsNullOrWhiteSpace([string]$settings.LastRun)) {
            try { $script:SchedulerLastRun = [DateTime]::Parse([string]$settings.LastRun) } catch {}
        }

        if ($chkSchedulerEnabled.Checked) {
            $script:SchedulerNextRun = (Get-Date).AddMinutes($interval)
        }
        else {
            $script:SchedulerNextRun = $null
        }
    }
    finally {
        $script:LoadingSchedulerUi = $false
    }

    Update-SchedulerStateUi
}


function Split-ExpectedFields {
    param([string]$Text)

    if ([string]::IsNullOrWhiteSpace($Text)) {
        return @()
    }

    $items = @(
        ($Text -split "[,;`r`n]+") |
        ForEach-Object { ([string]$_).Trim() } |
        Where-Object { -not [string]::IsNullOrWhiteSpace($_) } |
        Select-Object -Unique
    )

    # Guardrail: verification is intentionally lightweight.
    if ($items.Count -gt 20) {
        $items = @($items | Select-Object -First 20)
    }

    return @($items)
}

function Convert-FieldResultsToSummary {
    param($Verification)

    if ($null -eq $Verification) { return "Not checked" }

    if ([string]$Verification.State -ne "Verified") {
        return [string]$Verification.State
    }

    $results = @($Verification.Results)
    $active = @($results | Where-Object { $_.State -eq "Active" }).Count
    $missing = @($results | Where-Object { $_.State -eq "No recent data" }).Count

    if ($results.Count -eq 0) { return "No expected fields" }
    if ($missing -gt 0) { return "$missing missing / $($results.Count)" }

    return "$active/$($results.Count) active"
}

function Invoke-WithOptionalTlsBypass {
    param(
        [scriptblock]$Action,
        [bool]$IgnoreTls
    )

    $oldCallback = [System.Net.ServicePointManager]::ServerCertificateValidationCallback

    try {
        if ($IgnoreTls) {
            [System.Net.ServicePointManager]::ServerCertificateValidationCallback = {
                param($sender,$certificate,$chain,$sslPolicyErrors)
                return $true
            }
        }

        return & $Action
    }
    finally {
        [System.Net.ServicePointManager]::ServerCertificateValidationCallback = $oldCallback
    }
}

function Invoke-ElasticsearchFieldVerification {
    param(
        $Profile,
        $Dashboard
    )

    $expected = @(Split-ExpectedFields -Text ([string]$Dashboard.ExpectedFields))
    $indexPattern = ([string]$Dashboard.IndexPattern).Trim()

    if (-not [bool]$Profile.FieldVerifyEnabled) {
        return [PSCustomObject]@{
            State = "Disabled"
            Results = @()
            ExpectedFields = @($expected)
            IndexPattern = $indexPattern
            WindowMinutes = 0
            Message = "Field Verification is disabled for this profile."
        }
    }

    if ($expected.Count -eq 0) {
        return [PSCustomObject]@{
            State = "No expected fields"
            Results = @()
            ExpectedFields = @()
            IndexPattern = $indexPattern
            WindowMinutes = [int]$Profile.FieldVerifyWindowMinutes
            Message = "No Expected Fields are configured for this dashboard."
        }
    }

    if ([string]::IsNullOrWhiteSpace($indexPattern)) {
        return [PSCustomObject]@{
            State = "Index missing"
            Results = @()
            ExpectedFields = @($expected)
            IndexPattern = ""
            WindowMinutes = [int]$Profile.FieldVerifyWindowMinutes
            Message = "Expected Fields are configured, but Index Pattern is empty."
        }
    }

    $esUrl = ([string]$Profile.ElasticsearchUrl).Trim().TrimEnd('/')
    if ([string]::IsNullOrWhiteSpace($esUrl)) {
        return [PSCustomObject]@{
            State = "ES not configured"
            Results = @()
            ExpectedFields = @($expected)
            IndexPattern = $indexPattern
            WindowMinutes = [int]$Profile.FieldVerifyWindowMinutes
            Message = "Elasticsearch URL is not configured."
        }
    }

    $apiKey = Unprotect-SecretForCurrentUser -ProtectedBase64 ([string]$Profile.FieldVerifyApiKeyProtected)
    if ([string]::IsNullOrWhiteSpace($apiKey)) {
        return [PSCustomObject]@{
            State = "API key unavailable"
            Results = @()
            ExpectedFields = @($expected)
            IndexPattern = $indexPattern
            WindowMinutes = [int]$Profile.FieldVerifyWindowMinutes
            Message = "Field Verification API key is missing or unavailable."
        }
    }

    if ($apiKey.StartsWith("ApiKey ", [System.StringComparison]::OrdinalIgnoreCase)) {
        $apiKey = $apiKey.Substring(7).Trim()
    }

    $timeField = ([string]$Profile.FieldVerifyTimeField).Trim()
    if ([string]::IsNullOrWhiteSpace($timeField)) {
        $timeField = "@timestamp"
    }

    $window = 15
    try { $window = [Math]::Min(1440,[Math]::Max(1,[int]$Profile.FieldVerifyWindowMinutes)) } catch {}

    $aggs = @{}
    $map = @{}

    for ($i = 0; $i -lt $expected.Count; $i++) {
        $aggName = "f" + $i
        $fieldName = [string]$expected[$i]
        $map[$aggName] = $fieldName
        $aggs[$aggName] = @{
            filter = @{
                exists = @{
                    field = $fieldName
                }
            }
        }
    }

    # Performance design:
    # - size=0: no documents are returned
    # - track_total_hits=false: no expensive exact total count
    # - one request checks all expected fields
    # - request runs only AFTER the dashboard screenshot is captured
    $rangeSpec = @{}
    $rangeSpec[$timeField] = @{
        gte = ("now-" + $window + "m")
        lte = "now"
    }

    $body = @{
        size = 0
        track_total_hits = $false
        query = @{
            range = $rangeSpec
        }
        aggs = $aggs
    } | ConvertTo-Json -Depth 20 -Compress

    $headers = @{
        Authorization = "ApiKey " + $apiKey
    }

    $endpoint = $esUrl + "/" + $indexPattern + "/_search"

    try {
        $response = Invoke-WithOptionalTlsBypass -IgnoreTls ([bool]$Profile.FieldVerifyIgnoreTls) -Action {
            Invoke-RestMethod `
                -Uri $endpoint `
                -Method Post `
                -Headers $headers `
                -ContentType "application/json" `
                -Body $body `
                -TimeoutSec 3
        }

        $results = @()
        foreach ($aggName in @($map.Keys | Sort-Object)) {
            $fieldName = [string]$map[$aggName]
            $count = 0
            try { $count = [long]$response.aggregations.$aggName.doc_count } catch {}

            $results += [PSCustomObject]@{
                Field = $fieldName
                Count = $count
                State = $(if ($count -gt 0) { "Active" } else { "No recent data" })
            }
        }

        return [PSCustomObject]@{
            State = "Verified"
            Results = @($results)
            ExpectedFields = @($expected)
            IndexPattern = $indexPattern
            WindowMinutes = $window
            Message = "Fast verification completed with one size=0 Elasticsearch request."
        }
    }
    catch {
        return [PSCustomObject]@{
            State = "Error"
            Results = @()
            ExpectedFields = @($expected)
            IndexPattern = $indexPattern
            WindowMinutes = $window
            Message = ("Elasticsearch verification failed: " + $_.Exception.Message)
        }
    }
}

function Merge-VisualAndFieldHealth {
    param(
        $VisualHealth,
        $Verification
    )

    $status = $(if ($null -ne $VisualHealth) { [string]$VisualHealth.Status } else { "Unknown" })
    $noDataCount = $(if ($null -ne $VisualHealth) { [int]$VisualHealth.NoDataCount } else { -1 })
    $noDataPanels = $(if ($null -ne $VisualHealth) { @($VisualHealth.NoDataPanels) } else { @() })
    $errors = $(if ($null -ne $VisualHealth) { [int]$VisualHealth.Errors } else { 0 })
    $confidence = $(if ($null -ne $VisualHealth) { [string]$VisualHealth.Confidence } else { "" })
    $visualMessage = $(if ($null -ne $VisualHealth) { [string]$VisualHealth.Message } else { "Visual AI was not run." })

    $fieldState = $(if ($null -eq $Verification) { "Not checked" } else { [string]$Verification.State })
    $fieldResults = $(if ($null -eq $Verification) { @() } else { @($Verification.Results) })
    $missing = @($fieldResults | Where-Object { $_.State -eq "No recent data" })
    $active = @($fieldResults | Where-Object { $_.State -eq "Active" })

    $correlation = "Visual-only"
    $fieldMessage = $(if ($null -eq $Verification) { "Field Verification was not run." } else { [string]$Verification.Message })

    if ($fieldState -eq "Verified") {
        if ($missing.Count -gt 0 -and $noDataCount -gt 0) {
            $correlation = "DATA-SIDE SIGNAL"
            if ($status -eq "Healthy" -or $status -eq "Unknown") { $status = "Warning" }
            $fieldMessage = (
                "AI detected " + $noDataCount + " empty panel(s), and " +
                $missing.Count + " expected field(s) have zero recent documents. " +
                "Check ingestion, parsing, mapping and source logs."
            )
        }
        elseif ($missing.Count -eq 0 -and $noDataCount -gt 0) {
            $correlation = "DASHBOARD-SIDE SIGNAL"
            if ($status -eq "Healthy") { $status = "Warning" }
            $fieldMessage = (
                "Expected fields have recent data, but the screenshot still contains empty panel(s). " +
                "Check visualization filters, data view, KQL and dashboard time range."
            )
        }
        elseif ($missing.Count -gt 0) {
            $correlation = "FIELD GAP"
            if ($status -eq "Healthy" -or $status -eq "Unknown") { $status = "Warning" }
            $fieldMessage = (
                $missing.Count + " expected field(s) have zero documents in the verification window."
            )
        }
        else {
            $correlation = "FIELDS ACTIVE"
            $fieldMessage = "All configured expected fields have recent documents."
        }
    }
    elseif ($fieldState -eq "Error") {
        $correlation = "VERIFY ERROR"
    }
    elseif ($fieldState -eq "Disabled") {
        $correlation = "VERIFY OFF"
    }
    elseif ($fieldState -eq "No expected fields") {
        $correlation = "FIELDS NOT SET"
    }
    elseif ($fieldState -eq "Index missing") {
        $correlation = "INDEX NOT SET"
    }
    elseif ($fieldState -eq "ES not configured" -or $fieldState -eq "API key unavailable") {
        $correlation = "VERIFY NOT READY"
    }

    return [PSCustomObject]@{
        Status = $status
        NoDataCount = $noDataCount
        NoDataPanels = @($noDataPanels)
        Errors = $errors
        Confidence = $confidence
        Message = $visualMessage
        FieldState = $fieldState
        FieldResults = @($fieldResults)
        FieldSummary = Convert-FieldResultsToSummary -Verification $Verification
        Correlation = $correlation
        CorrelationMessage = $fieldMessage
        VerificationIndex = $(if ($null -eq $Verification) { "" } else { [string]$Verification.IndexPattern })
        VerificationWindow = $(if ($null -eq $Verification) { 0 } else { [int]$Verification.WindowMinutes })
    }
}

function Test-ElasticsearchFieldVerificationConnection {
    param(
        [string]$ElasticsearchUrl,
        [string]$ApiKey,
        [bool]$IgnoreTls
    )

    $url = $ElasticsearchUrl.Trim().TrimEnd('/')
    $key = $ApiKey.Trim()

    if ($key.StartsWith("ApiKey ", [System.StringComparison]::OrdinalIgnoreCase)) {
        $key = $key.Substring(7).Trim()
    }

    if ([string]::IsNullOrWhiteSpace($url)) {
        throw "Elasticsearch URL is required."
    }
    if ([string]::IsNullOrWhiteSpace($key)) {
        throw "API Key is required."
    }

    $headers = @{ Authorization = "ApiKey " + $key }

    return Invoke-WithOptionalTlsBypass -IgnoreTls $IgnoreTls -Action {
        Invoke-RestMethod `
            -Uri ($url + "/_security/_authenticate") `
            -Method Get `
            -Headers $headers `
            -TimeoutSec 3
    }
}

function Show-ElasticsearchApiKeyHelp {
    $help = New-Object System.Windows.Forms.Form
    $help.Text = "RAQEB - API Key Help"
    $help.StartPosition = "CenterParent"
    $help.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
    $help.MaximizeBox = $false
    $help.MinimizeBox = $false
    $help.ControlBox = $true
    $help.ShowIcon = $false
    $help.ClientSize = New-Object System.Drawing.Size(740,620)
    $help.Font = New-Object System.Drawing.Font("Segoe UI",9)

    $p = Get-AghrabPalette -Theme $script:CurrentTheme
    $help.BackColor = $p.Background
    $help.ForeColor = $p.Text

    $title = New-Object System.Windows.Forms.Label
    $title.Text = "راهنمای ساخت API Key برای RAQEB"
    $title.Font = New-Object System.Drawing.Font("Segoe UI Semibold",15,[System.Drawing.FontStyle]::Bold)
    $title.Location = New-Object System.Drawing.Point(22,18)
    $title.Size = New-Object System.Drawing.Size(690,32)
    $title.RightToLeft = [System.Windows.Forms.RightToLeft]::Yes
    $title.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
    $help.Controls.Add($title)

    $intro = New-Object System.Windows.Forms.Label
    $intro.Text = "این API Key فقط برای خواندن اطلاعات Elasticsearch و بررسی Expected Fields استفاده می‌شود. برای ساخت آن از Kibana Dev Tools استفاده کن."
    $intro.Location = New-Object System.Drawing.Point(24,54)
    $intro.Size = New-Object System.Drawing.Size(688,42)
    $intro.RightToLeft = [System.Windows.Forms.RightToLeft]::Yes
    $intro.TextAlign = [System.Drawing.ContentAlignment]::TopRight
    $intro.ForeColor = $p.Muted
    $help.Controls.Add($intro)

    $steps = New-Object System.Windows.Forms.Label
    $steps.Text = (
        "1) وارد Kibana شو و مسیر Dev Tools → Console را باز کن.`r`n" +
        "2) دستور زیر را اجرا کن. اگر Index/Data Streamهای تو نام دیگری دارند، مقدار names را مطابق محیط خودت تغییر بده.`r`n" +
        "3) در خروجی، مقدار encoded را کپی کن.`r`n" +
        "4) همان مقدار encoded را داخل فیلد API Key در RAQEB Paste کن."
    )
    $steps.Location = New-Object System.Drawing.Point(24,104)
    $steps.Size = New-Object System.Drawing.Size(688,92)
    $steps.RightToLeft = [System.Windows.Forms.RightToLeft]::Yes
    $steps.TextAlign = [System.Drawing.ContentAlignment]::TopRight
    $help.Controls.Add($steps)

    $lblCommand = New-Object System.Windows.Forms.Label
    $lblCommand.Text = "دستور ساخت API Key در Kibana Dev Tools"
    $lblCommand.Font = New-Object System.Drawing.Font("Segoe UI Semibold",10,[System.Drawing.FontStyle]::Bold)
    $lblCommand.Location = New-Object System.Drawing.Point(24,202)
    $lblCommand.Size = New-Object System.Drawing.Size(688,24)
    $lblCommand.RightToLeft = [System.Windows.Forms.RightToLeft]::Yes
    $lblCommand.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
    $help.Controls.Add($lblCommand)

    $apiCommand = @'
POST /_security/api_key
{
  "name": "aghrab-field-verification",
  "role_descriptors": {
    "aghrab_field_verify": {
      "cluster": [],
      "indices": [
        {
          "names": [
            "logs-*",
            "filebeat-*",
            "winlogbeat-*"
          ],
          "privileges": [
            "read",
            "view_index_metadata"
          ]
        }
      ]
    }
  }
}
'@

    $txtCommand = New-Object System.Windows.Forms.TextBox
    $txtCommand.Multiline = $true
    $txtCommand.ReadOnly = $true
    $txtCommand.ScrollBars = [System.Windows.Forms.ScrollBars]::Vertical
    $txtCommand.WordWrap = $false
    $txtCommand.Font = New-Object System.Drawing.Font("Consolas",9)
    $txtCommand.Location = New-Object System.Drawing.Point(24,230)
    $txtCommand.Size = New-Object System.Drawing.Size(688,235)
    $txtCommand.BackColor = $p.Input
    $txtCommand.ForeColor = $p.Text
    $txtCommand.Text = $apiCommand
    $help.Controls.Add($txtCommand)

    $btnCopyCommand = New-Object System.Windows.Forms.Button
    $btnCopyCommand.Text = "Copy Command"
    $btnCopyCommand.Location = New-Object System.Drawing.Point(24,474)
    $btnCopyCommand.Size = New-Object System.Drawing.Size(125,34)
    Style-PrimaryButton $btnCopyCommand
    $help.Controls.Add($btnCopyCommand)

    $lblNamesHint = New-Object System.Windows.Forms.Label
    $lblNamesHint.Text = "نکته: names باید Index/Data Streamهایی را پوشش دهد که Dashboardهای تو از آن‌ها استفاده می‌کنند. برای استفاده دائمی، دسترسی را روی الگوهای لازم محدود نگه دار."
    $lblNamesHint.Location = New-Object System.Drawing.Point(165,474)
    $lblNamesHint.Size = New-Object System.Drawing.Size(547,46)
    $lblNamesHint.RightToLeft = [System.Windows.Forms.RightToLeft]::Yes
    $lblNamesHint.TextAlign = [System.Drawing.ContentAlignment]::TopRight
    $lblNamesHint.ForeColor = $p.Muted
    $help.Controls.Add($lblNamesHint)

    $lblOutput = New-Object System.Windows.Forms.Label
    $lblOutput.Text = "بعد از اجرا، خروجی شبیه این است:"
    $lblOutput.Font = New-Object System.Drawing.Font("Segoe UI Semibold",9.5)
    $lblOutput.Location = New-Object System.Drawing.Point(24,530)
    $lblOutput.Size = New-Object System.Drawing.Size(688,22)
    $lblOutput.RightToLeft = [System.Windows.Forms.RightToLeft]::Yes
    $lblOutput.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
    $help.Controls.Add($lblOutput)

    $outputHint = New-Object System.Windows.Forms.Label
    $outputHint.Text = 'فقط مقدار "encoded" را کپی کن؛ id یا api_key را به‌تنهایی داخل راقب نگذار.'
    $outputHint.Location = New-Object System.Drawing.Point(24,555)
    $outputHint.Size = New-Object System.Drawing.Size(688,24)
    $outputHint.RightToLeft = [System.Windows.Forms.RightToLeft]::Yes
    $outputHint.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
    $outputHint.ForeColor = $p.Warning
    $help.Controls.Add($outputHint)

    $sample = New-Object System.Windows.Forms.TextBox
    $sample.ReadOnly = $true
    $sample.Location = New-Object System.Drawing.Point(24,584)
    $sample.Size = New-Object System.Drawing.Size(688,27)
    $sample.Font = New-Object System.Drawing.Font("Consolas",8.5)
    $sample.BackColor = $p.Input
    $sample.ForeColor = $p.Text
    $sample.Text = '"encoded": "YWJjMTIzOnh4eHh4eHh4eA=="'
    $help.Controls.Add($sample)

    $btnCopyCommand.Add_Click({
        try {
            [System.Windows.Forms.Clipboard]::SetText($apiCommand)
        }
        catch {}
    })

    # No extra Close button on purpose. The standard X in the title bar is the
    # intended close action, as requested.
    [void]$help.ShowDialog($dialog)
}


function Show-DashboardFieldHelp {
    $help = New-Object System.Windows.Forms.Form
    $help.Text = "RAQEB - Dashboard Field Help"
    $help.StartPosition = "CenterParent"
    $help.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
    $help.MaximizeBox = $false
    $help.MinimizeBox = $false
    $help.ControlBox = $true
    $help.ShowIcon = $false
    $help.ClientSize = New-Object System.Drawing.Size(760,650)
    $help.Font = New-Object System.Drawing.Font("Segoe UI",9)

    $p = Get-AghrabPalette -Theme $script:CurrentTheme
    $help.BackColor = $p.Background
    $help.ForeColor = $p.Text

    $title = New-Object System.Windows.Forms.Label
    $title.Text = "اگر اولین بار است، فقط این 4 مرحله را انجام بده"
    $title.Font = New-Object System.Drawing.Font("Segoe UI Semibold",15,[System.Drawing.FontStyle]::Bold)
    $title.Location = New-Object System.Drawing.Point(22,16)
    $title.Size = New-Object System.Drawing.Size(714,34)
    $title.RightToLeft = [System.Windows.Forms.RightToLeft]::Yes
    $title.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
    $help.Controls.Add($title)

    $intro = New-Object System.Windows.Forms.Label
    $intro.Text = "هدف ساده است: به راقب بگو این Dashboard داده‌اش را از کدام Index می‌گیرد و کدام چند فیلد برایش مهم هستند. همین."
    $intro.Location = New-Object System.Drawing.Point(24,55)
    $intro.Size = New-Object System.Drawing.Size(710,42)
    $intro.RightToLeft = [System.Windows.Forms.RightToLeft]::Yes
    $intro.TextAlign = [System.Drawing.ContentAlignment]::TopRight
    $intro.ForeColor = $p.Muted
    $help.Controls.Add($intro)

    # Step 1
    $s1 = New-Object System.Windows.Forms.Label
    $s1.Text = "مرحله 1 — اتصال Elasticsearch را یک‌بار تنظیم کن"
    $s1.Font = New-Object System.Drawing.Font("Segoe UI Semibold",10,[System.Drawing.FontStyle]::Bold)
    $s1.Location = New-Object System.Drawing.Point(24,104)
    $s1.Size = New-Object System.Drawing.Size(710,24)
    $s1.RightToLeft = [System.Windows.Forms.RightToLeft]::Yes
    $s1.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
    $help.Controls.Add($s1)

    $s1Text = New-Object System.Windows.Forms.Label
    $s1Text.Text = "در ELK Profiles روی Field Verification بزن و Elasticsearch URL + API Key را تنظیم کن. این کار برای هر Profile فقط یک‌بار انجام می‌شود."
    $s1Text.Location = New-Object System.Drawing.Point(24,132)
    $s1Text.Size = New-Object System.Drawing.Size(710,38)
    $s1Text.RightToLeft = [System.Windows.Forms.RightToLeft]::Yes
    $s1Text.TextAlign = [System.Drawing.ContentAlignment]::TopRight
    $help.Controls.Add($s1Text)

    # Step 2
    $s2 = New-Object System.Windows.Forms.Label
    $s2.Text = "مرحله 2 — ES Index را پیدا کن"
    $s2.Font = New-Object System.Drawing.Font("Segoe UI Semibold",10,[System.Drawing.FontStyle]::Bold)
    $s2.Location = New-Object System.Drawing.Point(24,176)
    $s2.Size = New-Object System.Drawing.Size(710,24)
    $s2.RightToLeft = [System.Windows.Forms.RightToLeft]::Yes
    $s2.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
    $help.Controls.Add($s2)

    $s2Text = New-Object System.Windows.Forms.Label
    $s2Text.Text = "اگر اسم Index/Data Stream را نمی‌دانی: در Kibana برو به Dev Tools → Console و یکی از دستورهای زیر را اجرا کن. اسم مربوط به لاگ Dashboard را پیدا کن."
    $s2Text.Location = New-Object System.Drawing.Point(24,204)
    $s2Text.Size = New-Object System.Drawing.Size(710,42)
    $s2Text.RightToLeft = [System.Windows.Forms.RightToLeft]::Yes
    $s2Text.TextAlign = [System.Drawing.ContentAlignment]::TopRight
    $help.Controls.Add($s2Text)

    $findCommands = @'
GET _data_stream

GET _cat/indices?h=index&s=index
'@

    $txtFind = New-Object System.Windows.Forms.TextBox
    $txtFind.Multiline = $true
    $txtFind.ReadOnly = $true
    $txtFind.WordWrap = $false
    $txtFind.Font = New-Object System.Drawing.Font("Consolas",9)
    $txtFind.Location = New-Object System.Drawing.Point(24,250)
    $txtFind.Size = New-Object System.Drawing.Size(560,62)
    $txtFind.BackColor = $p.Input
    $txtFind.ForeColor = $p.Text
    $txtFind.Text = $findCommands
    $help.Controls.Add($txtFind)

    $btnCopyFind = New-Object System.Windows.Forms.Button
    $btnCopyFind.Text = "Copy Commands"
    $btnCopyFind.Location = New-Object System.Drawing.Point(594,264)
    $btnCopyFind.Size = New-Object System.Drawing.Size(140,34)
    Style-PrimaryButton $btnCopyFind
    $help.Controls.Add($btnCopyFind)
    $btnCopyFind.Add_Click({
        try { [System.Windows.Forms.Clipboard]::SetText($findCommands) } catch {}
    })

    $s2Example = New-Object System.Windows.Forms.Label
    $s2Example.Text = "مثال: اگر لاگ Suricata است و نام‌ها شبیه logs-suricata-default هستند، می‌توانی ES Index را logs-suricata-* بگذاری. URL داشبورد Kibana را اینجا نگذار."
    $s2Example.Location = New-Object System.Drawing.Point(24,318)
    $s2Example.Size = New-Object System.Drawing.Size(710,42)
    $s2Example.RightToLeft = [System.Windows.Forms.RightToLeft]::Yes
    $s2Example.TextAlign = [System.Drawing.ContentAlignment]::TopRight
    $s2Example.ForeColor = $p.Warning
    $help.Controls.Add($s2Example)

    # Step 3
    $s3 = New-Object System.Windows.Forms.Label
    $s3.Text = "مرحله 3 — Expected Fields را انتخاب کن"
    $s3.Font = New-Object System.Drawing.Font("Segoe UI Semibold",10,[System.Drawing.FontStyle]::Bold)
    $s3.Location = New-Object System.Drawing.Point(24,366)
    $s3.Size = New-Object System.Drawing.Size(710,24)
    $s3.RightToLeft = [System.Windows.Forms.RightToLeft]::Yes
    $s3.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
    $help.Controls.Add($s3)

    $s3Text = New-Object System.Windows.Forms.Label
    $s3Text.Text = "در Kibana → Discover یک لاگ واقعی از همان منبع باز کن. 3 تا 8 فیلد مهمی که Dashboard با آن‌ها کار می‌کند انتخاب کن و با کاما بنویس. لازم نیست همه فیلدها را وارد کنی."
    $s3Text.Location = New-Object System.Drawing.Point(24,394)
    $s3Text.Size = New-Object System.Drawing.Size(710,44)
    $s3Text.RightToLeft = [System.Windows.Forms.RightToLeft]::Yes
    $s3Text.TextAlign = [System.Drawing.ContentAlignment]::TopRight
    $help.Controls.Add($s3Text)

    $txtFieldExamples = New-Object System.Windows.Forms.TextBox
    $txtFieldExamples.Multiline = $true
    $txtFieldExamples.ReadOnly = $true
    $txtFieldExamples.WordWrap = $false
    $txtFieldExamples.Font = New-Object System.Drawing.Font("Consolas",9)
    $txtFieldExamples.Location = New-Object System.Drawing.Point(24,442)
    $txtFieldExamples.Size = New-Object System.Drawing.Size(710,72)
    $txtFieldExamples.BackColor = $p.Input
    $txtFieldExamples.ForeColor = $p.Text
    $txtFieldExamples.Text = (
        "DNS:       dns.question.name, source.ip, client.ip`r`n" +
        "Suricata:  source.ip, destination.ip, network.transport, event.action`r`n" +
        "Firewall:   source.ip, destination.ip, source.port, destination.port"
    )
    $help.Controls.Add($txtFieldExamples)

    # Step 4
    $s4 = New-Object System.Windows.Forms.Label
    $s4.Text = "مرحله 4 — داخل Dashboard در RAQEB وارد کن و Add / Update را بزن"
    $s4.Font = New-Object System.Drawing.Font("Segoe UI Semibold",10,[System.Drawing.FontStyle]::Bold)
    $s4.Location = New-Object System.Drawing.Point(24,522)
    $s4.Size = New-Object System.Drawing.Size(710,24)
    $s4.RightToLeft = [System.Windows.Forms.RightToLeft]::Yes
    $s4.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
    $help.Controls.Add($s4)

    $completeExample = @'
Dashboard:       DNS
ES Index:        logs-windows.dns-*
Expected Fields: dns.question.name, source.ip, client.ip
'@

    $txtComplete = New-Object System.Windows.Forms.TextBox
    $txtComplete.Multiline = $true
    $txtComplete.ReadOnly = $true
    $txtComplete.WordWrap = $false
    $txtComplete.Font = New-Object System.Drawing.Font("Consolas",9)
    $txtComplete.Location = New-Object System.Drawing.Point(24,550)
    $txtComplete.Size = New-Object System.Drawing.Size(560,70)
    $txtComplete.BackColor = $p.Input
    $txtComplete.ForeColor = $p.Text
    $txtComplete.Text = $completeExample
    $help.Controls.Add($txtComplete)

    $btnCopyExample = New-Object System.Windows.Forms.Button
    $btnCopyExample.Text = "Copy Example"
    $btnCopyExample.Location = New-Object System.Drawing.Point(594,568)
    $btnCopyExample.Size = New-Object System.Drawing.Size(140,34)
    Style-SecondaryButton $btnCopyExample
    $help.Controls.Add($btnCopyExample)
    $btnCopyExample.Add_Click({
        try { [System.Windows.Forms.Clipboard]::SetText($completeExample) } catch {}
    })

    $footer = New-Object System.Windows.Forms.Label
    $footer.Text = "بعدش راقب خودش بررسی می‌کند: اگر Screenshot خالی بود، آیا این فیلدها در Elasticsearch واقعاً داده دارند یا نه."
    $footer.Location = New-Object System.Drawing.Point(24,624)
    $footer.Size = New-Object System.Drawing.Size(710,20)
    $footer.RightToLeft = [System.Windows.Forms.RightToLeft]::Yes
    $footer.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
    $footer.ForeColor = $p.Muted
    $help.Controls.Add($footer)

    [void]$help.ShowDialog($form)
}


function Get-AghrabLeafFieldPaths {
    param($Source)

    $paths = New-Object 'System.Collections.Generic.HashSet[string]'
    $walk = $null

    $walk = {
        param(
            $Value,
            [string]$Prefix,
            [int]$Depth
        )

        if ($Depth -gt 8 -or $null -eq $Value) {
            return
        }

        if ($Value -is [string] -or
            $Value -is [ValueType]) {
            if (-not [string]::IsNullOrWhiteSpace($Prefix)) {
                [void]$paths.Add($Prefix)
            }
            return
        }

        if ($Value -is [System.Collections.IDictionary]) {
            foreach ($key in @($Value.Keys)) {
                $name = [string]$key
                $next = $(if ([string]::IsNullOrWhiteSpace($Prefix)) {
                    $name
                } else {
                    $Prefix + "." + $name
                })
                & $walk $Value[$key] $next ($Depth + 1)
            }
            return
        }

        if ($Value -is [System.Collections.IEnumerable] -and
            -not ($Value -is [string])) {
            $seen = 0
            foreach ($item in $Value) {
                & $walk $item $Prefix ($Depth + 1)
                $seen++
                if ($seen -ge 3) { break }
            }
            return
        }

        $props = @(
            $Value.PSObject.Properties |
            Where-Object {
                $_.MemberType -in @(
                    "NoteProperty",
                    "Property",
                    "ScriptProperty"
                )
            }
        )

        if ($props.Count -eq 0) {
            if (-not [string]::IsNullOrWhiteSpace($Prefix)) {
                [void]$paths.Add($Prefix)
            }
            return
        }

        foreach ($prop in $props) {
            $name = [string]$prop.Name
            $next = $(if ([string]::IsNullOrWhiteSpace($Prefix)) {
                $name
            } else {
                $Prefix + "." + $name
            })

            try {
                & $walk $prop.Value $next ($Depth + 1)
            } catch {}
        }
    }

    & $walk $Source "" 0
    return @($paths | Sort-Object)
}


function Test-AghrabSuggestedFieldCandidate {
    param([string]$Field)

    if ([string]::IsNullOrWhiteSpace($Field)) {
        return $false
    }

    if ($Field -eq "@timestamp") {
        return $false
    }

    if ($Field -match '(^|\.)(_id|_index|_score|_source)$') {
        return $false
    }

    if ($Field -match '\.(keyword|raw|text)$') {
        return $false
    }

    if ($Field -match '^(ecs\.version|input\.type|data_stream\.|elastic_agent\.|agent\.ephemeral_id$)') {
        return $false
    }

    return $true
}


function Get-ElasticsearchSuggestedFields {
    param(
        $Profile,
        [string]$IndexPattern
    )

    $indexPattern = $IndexPattern.Trim()

    if ([string]::IsNullOrWhiteSpace($indexPattern)) {
        throw "Enter ES Index / Data Stream first."
    }

    $esUrl = ([string]$Profile.ElasticsearchUrl).Trim().TrimEnd('/')
    if ([string]::IsNullOrWhiteSpace($esUrl)) {
        throw "Elasticsearch URL is not configured. Open Field Verification first."
    }

    $apiKey = Unprotect-SecretForCurrentUser `
        -ProtectedBase64 ([string]$Profile.FieldVerifyApiKeyProtected)

    if ([string]::IsNullOrWhiteSpace($apiKey)) {
        throw "API Key is missing. Open Field Verification and configure it first."
    }

    if ($apiKey.StartsWith(
        "ApiKey ",
        [System.StringComparison]::OrdinalIgnoreCase
    )) {
        $apiKey = $apiKey.Substring(7).Trim()
    }

    $headers = @{
        Authorization = "ApiKey " + $apiKey
    }

    $timeField = ([string]$Profile.FieldVerifyTimeField).Trim()
    if ([string]::IsNullOrWhiteSpace($timeField)) {
        $timeField = "@timestamp"
    }

    $window = 15
    try {
        $window = [Math]::Min(
            1440,
            [Math]::Max(1,[int]$Profile.FieldVerifyWindowMinutes)
        )
    } catch {}

    # Verify authentication first so the user gets a clear error.
    [void](Test-ElasticsearchFieldVerificationConnection `
        -ElasticsearchUrl $esUrl `
        -ApiKey $apiKey `
        -IgnoreTls ([bool]$Profile.FieldVerifyIgnoreTls))

    $rangeSpec = @{}
    $rangeSpec[$timeField] = @{
        gte = ("now-" + $window + "m")
        lte = "now"
    }

    $recentBody = @{
        size = 5
        track_total_hits = $true
        query = @{
            range = $rangeSpec
        }
        "_source" = $true
    } | ConvertTo-Json -Depth 20 -Compress

    $endpoint = (
        $esUrl + "/" + $indexPattern +
        "/_search?ignore_unavailable=true&allow_no_indices=true"
    )

    $sampleResponse = Invoke-WithOptionalTlsBypass `
        -IgnoreTls ([bool]$Profile.FieldVerifyIgnoreTls) `
        -Action {
            Invoke-RestMethod `
                -Uri $endpoint `
                -Method Post `
                -Headers $headers `
                -ContentType "application/json" `
                -Body $recentBody `
                -TimeoutSec 7
        }

    $shardTotal = 0
    try { $shardTotal = [int]$sampleResponse._shards.total } catch {}

    if ($shardTotal -le 0) {
        throw (
            "No Elasticsearch index/data stream matched: " +
            $indexPattern
        )
    }

    $recentCount = 0
    try { $recentCount = [long]$sampleResponse.hits.total.value } catch {}

    $sampleMode = "Recent data"
    $hits = @($sampleResponse.hits.hits)

    # If the verification window contains no documents, inspect a few historical
    # documents so the user can still get useful field suggestions.
    if ($hits.Count -eq 0) {
        $fallbackBody = @{
            size = 5
            track_total_hits = $false
            query = @{
                match_all = @{}
            }
            "_source" = $true
        } | ConvertTo-Json -Depth 20 -Compress

        $sampleResponse = Invoke-WithOptionalTlsBypass `
            -IgnoreTls ([bool]$Profile.FieldVerifyIgnoreTls) `
            -Action {
                Invoke-RestMethod `
                    -Uri $endpoint `
                    -Method Post `
                    -Headers $headers `
                    -ContentType "application/json" `
                    -Body $fallbackBody `
                    -TimeoutSec 7
            }

        $hits = @($sampleResponse.hits.hits)
        $sampleMode = "Historical sample"
    }

    if ($hits.Count -eq 0) {
        throw (
            "The index/data stream exists, but RAQEB could not find any " +
            "documents to inspect for field suggestions."
        )
    }

    $observed = New-Object 'System.Collections.Generic.HashSet[string]'

    foreach ($hit in $hits) {
        if ($null -eq $hit._source) { continue }

        foreach ($field in @(Get-AghrabLeafFieldPaths -Source $hit._source)) {
            if (Test-AghrabSuggestedFieldCandidate -Field $field) {
                [void]$observed.Add([string]$field)
            }
        }
    }

    if ($observed.Count -eq 0) {
        throw "No useful leaf fields were found in the sampled documents."
    }

    # Security/ECS-oriented priority. These are suggested only if actually
    # observed in the sampled documents.
    $priority = @(
        "source.ip",
        "destination.ip",
        "client.ip",
        "server.ip",
        "source.port",
        "destination.port",
        "user.name",
        "user.id",
        "host.name",
        "host.ip",
        "event.action",
        "event.category",
        "event.type",
        "event.code",
        "event.dataset",
        "process.name",
        "process.executable",
        "process.command_line",
        "file.name",
        "file.path",
        "url.full",
        "url.domain",
        "dns.question.name",
        "network.transport",
        "network.protocol",
        "rule.name",
        "rule.id",
        "observer.name",
        "agent.name",
        "threat.indicator.ip"
    )

    $suggestions = New-Object System.Collections.Generic.List[object]
    $used = New-Object 'System.Collections.Generic.HashSet[string]'

    foreach ($field in $priority) {
        if ($observed.Contains($field)) {
            $suggestions.Add([PSCustomObject]@{
                Field = $field
                Reason = "Common SOC / ECS field found in sampled data"
                Recommended = $true
            })
            [void]$used.Add($field)
        }
    }

    foreach ($field in @($observed | Sort-Object)) {
        if ($used.Contains($field)) { continue }

        # Prefer useful dotted ECS-like fields and avoid giant payload fields.
        if ($field -match '(^message$|event\.original$|^labels\.|^tags$)') {
            continue
        }

        $suggestions.Add([PSCustomObject]@{
            Field = $field
            Reason = "Observed in sampled Elasticsearch documents"
            Recommended = $false
        })
        [void]$used.Add($field)

        if ($suggestions.Count -ge 40) {
            break
        }
    }

    return [PSCustomObject]@{
        IndexPattern = $indexPattern
        WindowMinutes = $window
        TimeField = $timeField
        RecentDocumentCount = $recentCount
        SampleMode = $sampleMode
        SampleDocuments = $hits.Count
        Suggestions = @($suggestions)
    }
}


function Show-SuggestedFieldsDialog {
    param(
        $SuggestionResult,
        [string]$CurrentFields
    )

    $palette = Get-AghrabPalette -Theme $script:CurrentTheme

    $dialog = New-Object System.Windows.Forms.Form
    $dialog.Text = "RAQEB - Suggest Fields"
    $dialog.StartPosition = "CenterParent"
    $dialog.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
    $dialog.MaximizeBox = $false
    $dialog.MinimizeBox = $false
    $dialog.ControlBox = $true
    $dialog.ShowIcon = $false
    $dialog.ClientSize = New-Object System.Drawing.Size(800,610)
    $dialog.Font = New-Object System.Drawing.Font("Segoe UI",9)
    $dialog.BackColor = $palette.Background
    $dialog.ForeColor = $palette.Text

    $title = New-Object System.Windows.Forms.Label
    $title.Text = "Suggested Expected Fields"
    $title.Font = New-Object System.Drawing.Font(
        "Segoe UI Semibold",
        15,
        [System.Drawing.FontStyle]::Bold
    )
    $title.Location = New-Object System.Drawing.Point(22,16)
    $title.Size = New-Object System.Drawing.Size(400,32)
    $dialog.Controls.Add($title)

    $sub = New-Object System.Windows.Forms.Label
    $sub.Text = (
        "RAQEB sampled real Elasticsearch documents and ranked useful " +
        "fields for dashboard health verification."
    )
    $sub.Location = New-Object System.Drawing.Point(24,51)
    $sub.Size = New-Object System.Drawing.Size(750,24)
    $sub.ForeColor = $palette.Muted
    $dialog.Controls.Add($sub)

    $meta = New-Object System.Windows.Forms.Label
    $meta.Text = (
        "Index: " + [string]$SuggestionResult.IndexPattern +
        "   |   Source: " + [string]$SuggestionResult.SampleMode +
        "   |   Sampled docs: " + [string]$SuggestionResult.SampleDocuments +
        "   |   Recent docs: " + [string]$SuggestionResult.RecentDocumentCount
    )
    $meta.Location = New-Object System.Drawing.Point(24,82)
    $meta.Size = New-Object System.Drawing.Size(750,24)
    $dialog.Controls.Add($meta)

    $hint = New-Object System.Windows.Forms.Label
    $hint.Text = (
        "Select the fields you actually care about. 3-8 fields is usually " +
        "enough; RAQEB supports a maximum of 20 Expected Fields."
    )
    $hint.Location = New-Object System.Drawing.Point(24,110)
    $hint.Size = New-Object System.Drawing.Size(750,38)
    $hint.ForeColor = $palette.Muted
    $dialog.Controls.Add($hint)

    $lv = New-Object System.Windows.Forms.ListView
    $lv.Location = New-Object System.Drawing.Point(24,154)
    $lv.Size = New-Object System.Drawing.Size(752,350)
    $lv.View = [System.Windows.Forms.View]::Details
    $lv.FullRowSelect = $true
    $lv.GridLines = $true
    $lv.CheckBoxes = $true
    $lv.MultiSelect = $false
    $lv.HideSelection = $false
    $lv.BackColor = $palette.Input
    $lv.ForeColor = $palette.Text
    [void]$lv.Columns.Add("Field",250)
    [void]$lv.Columns.Add("Why suggested",470)
    $dialog.Controls.Add($lv)

    $current = @(
        Split-ExpectedFields -Text $CurrentFields
    )
    $currentLookup = @{}
    foreach ($f in $current) {
        $currentLookup[[string]$f] = $true
    }

    $recommendedChecked = 0

    foreach ($s in @($SuggestionResult.Suggestions)) {
        $item = New-Object System.Windows.Forms.ListViewItem(
            [string]$s.Field
        )
        [void]$item.SubItems.Add([string]$s.Reason)

        $shouldCheck = $false

        if ($currentLookup.ContainsKey([string]$s.Field)) {
            $shouldCheck = $true
        }
        elseif ([bool]$s.Recommended -and $recommendedChecked -lt 8) {
            $shouldCheck = $true
            $recommendedChecked++
        }

        $item.Checked = $shouldCheck
        $item.Tag = [string]$s.Field
        [void]$lv.Items.Add($item)
    }

    $lblSelected = New-Object System.Windows.Forms.Label
    $lblSelected.Text = "Selected: 0 / 20"
    $lblSelected.Location = New-Object System.Drawing.Point(24,518)
    $lblSelected.Size = New-Object System.Drawing.Size(150,24)
    $dialog.Controls.Add($lblSelected)

    $updateSelected = {
        $count = @(
            $lv.Items |
            Where-Object { $_.Checked }
        ).Count

        $lblSelected.Text = "Selected: " + [string]$count + " / 20"
        $lblSelected.ForeColor = $(
            if ($count -gt 20) {
                $palette.Danger
            }
            elseif ($count -gt 8) {
                $palette.Warning
            }
            else {
                $palette.Muted
            }
        )
    }

    $lv.Add_ItemChecked({
        [System.Windows.Forms.Application]::DoEvents()
        & $updateSelected
    })

    $btnRecommended = New-Object System.Windows.Forms.Button
    $btnRecommended.Text = "Recommended"
    $btnRecommended.Location = New-Object System.Drawing.Point(185,514)
    $btnRecommended.Size = New-Object System.Drawing.Size(120,32)
    Style-SecondaryButton $btnRecommended
    $dialog.Controls.Add($btnRecommended)

    $btnAll = New-Object System.Windows.Forms.Button
    $btnAll.Text = "Select All"
    $btnAll.Location = New-Object System.Drawing.Point(315,514)
    $btnAll.Size = New-Object System.Drawing.Size(95,32)
    Style-SecondaryButton $btnAll
    $dialog.Controls.Add($btnAll)

    $btnClear = New-Object System.Windows.Forms.Button
    $btnClear.Text = "Clear"
    $btnClear.Location = New-Object System.Drawing.Point(420,514)
    $btnClear.Size = New-Object System.Drawing.Size(80,32)
    Style-SecondaryButton $btnClear
    $dialog.Controls.Add($btnClear)

    $btnUse = New-Object System.Windows.Forms.Button
    $btnUse.Text = "Use Selected Fields"
    $btnUse.Location = New-Object System.Drawing.Point(620,514)
    $btnUse.Size = New-Object System.Drawing.Size(156,34)
    Style-PrimaryButton $btnUse
    $dialog.Controls.Add($btnUse)

    $footer = New-Object System.Windows.Forms.Label
    $footer.Text = (
        "This only fills Expected Fields. Nothing is saved until you click " +
        "Add / Update (and then Save Profile)."
    )
    $footer.Location = New-Object System.Drawing.Point(24,560)
    $footer.Size = New-Object System.Drawing.Size(750,24)
    $footer.ForeColor = $palette.Muted
    $dialog.Controls.Add($footer)

    $script:SuggestedFieldsDialogResult = $null

    $btnRecommended.Add_Click({
        $n = 0
        foreach ($item in $lv.Items) {
            $item.Checked = $false
        }

        foreach ($s in @($SuggestionResult.Suggestions)) {
            if (-not [bool]$s.Recommended) { continue }

            foreach ($item in $lv.Items) {
                if ([string]$item.Tag -eq [string]$s.Field) {
                    $item.Checked = $true
                    $n++
                    break
                }
            }

            if ($n -ge 8) { break }
        }

        & $updateSelected
    })

    $btnAll.Add_Click({
        $n = 0
        foreach ($item in $lv.Items) {
            if ($n -lt 20) {
                $item.Checked = $true
                $n++
            }
            else {
                $item.Checked = $false
            }
        }
        & $updateSelected
    })

    $btnClear.Add_Click({
        foreach ($item in $lv.Items) {
            $item.Checked = $false
        }
        & $updateSelected
    })

    $btnUse.Add_Click({
        $selected = @(
            $lv.Items |
            Where-Object { $_.Checked } |
            ForEach-Object { [string]$_.Tag }
        )

        if ($selected.Count -eq 0) {
            [System.Windows.Forms.MessageBox]::Show(
                $dialog,
                "Select at least one field.",
                "RAQEB - Suggest Fields"
            )
            return
        }

        if ($selected.Count -gt 20) {
            [System.Windows.Forms.MessageBox]::Show(
                $dialog,
                "Select no more than 20 fields.",
                "RAQEB - Suggest Fields"
            )
            return
        }

        $script:SuggestedFieldsDialogResult = (
            $selected -join ", "
        )

        $dialog.DialogResult = [System.Windows.Forms.DialogResult]::OK
        $dialog.Close()
    })

    & $updateSelected

    $result = $dialog.ShowDialog($form)

    if ($result -eq [System.Windows.Forms.DialogResult]::OK) {
        return [string]$script:SuggestedFieldsDialogResult
    }

    return $null
}


function Invoke-ElasticsearchManualFieldVerification {
    param(
        $Profile,
        $Dashboard
    )

    $expected = @(Split-ExpectedFields -Text ([string]$Dashboard.ExpectedFields))
    $indexPattern = ([string]$Dashboard.IndexPattern).Trim()
    $dashboardName = ([string]$Dashboard.Name).Trim()

    if ([string]::IsNullOrWhiteSpace($dashboardName)) {
        $dashboardName = "(Current dashboard)"
    }

    $window = 15
    try {
        $window = [Math]::Min(
            1440,
            [Math]::Max(1,[int]$Profile.FieldVerifyWindowMinutes)
        )
    } catch {}

    $timeField = ([string]$Profile.FieldVerifyTimeField).Trim()
    if ([string]::IsNullOrWhiteSpace($timeField)) {
        $timeField = "@timestamp"
    }

    $result = [ordered]@{
        Dashboard = $dashboardName
        IndexPattern = $indexPattern
        WindowMinutes = $window
        TimeField = $timeField
        ConnectionStatus = "NOT CHECKED"
        ConnectionDetail = ""
        IndexStatus = "NOT CHECKED"
        IndexDetail = ""
        Fields = @()
        Overall = "NOT CHECKED"
        OverallDetail = ""
    }

    if ([string]::IsNullOrWhiteSpace($indexPattern)) {
        $result.IndexStatus = "NOT SET"
        $result.IndexDetail = "Enter ES Index / Data Stream for this dashboard."
        $result.Overall = "CONFIG ERROR"
        $result.OverallDetail = "ES Index / Data Stream is empty."
        return [PSCustomObject]$result
    }

    if ($expected.Count -eq 0) {
        $result.Overall = "CONFIG ERROR"
        $result.OverallDetail = "No Expected Fields are configured."
        return [PSCustomObject]$result
    }

    $esUrl = ([string]$Profile.ElasticsearchUrl).Trim().TrimEnd('/')
    if ([string]::IsNullOrWhiteSpace($esUrl)) {
        $result.ConnectionStatus = "NOT CONFIGURED"
        $result.ConnectionDetail = "Set Elasticsearch URL in Field Verification."
        $result.Overall = "CONFIG ERROR"
        $result.OverallDetail = "Elasticsearch URL is missing."
        return [PSCustomObject]$result
    }

    $apiKey = Unprotect-SecretForCurrentUser `
        -ProtectedBase64 ([string]$Profile.FieldVerifyApiKeyProtected)

    if ([string]::IsNullOrWhiteSpace($apiKey)) {
        $result.ConnectionStatus = "NO API KEY"
        $result.ConnectionDetail = "Create or paste the encoded Elasticsearch API Key."
        $result.Overall = "CONFIG ERROR"
        $result.OverallDetail = "API Key is missing or unavailable."
        return [PSCustomObject]$result
    }

    if ($apiKey.StartsWith(
        "ApiKey ",
        [System.StringComparison]::OrdinalIgnoreCase
    )) {
        $apiKey = $apiKey.Substring(7).Trim()
    }

    $headers = @{
        Authorization = "ApiKey " + $apiKey
    }

    # 1) Authentication test.
    try {
        $auth = Invoke-WithOptionalTlsBypass `
            -IgnoreTls ([bool]$Profile.FieldVerifyIgnoreTls) `
            -Action {
                Invoke-RestMethod `
                    -Uri ($esUrl + "/_security/_authenticate") `
                    -Method Get `
                    -Headers $headers `
                    -TimeoutSec 5
            }

        $who = ""
        try { $who = [string]$auth.username } catch {}

        $result.ConnectionStatus = "OK"
        $result.ConnectionDetail = $(
            if ([string]::IsNullOrWhiteSpace($who)) {
                "Elasticsearch authentication succeeded."
            }
            else {
                "Authenticated as: " + $who
            }
        )
    }
    catch {
        $message = $_.Exception.Message
        $result.ConnectionStatus = $(
            if ($message -match "401|Unauthorized") { "UNAUTHORIZED" }
            elseif ($message -match "403|Forbidden") { "FORBIDDEN" }
            else { "ERROR" }
        )
        $result.ConnectionDetail = $message
        $result.Overall = "CONNECTION ERROR"
        $result.OverallDetail = "Could not authenticate to Elasticsearch."
        return [PSCustomObject]$result
    }

    # Build one time-bounded search for all fields.
    $aggs = @{}
    $aggToField = @{}

    for ($i = 0; $i -lt $expected.Count; $i++) {
        $aggName = "f" + $i
        $fieldName = [string]$expected[$i]
        $aggToField[$aggName] = $fieldName
        $aggs[$aggName] = @{
            filter = @{
                exists = @{
                    field = $fieldName
                }
            }
        }
    }

    $rangeSpec = @{}
    $rangeSpec[$timeField] = @{
        gte = ("now-" + $window + "m")
        lte = "now"
    }

    $body = @{
        size = 0
        track_total_hits = $true
        query = @{
            range = $rangeSpec
        }
        aggs = $aggs
    } | ConvertTo-Json -Depth 20 -Compress

    # 2) Resolve the index pattern by running a zero-document search.
    #    _shards.total == 0 means the wildcard/data-stream pattern matched nothing.
    try {
        $searchResponse = Invoke-WithOptionalTlsBypass `
            -IgnoreTls ([bool]$Profile.FieldVerifyIgnoreTls) `
            -Action {
                Invoke-RestMethod `
                    -Uri (
                        $esUrl + "/" + $indexPattern +
                        "/_search?ignore_unavailable=true&allow_no_indices=true"
                    ) `
                    -Method Post `
                    -Headers $headers `
                    -ContentType "application/json" `
                    -Body $body `
                    -TimeoutSec 6
            }

        $shardTotal = 0
        try { $shardTotal = [int]$searchResponse._shards.total } catch {}

        if ($shardTotal -le 0) {
            $result.IndexStatus = "NOT FOUND"
            $result.IndexDetail = (
                "No Elasticsearch index/data stream matched: " +
                $indexPattern
            )
            $result.Overall = "INDEX NOT FOUND"
            $result.OverallDetail = (
                "Check the ES Index / Data Stream value for this dashboard."
            )
            return [PSCustomObject]$result
        }

        $recentDocs = 0
        try {
            $recentDocs = [long]$searchResponse.hits.total.value
        } catch {}

        $result.IndexStatus = "FOUND"
        $result.IndexDetail = (
            "Matched Elasticsearch data. Shards: " +
            [string]$shardTotal +
            " | Recent docs in window: " +
            [string]$recentDocs
        )
    }
    catch {
        $message = $_.Exception.Message
        $result.IndexStatus = $(
            if ($message -match "404|index_not_found_exception") {
                "NOT FOUND"
            }
            elseif ($message -match "403|Forbidden") {
                "FORBIDDEN"
            }
            else {
                "ERROR"
            }
        )
        $result.IndexDetail = $message
        $result.Overall = "INDEX ERROR"
        $result.OverallDetail = (
            "RAQEB could not query the configured ES Index / Data Stream."
        )
        return [PSCustomObject]$result
    }

    # 3) Field Caps distinguishes "field not mapped" from
    #    "field exists but has zero recent documents".
    $fieldCaps = $null
    try {
        $encodedFields = [System.Uri]::EscapeDataString(
            ($expected -join ",")
        )

        $fieldCaps = Invoke-WithOptionalTlsBypass `
            -IgnoreTls ([bool]$Profile.FieldVerifyIgnoreTls) `
            -Action {
                Invoke-RestMethod `
                    -Uri (
                        $esUrl + "/" + $indexPattern +
                        "/_field_caps?fields=" + $encodedFields +
                        "&ignore_unavailable=true&allow_no_indices=true"
                    ) `
                    -Method Get `
                    -Headers $headers `
                    -TimeoutSec 6
            }
    }
    catch {
        $message = $_.Exception.Message
        $result.Overall = "FIELD CHECK ERROR"
        $result.OverallDetail = (
            "Could not read field mappings: " + $message
        )
        return [PSCustomObject]$result
    }

    $missingCount = 0
    $noDataCount = 0
    $activeCount = 0

    foreach ($aggName in @($aggToField.Keys | Sort-Object)) {
        $fieldName = [string]$aggToField[$aggName]

        $mapped = $false
        try {
            $mapped = (
                $null -ne $fieldCaps.fields -and
                $null -ne $fieldCaps.fields.PSObject.Properties[$fieldName]
            )
        } catch {}

        if (-not $mapped) {
            $missingCount++
            $result.Fields += [PSCustomObject]@{
                Field = $fieldName
                Status = "NOT FOUND"
                Count = "-"
                Detail = "Field is not present in the resolved Elasticsearch mappings."
            }
            continue
        }

        $count = 0
        try {
            $count = [long]$searchResponse.aggregations.$aggName.doc_count
        } catch {}

        if ($count -gt 0) {
            $activeCount++
            $result.Fields += [PSCustomObject]@{
                Field = $fieldName
                Status = "ACTIVE"
                Count = [string]$count
                Detail = (
                    "Field exists and has recent data in the last " +
                    [string]$window + " minutes."
                )
            }
        }
        else {
            $noDataCount++
            $result.Fields += [PSCustomObject]@{
                Field = $fieldName
                Status = "NO DATA"
                Count = "0"
                Detail = (
                    "Field exists in mapping, but no recent document has a value " +
                    "for it in the selected verification window."
                )
            }
        }
    }

    if ($missingCount -gt 0) {
        $result.Overall = "FIELD GAP"
        $result.OverallDetail = (
            [string]$missingCount +
            " expected field(s) are not present in the resolved mappings."
        )
    }
    elseif ($noDataCount -gt 0) {
        $result.Overall = "FIELD GAP"
        $result.OverallDetail = (
            [string]$noDataCount +
            " expected field(s) exist, but have no recent data."
        )
    }
    else {
        $result.Overall = "FIELDS ACTIVE"
        $result.OverallDetail = (
            "All " + [string]$activeCount +
            " expected field(s) exist and have recent data."
        )
    }

    return [PSCustomObject]$result
}


function Convert-ManualFieldVerificationToText {
    param($Result)

    $lines = New-Object System.Collections.Generic.List[string]

    $lines.Add("RAQEB - Verify Fields Now")
    $lines.Add("")
    $lines.Add("Dashboard: " + [string]$Result.Dashboard)
    $lines.Add("Index: " + [string]$Result.IndexPattern)
    $lines.Add(
        "Window: Last " + [string]$Result.WindowMinutes +
        " minutes | Time field: " + [string]$Result.TimeField
    )
    $lines.Add("")
    $lines.Add(
        "Connection: " + [string]$Result.ConnectionStatus +
        " | " + [string]$Result.ConnectionDetail
    )
    $lines.Add(
        "Index: " + [string]$Result.IndexStatus +
        " | " + [string]$Result.IndexDetail
    )
    $lines.Add("")
    $lines.Add("Fields:")

    foreach ($field in @($Result.Fields)) {
        $lines.Add(
            "  " + [string]$field.Field +
            " | " + [string]$field.Status +
            " | Count: " + [string]$field.Count +
            " | " + [string]$field.Detail
        )
    }

    if (@($Result.Fields).Count -eq 0) {
        $lines.Add("  No field results.")
    }

    $lines.Add("")
    $lines.Add(
        "Result: " + [string]$Result.Overall +
        " | " + [string]$Result.OverallDetail
    )

    return ($lines -join "`r`n")
}


function Show-ManualFieldVerificationResult {
    param($Result)

    $palette = Get-AghrabPalette -Theme $script:CurrentTheme

    $dialog = New-Object System.Windows.Forms.Form
    $dialog.Text = "RAQEB - Verify Fields Now"
    $dialog.StartPosition = "CenterParent"
    $dialog.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
    $dialog.MaximizeBox = $false
    $dialog.MinimizeBox = $false
    $dialog.ControlBox = $true
    $dialog.ShowIcon = $false
    $dialog.ClientSize = New-Object System.Drawing.Size(790,600)
    $dialog.Font = New-Object System.Drawing.Font("Segoe UI",9)
    $dialog.BackColor = $palette.Background
    $dialog.ForeColor = $palette.Text

    $title = New-Object System.Windows.Forms.Label
    $title.Text = "Verify Fields Now"
    $title.Font = New-Object System.Drawing.Font(
        "Segoe UI Semibold",
        15,
        [System.Drawing.FontStyle]::Bold
    )
    $title.Location = New-Object System.Drawing.Point(22,16)
    $title.Size = New-Object System.Drawing.Size(350,32)
    $dialog.Controls.Add($title)

    $sub = New-Object System.Windows.Forms.Label
    $sub.Text = (
        "Direct Elasticsearch check — no Kibana browser, screenshot or AI is used."
    )
    $sub.Location = New-Object System.Drawing.Point(24,50)
    $sub.Size = New-Object System.Drawing.Size(730,24)
    $sub.ForeColor = $palette.Muted
    $dialog.Controls.Add($sub)

    $lblDashboard = New-Object System.Windows.Forms.Label
    $lblDashboard.Text = (
        "Dashboard: " + [string]$Result.Dashboard +
        "   |   Window: Last " + [string]$Result.WindowMinutes +
        " min   |   Time field: " + [string]$Result.TimeField
    )
    $lblDashboard.Location = New-Object System.Drawing.Point(24,83)
    $lblDashboard.Size = New-Object System.Drawing.Size(742,22)
    $dialog.Controls.Add($lblDashboard)

    $lblIndex = New-Object System.Windows.Forms.Label
    $lblIndex.Text = "Index / Data Stream: " + [string]$Result.IndexPattern
    $lblIndex.Location = New-Object System.Drawing.Point(24,108)
    $lblIndex.Size = New-Object System.Drawing.Size(742,22)
    $dialog.Controls.Add($lblIndex)

    $panelSummary = New-Object System.Windows.Forms.Panel
    $panelSummary.Location = New-Object System.Drawing.Point(24,140)
    $panelSummary.Size = New-Object System.Drawing.Size(742,88)
    $panelSummary.BackColor = $palette.Surface
    Set-RoundedControlRegion -Control $panelSummary -Radius 10
    $dialog.Controls.Add($panelSummary)

    $lblConnection = New-Object System.Windows.Forms.Label
    $lblConnection.Text = (
        "Connection: " + [string]$Result.ConnectionStatus
    )
    $lblConnection.Font = New-Object System.Drawing.Font(
        "Segoe UI Semibold",
        9.5
    )
    $lblConnection.Location = New-Object System.Drawing.Point(14,12)
    $lblConnection.Size = New-Object System.Drawing.Size(220,22)
    $panelSummary.Controls.Add($lblConnection)

    $lblConnectionDetail = New-Object System.Windows.Forms.Label
    $lblConnectionDetail.Text = [string]$Result.ConnectionDetail
    $lblConnectionDetail.Location = New-Object System.Drawing.Point(240,12)
    $lblConnectionDetail.Size = New-Object System.Drawing.Size(486,22)
    $lblConnectionDetail.ForeColor = $palette.Muted
    $panelSummary.Controls.Add($lblConnectionDetail)

    $lblIndexState = New-Object System.Windows.Forms.Label
    $lblIndexState.Text = "Index: " + [string]$Result.IndexStatus
    $lblIndexState.Font = New-Object System.Drawing.Font(
        "Segoe UI Semibold",
        9.5
    )
    $lblIndexState.Location = New-Object System.Drawing.Point(14,42)
    $lblIndexState.Size = New-Object System.Drawing.Size(220,22)
    $panelSummary.Controls.Add($lblIndexState)

    $lblIndexDetail = New-Object System.Windows.Forms.Label
    $lblIndexDetail.Text = [string]$Result.IndexDetail
    $lblIndexDetail.Location = New-Object System.Drawing.Point(240,42)
    $lblIndexDetail.Size = New-Object System.Drawing.Size(486,36)
    $lblIndexDetail.ForeColor = $palette.Muted
    $panelSummary.Controls.Add($lblIndexDetail)

    $lv = New-Object System.Windows.Forms.ListView
    $lv.Location = New-Object System.Drawing.Point(24,244)
    $lv.Size = New-Object System.Drawing.Size(742,245)
    $lv.View = [System.Windows.Forms.View]::Details
    $lv.FullRowSelect = $true
    $lv.GridLines = $true
    $lv.MultiSelect = $false
    $lv.HideSelection = $false
    $lv.BackColor = $palette.Input
    $lv.ForeColor = $palette.Text
    [void]$lv.Columns.Add("Field",220)
    [void]$lv.Columns.Add("Status",95)
    [void]$lv.Columns.Add("Count",75)
    [void]$lv.Columns.Add("What it means",330)
    $dialog.Controls.Add($lv)

    foreach ($field in @($Result.Fields)) {
        $item = New-Object System.Windows.Forms.ListViewItem(
            [string]$field.Field
        )
        [void]$item.SubItems.Add([string]$field.Status)
        [void]$item.SubItems.Add([string]$field.Count)
        [void]$item.SubItems.Add([string]$field.Detail)

        if ([string]$field.Status -eq "ACTIVE") {
            $item.ForeColor = $palette.Success
        }
        elseif ([string]$field.Status -in @("NO DATA","NOT FOUND")) {
            $item.ForeColor = $palette.Warning
        }

        [void]$lv.Items.Add($item)
    }

    $panelResult = New-Object System.Windows.Forms.Panel
    $panelResult.Location = New-Object System.Drawing.Point(24,505)
    $panelResult.Size = New-Object System.Drawing.Size(742,60)
    $panelResult.BackColor = $palette.Surface
    Set-RoundedControlRegion -Control $panelResult -Radius 10
    $dialog.Controls.Add($panelResult)

    $lblResult = New-Object System.Windows.Forms.Label
    $lblResult.Text = "Result: " + [string]$Result.Overall
    $lblResult.Font = New-Object System.Drawing.Font(
        "Segoe UI Semibold",
        11,
        [System.Drawing.FontStyle]::Bold
    )
    $lblResult.Location = New-Object System.Drawing.Point(14,8)
    $lblResult.Size = New-Object System.Drawing.Size(220,24)
    $panelResult.Controls.Add($lblResult)

    $lblResultDetail = New-Object System.Windows.Forms.Label
    $lblResultDetail.Text = [string]$Result.OverallDetail
    $lblResultDetail.Location = New-Object System.Drawing.Point(14,32)
    $lblResultDetail.Size = New-Object System.Drawing.Size(560,20)
    $lblResultDetail.ForeColor = $palette.Muted
    $panelResult.Controls.Add($lblResultDetail)

    $btnCopy = New-Object System.Windows.Forms.Button
    $btnCopy.Text = "Copy Result"
    $btnCopy.Location = New-Object System.Drawing.Point(610,14)
    $btnCopy.Size = New-Object System.Drawing.Size(116,32)
    Style-SecondaryButton $btnCopy
    $panelResult.Controls.Add($btnCopy)

    $report = Convert-ManualFieldVerificationToText -Result $Result

    $btnCopy.Add_Click({
        try {
            [System.Windows.Forms.Clipboard]::SetText($report)
        } catch {}
    })

    $resultState = [string]$Result.Overall
    $resultColor = $palette.Muted

    if ($resultState -eq "FIELDS ACTIVE") {
        $resultColor = $palette.Success
    }
    elseif ($resultState -match "ERROR|NOT FOUND|FIELD GAP") {
        $resultColor = $palette.Warning
    }

    $lblResult.ForeColor = $resultColor

    if ([string]$Result.ConnectionStatus -eq "OK") {
        $lblConnection.ForeColor = $palette.Success
    }
    elseif ([string]$Result.ConnectionStatus -ne "NOT CHECKED") {
        $lblConnection.ForeColor = $palette.Danger
    }

    if ([string]$Result.IndexStatus -eq "FOUND") {
        $lblIndexState.ForeColor = $palette.Success
    }
    elseif ([string]$Result.IndexStatus -ne "NOT CHECKED") {
        $lblIndexState.ForeColor = $palette.Warning
    }

    [void]$dialog.ShowDialog($form)
}


function Show-ElasticsearchVerificationDialog {
    $dialog = New-Object System.Windows.Forms.Form
    $dialog.Text = "RAQEB Field Verification"
    $dialog.StartPosition = "CenterParent"
    $dialog.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
    $dialog.MaximizeBox = $false
    $dialog.MinimizeBox = $false
    $dialog.ClientSize = New-Object System.Drawing.Size(620,390)
    $dialog.Font = New-Object System.Drawing.Font("Segoe UI",9)

    $palette = Get-AghrabPalette -Theme $script:CurrentTheme
    $dialog.BackColor = $palette.Background
    $dialog.ForeColor = $palette.Text

    $title = New-Object System.Windows.Forms.Label
    $title.Text = "Fast Elasticsearch Field Verification"
    $title.Font = New-Object System.Drawing.Font("Segoe UI Semibold",14,[System.Drawing.FontStyle]::Bold)
    $title.Location = New-Object System.Drawing.Point(20,16)
    $title.AutoSize = $true
    $dialog.Controls.Add($title)

    $hint = New-Object System.Windows.Forms.Label
    $hint.Text = "Runs AFTER each screenshot. One size=0 request checks all Expected Fields, so dashboard rendering speed is not reduced."
    $hint.Location = New-Object System.Drawing.Point(22,50)
    $hint.Size = New-Object System.Drawing.Size(570,38)
    $hint.ForeColor = $palette.Muted
    $dialog.Controls.Add($hint)

    $chkEnabled = New-Object System.Windows.Forms.CheckBox
    $chkEnabled.Text = "Enable Field Verification"
    $chkEnabled.Location = New-Object System.Drawing.Point(22,96)
    $chkEnabled.AutoSize = $true
    $chkEnabled.Checked = [bool]$script:EditorFieldVerifyEnabled
    $dialog.Controls.Add($chkEnabled)

    $lblUrl = New-Object System.Windows.Forms.Label
    $lblUrl.Text = "Elasticsearch URL"
    $lblUrl.Location = New-Object System.Drawing.Point(22,132)
    $lblUrl.AutoSize = $true
    $dialog.Controls.Add($lblUrl)

    $txtUrl = New-Object System.Windows.Forms.TextBox
    $txtUrl.Location = New-Object System.Drawing.Point(160,128)
    $txtUrl.Size = New-Object System.Drawing.Size(430,28)
    $txtUrl.Text = [string]$script:EditorElasticsearchUrl
    $dialog.Controls.Add($txtUrl)

    # Visual-only placeholder. It is never written into $txtUrl.Text,
    # so it cannot accidentally be saved as the real Elasticsearch URL.
    $lblUrlPlaceholder = New-Object System.Windows.Forms.Label
    $lblUrlPlaceholder.Text = "https://ELASTICSEARCH-IP:9200"
    $lblUrlPlaceholder.Location = New-Object System.Drawing.Point(166,133)
    $lblUrlPlaceholder.Size = New-Object System.Drawing.Size(300,18)
    $lblUrlPlaceholder.BackColor = $palette.Input
    $lblUrlPlaceholder.ForeColor = $palette.Muted
    $lblUrlPlaceholder.Cursor = [System.Windows.Forms.Cursors]::IBeam
    $dialog.Controls.Add($lblUrlPlaceholder)
    $lblUrlPlaceholder.BringToFront()

    $refreshUrlPlaceholder = {
        $lblUrlPlaceholder.Visible = [string]::IsNullOrWhiteSpace($txtUrl.Text)
    }

    $txtUrl.Add_TextChanged({
        & $refreshUrlPlaceholder
    })

    $txtUrl.Add_Enter({
        $lblUrlPlaceholder.Visible = $false
    })

    $txtUrl.Add_Leave({
        & $refreshUrlPlaceholder
    })

    $lblUrlPlaceholder.Add_Click({
        $txtUrl.Focus()
        $lblUrlPlaceholder.Visible = $false
    })

    & $refreshUrlPlaceholder

    $lblApi = New-Object System.Windows.Forms.Label
    $lblApi.Text = "API Key"
    $lblApi.Location = New-Object System.Drawing.Point(22,171)
    $lblApi.AutoSize = $true
    $dialog.Controls.Add($lblApi)

    $txtApi = New-Object System.Windows.Forms.TextBox
    $txtApi.Location = New-Object System.Drawing.Point(160,167)
    $txtApi.Size = New-Object System.Drawing.Size(320,28)
    $txtApi.UseSystemPasswordChar = $true
    $existingKey = Unprotect-SecretForCurrentUser -ProtectedBase64 ([string]$script:EditorFieldVerifyApiKeyProtected)
    if (-not [string]::IsNullOrWhiteSpace($existingKey)) {
        $txtApi.Text = $existingKey
    }
    $dialog.Controls.Add($txtApi)

    $lblApiPlaceholder = New-Object System.Windows.Forms.Label
    $lblApiPlaceholder.Text = "Paste encoded Elasticsearch API Key"
    $lblApiPlaceholder.Location = New-Object System.Drawing.Point(166,172)
    $lblApiPlaceholder.Size = New-Object System.Drawing.Size(255,18)
    $lblApiPlaceholder.BackColor = $palette.Input
    $lblApiPlaceholder.ForeColor = $palette.Muted
    $lblApiPlaceholder.Cursor = [System.Windows.Forms.Cursors]::IBeam
    $dialog.Controls.Add($lblApiPlaceholder)
    $lblApiPlaceholder.BringToFront()

    $refreshApiPlaceholder = {
        $lblApiPlaceholder.Visible = [string]::IsNullOrWhiteSpace($txtApi.Text)
    }

    $txtApi.Add_TextChanged({
        & $refreshApiPlaceholder
    })
    $txtApi.Add_Enter({
        $lblApiPlaceholder.Visible = $false
    })
    $txtApi.Add_Leave({
        & $refreshApiPlaceholder
    })
    $lblApiPlaceholder.Add_Click({
        $txtApi.Focus()
        $lblApiPlaceholder.Visible = $false
    })
    & $refreshApiPlaceholder

    $btnApiHelp = New-Object System.Windows.Forms.Button
    $btnApiHelp.Text = "API Help"
    $btnApiHelp.Location = New-Object System.Drawing.Point(490,165)
    $btnApiHelp.Size = New-Object System.Drawing.Size(100,32)
    Style-SecondaryButton $btnApiHelp
    $dialog.Controls.Add($btnApiHelp)

    $btnApiHelp.Add_Click({
        Show-ElasticsearchApiKeyHelp
    })

    $lblTime = New-Object System.Windows.Forms.Label
    $lblTime.Text = "Time field"
    $lblTime.Location = New-Object System.Drawing.Point(22,210)
    $lblTime.AutoSize = $true
    $dialog.Controls.Add($lblTime)

    $txtTime = New-Object System.Windows.Forms.TextBox
    $txtTime.Location = New-Object System.Drawing.Point(160,206)
    $txtTime.Size = New-Object System.Drawing.Size(170,28)
    $txtTime.Text = [string]$script:EditorFieldVerifyTimeField
    $dialog.Controls.Add($txtTime)

    $lblWindow = New-Object System.Windows.Forms.Label
    $lblWindow.Text = "Window"
    $lblWindow.Location = New-Object System.Drawing.Point(355,210)
    $lblWindow.AutoSize = $true
    $dialog.Controls.Add($lblWindow)

    $numWindow = New-Object System.Windows.Forms.NumericUpDown
    $numWindow.Minimum = 1
    $numWindow.Maximum = 1440
    $numWindow.Value = [Math]::Min([decimal]1440,[Math]::Max([decimal]1,[decimal]$script:EditorFieldVerifyWindowMinutes))
    $numWindow.Location = New-Object System.Drawing.Point(415,206)
    $numWindow.Size = New-Object System.Drawing.Size(80,28)
    $dialog.Controls.Add($numWindow)

    $lblMin = New-Object System.Windows.Forms.Label
    $lblMin.Text = "minutes"
    $lblMin.Location = New-Object System.Drawing.Point(500,210)
    $lblMin.AutoSize = $true
    $dialog.Controls.Add($lblMin)

    $chkTls = New-Object System.Windows.Forms.CheckBox
    $chkTls.Text = "Ignore self-signed / internal TLS certificate errors"
    $chkTls.Location = New-Object System.Drawing.Point(160,246)
    $chkTls.AutoSize = $true
    $chkTls.Checked = [bool]$script:EditorFieldVerifyIgnoreTls
    $dialog.Controls.Add($chkTls)

    $status = New-Object System.Windows.Forms.Label
    $status.Text = "API Key is stored with Windows Current-User DPAPI."
    $status.Location = New-Object System.Drawing.Point(22,282)
    $status.Size = New-Object System.Drawing.Size(570,38)
    $status.ForeColor = $palette.Muted
    $dialog.Controls.Add($status)

    $btnTest = New-Object System.Windows.Forms.Button
    $btnTest.Text = "Test Connection"
    $btnTest.Location = New-Object System.Drawing.Point(22,335)
    $btnTest.Size = New-Object System.Drawing.Size(125,34)
    Style-SecondaryButton $btnTest
    $dialog.Controls.Add($btnTest)

    $btnSave = New-Object System.Windows.Forms.Button
    $btnSave.Text = "Save"
    $btnSave.Location = New-Object System.Drawing.Point(405,335)
    $btnSave.Size = New-Object System.Drawing.Size(85,34)
    Style-PrimaryButton $btnSave
    $dialog.Controls.Add($btnSave)

    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text = "Cancel"
    $btnCancel.Location = New-Object System.Drawing.Point(500,335)
    $btnCancel.Size = New-Object System.Drawing.Size(90,34)
    Style-SecondaryButton $btnCancel
    $dialog.Controls.Add($btnCancel)

    $btnTest.Add_Click({
        try {
            $status.Text = "Testing..."
            $status.ForeColor = $palette.Muted
            [System.Windows.Forms.Application]::DoEvents()

            $auth = Test-ElasticsearchFieldVerificationConnection `
                -ElasticsearchUrl $txtUrl.Text `
                -ApiKey $txtApi.Text `
                -IgnoreTls ([bool]$chkTls.Checked)

            $who = ""
            try { $who = [string]$auth.username } catch {}
            $status.Text = $(if ([string]::IsNullOrWhiteSpace($who)) { "Connection successful." } else { "Connection successful. Authenticated as: " + $who })
            $status.ForeColor = $palette.Success
        }
        catch {
            $status.Text = "Connection failed: " + $_.Exception.Message
            $status.ForeColor = $palette.Danger
        }
    })

    $btnSave.Add_Click({
        $script:EditorFieldVerifyEnabled = [bool]$chkEnabled.Checked
        $script:EditorElasticsearchUrl = $txtUrl.Text.Trim()
        $script:EditorFieldVerifyTimeField = $(if ([string]::IsNullOrWhiteSpace($txtTime.Text)) { "@timestamp" } else { $txtTime.Text.Trim() })
        $script:EditorFieldVerifyWindowMinutes = [int]$numWindow.Value
        $script:EditorFieldVerifyIgnoreTls = [bool]$chkTls.Checked

        $plainKey = $txtApi.Text.Trim()
        if (-not [string]::IsNullOrWhiteSpace($plainKey)) {
            $script:EditorFieldVerifyApiKeyProtected = Protect-SecretForCurrentUser -PlainText $plainKey
        }
        elseif ($script:EditorFieldVerifyEnabled) {
            $script:EditorFieldVerifyApiKeyProtected = ""
        }

        $dialog.DialogResult = [System.Windows.Forms.DialogResult]::OK
        $dialog.Close()
    })

    $btnCancel.Add_Click({
        $dialog.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
        $dialog.Close()
    })

    [void]$dialog.ShowDialog($form)
}

function Invoke-HealthAiAnalysis {
    param([string]$ImagePath)

    [void](Start-BuiltInAi)

    $prompt = @"
You are checking ONE SOC/Kibana dashboard screenshot for a monitoring health center.

Analyze only what is visibly supported.
Return ONLY JSON.

Rules:
- Login/authentication page instead of the expected dashboard = Critical.
- Fatal dashboard load/error state = Critical.
- One or more panels with "No results", "No results found" or "No data" = at least Warning.
- A legitimate visible metric value of 0 is DATA, not NO_DATA.
- Loading/spinner is UNKNOWN, not NO_DATA.
- Never invent panel names.
- For each visible NO DATA panel, copy its visible title exactly.
- If a NO DATA panel title cannot be read, use "Unreadable panel".
- Do not claim ingestion failure as fact.

Schema:
{
  "overall_status": "Normal|Warning|Critical",
  "dashboard_loaded": true,
  "login_page_detected": false,
  "visible_errors": 0,
  "empty_panels": 0,
  "panels_with_data": 0,
  "no_data_panels": [
    {
      "title": "exact visible panel title",
      "evidence": "short visible reason"
    }
  ],
  "findings": ["..."],
  "security_observations": ["..."],
  "possible_causes": ["..."],
  "recommended_actions": ["..."],
  "summary": "...",
  "confidence": "high|medium|low"
}
"@

    $answer = Invoke-AiVisionRequest -Prompt $prompt -ImagePaths @($ImagePath)
    $result = ConvertFrom-AiJsonResponse -Text $answer
    $result = Apply-SocHealthRules -Result $result

    $status = "Unknown"
    switch ([string]$result.overall_status) {
        "Normal" { $status = "Healthy" }
        "Warning" { $status = "Warning" }
        "Critical" { $status = "Critical" }
        default { $status = "Unknown" }
    }

    $noData = @(Get-NoDataPanelItems -Result $result)
    $names = @()
    foreach ($panel in $noData) {
        $names += [string]$panel.title
    }

    $count = -1
    if ($noData.Count -gt 0) {
        $count = $noData.Count
    }
    else {
        try { $count = [int]$result.empty_panels } catch {}
    }

    $errors = 0
    try { $errors = [int]$result.visible_errors } catch {}

    return [PSCustomObject]@{
        Status = $status
        NoDataCount = $count
        NoDataPanels = @($names)
        Errors = $errors
        Confidence = [string]$result.confidence
        Message = [string]$result.summary
    }
}

function Set-ProfileDashboardsHealthFailure {
    param(
        $Profile,
        [string]$Message
    )

    foreach ($dashboard in @($Profile.Dashboards)) {
        Set-HealthRecord `
            -Profile ([string]$Profile.Name) `
            -Dashboard ([string]$dashboard.Name) `
            -Status "Critical" `
            -NoDataCount -1 `
            -Errors 1 `
            -Confidence "" `
            -Message $Message `
            -Screenshot ""
    }
}

function Invoke-AutomaticCaptureCycle {
    param(
        [switch]$Interactive,
        [string]$DashboardName = ""
    )

    if (
        [string]::IsNullOrWhiteSpace($DashboardName) -and
        -not (Test-AghrabCommercialFeatureAccess -Feature "AutomaticCapture")
    ) {
        if ($Interactive) {
            Show-AghrabLicenseRestriction -FeatureName "Automatic Capture"
        }
        try {
            Write-SchedulerLog "Automatic Capture skipped: license does not allow this feature."
        } catch {}
        return
    }

    if ($script:SchedulerBusy -or $script:CaptureBusy) {
        if ($Interactive) {
            [System.Windows.Forms.MessageBox]::Show($form,"A capture is already running.","RAQEB Sentinel Pro")
        }
        return
    }

    $profileName = [string]$cmbSchedulerProfile.SelectedItem
    $profile = Get-ElkProfileByName -Name $profileName

    if ($null -eq $profile) {
        if ($Interactive) {
            [System.Windows.Forms.MessageBox]::Show($form,"Select a valid ELK profile first.","RAQEB Sentinel Pro")
        }
        Write-SchedulerLog "Run skipped: invalid profile."
        return
    }

    $credState = Get-SchedulerCredentialState -ProfileName $profileName
    if (-not $credState.Ready) {
        $msg = [string]$credState.Detail
        Write-SchedulerLog ("Preflight failed: " + [string]$credState.State + ". " + $msg)

        if (-not [string]::IsNullOrWhiteSpace($DashboardName)) {
            Set-HealthRecord `
                -Profile ([string]$profile.Name) `
                -Dashboard $DashboardName `
                -Status "Critical" `
                -NoDataCount -1 `
                -Errors 1 `
                -Confidence "" `
                -Message $msg `
                -Screenshot ""
        }
        else {
            Set-ProfileDashboardsHealthFailure -Profile $profile -Message $msg
        }

        if ($Interactive) {
            [System.Windows.Forms.MessageBox]::Show(
                $form,
                "Automatic Capture cannot start.`r`n`r`nCredentials: " + [string]$credState.State + "`r`n`r`n" + $msg,
                "RAQEB Sentinel Pro",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Warning
            )
        }

        Refresh-HealthCenter
        Update-SchedulerStateUi
        return
    }

    $dashboards = @($profile.Dashboards)

    if (-not [string]::IsNullOrWhiteSpace($DashboardName)) {
        $dashboards = @(
            $dashboards |
            Where-Object { [string]$_.Name -eq $DashboardName }
        )
    }

    if ($dashboards.Count -eq 0) {
        $msg = "Profile '$profileName' has no dashboards."
        Write-SchedulerLog $msg
        if ($Interactive) {
            [System.Windows.Forms.MessageBox]::Show($form,$msg,"RAQEB Sentinel Pro")
        }
        return
    }

    $browser = $txtBrowser.Text.Trim()
    if (-not $browser -or -not (Test-Path -LiteralPath $browser -PathType Leaf)) {
        Auto-Detect-Browser
        $browser = $txtBrowser.Text.Trim()
    }

    if (-not $browser -or -not (Test-Path -LiteralPath $browser -PathType Leaf)) {
        $msg = "Browser not found. Automatic Capture cannot start."
        Write-SchedulerLog $msg

        if (-not [string]::IsNullOrWhiteSpace($DashboardName)) {
            Set-HealthRecord `
                -Profile ([string]$profile.Name) `
                -Dashboard $DashboardName `
                -Status "Critical" `
                -NoDataCount -1 `
                -Errors 1 `
                -Confidence "" `
                -Message $msg `
                -Screenshot ""
        }
        else {
            Set-ProfileDashboardsHealthFailure -Profile $profile -Message $msg
        }

        if ($Interactive) {
            [System.Windows.Forms.MessageBox]::Show($form,$msg,"RAQEB Sentinel Pro")
        }
        return
    }

    $outDir = Get-OutputRoot
    if ([string]::IsNullOrWhiteSpace($outDir)) {
        $msg = "Output folder is empty."
        Write-SchedulerLog $msg
        if ($Interactive) {
            [System.Windows.Forms.MessageBox]::Show($form,$msg,"RAQEB Sentinel Pro")
        }
        return
    }

    New-Item -ItemType Directory -Force -Path $outDir | Out-Null

    $runAi = [bool]$chkSchedulerAi.Checked
    $aiReady = $false
    $success = 0
    $partial = 0
    $failed = 0
    $cycleError = ""
    $aiStartupError = ""
    $captchaPaused = $false

    $script:SchedulerBusy = $true
    $script:CaptureBusy = $true
    $script:StopRequested = $false
    Update-SchedulerStateUi
    if (-not [string]::IsNullOrWhiteSpace($DashboardName)) {
        Write-SchedulerLog ("Starting single-dashboard recheck: profile='" + $profileName + "' dashboard='" + $DashboardName + "'.")
    }
    else {
        Write-SchedulerLog ("Starting automatic cycle for profile '" + $profileName + "' with " + $dashboards.Count + " dashboard(s).")
    }

    try {
        try {
            $session = Start-ElkLiveSession -Browser $browser -Profile $profile

            if (
                $script:SkipNextAutoLogin -and
                (Test-ElkLiveSession -ProfileName ([string]$profile.Name))
            ) {
                $script:SkipNextAutoLogin = $false
                Write-SchedulerLog "Reusing authenticated browser session after manual CAPTCHA."
            }
            else {
                Write-SchedulerLog "Browser session opened. Detecting Kibana/Keycloak login flow..."
                $null = Ensure-ElkAutoLogin -Port $session.Port -Profile $profile
                Write-SchedulerLog "Auto Login successful. Kibana authenticated."
            }
        }
        catch {
            if ($_.Exception.Message -eq "CAPTCHA_REQUIRED") {
                $captchaPaused = $true

                $captchaMode = $(if ([string]::IsNullOrWhiteSpace($DashboardName)) {
                    "scheduler"
                } else {
                    "scheduler-recheck"
                })

                Set-ElkCaptchaPending `
                    -Mode $captchaMode `
                    -ProfileName ([string]$profile.Name) `
                    -DashboardName $DashboardName

                Write-SchedulerLog "Automatic Capture is waiting for manual CAPTCHA. Browser/session kept open."
                return
            }

            $msg = "Auto Login failed: " + $_.Exception.Message
            Write-SchedulerLog $msg

            if (-not [string]::IsNullOrWhiteSpace($DashboardName)) {
                Set-HealthRecord `
                    -Profile ([string]$profile.Name) `
                    -Dashboard $DashboardName `
                    -Status "Critical" `
                    -NoDataCount -1 `
                    -Errors 1 `
                    -Confidence "" `
                    -Message $msg `
                    -Screenshot ""
            }
            else {
                Set-ProfileDashboardsHealthFailure -Profile $profile -Message $msg
            }

            throw $msg
        }

        if ($runAi) {
            try {
                [void](Start-BuiltInAi)
                $aiReady = $true
                Write-SchedulerLog "Local AI is ready for dashboard health analysis."
            }
            catch {
                $aiReady = $false
                $aiStartupError = [string]$_.Exception.Message
                Write-SchedulerLog ("AI REQUIRED but unavailable. Screenshots will still be captured, but the run will be PARTIAL: " + $aiStartupError)
            }
        }

        $script:CsvReportPath = Join-Path $outDir "ScreenshotReport.csv"
        $index = 0

        foreach ($dashboard in $dashboards) {
            if ($script:StopRequested) { break }

            $index++
            $name = [string]$dashboard.Name
            Write-SchedulerLog ("[" + $index + "/" + $dashboards.Count + "] Capturing " + $name)

            try {
                $result = Capture-ElkDashboard `
                    -Profile $profile `
                    -Dashboard $dashboard `
                    -Browser $browser `
                    -OutputRoot $outDir `
                    -LiveCdpPort $script:ElkLivePort

                # Do not mark Success yet.
                # If Local AI is requested, Success means screenshot + AI analysis.
                # Screenshot-only with requested AI unavailable becomes Partial.

                Write-CsvReportRow `
                    -Url $result.Url `
                    -Status "Success" `
                    -ScreenshotPath $result.File `
                    -Browser (Get-BrowserName $browser) `
                    -Detail ("Automatic Capture; profile: " + [string]$profile.Name + "; dashboard: " + $name)

                # Fast Field Verification runs only after browser rendering and screenshot
                # are complete, so it does not slow Kibana render/scroll/capture.
                $fieldVerify = Invoke-ElasticsearchFieldVerification -Profile $profile -Dashboard $dashboard
                Write-SchedulerLog ("  Field Verify: " + (Convert-FieldResultsToSummary -Verification $fieldVerify))

                if ($runAi -and $aiReady) {
                    try {
                        $health = Invoke-HealthAiAnalysis -ImagePath $result.File
                        $combined = Merge-VisualAndFieldHealth -VisualHealth $health -Verification $fieldVerify

                        Set-HealthRecord `
                            -Profile ([string]$profile.Name) `
                            -Dashboard $name `
                            -Status ([string]$combined.Status) `
                            -NoDataCount ([int]$combined.NoDataCount) `
                            -NoDataPanels @($combined.NoDataPanels) `
                            -Errors ([int]$combined.Errors) `
                            -Confidence ([string]$combined.Confidence) `
                            -Message ([string]$combined.Message) `
                            -Screenshot ([string]$result.File) `
                            -FieldState ([string]$combined.FieldState) `
                            -FieldResults @($combined.FieldResults) `
                            -FieldSummary ([string]$combined.FieldSummary) `
                            -Correlation ([string]$combined.Correlation) `
                            -CorrelationMessage ([string]$combined.CorrelationMessage) `
                            -VerificationIndex ([string]$combined.VerificationIndex) `
                            -VerificationWindow ([int]$combined.VerificationWindow)

                        $success++
                        Write-SchedulerLog ("  RESULT: SUCCESS | Health: " + [string]$combined.Status + " | No Data: " + (Convert-HealthCountText -Value $combined.NoDataCount) + " | Correlation: " + [string]$combined.Correlation)
                    }
                    catch {
                        $combined = Merge-VisualAndFieldHealth -VisualHealth $null -Verification $fieldVerify
                        $fallbackStatus = [string]$combined.Status
                        if ($fallbackStatus -eq "Healthy") { $fallbackStatus = "Unknown" }

                        Set-HealthRecord `
                            -Profile ([string]$profile.Name) `
                            -Dashboard $name `
                            -Status $fallbackStatus `
                            -NoDataCount -1 `
                            -Errors 0 `
                            -Confidence "" `
                            -Message ("Capture successful. AI health analysis failed: " + $_.Exception.Message) `
                            -Screenshot ([string]$result.File) `
                            -FieldState ([string]$combined.FieldState) `
                            -FieldResults @($combined.FieldResults) `
                            -FieldSummary ([string]$combined.FieldSummary) `
                            -Correlation ([string]$combined.Correlation) `
                            -CorrelationMessage ([string]$combined.CorrelationMessage) `
                            -VerificationIndex ([string]$combined.VerificationIndex) `
                            -VerificationWindow ([int]$combined.VerificationWindow)

                        $partial++
                        Write-SchedulerLog ("  RESULT: PARTIAL | Screenshot saved, but AI analysis failed: " + $_.Exception.Message)
                    }
                }
                elseif ($runAi -and -not $aiReady) {
                    $combined = Merge-VisualAndFieldHealth -VisualHealth $null -Verification $fieldVerify

                    Set-HealthRecord `
                        -Profile ([string]$profile.Name) `
                        -Dashboard $name `
                        -Status "Unknown" `
                        -NoDataCount -1 `
                        -Errors 0 `
                        -Confidence "AI unavailable" `
                        -Message ("Screenshot captured, but required Local AI analysis did not run. " + $aiStartupError) `
                        -Screenshot ([string]$result.File) `
                        -FieldState ([string]$combined.FieldState) `
                        -FieldResults @($combined.FieldResults) `
                        -FieldSummary ([string]$combined.FieldSummary) `
                        -Correlation "AI NOT AVAILABLE" `
                        -CorrelationMessage "Automatic Capture requested Local AI, so this dashboard is PARTIAL, not SUCCESS." `
                        -VerificationIndex ([string]$combined.VerificationIndex) `
                        -VerificationWindow ([int]$combined.VerificationWindow)

                    $partial++
                    Write-SchedulerLog ("  RESULT: PARTIAL | Screenshot saved, but required Local AI is unavailable.")
                }
                else {
                    # Local AI was intentionally disabled by the user.
                    # In this mode a completed screenshot is a valid Success.
                    $combined = Merge-VisualAndFieldHealth -VisualHealth $null -Verification $fieldVerify

                    Set-HealthRecord `
                        -Profile ([string]$profile.Name) `
                        -Dashboard $name `
                        -Status ([string]$combined.Status) `
                        -NoDataCount -1 `
                        -Errors 0 `
                        -Confidence "Capture only" `
                        -Message "Capture successful. Local AI was intentionally disabled for this run." `
                        -Screenshot ([string]$result.File) `
                        -FieldState ([string]$combined.FieldState) `
                        -FieldResults @($combined.FieldResults) `
                        -FieldSummary ([string]$combined.FieldSummary) `
                        -Correlation ([string]$combined.Correlation) `
                        -CorrelationMessage ([string]$combined.CorrelationMessage) `
                        -VerificationIndex ([string]$combined.VerificationIndex) `
                        -VerificationWindow ([int]$combined.VerificationWindow)

                    $success++
                    Write-SchedulerLog "  RESULT: SUCCESS | Capture-only mode was intentionally selected."
                }
            }
            catch {
                $failed++
                $detail = $_.Exception.Message

                Set-HealthRecord `
                    -Profile ([string]$profile.Name) `
                    -Dashboard $name `
                    -Status "Critical" `
                    -NoDataCount -1 `
                    -Errors 1 `
                    -Confidence "" `
                    -Message ("Capture failed: " + $detail) `
                    -Screenshot ""

                Write-SchedulerLog ("  ERROR: " + $detail)
            }

            [System.Windows.Forms.Application]::DoEvents()
        }
    }
    catch {
        $cycleError = [string]$_.Exception.Message

        # If authentication/preflight failed before the dashboard loop,
        # all configured dashboards were skipped. Report that accurately.
        if ($success -eq 0 -and $partial -eq 0 -and $failed -eq 0) {
            $failed = $dashboards.Count
        }

        Write-SchedulerLog ("Automatic cycle stopped: " + $cycleError)
    }
    finally {
        $script:SchedulerBusy = $false
        $script:CaptureBusy = $false

        if ($captchaPaused -or (Test-ElkSchedulerCaptchaPending)) {
            $script:SchedulerNextRun = $null
            $script:SchedulerLastSummary = "PAUSED - CAPTCHA manual action required"

            Update-SchedulerStateUi
            try { Update-HeaderStatus } catch {}

            Write-SchedulerLog "Cycle PAUSED. No failure was recorded because CAPTCHA manual action is pending."
        }
        else {
            $script:SchedulerLastRun = Get-Date

            if ($chkSchedulerEnabled.Checked) {
                $script:SchedulerNextRun = (Get-Date).AddMinutes([int]$numSchedulerInterval.Value)
            }
            else {
                $script:SchedulerNextRun = $null
            }

            $script:SchedulerLastSuccess = $success
            $script:SchedulerLastPartial = $partial
            $script:SchedulerLastFailed = $failed
            $script:SchedulerLastSummary = "Success: $success | Partial: $partial | Failed: $failed"

            Save-AutomaticCaptureSettings `
                -Enabled ([bool]$chkSchedulerEnabled.Checked) `
                -ProfileName ([string]$cmbSchedulerProfile.SelectedItem) `
                -IntervalMinutes ([int]$numSchedulerInterval.Value) `
                -RunAi ([bool]$chkSchedulerAi.Checked) `
                -LastRun $script:SchedulerLastRun.ToString("o") `
                -LastSuccess ([int]$script:SchedulerLastSuccess) `
                -LastPartial ([int]$script:SchedulerLastPartial) `
                -LastFailed ([int]$script:SchedulerLastFailed)

            Refresh-Gallery
            Refresh-AnalyzeAlbums
            Refresh-HealthCenter
            Update-SchedulerStateUi

            Write-SchedulerLog ("Cycle finished. Success=" + $success + "; Partial=" + $partial + "; Failed=" + $failed)

            if ($Interactive) {
                $popupText = $(if (-not [string]::IsNullOrWhiteSpace($DashboardName)) {
                    "Dashboard recheck finished.`r`n`r`nDashboard: $DashboardName`r`nSuccess: $success`r`nPartial: $partial`r`nFailed: $failed"
                } else {
                    "Automatic Capture cycle finished.`r`n`r`nSuccess: $success`r`nPartial: $partial`r`nFailed: $failed"
                })

                if ($runAi -and -not $aiReady) {
                    $popupText += "`r`n`r`nLocal AI was requested but was not available."
                }

                if (-not [string]::IsNullOrWhiteSpace($cycleError)) {
                    $popupText += "`r`n`r`nReason:`r`n" + $cycleError
                }

                $popupText += "`r`n`r`nHealth Center has been updated."

                [System.Windows.Forms.MessageBox]::Show(
                    $form,
                    $popupText,
                    "RAQEB Sentinel Pro",
                    [System.Windows.Forms.MessageBoxButtons]::OK,
                    $(if ($partial -gt 0 -or $failed -gt 0 -or -not [string]::IsNullOrWhiteSpace($cycleError)) { [System.Windows.Forms.MessageBoxIcon]::Warning } else { [System.Windows.Forms.MessageBoxIcon]::Information })
                ) | Out-Null
            }
        }
    }
}

function Invoke-SchedulerTick {
    if (-not (Test-AghrabCommercialFeatureAccess -Feature "AutomaticCapture")) {
        $script:SchedulerNextRun = $null
        return
    }

    if ($null -eq $chkSchedulerEnabled -or -not $chkSchedulerEnabled.Checked) {
        return
    }

    if (Test-ElkSchedulerCaptchaPending) {
        $script:SchedulerNextRun = $null
        return
    }

    if ($script:SchedulerBusy -or $script:CaptureBusy) {
        return
    }

    if ($null -eq $script:SchedulerNextRun) {
        $script:SchedulerNextRun = (Get-Date).AddMinutes([int]$numSchedulerInterval.Value)
        Update-SchedulerStateUi
        return
    }

    if ((Get-Date) -ge $script:SchedulerNextRun) {
        Invoke-AutomaticCaptureCycle
    }
}

function Get-AghrabPalette {
    param([string]$Theme)

    if ($Theme -eq "Dark") {
        return [PSCustomObject]@{
            Background     = [System.Drawing.Color]::FromArgb(7,10,14)
            Header         = [System.Drawing.Color]::FromArgb(10,15,21)
            Sidebar        = [System.Drawing.Color]::FromArgb(13,19,26)
            Surface        = [System.Drawing.Color]::FromArgb(18,25,33)
            Surface2       = [System.Drawing.Color]::FromArgb(23,32,42)
            Input          = [System.Drawing.Color]::FromArgb(12,18,24)
            Border         = [System.Drawing.Color]::FromArgb(52,65,78)
            BorderSoft     = [System.Drawing.Color]::FromArgb(34,45,56)
            Text           = [System.Drawing.Color]::FromArgb(235,238,242)
            Muted          = [System.Drawing.Color]::FromArgb(151,163,175)
            Accent         = [System.Drawing.Color]::FromArgb(0,191,179)
            AccentHover    = [System.Drawing.Color]::FromArgb(15,207,194)
            AccentPressed  = [System.Drawing.Color]::FromArgb(0,158,148)
            Secondary      = [System.Drawing.Color]::FromArgb(24,34,45)
            SecondaryHover = [System.Drawing.Color]::FromArgb(31,44,57)
            SecondaryPress = [System.Drawing.Color]::FromArgb(17,27,36)
            Success        = [System.Drawing.Color]::FromArgb(84,179,84)
            Warning        = [System.Drawing.Color]::FromArgb(249,166,2)
            Danger         = [System.Drawing.Color]::FromArgb(189,39,30)
            DangerHover    = [System.Drawing.Color]::FromArgb(216,55,45)
            Selection      = [System.Drawing.Color]::FromArgb(18,74,78)
        }
    }

    return [PSCustomObject]@{
        Background     = [System.Drawing.Color]::FromArgb(246,249,252)
        Header         = [System.Drawing.Color]::White
        Sidebar        = [System.Drawing.Color]::White
        Surface        = [System.Drawing.Color]::White
        Surface2       = [System.Drawing.Color]::FromArgb(243,247,250)
        Input          = [System.Drawing.Color]::White
        Border         = [System.Drawing.Color]::FromArgb(214,223,231)
        BorderSoft     = [System.Drawing.Color]::FromArgb(229,235,240)
        Text           = [System.Drawing.Color]::FromArgb(20,35,55)
        Muted          = [System.Drawing.Color]::FromArgb(100,112,124)
        Accent         = [System.Drawing.Color]::FromArgb(0,145,137)
        AccentHover    = [System.Drawing.Color]::FromArgb(0,166,156)
        AccentPressed  = [System.Drawing.Color]::FromArgb(0,120,113)
        Secondary      = [System.Drawing.Color]::White
        SecondaryHover = [System.Drawing.Color]::FromArgb(242,247,251)
        SecondaryPress = [System.Drawing.Color]::FromArgb(231,239,246)
        Success        = [System.Drawing.Color]::DarkGreen
        Warning        = [System.Drawing.Color]::DarkOrange
        Danger         = [System.Drawing.Color]::FromArgb(189,39,30)
        DangerHover    = [System.Drawing.Color]::FromArgb(216,55,45)
        Selection      = [System.Drawing.Color]::FromArgb(215,240,238)
    }
}



function Get-AghrabPngIcon {
    param(
        [string]$Name,
        [int]$Size = 18
    )

    try {
        $path = Join-Path (Join-Path $BaseDir "icons") ($Name + ".png")
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
            return $null
        }

        # Load through bytes so the PNG file is not locked by WinForms.
        $bytes = [System.IO.File]::ReadAllBytes($path)
        $ms = New-Object System.IO.MemoryStream(,$bytes)
        try {
            $source = [System.Drawing.Image]::FromStream($ms)
            try {
                $bmp = New-Object System.Drawing.Bitmap($Size,$Size)
                $g = [System.Drawing.Graphics]::FromImage($bmp)
                try {
                    $g.Clear([System.Drawing.Color]::Transparent)
                    $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
                    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
                    $g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
                    $g.DrawImage($source,0,0,$Size,$Size)
                }
                finally {
                    $g.Dispose()
                }
                return $bmp
            }
            finally {
                $source.Dispose()
            }
        }
        finally {
            $ms.Dispose()
        }
    }
    catch {
        return $null
    }
}

function Get-AghrabIconImage {
    param(
        [string]$Kind,
        [System.Drawing.Color]$FallbackColor,
        [int]$Size = 18
    )

    $assetName = switch ($Kind) {
        "health" { "health" }
        "profiles" { "profiles" }
        "timer" { "timer" }
        "gallery" { "gallery" }
        "ai" { "ai" }
        "shield" { "shield" }
        "settings" { "settings" }
        "bolt" { "bolt" }
        "status-total" { "status-total" }
        "status-healthy" { "status-healthy" }
        "status-warning" { "status-warning" }
        "status-critical" { "status-critical" }
        "status-unknown" { "status-unknown" }
        default { "" }
    }

    if (-not [string]::IsNullOrWhiteSpace($assetName)) {
        $png = Get-AghrabPngIcon -Name $assetName -Size $Size
        if ($null -ne $png) {
            return $png
        }
    }

    # Offline/native fallback if an asset is ever missing.
    return (New-AghrabIconBitmap -Kind $Kind -Color $FallbackColor -Size $Size)
}

function New-AghrabIconBitmap {
    param(
        [string]$Kind,
        [System.Drawing.Color]$Color,
        [int]$Size = 18
    )

    $bmp = New-Object System.Drawing.Bitmap($Size,$Size)
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    try {
        $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
        $g.Clear([System.Drawing.Color]::Transparent)

        $pen = New-Object System.Drawing.Pen($Color,1.6)
        $brush = New-Object System.Drawing.SolidBrush($Color)
        try {
            switch ($Kind) {
                "health" {
                    $g.DrawEllipse($pen,2,2,$Size-5,$Size-5)
                    $g.DrawLine($pen,5,[int]($Size/2),8,[int]($Size/2))
                    $g.DrawLine($pen,8,[int]($Size/2),10,[int]($Size/2)-4)
                    $g.DrawLine($pen,10,[int]($Size/2)-4,12,[int]($Size/2)+4)
                    $g.DrawLine($pen,12,[int]($Size/2)+4,14,[int]($Size/2))
                }
                "profiles" {
                    $g.DrawRectangle($pen,2,4,$Size-5,$Size-7)
                    $g.DrawLine($pen,5,7,$Size-5,7)
                    $g.DrawLine($pen,5,10,$Size-5,10)
                    $g.DrawLine($pen,5,13,$Size-5,13)
                }
                "timer" {
                    $g.DrawEllipse($pen,3,4,$Size-7,$Size-7)
                    $g.DrawLine($pen,[int]($Size/2),2,[int]($Size/2),5)
                    $g.DrawLine($pen,[int]($Size/2),[int]($Size/2),[int]($Size/2),6)
                    $g.DrawLine($pen,[int]($Size/2),[int]($Size/2),$Size-6,[int]($Size/2)+2)
                }
                "gallery" {
                    $g.DrawRectangle($pen,2,3,$Size-5,$Size-7)
                    $g.FillEllipse($brush,5,6,3,3)
                    $pts = @(
                        (New-Object System.Drawing.Point(4,$Size-6)),
                        (New-Object System.Drawing.Point(8,10)),
                        (New-Object System.Drawing.Point(11,13)),
                        (New-Object System.Drawing.Point(14,9))
                    )
                    $g.DrawLines($pen,$pts)
                }
                "ai" {
                    $g.DrawRectangle($pen,4,5,$Size-9,$Size-9)
                    $g.DrawLine($pen,7,2,7,5)
                    $g.DrawLine($pen,$Size-8,2,$Size-8,5)
                    $g.FillEllipse($brush,7,9,2,2)
                    $g.FillEllipse($brush,$Size-9,9,2,2)
                    $g.DrawLine($pen,7,14,$Size-8,14)
                }
                "shield" {
                    $pts = @(
                        (New-Object System.Drawing.Point([int]($Size/2),2)),
                        (New-Object System.Drawing.Point($Size-4,5)),
                        (New-Object System.Drawing.Point($Size-5,11)),
                        (New-Object System.Drawing.Point([int]($Size/2),$Size-3)),
                        (New-Object System.Drawing.Point(3,11)),
                        (New-Object System.Drawing.Point(2,5)),
                        (New-Object System.Drawing.Point([int]($Size/2),2))
                    )
                    $g.DrawLines($pen,$pts)
                }
                "settings" {
                    $cx=[int]($Size/2); $cy=[int]($Size/2)
                    $g.DrawEllipse($pen,$cx-4,$cy-4,8,8)
                    $g.FillEllipse($brush,$cx-1,$cy-1,2,2)
                    for ($i=0; $i -lt 8; $i++) {
                        $a = $i * [Math]::PI / 4.0
                        $x1 = [int]($cx + [Math]::Cos($a)*6)
                        $y1 = [int]($cy + [Math]::Sin($a)*6)
                        $x2 = [int]($cx + [Math]::Cos($a)*8)
                        $y2 = [int]($cy + [Math]::Sin($a)*8)
                        $g.DrawLine($pen,$x1,$y1,$x2,$y2)
                    }
                }
                "chart" {
                    $g.DrawRectangle($pen,2,3,$Size-5,$Size-6)
                    $g.FillRectangle($brush,5,$Size-8,2,4)
                    $g.FillRectangle($brush,9,$Size-11,2,7)
                    $g.FillRectangle($brush,13,$Size-14,2,10)
                }
                "bolt" {
                    $pts = @(
                        (New-Object System.Drawing.Point(10,2)),
                        (New-Object System.Drawing.Point(5,10)),
                        (New-Object System.Drawing.Point(9,10)),
                        (New-Object System.Drawing.Point(7,16)),
                        (New-Object System.Drawing.Point(14,7)),
                        (New-Object System.Drawing.Point(10,7)),
                        (New-Object System.Drawing.Point(10,2))
                    )
                    $g.FillPolygon($brush,$pts)
                }
                default {
                    $g.FillEllipse($brush,4,4,$Size-8,$Size-8)
                }
            }
        }
        finally {
            $pen.Dispose()
            $brush.Dispose()
        }
    }
    finally {
        $g.Dispose()
    }

    return $bmp
}

function Set-AghrabButtonIcon {
    param(
        [System.Windows.Forms.Button]$Button,
        [string]$Kind,
        [System.Drawing.Color]$Color
    )

    try {
        if ($null -ne $Button.Image) {
            $old = $Button.Image
            $Button.Image = $null
            $old.Dispose()
        }
    }
    catch {}

    $Button.Image = Get-AghrabIconImage -Kind $Kind -FallbackColor $Color -Size 24

    if ($script:CurrentLanguage -eq "Persian") {
        $Button.ImageAlign = [System.Drawing.ContentAlignment]::MiddleRight
        $Button.TextImageRelation = [System.Windows.Forms.TextImageRelation]::TextBeforeImage
        $Button.Padding = New-Object System.Windows.Forms.Padding(0,0,10,0)
    }
    else {
        $Button.ImageAlign = [System.Drawing.ContentAlignment]::MiddleLeft
        $Button.TextImageRelation = [System.Windows.Forms.TextImageRelation]::ImageBeforeText
        $Button.Padding = New-Object System.Windows.Forms.Padding(10,0,0,0)
    }
}

function Get-HealthStatusVisual {
    param(
        [string]$Status,
        [string]$Theme
    )

    $p = Get-AghrabPalette -Theme $Theme

    if ($Theme -eq "Dark") {
        switch ($Status) {
            "Healthy" {
                return [PSCustomObject]@{
                    Back = [System.Drawing.Color]::FromArgb(17,39,31)
                    Badge = [System.Drawing.Color]::FromArgb(22,52,40)
                    Border = [System.Drawing.Color]::FromArgb(50,103,77)
                    Fore = $p.Success
                }
            }
            "Warning" {
                return [PSCustomObject]@{
                    Back = [System.Drawing.Color]::FromArgb(46,36,15)
                    Badge = [System.Drawing.Color]::FromArgb(61,47,17)
                    Border = [System.Drawing.Color]::FromArgb(128,94,21)
                    Fore = $p.Warning
                }
            }
            "Critical" {
                return [PSCustomObject]@{
                    Back = [System.Drawing.Color]::FromArgb(46,23,24)
                    Badge = [System.Drawing.Color]::FromArgb(61,28,29)
                    Border = [System.Drawing.Color]::FromArgb(111,49,48)
                    Fore = $p.Danger
                }
            }
            "Unknown" {
                return [PSCustomObject]@{
                    Back = [System.Drawing.Color]::FromArgb(25,32,40)
                    Badge = [System.Drawing.Color]::FromArgb(32,41,51)
                    Border = [System.Drawing.Color]::FromArgb(64,76,89)
                    Fore = $p.Muted
                }
            }
            default {
                return [PSCustomObject]@{
                    Back = [System.Drawing.Color]::FromArgb(15,32,39)
                    Badge = [System.Drawing.Color]::FromArgb(18,43,50)
                    Border = [System.Drawing.Color]::FromArgb(39,89,95)
                    Fore = $p.Accent
                }
            }
        }
    }

    switch ($Status) {
        "Healthy" {
            return [PSCustomObject]@{
                Back = [System.Drawing.Color]::FromArgb(238,249,243)
                Badge = [System.Drawing.Color]::FromArgb(226,244,234)
                Border = [System.Drawing.Color]::FromArgb(171,218,190)
                Fore = [System.Drawing.Color]::FromArgb(30,126,72)
            }
        }
        "Warning" {
            return [PSCustomObject]@{
                Back = [System.Drawing.Color]::FromArgb(255,249,233)
                Badge = [System.Drawing.Color]::FromArgb(255,243,211)
                Border = [System.Drawing.Color]::FromArgb(236,204,127)
                Fore = [System.Drawing.Color]::FromArgb(177,105,0)
            }
        }
        "Critical" {
            return [PSCustomObject]@{
                Back = [System.Drawing.Color]::FromArgb(254,241,241)
                Badge = [System.Drawing.Color]::FromArgb(252,228,228)
                Border = [System.Drawing.Color]::FromArgb(229,171,170)
                Fore = [System.Drawing.Color]::FromArgb(177,42,37)
            }
        }
        "Unknown" {
            return [PSCustomObject]@{
                Back = [System.Drawing.Color]::FromArgb(245,247,249)
                Badge = [System.Drawing.Color]::FromArgb(237,241,244)
                Border = [System.Drawing.Color]::FromArgb(202,211,219)
                Fore = [System.Drawing.Color]::FromArgb(94,108,121)
            }
        }
        default {
            return [PSCustomObject]@{
                Back = [System.Drawing.Color]::FromArgb(238,248,250)
                Badge = [System.Drawing.Color]::FromArgb(225,243,246)
                Border = [System.Drawing.Color]::FromArgb(164,213,219)
                Fore = $p.Accent
            }
        }
    }
}

function Set-RoundedControlRegion {
    param(
        [System.Windows.Forms.Control]$Control,
        [int]$Radius = 10
    )

    if ($null -eq $Control -or $Control.Width -lt 4 -or $Control.Height -lt 4) {
        return
    }

    $diameter = [Math]::Min($Radius * 2, [Math]::Min($Control.Width, $Control.Height))
    if ($diameter -lt 4) {
        return
    }

    $path = New-Object System.Drawing.Drawing2D.GraphicsPath
    try {
        $path.StartFigure()
        $path.AddArc(0, 0, $diameter, $diameter, 180, 90)
        $path.AddArc($Control.Width - $diameter - 1, 0, $diameter, $diameter, 270, 90)
        $path.AddArc($Control.Width - $diameter - 1, $Control.Height - $diameter - 1, $diameter, $diameter, 0, 90)
        $path.AddArc(0, $Control.Height - $diameter - 1, $diameter, $diameter, 90, 90)
        $path.CloseFigure()

        if ($null -ne $Control.Region) {
            try { $Control.Region.Dispose() } catch {}
        }

        $Control.Region = New-Object System.Drawing.Region($path)
    }
    finally {
        $path.Dispose()
    }
}

function Initialize-AghrabCard {
    param([System.Windows.Forms.Panel]$Card)

    $Card.Tag = "card"
    $Card.BorderStyle = [System.Windows.Forms.BorderStyle]::None
    Set-RoundedControlRegion -Control $Card -Radius 10

    $Card.Add_Paint({
        param($sender,$e)
        try {
            $palette = Get-AghrabPalette -Theme $script:CurrentTheme
            $pen = New-Object System.Drawing.Pen($palette.BorderSoft,1)
            try {
                $e.Graphics.DrawRectangle(
                    $pen,
                    0,0,
                    [Math]::Max(0,$sender.ClientSize.Width-1),
                    [Math]::Max(0,$sender.ClientSize.Height-1)
                )
            }
            finally {
                $pen.Dispose()
            }
        }
        catch {}
    })
}

function Test-IsDangerButton {
    param([System.Windows.Forms.Button]$Button)

    $t = ([string]$Button.Text).Trim().ToLowerInvariant()

    return (
        $t -eq "stop" -or
        $t -match '^delete' -or
        $t -match '^remove'
    )
}

function Test-IsPrimaryButton {
    param([System.Windows.Forms.Button]$Button)

    # Existing primary buttons already use the product blue.
    $blueArgb = [System.Drawing.Color]::FromArgb(0,142,224).ToArgb()

    if ($Button.BackColor.ToArgb() -eq $blueArgb) {
        return $true
    }

    $t = ([string]$Button.Text).Trim().ToLowerInvariant()
    return (
        $t -match '^ai analyze' -or
        $t -match '^ai compare' -or
        $t -eq 'capture all dashboards' -or
        $t -eq 'apply'
    )
}

function Set-AghrabButtonTheme {
    param(
        [System.Windows.Forms.Button]$Button,
        $Palette,
        [string]$Theme
    )

    $Button.UseVisualStyleBackColor = $false
    $Button.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $Button.FlatAppearance.BorderSize = 1
    $Button.Cursor = [System.Windows.Forms.Cursors]::Hand
    Set-RoundedControlRegion -Control $Button -Radius 7

    if (Test-IsDangerButton -Button $Button) {
        $Button.BackColor = $Palette.Danger
        $Button.ForeColor = [System.Drawing.Color]::White
        $Button.FlatAppearance.BorderColor = $Palette.Danger
        $Button.FlatAppearance.MouseOverBackColor = $Palette.DangerHover
        $Button.FlatAppearance.MouseDownBackColor = $Palette.Danger
        return
    }

    if (Test-IsPrimaryButton -Button $Button) {
        $Button.BackColor = $Palette.Accent
        $Button.ForeColor = [System.Drawing.Color]::White
        $Button.FlatAppearance.BorderColor = $Palette.Accent
        $Button.FlatAppearance.MouseOverBackColor = $Palette.AccentHover
        $Button.FlatAppearance.MouseDownBackColor = $Palette.AccentPressed
        return
    }

    $Button.BackColor = $Palette.Secondary
    $Button.ForeColor = $Palette.Text
    $Button.FlatAppearance.BorderColor = $Palette.Border
    $Button.FlatAppearance.MouseOverBackColor = $Palette.SecondaryHover
    $Button.FlatAppearance.MouseDownBackColor = $Palette.SecondaryPress
}

function Set-ControlThemeRecursive {
    param(
        [System.Windows.Forms.Control]$Control,
        [string]$Theme,
        $Palette = $null
    )

    if ($null -eq $Control) {
        return
    }

    if ($null -eq $Palette) {
        $Palette = Get-AghrabPalette -Theme $Theme
    }

    if ($Control -is [System.Windows.Forms.Form]) {
        $Control.BackColor = $Palette.Background
        $Control.ForeColor = $Palette.Text
    }
    elseif ($Control -is [System.Windows.Forms.TabPage]) {
        $Control.BackColor = $Palette.Background
        $Control.ForeColor = $Palette.Text
    }
    elseif ($Control -is [System.Windows.Forms.GroupBox]) {
        $Control.BackColor = $Palette.Surface
        $Control.ForeColor = $(if ($Theme -eq "Dark") { $Palette.Accent } else { $Palette.Text })
    }
    elseif ($Control -is [System.Windows.Forms.Panel]) {
        if ([string]$Control.Tag -eq "sidebar") {
            $Control.BackColor = $Palette.Sidebar
        }
        elseif ([string]$Control.Tag -eq "card") {
            $Control.BackColor = $Palette.Surface
        }
        else {
            $Control.BackColor = $Palette.Surface
        }
        $Control.ForeColor = $Palette.Text
    }
    elseif ($Control.GetType().Name -eq "AghrabProgressBar") {
        $Control.BackColor = $Palette.Surface2
        $Control.ForeColor = $Palette.Accent
        try { $Control.BorderColor = $Palette.Border } catch {}
    }
    elseif ($Control -is [System.Windows.Forms.Button]) {
        Set-AghrabButtonTheme -Button $Control -Palette $Palette -Theme $Theme
    }
    elseif (
        $Control -is [System.Windows.Forms.TextBox] -or
        $Control -is [System.Windows.Forms.ComboBox] -or
        $Control -is [System.Windows.Forms.NumericUpDown] -or
        $Control -is [System.Windows.Forms.ListBox]
    ) {
        $Control.BackColor = $Palette.Input
        $Control.ForeColor = $Palette.Text
    }
    elseif ($Control -is [System.Windows.Forms.ListView]) {
        $Control.BackColor = $Palette.Input
        $Control.ForeColor = $Palette.Text
    }
    elseif ($Control -is [System.Windows.Forms.PictureBox]) {
        $Control.BackColor = $(if ($Theme -eq "Dark") {
            [System.Drawing.Color]::FromArgb(8,12,17)
        } else {
            [System.Drawing.Color]::White
        })
    }
    elseif ($Control -is [System.Windows.Forms.CheckBox]) {
        $Control.ForeColor = $Palette.Text
        $Control.BackColor = [System.Drawing.Color]::Transparent
    }
    elseif ($Control -is [System.Windows.Forms.RadioButton]) {
        $Control.ForeColor = $Palette.Text
        $Control.BackColor = [System.Drawing.Color]::Transparent
    }
    elseif ($Control -is [System.Windows.Forms.Label]) {
        if ([string]$Control.Tag -eq "muted") {
            $Control.ForeColor = $Palette.Muted
            $Control.BackColor = [System.Drawing.Color]::Transparent
            return
        }

        $current = $Control.ForeColor
        $semantic = (
            $current.ToArgb() -eq [System.Drawing.Color]::DarkGreen.ToArgb() -or
            $current.ToArgb() -eq [System.Drawing.Color]::DarkRed.ToArgb() -or
            $current.ToArgb() -eq [System.Drawing.Color]::DarkOrange.ToArgb() -or
            $current.ToArgb() -eq $Palette.Success.ToArgb() -or
            $current.ToArgb() -eq $Palette.Warning.ToArgb() -or
            $current.ToArgb() -eq $Palette.Danger.ToArgb()
        )

        if ([string]$Control.Tag -eq "section") {
            $Control.ForeColor = $(if ($Theme -eq "Dark") { $Palette.Accent } else { $Palette.Text })
        }
        elseif (-not $semantic) {
            $Control.ForeColor = $Palette.Text
        }

        $Control.BackColor = [System.Drawing.Color]::Transparent
    }

    foreach ($child in $Control.Controls) {
        Set-ControlThemeRecursive -Control $child -Theme $Theme -Palette $Palette
    }
}

function Apply-AghrabTheme {
    param(
        [string]$Theme
    )

    if ($Theme -ne "Dark") {
        $Theme = "Light"
    }

    $script:CurrentTheme = $Theme
    $palette = Get-AghrabPalette -Theme $Theme

    Set-ControlThemeRecursive -Control $form -Theme $Theme -Palette $palette

    # Header / branding
    $form.BackColor = $palette.Background
    $header.BackColor = $palette.Header
    $tabs.BackColor = $palette.Background
    $tabs.ForeColor = $palette.Text

    if ($null -ne $sideNav) {
        $sideNav.BackColor = $palette.Sidebar
        Update-SidebarNavigation
    }

    if ($null -ne $lblDashboardIndexPlaceholder) {
        $lblDashboardIndexPlaceholder.BackColor = $palette.Input
        $lblDashboardIndexPlaceholder.ForeColor = $palette.Muted
    }
    if ($null -ne $lblExpectedFieldsPlaceholder) {
        $lblExpectedFieldsPlaceholder.BackColor = $palette.Input
        $lblExpectedFieldsPlaceholder.ForeColor = $palette.Muted
    }

    foreach ($card in @(
        $cardProfiles,$cardConnection,$cardAuth,$cardCapture,$cardDashboards,
        $cardAiReport,$panelNoDataInspector,
        $cardSecurityStatus,$cardSecurityActions,$cardSecurityAudit,
        $cardHealthManager,$cardHealthDetail,
        $cardSchedulerMain,$cardSchedulerLast,$cardSchedulerNext,
        $cardSchedulerSuccess,$cardSchedulerPartial,$cardSchedulerFailed,$cardSchedulerAi,
        $cardSchedulerOutput,$cardSchedulerLog,
        $cardGalleryRoot,$cardGalleryAlbums,$cardGalleryMedia
    )) {
        if ($null -ne $card) {
            $card.BackColor = $palette.Surface
            $card.ForeColor = $palette.Text
            Set-RoundedControlRegion -Control $card -Radius 10
        }
    }

    $brandLabel.ForeColor = $(if ($Theme -eq "Dark") {
        [System.Drawing.Color]::White
    } else {
        $Navy
    })
    if ($null -ne $brandEdition) {
        $brandEdition.ForeColor = $palette.Accent
    }
    $brandSubLabel.ForeColor = $palette.Muted

    if ($null -ne $panelHeaderLicense) {
        $panelHeaderLicense.BackColor = [System.Drawing.Color]::Transparent
    }
    if ($null -ne $verLabel) {
        $verLabel.ForeColor = $palette.Muted
    }

    foreach ($headerCard in @($panelHeaderAi,$panelHeaderAutomation,$panelHeaderHealth)) {
        if ($null -ne $headerCard) {
            $headerCard.BackColor = $palette.Surface2
            Set-RoundedControlRegion -Control $headerCard -Radius 9
        }
    }
    if ($null -ne $headerDivider) { $headerDivider.BackColor = $palette.BorderSoft }
    try { Update-HeaderStatus } catch {}

    if ($null -ne $lblAnalyzePageTitle) { $lblAnalyzePageTitle.ForeColor = $palette.Text }
    if ($null -ne $lblAnalyzePageSubtitle) { $lblAnalyzePageSubtitle.ForeColor = $palette.Muted }
    if ($null -ne $lblAnalyzeAiActions) { $lblAnalyzeAiActions.ForeColor = $palette.Muted }

    foreach ($analysisCard in @(
        $cardAnalyzeControls,$grpAi,$grpAnalyzeBefore,$grpAnalyzeAfter,
        $cardAnalyzeKpis,$cardAiReport
    )) {
        if ($null -ne $analysisCard) {
            $analysisCard.BackColor = $palette.Surface
            Set-RoundedControlRegion -Control $analysisCard -Radius 10
        }
    }

    if ($null -ne $lblBeforeBadge) {
        $lblBeforeBadge.BackColor = $palette.Surface2
        $lblBeforeBadge.ForeColor = $palette.Muted
        Set-RoundedControlRegion -Control $lblBeforeBadge -Radius 10
    }
    if ($null -ne $lblAfterBadge) {
        $lblAfterBadge.BackColor = $palette.Selection
        $lblAfterBadge.ForeColor = $palette.Accent
        Set-RoundedControlRegion -Control $lblAfterBadge -Radius 10
    }
    if ($null -ne $panelNoDataInspector) {
        $panelNoDataInspector.BackColor = $palette.Surface2
        Set-RoundedControlRegion -Control $panelNoDataInspector -Radius 9
    }
    if ($null -ne $txtAiResult) {
        $txtAiResult.BackColor = $(if ($Theme -eq "Dark") { [System.Drawing.Color]::FromArgb(9,15,21) } else { [System.Drawing.Color]::White })
        $txtAiResult.ForeColor = $palette.Text
    }
    if ($null -ne $lstNoDataPanels) {
        $lstNoDataPanels.BackColor = $palette.Input
        $lstNoDataPanels.ForeColor = $palette.Text
    }

    try { Update-AnalyzeAiVisual } catch {}
    try { Set-AiSocHeader } catch {}

    if ($null -ne $lblGalleryTitle) { $lblGalleryTitle.ForeColor = $palette.Text }
    if ($null -ne $lblGallerySubtitle) { $lblGallerySubtitle.ForeColor = $palette.Muted }
    if ($null -ne $lblGallerySelectedAlbum) { $lblGallerySelectedAlbum.ForeColor = $palette.Text }
    if ($null -ne $lblGalleryImageCount) { $lblGalleryImageCount.ForeColor = $palette.Muted }
    if ($null -ne $lblPreviewBadge) {
        $lblPreviewBadge.BackColor = $palette.Selection
        $lblPreviewBadge.ForeColor = $palette.Accent
        Set-RoundedControlRegion -Control $lblPreviewBadge -Radius 10
    }
    if ($null -ne $panelGalleryPreview) {
        $panelGalleryPreview.BackColor = $palette.Surface2
        Set-RoundedControlRegion -Control $panelGalleryPreview -Radius 10
    }
    if ($null -ne $lblShotsHint) { $lblShotsHint.ForeColor = $palette.Muted }
    if ($null -ne $galleryToolbarLine) { $galleryToolbarLine.BackColor = $palette.BorderSoft }
    $verLabel.ForeColor = $palette.Muted

    # Make AI output feel like a console/report surface, not a plain textbox.
    if ($null -ne $txtAiResult) {
        $txtAiResult.BackColor = $(if ($Theme -eq "Dark") {
            [System.Drawing.Color]::FromArgb(9,15,21)
        } else {
            [System.Drawing.Color]::White
        })
        $txtAiResult.ForeColor = $palette.Text
        $txtAiResult.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
    }

    if ($null -ne $txtSecurityAudit) {
        $txtSecurityAudit.BackColor = $(if ($Theme -eq "Dark") {
            [System.Drawing.Color]::FromArgb(9,15,21)
        } else {
            [System.Drawing.Color]::White
        })
        $txtSecurityAudit.ForeColor = $palette.Text
        $txtSecurityAudit.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
    }

    # Gallery / Analyze previews
    foreach ($preview in @($picGalleryPreview, $picAnalyzeBefore, $picAnalyzeAfter)) {
        if ($null -ne $preview) {
            $preview.BackColor = $(if ($Theme -eq "Dark") {
                [System.Drawing.Color]::FromArgb(7,11,16)
            } else {
                [System.Drawing.Color]::White
            })
        }
    }

    # Semantic status colors adapted for dark backgrounds.
    if ($Theme -eq "Dark") {
        if ($null -ne $lblAiStatus -and $lblAiStatus.Text -match "Ready") {
            $lblAiStatus.ForeColor = $palette.Success
        }
        if ($null -ne $lblElkSessionStatus -and $lblElkSessionStatus.Text -match "connected|SUCCESS") {
            $lblElkSessionStatus.ForeColor = $palette.Success
        }
    }

    foreach ($lv in @($lvElkDashboards, $lstGalleryAlbums, $lstGalleryImages, $lstAnalyzeAlbums)) {
        if ($null -ne $lv) {
            try {
                $lv.BackColor = $(if ($Theme -eq "Dark") { $palette.Input } else { [System.Drawing.Color]::White })
                $lv.ForeColor = $palette.Text
            } catch {}
        }
    }

    if ($null -ne $lvImages) {
        try {
            $lvImages.BackColor = $palette.Input
            $lvImages.ForeColor = $palette.Text
        } catch {}
    }

    if ($null -ne $lstAlbums) {
        try {
            $lstAlbums.BackColor = $palette.Input
            $lstAlbums.ForeColor = $palette.Text
        } catch {}
    }

    if ($null -ne $cmbThemeMode) {
        if ($cmbThemeMode.Items.Contains($Theme)) {
            $cmbThemeMode.SelectedItem = $Theme
        }
    }

    if ($null -ne $lvHealth) {
        try { Refresh-HealthCenter } catch {}
    }
    if ($null -ne $lblHealthShowing) {
        try {
            $lblHealthShowing.BackColor = $palette.Surface2
            $lblHealthShowing.ForeColor = $palette.Muted
            Set-RoundedControlRegion -Control $lblHealthShowing -Radius 10
        } catch {}
    }
    if ($null -ne $healthManagerSeparator) {
        try { $healthManagerSeparator.BackColor = $palette.BorderSoft } catch {}
    }

    if ($null -ne $panelHealthSearch) {
        try {
            $panelHealthSearch.BackColor = $palette.Input
            $txtHealthSearch.BackColor = $palette.Input
            $txtHealthSearch.ForeColor = $palette.Text
            $lblHealthSearchPlaceholder.ForeColor = $palette.Muted
            $btnHealthSearchClear.BackColor = $palette.Input
            $btnHealthSearchClear.ForeColor = $palette.Muted
            $panelHealthSearch.Invalidate()
        }
        catch {}
    }

    if ($null -ne $lblSchedulerLastValue) {
        try { Update-SchedulerStateUi } catch {}
    }

    $tabs.Invalidate()
    $form.Refresh()
}


# ---------------- LANGUAGE / RTL ----------------
$script:CurrentLanguage = "English"
$script:CurrentPersianFont = "Tahoma"
$script:LanguageApplyInProgress = $false
$script:AghrabOriginalFonts = @{}
$script:AghrabLayoutBase = @{}
$script:AghrabFormLanguageState = @{}
$script:AghrabFaTextMap = @{
    "RAQEB Import / Export Center" = "مرکز ورود / خروج راقب"
    "Portable Transfer Center" = "مرکز انتقال قابل‌حمل"
    "Move RAQEB ELK profiles and dashboards safely between systems." = "پروفایل‌ها و داشبوردهای ELK را به‌صورت امن بین سیستم‌های راقب منتقل کنید."
    "PORTABLE & SAFE" = "قابل‌حمل و امن"
    "PROFILE TRANSFER" = "انتقال پروفایل"
    "Profile:" = "پروفایل:"
    "Export Profile" = "خروجی پروفایل"
    "Export All Profiles" = "خروجی همه پروفایل‌ها"
    "Import Profile(s)" = "ورود پروفایل(ها)"
    "DASHBOARD TRANSFER" = "انتقال داشبورد"
    "Source Profile:" = "پروفایل مبدا:"
    "Dashboards:" = "داشبوردها:"
    "Select All" = "انتخاب همه"
    "Clear" = "پاک کردن انتخاب‌ها"
    "Export Selected Dashboards" = "خروجی داشبوردهای انتخاب‌شده"
    "Export All Dashboards" = "خروجی همه داشبوردها"
    "Destination Profile:" = "پروفایل مقصد:"
    "Import Dashboard(s)" = "ورود داشبورد(ها)"
    "Ready" = "آماده"
    "Close" = "بستن"
    "Health Center" = "مرکز سلامت"
    "ELK Profiles" = "پروفایل‌های ELK"
    "Automatic Capture" = "تصویربرداری خودکار"
    "Gallery" = "گالری"
    "Analyze" = "تحلیل"
    "Security" = "امنیت"
    "Settings" = "تنظیمات"
    "Capture" = "تصویربرداری"
    "WORKSPACE  •  SOC" = "فضای کاری  •  SOC"
    "RAQEB SENTINEL PRO`r`nVisual SOC Intelligence" = "RAQEB SENTINEL PRO`r`nهوشمندی بصری SOC"
    "Autonomous Visual SOC Monitoring  |  Local AI Operations" = "پایش بصری خودکار SOC  |  عملیات هوش مصنوعی محلی"
    "UNLICENSED" = "بدون لایسنس"
    "LICENSED" = "دارای لایسنس"
    "TRIAL" = "آزمایشی"
    "TRIAL EXPIRED" = "آزمایشی منقضی شده"
    "TRIAL INVALID" = "آزمایشی نامعتبر"
    "EXPIRED" = "منقضی شده"
    "INVALID" = "نامعتبر"
    "MACHINE MISMATCH" = "عدم تطابق سیستم"
    "No active license" = "لایسنس فعالی وجود ندارد"
    "STOPPED" = "متوقف"
    "NOT INSTALLED" = "نصب نیست"
    "OFF" = "خاموش"
    "RUNNING" = "در حال اجرا"
    "ON" = "روشن"
    "CRITICAL" = "بحرانی"
    "WARNING" = "هشدار"
    "UNKNOWN" = "نامشخص"
    "HEALTHY" = "سالم"
    "Activate to unlock" = "برای فعال‌سازی لایسنس وارد کنید"
    "Activation required" = "نیاز به فعال‌سازی"
    "License expired" = "لایسنس منقضی شده"
    "Invalid license" = "لایسنس نامعتبر"
    "Browser:" = "مرورگر:"
    "Auto Detect" = "تشخیص خودکار"
    "Browse..." = "انتخاب..."
    "URL / IP list (one per line):" = "فهرست URL / IP (هر مورد یک خط):"
    "Import TXT" = "ورود TXT"
    "Output folder:" = "پوشه خروجی:"
    "Browse" = "انتخاب"
    "Timeout:" = "مهلت انتظار:"
    "sec" = "ثانیه"
    "Wait after load:" = "انتظار بعد از بارگذاری:"
    "Width:" = "عرض:"
    "Height:" = "ارتفاع:"
    "Ignore HTTPS certificate errors" = "نادیده گرفتن خطاهای گواهی HTTPS"
    "Scroll delay:" = "تاخیر اسکرول:"
    "ms" = "میلی‌ثانیه"
    "Full Page (auto-scroll)" = "صفحه کامل (اسکرول خودکار)"
    "Final settle:" = "انتظار نهایی:"
    "START SCREENSHOT" = "شروع تصویربرداری"
    "STOP" = "توقف"
    "Open Output" = "باز کردن خروجی"
    "Profiles" = "پروفایل‌ها"
    "New Profile" = "پروفایل جدید"
    "Delete Profile" = "حذف پروفایل"
    "Authentication" = "احراز هویت"
    "Auto Login before Capture" = "ورود خودکار قبل از تصویربرداری"
    "Username:" = "نام کاربری:"
    "Password:" = "رمز عبور:"
    "Test Auto Login" = "تست ورود"
    "Continue CAPTCHA" = "ادامه CAPTCHA"
    "Profile name:" = "نام پروفایل:"
    "Kibana URL:" = "آدرس Kibana:"
    "Save Profile" = "ذخیره پروفایل"
    "Login Browser" = "مرورگر ورود"
    "Session: not connected" = "نشست: متصل نیست"
    "Capture All Dashboards" = "تصویربرداری داشبوردها"
    "Load wait:" = "انتظار بارگذاری:"
    "Scroll:" = "اسکرول:"
    "Name:" = "نام:"
    "Time Range:" = "بازه زمانی:"
    "URL:" = "آدرس:"
    "ES Index:" = "ایندکس ES:"
    "Expected Fields:" = "فیلدهای مورد انتظار:"
    "Add / Update" = "افزودن / به‌روزرسانی"
    "Delete Dashboard" = "حذف داشبورد"
    "Import / Export" = "ورود / خروج"
    "Portable transfer for profiles and dashboards" = "انتقال قابل‌حمل پروفایل‌ها و داشبوردها"
    "Field Verification" = "بررسی فیلدها"
    "Suggest Fields" = "پیشنهاد فیلدها"
    "Field Help" = "راهنمای فیلدها"
    "Health Summary Report" = "گزارش خلاصه سلامت"
    "Export HTML" = "خروجی HTML"
    "Export TXT" = "خروجی TXT"
    "Export CSV" = "خروجی CSV"
    "Copy Summary" = "کپی خلاصه"
    "Operations Health Center" = "مرکز سلامت عملیات"
    "Live operational view of every configured Kibana dashboard" = "نمای زنده عملیاتی از تمام داشبوردهای پیکربندی‌شده Kibana"
    "Health Summary" = "خلاصه سلامت"
    "Dashboard Manager" = "مدیریت داشبوردها"
    "FILTERS" = "فیلترها"
    "Search dashboards..." = "جستجوی داشبورد..."
    "Sync / Refresh" = "همگام‌سازی / بروزرسانی"
    "Add / Manage" = "افزودن / مدیریت"
    "History CSV" = "تاریخچه CSV"
    "Panel Health / No Data" = "سلامت پنل / بدون داده"
    "Diagnosis / Correlation" = "تشخیص / همبستگی"
    "Select a dashboard" = "یک داشبورد انتخاب کنید"
    "No Data panels will appear here." = "پنل‌های بدون داده در اینجا نمایش داده می‌شوند."
    "Details" = "جزئیات"
    "History" = "تاریخچه"
    "Recheck" = "بررسی مجدد"
    "Open Screenshot" = "باز کردن تصویر"
    "Open Full CSV" = "باز کردن CSV کامل"
    "No dashboards to show" = "داشبوردی برای نمایش وجود ندارد"
    "Add dashboards in ELK Profiles or change the current filters." = "در پروفایل‌های ELK داشبورد اضافه کنید یا فیلترها را تغییر دهید."
    "Hands-free Kibana capture and optional Local AI health analysis" = "تصویربرداری خودکار Kibana و تحلیل اختیاری سلامت با هوش مصنوعی محلی"
    "Enable Automatic Capture" = "فعال‌سازی تصویربرداری خودکار"
    "Profile" = "پروفایل"
    "Run every" = "اجرا هر"
    "Run Local AI after each capture" = "اجرای هوش مصنوعی محلی بعد از هر تصویربرداری"
    "Save Schedule" = "ذخیره زمان‌بندی"
    "Run Now" = "اجرای الآن"
    "Saved Credentials:" = "اعتبارنامه ذخیره‌شده:"
    "Output" = "خروجی"
    "Change Folder" = "تغییر پوشه"
    "Automatic Capture Activity" = "فعالیت تصویربرداری خودکار"
    "Automatic Capture is RUNNING" = "تصویربرداری خودکار در حال اجراست"
    "Automatic Capture is ON" = "تصویربرداری خودکار روشن است"
    "Automatic Capture is OFF" = "تصویربرداری خودکار خاموش است"
    "Screenshot Gallery" = "گالری تصاویر"
    "Browse dashboard captures, retention policies and visual history" = "مرور تصاویر داشبورد، سیاست نگهداری و تاریخچه بصری"
    "Albums root:" = "مسیر اصلی آلبوم‌ها:"
    "Refresh" = "بروزرسانی"
    "Open Root" = "باز کردن پوشه"
    "Albums (sites)" = "آلبوم‌ها (سایت‌ها)"
    "Open Album" = "باز کردن"
    "Delete Album" = "حذف"
    "Policy for selected album:" = "سیاست آلبوم انتخاب‌شده:"
    "Retention - Selected Album" = "نگهداری - آلبوم انتخاب‌شده"
    "Keep days:" = "تعداد روز نگهداری:"
    "Max images:" = "حداکثر تصاویر:"
    "0 = unlimited" = "0 = نامحدود"
    "Save Policy" = "ذخیره"
    "Cleanup Now" = "پاکسازی"
    "Screenshots" = "تصاویر"
    "Select an image to preview below" = "یک تصویر را برای پیش‌نمایش انتخاب کنید"
    "No album selected" = "آلبومی انتخاب نشده"
    "Selected Capture" = "تصویر انتخاب‌شده"
    "PREVIEW" = "پیش‌نمایش"
    "No image selected" = "تصویری انتخاب نشده"
    "Open Image" = "باز کردن"
    "Delete Image" = "حذف تصویر"
    "AI Visual Analysis" = "تحلیل بصری هوش مصنوعی"
    "Compare dashboard captures, inspect visual health and run local AI analysis" = "مقایسه تصاویر داشبورد، بررسی سلامت بصری و اجرای تحلیل هوش مصنوعی محلی"
    "Album" = "آلبوم"
    "Pixel Threshold" = "آستانه پیکسل"
    "Pixel Compare" = "مقایسه تصویر"
    "Ready for visual comparison" = "آماده مقایسه بصری"
    "Local Vision AI" = "هوش مصنوعی بینایی محلی"
    "AI STATUS" = "وضعیت AI"
    "Status: checking..." = "وضعیت: در حال بررسی..."
    "Start AI" = "شروع AI"
    "Stop AI" = "توقف AI"
    "Test AI" = "تست AI"
    "Open AI Folder" = "باز کردن پوشه AI"
    "AI Analyze" = "تحلیل AI"
    "AI Compare" = "مقایسه AI"
    "ANALYSIS ACTIONS" = "عملیات تحلیل"
    "AI Analyze Latest" = "تحلیل آخرین تصویر"
    "AI Compare Last 2" = "مقایسه دو تصویر"
    "BASELINE" = "مبنای مقایسه"
    "LATEST" = "آخرین"
    "No baseline image" = "تصویر مبنا وجود ندارد"
    "No latest image" = "آخرین تصویر وجود ندارد"
    "Analysis Report" = "گزارش تحلیل"
    "Copy" = "کپی"
    "No Data Inspector" = "بررسی بدون داده"
    "No Data" = "بدون داده"
    "Verify" = "بررسی"
    "Security Center" = "مرکز امنیت"
    "Local protection, integrity, sessions and security audit for RAQEB Sentinel" = "حفاظت محلی، یکپارچگی، نشست‌ها و ممیزی امنیتی RAQEB Sentinel"
    "Protection Status" = "وضعیت حفاظت"
    "Checking..." = "در حال بررسی..."
    "Security Actions" = "عملیات امنیتی"
    "Run Security Check" = "اجرای بررسی امنیتی"
    "Clear Saved Sessions" = "پاک کردن نشست‌های ذخیره‌شده"
    "Clear AI Cache" = "پاک کردن کش AI"
    "Open Audit Log" = "باز کردن لاگ ممیزی"
    "Refresh Status" = "بروزرسانی وضعیت"
    "Recent Security Activity" = "فعالیت امنیتی اخیر"
    "No security events recorded yet." = "هنوز رویداد امنیتی ثبت نشده است."
    "Protected - Windows DPAPI (Current User)" = "محافظت‌شده - Windows DPAPI (کاربر فعلی)"
    "Local Only - 127.0.0.1" = "فقط محلی - 127.0.0.1"
    "Attention - non-local endpoint" = "توجه - مقصد غیرمحلی"
    "Stopped - configured for localhost only" = "متوقف - فقط برای localhost تنظیم شده"
    "Appearance & Theme" = "ظاهر و پوسته"
    "Background mode:" = "حالت پس‌زمینه:"
    "Preview:" = "پیش‌نمایش:"
    "Apply" = "اعمال"
    "Save Settings" = "ذخیره تنظیمات"
    "Language:" = "زبان:"
    "Persian font:" = "فونت فارسی:"
    "English" = "English"
    "Health Alerts" = "هشدارهای سلامت"
    "Enable desktop health alerts" = "فعال‌سازی هشدارهای سلامت دسکتاپ"
    "Notify when status becomes Warning" = "اعلان هنگام تبدیل وضعیت به هشدار"
    "Notify when status becomes Critical" = "اعلان هنگام تبدیل وضعیت به بحرانی"
    "Notify when Warning/Critical recovers to Healthy" = "اعلان هنگام بازگشت هشدار/بحرانی به وضعیت سالم"
    "Test Notification" = "تست اعلان"
    "State: OFF" = "وضعیت: خاموش"
    "State: ON" = "وضعیت: روشن"
    "Product & Support" = "محصول و پشتیبانی"
    "About RAQEB" = "درباره راقب"
    "Export Support Package" = "خروجی بسته پشتیبانی"
    "Available after Trial too - sanitized ZIP" = "بعد از پایان نسخه آزمایشی هم فعال است - ZIP پاک‌سازی‌شده"
    "License" = "لایسنس"
    "RAQEB Activation Center | 7-Day Full Trial + Professional License" = "مرکز فعال‌سازی راقب | لایسنس حرفه‌ای"
    "Status" = "وضعیت"
    "Customer" = "مشتری"
    "Edition" = "نسخه"
    "License ID" = "شناسه لایسنس"
    "Expires" = "انقضا"
    "Days left" = "روز باقی‌مانده"
    "Access" = "دسترسی"
    "Machine ID" = "شناسه سیستم"
    "Import License" = "ورود لایسنس"
    "License Folder" = "پوشه لایسنس"
    "Copy Machine ID" = "کپی شناسه سیستم"
    "About RAQEB Sentinel Pro" = "درباره راقب Sentinel Pro"
    "Save" = "ذخیره"
    "Cancel" = "انصراف"
    "Testing..." = "در حال تست..."
    "Test Connection" = "تست اتصال"
    "Enable Field Verification" = "فعال‌سازی بررسی فیلدها"
    "Elasticsearch URL" = "آدرس Elasticsearch"
    "API Key" = "کلید API"
    "API Help" = "راهنمای API"
    "Time field" = "فیلد زمان"
    "Window" = "بازه"
    "minutes" = "دقیقه"
    "Ignore self-signed / internal TLS certificate errors" = "نادیده گرفتن خطاهای گواهی TLS داخلی / خودامضا"
    "Fast Elasticsearch Field Verification" = "بررسی سریع فیلدهای Elasticsearch"
    "Copy Command" = "کپی دستور"
    "Copy Commands" = "کپی دستورات"
    "Copy Example" = "کپی مثال"
    "Recommended" = "پیشنهادی"
    "Use Selected Fields" = "استفاده از فیلدهای انتخاب‌شده"
    "Verify Fields Now" = "بررسی فیلدها الآن"
    "Copy Result" = "کپی نتیجه"
    "A profile export includes all dashboards inside that profile. Credentials are excluded." = "خروجی هر پروفایل شامل تمام داشبوردهای آن است. اطلاعات ورود منتقل نمی‌شوند."
    "Existing items are never overwritten. Name conflicts create a new '(Imported)' copy." = "موارد موجود هرگز بازنویسی نمی‌شوند. در تداخل نام یک نسخه جدید با (Imported) ساخته می‌شود."
    "Passwords, Elasticsearch API Keys, DPAPI credentials, cookies and browser sessions are never exported. Re-enter credentials on the destination system." = "رمزها، کلیدهای API الستیک، اطلاعات DPAPI، کوکی‌ها و نشست مرورگر هرگز خروجی گرفته نمی‌شوند. اطلاعات ورود را در سیستم مقصد دوباره وارد کنید."
    "Profile exported successfully." = "پروفایل با موفقیت خروجی گرفته شد."
    "All profiles exported successfully." = "همه پروفایل‌ها با موفقیت خروجی گرفته شدند."
    "All dashboards from the selected profile were exported." = "همه داشبوردهای پروفایل انتخاب‌شده خروجی گرفته شدند."
    "LOCAL AI" = "AI محلی"
    "AUTOMATION" = "خودکارسازی"
    "DASHBOARD HEALTH" = "سلامت داشبورد"
    "CHECKING" = "در حال بررسی"
    "Total Dashboards" = "کل داشبوردها"
    "All Profiles" = "همه پروفایل‌ها"
    "All Statuses" = "همه وضعیت‌ها"
    "Table View" = "نمای جدولی"
    "Shot" = "تصویر"
    "Not checked" = "بررسی نشده"
    "AI NOT AVAILABLE" = "AI در دسترس نیست"
    "No empty panels detected." = "پنل خالی مشاهده نشد."
    "No Data panel names are not available." = "نام پنل‌های بدون داده در دسترس نیست."
    "Select a checked dashboard to see Elasticsearch field verification." = "برای مشاهده نتیجه بررسی فیلدها، یک داشبورد بررسی‌شده را انتخاب کنید."
    "RAQEB will explain whether the issue looks data-side or dashboard-side." = "راقب مشخص می‌کند مشکل از داده است یا از داشبورد."
    "Capture Settings" = "تنظیمات تصویربرداری"
    "Dashboards" = "داشبوردها"
    "Dashboard" = "داشبورد"
    "Time Range" = "بازه زمانی"
    "URL / Relative Path" = "URL / مسیر نسبی"
    "Index" = "ایندکس"
    "Expected Fields" = "فیلدهای مورد انتظار"
    "Optional: direct Elasticsearch verification for this dashboard." = "اختیاری: بررسی مستقیم این داشبورد از Elasticsearch."
    "Manual login:``r``n1. Open Login Browser``r``n2. Login to Kibana``r``n3. KEEP browser open``r``n4. Capture All" = "ورود دستی:``r``n1. مرورگر ورود را باز کنید``r``n2. وارد Kibana شوید``r``n3. مرورگر را باز نگه دارید``r``n4. تصویربرداری را اجرا کنید"
    "OVERALL" = "وضعیت کلی"
    "DASHBOARD LOADED" = "بارگذاری"
    "EMPTY PANELS" = "پنل خالی"
    "WITH DATA" = "دارای داده"
    "ERRORS" = "خطاها"
    "AI CONFIDENCE" = "اطمینان AI"
    "Select an album and click Analyze Latest." = "یک آلبوم انتخاب کنید و تحلیل آخرین تصویر را اجرا کنید."
    "AI is local and optional. Select an album and run AI Analyze Latest." = "هوش مصنوعی محلی و اختیاری است. یک آلبوم انتخاب و تحلیل آخرین تصویر را اجرا کنید."
    "Status: Ready" = "وضعیت: آماده"
    "Status: Installed / Stopped" = "وضعیت: نصب‌شده / متوقف"
    "Status: AI Pack not installed" = "وضعیت: بسته AI نصب نیست"
    "Elastic Dark uses sidebar navigation, card-based sections, rounded controls and fully dark data surfaces." = "پوسته تیره، منوی کناری و کارت‌های برنامه را با ظاهر تیره نمایش می‌دهد."
    "Alerts fire only when a dashboard status changes, so repeated cycles do not create notification spam." = "اعلان فقط هنگام تغییر وضعیت داشبورد ارسال می‌شود و تکرار نمی‌شود."
    "Copy this Machine ID and send it to your RAQEB supplier. Import the signed .lic file you receive." = "شناسه سیستم را برای تأمین‌کننده راقب ارسال و فایل لایسنس امضاشده را وارد کنید."
    "Valid signed Professional license." = "لایسنس حرفه‌ای معتبر و امضاشده است."
    "FULL ACCESS - PROFESSIONAL" = "دسترسی کامل - حرفه‌ای"
    "LOCKED - Gallery + License + Support only" = "قفل - فقط گالری، لایسنس و پشتیبانی"
    "Perpetual license" = "لایسنس دائمی"
    "Machine ID copied to clipboard." = "شناسه سیستم کپی شد."

}

$script:AghrabEnTextMap = @{}
foreach ($entry in $script:AghrabFaTextMap.GetEnumerator()) {
    if (-not $script:AghrabEnTextMap.ContainsKey([string]$entry.Value)) {
        $script:AghrabEnTextMap[[string]$entry.Value] = [string]$entry.Key
    }
}

function Get-AghrabControlKey {
    param([System.Windows.Forms.Control]$Control)

    if ($null -eq $Control) {
        return ""
    }

    return (
        $Control.GetType().FullName +
        ":" +
        [System.Runtime.CompilerServices.RuntimeHelpers]::GetHashCode($Control).ToString()
    )
}

function Convert-AghrabUiText {
    param(
        [string]$Text,
        [string]$Language
    )

    if ([string]::IsNullOrEmpty($Text)) {
        return $Text
    }

    if ($Language -eq "Persian") {
        if ($script:AghrabFaTextMap.ContainsKey($Text)) {
            return [string]$script:AghrabFaTextMap[$Text]
        }

        if ($Text -match '^Status:\s*(.+)$') {
            return ("وضعیت: " + [string]$matches[1])
        }
        if ($Text -match '^Profile:\s*(.+)$') {
            return ("پروفایل: " + [string]$matches[1])
        }
        if ($Text -match '^Count:\s*(.+)$') {
            return ("تعداد: " + [string]$matches[1])
        }
        if ($Text -match '^Updated:\s*(.+)$') {
            return ("به‌روزرسانی: " + [string]$matches[1])
        }
        if ($Text -match '^Last check:\s*(.+)$') {
            return ("آخرین بررسی: " + [string]$matches[1])
        }
        if ($Text -match '^Current images:\s*(\d+)$') {
            return ("تصاویر فعلی: " + [string]$matches[1])
        }
        if ($Text -match '^(\d+)\s+captures?$') {
            return ([string]$matches[1] + " تصویر")
        }
        if ($Text -match '^No Data\s+(.+)$') {
            return ("بدون داده: " + [string]$matches[1])
        }
        if ($Text -match '^Verify\s+(.+)$') {
            return ("بررسی: " + [string]$matches[1])
        }
        if ($Text -match '^Professional license expires in\s+(\d+)\s+day\(s\)\. Renewal is recommended\.$') {
            return ("لایسنس حرفه‌ای تا " + [string]$matches[1] + " روز دیگر منقضی می‌شود. تمدید پیشنهاد می‌شود.")
        }
        if ($Text -match '^7-day Full Trial is active\..*?(\d+)\s+day\(s\) remaining\.$') {
            return ("نسخه آزمایشی ۷ روزه فعال است. " + [string]$matches[1] + " روز باقی مانده است.")
        }
        if ($Text -match '^FULL ACCESS - 7-DAY TRIAL \|\s*(\d+)\s+day\(s\) left$') {
            return ("دسترسی کامل - آزمایشی ۷ روزه | " + [string]$matches[1] + " روز باقی‌مانده")
        }
        if ($Text -match '^RAQEB Sentinel Pro v(.+) \| Commercial Build\r\nVisual SOC monitoring, portable profile transfer, local AI and signed offline licensing\.$') {
            return ("RAQEB Sentinel Pro v" + [string]$matches[1] + " | نسخه تجاری`r`nپایش بصری SOC، انتقال پروفایل، هوش مصنوعی محلی و لایسنس آفلاین امضاشده.")
        }
        if ($Text -match '^Showing\s+(.+)\s+of\s+(.+)$') {
            return ("نمایش " + [string]$matches[1] + " از " + [string]$matches[2])
        }
        if ($Text -match '^(\d+)\s+days left$') {
            return ([string]$matches[1] + " روز باقی‌مانده")
        }
        if ($Text -match '^(\d+)\s+days left\s+\|\s+Full Trial$') {
            return ([string]$matches[1] + " روز باقی‌مانده | آزمایشی کامل")
        }

        return $Text
    }

    if ($script:AghrabEnTextMap.ContainsKey($Text)) {
        return [string]$script:AghrabEnTextMap[$Text]
    }

    if ($Text -match '^وضعیت:\s*(.+)$') {
        return ("Status: " + [string]$matches[1])
    }
    if ($Text -match '^پروفایل:\s*(.+)$') {
        return ("Profile: " + [string]$matches[1])
    }
    if ($Text -match '^تعداد:\s*(.+)$') {
        return ("Count: " + [string]$matches[1])
    }
    if ($Text -match '^به‌روزرسانی:\s*(.+)$') {
        return ("Updated: " + [string]$matches[1])
    }
    if ($Text -match '^آخرین بررسی:\s*(.+)$') {
        return ("Last check: " + [string]$matches[1])
    }
    if ($Text -match '^تصاویر فعلی:\s*(\d+)$') {
        return ("Current images: " + [string]$matches[1])
    }
    if ($Text -match '^(\d+)\s+تصویر$') {
        return ([string]$matches[1] + " captures")
    }
    if ($Text -match '^بدون داده:\s*(.+)$') {
        return ("No Data  " + [string]$matches[1])
    }
    if ($Text -match '^بررسی:\s*(.+)$') {
        return ("Verify  " + [string]$matches[1])
    }
    if ($Text -match '^نمایش\s+(.+)\s+از\s+(.+)$') {
        return ("Showing " + [string]$matches[1] + " of " + [string]$matches[2])
    }
    if ($Text -match '^(\d+)\s+روز باقی‌مانده$') {
        return ([string]$matches[1] + " days left")
    }
    if ($Text -match '^(\d+)\s+روز باقی‌مانده\s+\|\s+آزمایشی کامل$') {
        return ([string]$matches[1] + " days left | Full Trial")
    }

    return $Text
}

function Write-AghrabLanguageError {
    param([string]$Detail)

    try {
        $dir = Join-Path $env:APPDATA "aghrab"
        if (-not (Test-Path -LiteralPath $dir)) {
            New-Item -ItemType Directory -Path $dir -Force | Out-Null
        }

        $path = Join-Path $dir "language-error.log"
        (
            (Get-Date -Format "yyyy-MM-dd HH:mm:ss") +
            " | " +
            [string]$Detail +
            "`r`n"
        ) | Add-Content -LiteralPath $path -Encoding UTF8
    }
    catch {}
}

function Test-AghrabTechnicalInputControl {
    param([System.Windows.Forms.Control]$Control)

    if ($null -eq $Control) {
        return $false
    }

    return (
        $Control -is [System.Windows.Forms.TextBox] -or
        $Control -is [System.Windows.Forms.RichTextBox] -or
        $Control -is [System.Windows.Forms.MaskedTextBox] -or
        $Control -is [System.Windows.Forms.NumericUpDown] -or
        $Control -is [System.Windows.Forms.ComboBox]
    )
}

function Test-AghrabFontInstalled {
    param([string]$FontName)

    if ([string]::IsNullOrWhiteSpace($FontName)) {
        return $false
    }

    try {
        $fonts = New-Object System.Drawing.Text.InstalledFontCollection
        foreach ($family in $fonts.Families) {
            if ([string]::Equals(
                [string]$family.Name,
                [string]$FontName,
                [System.StringComparison]::OrdinalIgnoreCase
            )) {
                return $true
            }
        }
    }
    catch {}

    return $false
}

function Get-AghrabEffectivePersianFont {
    param([string]$RequestedFont)

    if ($RequestedFont -eq "B Koodak" -and
        (Test-AghrabFontInstalled -FontName "B Koodak")) {
        return "B Koodak"
    }

    return "Tahoma"
}

function Save-AghrabOriginalUiFont {
    param([System.Windows.Forms.Control]$Control)

    if ($null -eq $Control -or $null -eq $Control.Font) {
        return
    }

    $key = Get-AghrabControlKey -Control $Control
    if ([string]::IsNullOrWhiteSpace($key)) {
        return
    }

    if (-not $script:AghrabOriginalFonts.ContainsKey($key)) {
        $script:AghrabOriginalFonts[$key] = [PSCustomObject]@{
            Family = [string]$Control.Font.FontFamily.Name
            Size = [single]$Control.Font.Size
            Style = [int]$Control.Font.Style
            Unit = [int]$Control.Font.Unit
        }
    }
}

function Restore-AghrabOriginalUiFont {
    param([System.Windows.Forms.Control]$Control)

    if ($null -eq $Control) {
        return
    }

    try {
        $key = Get-AghrabControlKey -Control $Control
        if (-not $script:AghrabOriginalFonts.ContainsKey($key)) {
            return
        }

        $base = $script:AghrabOriginalFonts[$key]
        $Control.Font = New-Object System.Drawing.Font(
            [string]$base.Family,
            [single]$base.Size,
            [System.Drawing.FontStyle][int]$base.Style,
            [System.Drawing.GraphicsUnit][int]$base.Unit
        )
    }
    catch {}
}

function Set-AghrabPersianUiFontSafe {
    param(
        [System.Windows.Forms.Control]$Control,
        [ValidateSet("English","Persian")]
        [string]$Language
    )

    if ($null -eq $Control -or $null -eq $Control.Font) {
        return
    }

    # Never touch data/input/dense controls. Their original font is kept.
    if (
        $Control -is [System.Windows.Forms.TextBox] -or
        $Control -is [System.Windows.Forms.RichTextBox] -or
        $Control -is [System.Windows.Forms.MaskedTextBox] -or
        $Control -is [System.Windows.Forms.NumericUpDown] -or
        $Control -is [System.Windows.Forms.ComboBox] -or
        $Control -is [System.Windows.Forms.ListView] -or
        $Control -is [System.Windows.Forms.DataGridView] -or
        $Control -is [System.Windows.Forms.ListBox] -or
        $Control -is [System.Windows.Forms.CheckedListBox] -or
        $Control -is [System.Windows.Forms.PictureBox]
    ) {
        return
    }

    # Only visible caption controls are font-switchable.
    if (-not (
        $Control -is [System.Windows.Forms.Label] -or
        $Control -is [System.Windows.Forms.Button] -or
        $Control -is [System.Windows.Forms.CheckBox] -or
        $Control -is [System.Windows.Forms.RadioButton] -or
        $Control -is [System.Windows.Forms.GroupBox] -or
        $Control -is [System.Windows.Forms.TabPage]
    )) {
        return
    }

    Save-AghrabOriginalUiFont -Control $Control

    if ($Language -eq "English") {
        Restore-AghrabOriginalUiFont -Control $Control
        return
    }

    try {
        $key = Get-AghrabControlKey -Control $Control
        if (-not $script:AghrabOriginalFonts.ContainsKey($key)) {
            return
        }

        $base = $script:AghrabOriginalFonts[$key]
        $family = Get-AghrabEffectivePersianFont `
            -RequestedFont $script:CurrentPersianFont

        $size = [single]$base.Size

        # B Koodak is visually larger than Segoe UI/Tahoma.
        # Reduce it slightly without changing control dimensions.
        if ($family -eq "B Koodak") {
            $size = [single][Math]::Max(
                7.0,
                ([double]$base.Size - 1.0)
            )
        }

        $Control.Font = New-Object System.Drawing.Font(
            $family,
            $size,
            [System.Drawing.FontStyle][int]$base.Style,
            [System.Drawing.GraphicsUnit][int]$base.Unit
        )
    }
    catch {
        # Font choice must never close or destabilize RAQEB.
    }
}

function Set-AghrabStaticControlLanguage {
    param(
        [System.Windows.Forms.Control]$Control,
        [ValidateSet("English","Persian")]
        [string]$Language
    )

    if ($null -eq $Control) {
        return
    }

    $rtl = ($Language -eq "Persian")
    $technical = Test-AghrabTechnicalInputControl -Control $Control

    try {
        if (-not $technical) {
            if (
                $Control -is [System.Windows.Forms.Label] -or
                $Control -is [System.Windows.Forms.Button] -or
                $Control -is [System.Windows.Forms.CheckBox] -or
                $Control -is [System.Windows.Forms.RadioButton] -or
                $Control -is [System.Windows.Forms.GroupBox] -or
                $Control -is [System.Windows.Forms.TabPage]
            ) {
                $newText = Convert-AghrabUiText `
                    -Text ([string]$Control.Text) `
                    -Language $Language

                if ([string]$Control.Text -ne [string]$newText) {
                    $Control.Text = $newText
                }
            }
        }
    }
    catch {}

    Set-AghrabPersianUiFontSafe `
        -Control $Control `
        -Language $Language

    try {
        if ($Control.PSObject.Properties["AutoEllipsis"] -and
            ($Control -is [System.Windows.Forms.Label] -or
             $Control -is [System.Windows.Forms.Button])) {
            $Control.AutoEllipsis = $true
        }
    } catch {}

    # Only text alignment. No RightToLeft propagation and no coordinate changes.
    try {
        if (-not $technical -and
            $Control.PSObject.Properties["TextAlign"]) {

            if ($Control -is [System.Windows.Forms.Label] -or
                $Control -is [System.Windows.Forms.Button] -or
                $Control -is [System.Windows.Forms.CheckBox] -or
                $Control -is [System.Windows.Forms.RadioButton]) {

                $Control.TextAlign = $(if ($rtl) {
                    [System.Drawing.ContentAlignment]::MiddleRight
                } else {
                    [System.Drawing.ContentAlignment]::MiddleLeft
                })
            }
        }
    }
    catch {}

    # Keep all text-entry / technical controls LTR.
    try {
        if ($technical) {
            $Control.RightToLeft = [System.Windows.Forms.RightToLeft]::No
        }
    }
    catch {}

    # Column headers only; rows/values remain untouched.
    try {
        if ($Control -is [System.Windows.Forms.ListView]) {
            foreach ($column in $Control.Columns) {
                $column.Text = Convert-AghrabUiText `
                    -Text ([string]$column.Text) `
                    -Language $Language
            }
        }
        elseif ($Control -is [System.Windows.Forms.DataGridView]) {
            foreach ($column in $Control.Columns) {
                $column.HeaderText = Convert-AghrabUiText `
                    -Text ([string]$column.HeaderText) `
                    -Language $Language
            }
        }
    }
    catch {}
}

function Update-AghrabMainFormCaptions {
    param(
        [ValidateSet("English","Persian")]
        [string]$Language
    )

    # Iterative traversal avoids deep recursive WinForms traversal.
    $queue = New-Object System.Collections.Queue
    $queue.Enqueue($form)

    $visited = 0
    while ($queue.Count -gt 0 -and $visited -lt 5000) {
        $control = $queue.Dequeue()
        $visited++

        Set-AghrabStaticControlLanguage `
            -Control $control `
            -Language $Language

        try {
            foreach ($child in @($control.Controls)) {
                if ($null -ne $child) {
                    $queue.Enqueue($child)
                }
            }
        }
        catch {}
    }
}

function Set-AghrabMainWorkspaceDirection {
    param(
        [ValidateSet("English","Persian")]
        [string]$Language
    )

    try {
        if ($Language -eq "Persian") {
            $sideNav.Location = New-Object System.Drawing.Point(
                [Math]::Max(0, $form.ClientSize.Width - 204),
                145
            )
            $sideNav.Anchor = "Top,Bottom,Right"

            $tabs.Location = New-Object System.Drawing.Point(14,145)
            $tabs.Size = New-Object System.Drawing.Size(
                [Math]::Max(900, $form.ClientSize.Width - 238),
                [Math]::Max(650, $form.ClientSize.Height - 185)
            )
            $tabs.Anchor = "Top,Bottom,Left,Right"
        }
        else {
            $sideNav.Location = New-Object System.Drawing.Point(20,145)
            $sideNav.Size = New-Object System.Drawing.Size(184,715)
            $sideNav.Anchor = "Top,Bottom,Left"

            $tabs.Location = New-Object System.Drawing.Point(224,145)
            $tabs.Size = New-Object System.Drawing.Size(981,715)
            $tabs.Anchor = "Top,Bottom,Left,Right"
        }
    }
    catch {
        Write-AghrabLanguageError `
            -Detail ("Workspace direction: " + $_.Exception.Message)
    }

    try {
        foreach ($button in @(
            $btnNavHealth,
            $btnNavElk,
            $btnNavScheduler,
            $btnNavGallery,
            $btnNavAnalyze,
            $btnNavSecurity,
            $btnNavSettings
        )) {
            if ($null -eq $button) {
                continue
            }

            if ($Language -eq "Persian") {
                $button.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
                $button.ImageAlign = [System.Drawing.ContentAlignment]::MiddleRight
                $button.TextImageRelation = [System.Windows.Forms.TextImageRelation]::TextBeforeImage
                $button.Padding = New-Object System.Windows.Forms.Padding(0,0,10,0)
            }
            else {
                $button.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
                $button.ImageAlign = [System.Drawing.ContentAlignment]::MiddleLeft
                $button.TextImageRelation = [System.Windows.Forms.TextImageRelation]::ImageBeforeText
                $button.Padding = New-Object System.Windows.Forms.Padding(10,0,0,0)
            }
        }
    }
    catch {}
}

function Apply-AghrabLanguage {
    param(
        [ValidateSet("English","Persian")]
        [string]$Language
    )

    if ($script:LanguageApplyInProgress) {
        return
    }

    $script:LanguageApplyInProgress = $true

    try {
        $script:CurrentLanguage = $Language

        Set-AghrabMainWorkspaceDirection -Language $Language
        Update-AghrabMainFormCaptions -Language $Language

        try { Update-SidebarNavigation } catch {}

        try { Refresh-HealthManagerProfiles } catch {}
        try { Refresh-AghrabHealthStatusFilterLanguage } catch {}
        try { Refresh-HealthCenter } catch {}
        try { Update-AiStatus } catch {}
        try { Update-HeaderStatus } catch {}
        try { Refresh-Gallery } catch {}
        try { Refresh-AnalyzeAlbums } catch {}
        try { Update-AghrabLicenseUi | Out-Null } catch {}
        try { Update-SchedulerStateUi } catch {}

        try { $tabs.Invalidate() } catch {}
        try { $form.Refresh() } catch {}
    }
    catch {
        Write-AghrabLanguageError `
            -Detail ("Apply language '$Language': " + $_.Exception.ToString())

        $script:CurrentLanguage = "English"

        try {
            Set-AghrabMainWorkspaceDirection -Language "English"
            Update-AghrabMainFormCaptions -Language "English"
        }
        catch {}

        try {
            [System.Windows.Forms.MessageBox]::Show(
                $form,
                "Language change could not be applied safely. RAQEB returned to English.`r`n`r`n" +
                "Diagnostic: %APPDATA%\aghrab\language-error.log",
                "RAQEB Language",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Warning
            ) | Out-Null
        }
        catch {}
    }
    finally {
        $script:LanguageApplyInProgress = $false
    }
}

function Get-AghrabSelectedLanguage {
    if ($null -eq $cmbLanguage) {
        return "English"
    }

    if ([string]$cmbLanguage.SelectedItem -eq "فارسی") {
        return "Persian"
    }

    return "English"
}

function Get-AghrabSelectedPersianFont {
    if ($null -eq $cmbPersianFont) {
        return "Tahoma"
    }

    $font = [string]$cmbPersianFont.SelectedItem
    if ($font -notin @("Tahoma","B Koodak")) {
        return "Tahoma"
    }

    return $font
}

# Theme
$Navy   = [System.Drawing.Color]::FromArgb(0,31,63)
$Blue   = [System.Drawing.Color]::FromArgb(0,142,224)
$Light  = [System.Drawing.Color]::FromArgb(246,249,252)
$Border = [System.Drawing.Color]::FromArgb(218,226,235)

function Style-PrimaryButton($b) {
    $b.UseVisualStyleBackColor = $false
    $b.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $b.FlatAppearance.BorderSize = 0
    $b.FlatAppearance.MouseOverBackColor = [System.Drawing.Color]::FromArgb(0,166,156)
    $b.FlatAppearance.MouseDownBackColor = [System.Drawing.Color]::FromArgb(0,120,113)
    $b.BackColor = $Blue
    $b.ForeColor = [System.Drawing.Color]::White
    $b.Font = New-Object System.Drawing.Font("Segoe UI Semibold",9)
    $b.Cursor = [System.Windows.Forms.Cursors]::Hand
    Set-RoundedControlRegion -Control $b -Radius 8
}
function Style-SecondaryButton($b) {
    $b.UseVisualStyleBackColor = $false
    $b.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $b.FlatAppearance.BorderSize = 1
    $b.FlatAppearance.BorderColor = $Border
    $b.FlatAppearance.MouseOverBackColor = [System.Drawing.Color]::FromArgb(242,247,251)
    $b.FlatAppearance.MouseDownBackColor = [System.Drawing.Color]::FromArgb(231,239,246)
    $b.BackColor = [System.Drawing.Color]::White
    $b.ForeColor = $Navy
    $b.Font = New-Object System.Drawing.Font("Segoe UI Semibold",9)
    $b.Cursor = [System.Windows.Forms.Cursors]::Hand
    Set-RoundedControlRegion -Control $b -Radius 8
}

$form = New-Object System.Windows.Forms.Form
$form.Text = "$AppName v$AppVersion"
$form.Size = New-Object System.Drawing.Size(1235, 900)
$form.StartPosition = "CenterScreen"
$form.MinimumSize = New-Object System.Drawing.Size(1120,800)
$form.BackColor = $Light

$iconFile = Join-Path $BaseDir "aghrab.ico"
if (Test-Path $iconFile) {
    try { $form.Icon = New-Object System.Drawing.Icon($iconFile) } catch {}
}

# Header
$header = New-Object System.Windows.Forms.Panel
$header.Location = New-Object System.Drawing.Point(0,0)
$header.Size = New-Object System.Drawing.Size(1235,128)
$header.Anchor = "Top,Left,Right"
$header.BackColor = [System.Drawing.Color]::White
$form.Controls.Add($header)

$logoFile = Join-Path $BaseDir "aghrab-icon.png"
$pic = New-Object System.Windows.Forms.PictureBox
$pic.Location = New-Object System.Drawing.Point(22,18)
$pic.Size = New-Object System.Drawing.Size(82,82)
$pic.SizeMode = "Zoom"
if (Test-Path $logoFile) {
    try { $pic.Image = [System.Drawing.Image]::FromFile($logoFile) } catch {}
}
$header.Controls.Add($pic)

$brandLabel = New-Object System.Windows.Forms.Label
$brandLabel.Text = "RAQEB"
$brandLabel.Font = New-Object System.Drawing.Font("Segoe UI",29,[System.Drawing.FontStyle]::Bold)
$brandLabel.ForeColor = $Navy
$brandLabel.Location = New-Object System.Drawing.Point(122,22)
$brandLabel.AutoSize = $true
$header.Controls.Add($brandLabel)

$brandEdition = New-Object System.Windows.Forms.Label
$brandEdition.Text = "SENTINEL PRO"
$brandEdition.Font = New-Object System.Drawing.Font("Segoe UI Semibold",13,[System.Drawing.FontStyle]::Bold)
$brandEdition.ForeColor = [System.Drawing.Color]::FromArgb(0,145,137)
$brandEdition.Location = New-Object System.Drawing.Point(300,38)
$brandEdition.AutoSize = $true
$header.Controls.Add($brandEdition)

$brandSubLabel = New-Object System.Windows.Forms.Label
$brandSubLabel.Text = "Autonomous Visual SOC Monitoring  |  Local AI Operations"
$brandSubLabel.Font = New-Object System.Drawing.Font("Segoe UI",9.5)
$brandSubLabel.ForeColor = [System.Drawing.Color]::DimGray
$brandSubLabel.Location = New-Object System.Drawing.Point(126,76)
$brandSubLabel.AutoSize = $true
$header.Controls.Add($brandSubLabel)

$panelHeaderLicense = New-Object System.Windows.Forms.Panel
$panelHeaderLicense.Location = New-Object System.Drawing.Point(1018,6)
$panelHeaderLicense.Size = New-Object System.Drawing.Size(190,38)
$panelHeaderLicense.Anchor = "Top,Right"
$panelHeaderLicense.BackColor = [System.Drawing.Color]::Transparent
$header.Controls.Add($panelHeaderLicense)

$verLabel = New-Object System.Windows.Forms.Label
$verLabel.Text = "v$AppVersion"
$verLabel.Font = New-Object System.Drawing.Font("Segoe UI Semibold",8.5)
$verLabel.ForeColor = [System.Drawing.Color]::Gray
$verLabel.Location = New-Object System.Drawing.Point(0,2)
$verLabel.Size = New-Object System.Drawing.Size(62,18)
$verLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
$panelHeaderLicense.Controls.Add($verLabel)

$lblHeaderLicenseStatus = New-Object System.Windows.Forms.Label
$lblHeaderLicenseStatus.Text = "UNLICENSED"
$lblHeaderLicenseStatus.Font = New-Object System.Drawing.Font("Segoe UI Semibold",8,[System.Drawing.FontStyle]::Bold)
$lblHeaderLicenseStatus.Location = New-Object System.Drawing.Point(68,1)
$lblHeaderLicenseStatus.Size = New-Object System.Drawing.Size(118,20)
$lblHeaderLicenseStatus.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$panelHeaderLicense.Controls.Add($lblHeaderLicenseStatus)
Set-RoundedControlRegion -Control $lblHeaderLicenseStatus -Radius 9

$lblHeaderLicenseDays = New-Object System.Windows.Forms.Label
$lblHeaderLicenseDays.Text = "No active license"
$lblHeaderLicenseDays.Font = New-Object System.Drawing.Font("Segoe UI",8.2)
$lblHeaderLicenseDays.ForeColor = [System.Drawing.Color]::Gray
$lblHeaderLicenseDays.Location = New-Object System.Drawing.Point(0,21)
$lblHeaderLicenseDays.Size = New-Object System.Drawing.Size(186,16)
$lblHeaderLicenseDays.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
$panelHeaderLicense.Controls.Add($lblHeaderLicenseDays)

function New-HeaderStatusCard {
    param(
        [int]$Left,
        [string]$Title,
        [string]$Value,
        [string]$IconKind
    )

    $panel = New-Object System.Windows.Forms.Panel
    $panel.Location = New-Object System.Drawing.Point($Left,47)
    $panel.Size = New-Object System.Drawing.Size(142,56)
    $panel.Anchor = "Top,Right"
    $panel.Tag = "card"
    Set-RoundedControlRegion -Control $panel -Radius 11
    $header.Controls.Add($panel)

    $icon = New-Object System.Windows.Forms.PictureBox
    $icon.Location = New-Object System.Drawing.Point(10,16)
    $icon.Size = New-Object System.Drawing.Size(24,24)
    $icon.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::CenterImage
    $icon.Image = Get-AghrabIconImage -Kind $IconKind -FallbackColor ([System.Drawing.Color]::Gray) -Size 24
    $panel.Controls.Add($icon)

    $titleLabel = New-Object System.Windows.Forms.Label
    $titleLabel.Text = $Title
    $titleLabel.Font = New-Object System.Drawing.Font("Segoe UI Semibold",7.5)
    $titleLabel.Location = New-Object System.Drawing.Point(42,8)
    $titleLabel.Size = New-Object System.Drawing.Size(91,17)
    $titleLabel.AutoEllipsis = $true
    $titleLabel.Tag = "muted"
    $panel.Controls.Add($titleLabel)

    $valueLabel = New-Object System.Windows.Forms.Label
    $valueLabel.Text = $Value
    $valueLabel.Font = New-Object System.Drawing.Font("Segoe UI Semibold",9.4,[System.Drawing.FontStyle]::Bold)
    $valueLabel.Location = New-Object System.Drawing.Point(42,27)
    $valueLabel.Size = New-Object System.Drawing.Size(91,20)
    $valueLabel.AutoEllipsis = $true
    $panel.Controls.Add($valueLabel)

    $accent = New-Object System.Windows.Forms.Panel
    $accent.Location = New-Object System.Drawing.Point(8,52)
    $accent.Size = New-Object System.Drawing.Size(126,3)
    $panel.Controls.Add($accent)

    return [PSCustomObject]@{
        Panel = $panel
        Title = $titleLabel
        Value = $valueLabel
        Icon = $icon
        Accent = $accent
    }
}

$headerAiState = New-HeaderStatusCard -Left 672 -Title "LOCAL AI" -Value "CHECKING" -IconKind "ai"
$headerAutomationState = New-HeaderStatusCard -Left 824 -Title "AUTOMATION" -Value "OFF" -IconKind "timer"
$headerHealthState = New-HeaderStatusCard -Left 976 -Title "DASHBOARD HEALTH" -Value "UNKNOWN" -IconKind "health"

$panelHeaderAi = $headerAiState.Panel
$panelHeaderAutomation = $headerAutomationState.Panel
$panelHeaderHealth = $headerHealthState.Panel
$lblHeaderAi = $headerAiState.Value
$lblHeaderAutomation = $headerAutomationState.Value
$lblHeaderHealth = $headerHealthState.Value

$picHeaderAi = $headerAiState.Icon
$picHeaderAutomation = $headerAutomationState.Icon
$picHeaderHealth = $headerHealthState.Icon

$barHeaderAi = $headerAiState.Accent
$barHeaderAutomation = $headerAutomationState.Accent
$barHeaderHealth = $headerHealthState.Accent

$headerDivider = New-Object System.Windows.Forms.Panel
$headerDivider.Location = New-Object System.Drawing.Point(0,126)
$headerDivider.Size = New-Object System.Drawing.Size(1235,1)
$headerDivider.Anchor = "Top,Left,Right"
$header.Controls.Add($headerDivider)

function Update-HeaderStatus {
    try {
        $palette = Get-AghrabPalette -Theme $script:CurrentTheme

        # LOCAL AI
        $aiVisual = Get-HealthStatusVisual -Status "Unknown" -Theme $script:CurrentTheme
        if ($null -ne $lblHeaderAi) {
            if (Test-AiServerReady) {
                $lblHeaderAi.Text = Convert-AghrabUiText -Text "Ready" -Language $script:CurrentLanguage
                $aiVisual = Get-HealthStatusVisual -Status "Healthy" -Theme $script:CurrentTheme
            }
            elseif (Test-AiPackInstalled) {
                $lblHeaderAi.Text = Convert-AghrabUiText -Text "STOPPED" -Language $script:CurrentLanguage
                $aiVisual = Get-HealthStatusVisual -Status "Warning" -Theme $script:CurrentTheme
            }
            else {
                $lblHeaderAi.Text = Convert-AghrabUiText -Text "NOT INSTALLED" -Language $script:CurrentLanguage
                $aiVisual = Get-HealthStatusVisual -Status "Critical" -Theme $script:CurrentTheme
            }

            $lblHeaderAi.ForeColor = $aiVisual.Fore
            $panelHeaderAi.BackColor = $aiVisual.Back
            $barHeaderAi.BackColor = $aiVisual.Fore
        }

        # AUTOMATION
        $autoVisual = Get-HealthStatusVisual -Status "Unknown" -Theme $script:CurrentTheme
        if ($null -ne $lblHeaderAutomation) {
            if (Test-ElkSchedulerCaptchaPending) {
                $lblHeaderAutomation.Text = "CAPTCHA"
                $autoVisual = Get-HealthStatusVisual -Status "Warning" -Theme $script:CurrentTheme
            }
            elseif ($script:SchedulerBusy) {
                $lblHeaderAutomation.Text = Convert-AghrabUiText -Text "RUNNING" -Language $script:CurrentLanguage
                $autoVisual = Get-HealthStatusVisual -Status "Total" -Theme $script:CurrentTheme
            }
            elseif ($null -ne $chkSchedulerEnabled -and $chkSchedulerEnabled.Checked) {
                $lblHeaderAutomation.Text = Convert-AghrabUiText -Text "ON" -Language $script:CurrentLanguage
                $autoVisual = Get-HealthStatusVisual -Status "Healthy" -Theme $script:CurrentTheme
            }
            else {
                $lblHeaderAutomation.Text = Convert-AghrabUiText -Text "OFF" -Language $script:CurrentLanguage
            }

            $lblHeaderAutomation.ForeColor = $autoVisual.Fore
            $panelHeaderAutomation.BackColor = $autoVisual.Back
            $barHeaderAutomation.BackColor = $autoVisual.Fore
        }

        # DASHBOARD HEALTH
        $healthVisual = Get-HealthStatusVisual -Status "Unknown" -Theme $script:CurrentTheme
        if ($null -ne $lblHeaderHealth) {
            $critical = 0
            $warning = 0
            $unknown = 0

            try { $critical = [int]$lblHealthCriticalValue.Text } catch {}
            try { $warning = [int]$lblHealthWarningValue.Text } catch {}
            try { $unknown = [int]$lblHealthUnknownValue.Text } catch {}

            if ($critical -gt 0) {
                $lblHeaderHealth.Text = (Convert-AghrabUiText -Text "CRITICAL" -Language $script:CurrentLanguage) + "  " + $critical
                $healthVisual = Get-HealthStatusVisual -Status "Critical" -Theme $script:CurrentTheme
            }
            elseif ($warning -gt 0) {
                $lblHeaderHealth.Text = (Convert-AghrabUiText -Text "WARNING" -Language $script:CurrentLanguage) + "  " + $warning
                $healthVisual = Get-HealthStatusVisual -Status "Warning" -Theme $script:CurrentTheme
            }
            elseif ($unknown -gt 0) {
                $lblHeaderHealth.Text = (Convert-AghrabUiText -Text "UNKNOWN" -Language $script:CurrentLanguage) + "  " + $unknown
            }
            else {
                $lblHeaderHealth.Text = Convert-AghrabUiText -Text "HEALTHY" -Language $script:CurrentLanguage
                $healthVisual = Get-HealthStatusVisual -Status "Healthy" -Theme $script:CurrentTheme
            }

            $lblHeaderHealth.ForeColor = $healthVisual.Fore
            $panelHeaderHealth.BackColor = $healthVisual.Back
            $barHeaderHealth.BackColor = $healthVisual.Fore
        }

        foreach ($headerPanel in @($panelHeaderAi,$panelHeaderAutomation,$panelHeaderHealth)) {
            if ($null -ne $headerPanel) {
                Set-RoundedControlRegion -Control $headerPanel -Radius 11
            }
        }
    }
    catch {}
}

# Tabs
$tabs = New-Object System.Windows.Forms.TabControl
$tabs.Location = New-Object System.Drawing.Point(224,145)
$tabs.Size = New-Object System.Drawing.Size(981,715)
$tabs.Anchor = "Top,Bottom,Left,Right"
$form.Controls.Add($tabs)

$tabs.DrawMode = [System.Windows.Forms.TabDrawMode]::OwnerDrawFixed
$tabs.SizeMode = [System.Windows.Forms.TabSizeMode]::Fixed
$tabs.ItemSize = New-Object System.Drawing.Size(138,36)
$tabs.Padding = New-Object System.Drawing.Point(18,6)

$tabs.Add_DrawItem({
    param($sender, $e)

    try {
        $palette = Get-AghrabPalette -Theme $script:CurrentTheme
        $selected = ($e.Index -eq $sender.SelectedIndex)
        $rect = $e.Bounds

        $back = $(if ($selected) { $palette.Surface } else { $palette.Header })
        $fore = $(if ($selected) { $palette.Text } else { $palette.Muted })
        $border = $(if ($selected) { $palette.Border } else { $palette.BorderSoft })

        $backBrush = New-Object System.Drawing.SolidBrush($back)
        $borderPen = New-Object System.Drawing.Pen($border)
        try {
            $e.Graphics.FillRectangle($backBrush, $rect)
            $e.Graphics.DrawRectangle($borderPen, $rect.X, $rect.Y, $rect.Width - 1, $rect.Height - 1)

            if ($selected) {
                $accentBrush = New-Object System.Drawing.SolidBrush($palette.Accent)
                try {
                    $accentRect = New-Object System.Drawing.Rectangle(
                        $rect.X + 10,
                        $rect.Bottom - 4,
                        $rect.Width - 20,
                        3
                    )
                    $e.Graphics.FillRectangle($accentBrush, $accentRect)
                }
                finally {
                    $accentBrush.Dispose()
                }
            }

            $innerRect = New-Object System.Drawing.Rectangle(
                $rect.X + 6,
                $rect.Y + 2,
                $rect.Width - 12,
                $rect.Height - 8
            )

            [System.Windows.Forms.TextRenderer]::DrawText(
                $e.Graphics,
                [string]$sender.TabPages[$e.Index].Text,
                $sender.Font,
                $innerRect,
                $fore,
                [System.Windows.Forms.TextFormatFlags]::HorizontalCenter -bor
                [System.Windows.Forms.TextFormatFlags]::VerticalCenter -bor
                [System.Windows.Forms.TextFormatFlags]::EndEllipsis
            )
        }
        finally {
            $backBrush.Dispose()
            $borderPen.Dispose()
        }
    }
    catch {}
})
$tabs.Add_SelectedIndexChanged({ $tabs.Invalidate() })

# Sidebar navigation replaces visible TabControl headers.
$tabs.DrawMode = [System.Windows.Forms.TabDrawMode]::Normal
$tabs.Appearance = [System.Windows.Forms.TabAppearance]::Buttons
$tabs.SizeMode = [System.Windows.Forms.TabSizeMode]::Fixed
$tabs.ItemSize = New-Object System.Drawing.Size(0,1)
$tabs.Padding = New-Object System.Drawing.Point(0,0)

$tabCapture = New-Object System.Windows.Forms.TabPage
$tabCapture.Text = "Capture"
$tabCapture.BackColor = $Light

$tabHealth = New-Object System.Windows.Forms.TabPage
$tabHealth.Text = "Health Center"
$tabHealth.BackColor = $Light

$tabElk = New-Object System.Windows.Forms.TabPage
$tabElk.Text = "ELK Profiles"
$tabElk.BackColor = $Light

$tabScheduler = New-Object System.Windows.Forms.TabPage
$tabScheduler.Text = "Automatic Capture"
$tabScheduler.BackColor = $Light

$tabGallery = New-Object System.Windows.Forms.TabPage
$tabGallery.Text = "Gallery"
$tabGallery.BackColor = $Light

$tabAnalyze = New-Object System.Windows.Forms.TabPage
$tabAnalyze.Text = "Analyze"
$tabAnalyze.BackColor = $Light

$tabSecurity = New-Object System.Windows.Forms.TabPage
$tabSecurity.Text = "Security"
$tabSecurity.BackColor = $Light

$tabSettings = New-Object System.Windows.Forms.TabPage
$tabSettings.Text = "Settings"
$tabSettings.BackColor = $Light

$tabs.TabPages.Add($tabHealth)
$tabs.TabPages.Add($tabElk)
$tabs.TabPages.Add($tabScheduler)
$tabs.TabPages.Add($tabGallery)
$tabs.TabPages.Add($tabAnalyze)
$tabs.TabPages.Add($tabSecurity)
$tabs.TabPages.Add($tabSettings)

# Keep the stable v7.6.3 fixed geometry, but allow scrollbars when
# monitor height / DPI cannot show the full page.
foreach ($workspacePage in @(
    $tabCapture,
    $tabHealth,
    $tabElk,
    $tabScheduler,
    $tabGallery,
    $tabAnalyze,
    $tabSecurity,
    $tabSettings
)) {
    $workspacePage.AutoScroll = $true
}

# ---------------- SIDEBAR NAVIGATION ----------------
$sideNav = New-Object System.Windows.Forms.Panel
$sideNav.Location = New-Object System.Drawing.Point(20,145)
$sideNav.Size = New-Object System.Drawing.Size(184,715)
$sideNav.Anchor = "Top,Bottom,Left"
$sideNav.Tag = "sidebar"
$form.Controls.Add($sideNav)

$lblSideNav = New-Object System.Windows.Forms.Label
$lblSideNav.Text = "WORKSPACE  •  SOC"
$lblSideNav.Font = New-Object System.Drawing.Font("Segoe UI Semibold",8)
$lblSideNav.Location = New-Object System.Drawing.Point(18,18)
$lblSideNav.Size = New-Object System.Drawing.Size(150,20)
$sideNav.Controls.Add($lblSideNav)

function New-SideNavButton {
    param(
        [string]$Text,
        [int]$Top
    )

    $b = New-Object System.Windows.Forms.Button
    $b.Text = $Text
    $b.Location = New-Object System.Drawing.Point(10,$Top)
    $b.Size = New-Object System.Drawing.Size(164,46)
    $b.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $b.FlatAppearance.BorderSize = 0
    $b.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $b.Padding = New-Object System.Windows.Forms.Padding(10,0,0,0)
    $b.Font = New-Object System.Drawing.Font("Segoe UI",10.25)
    $b.Tag = "nav"
    $b.Cursor = [System.Windows.Forms.Cursors]::Hand
    Set-RoundedControlRegion -Control $b -Radius 10
    [void]$sideNav.Controls.Add($b)
    return $b
}

$btnNavHealth = New-SideNavButton -Text "Health Center" -Top 52
$btnNavElk = New-SideNavButton -Text "ELK Profiles" -Top 106
$btnNavScheduler = New-SideNavButton -Text "Automatic Capture" -Top 160
$btnNavGallery = New-SideNavButton -Text "Gallery" -Top 214
$btnNavAnalyze = New-SideNavButton -Text "Analyze" -Top 268
$btnNavSecurity = New-SideNavButton -Text "Security" -Top 322
$btnNavSettings = New-SideNavButton -Text "Settings" -Top 376

$lblSideInfo = New-Object System.Windows.Forms.Label
$lblSideInfo.Text = "RAQEB SENTINEL PRO`r`nVisual SOC Intelligence"
$lblSideInfo.Font = New-Object System.Drawing.Font("Segoe UI",8.5)
$lblSideInfo.Location = New-Object System.Drawing.Point(18,640)
$lblSideInfo.Size = New-Object System.Drawing.Size(150,48)
$lblSideInfo.Anchor = "Left,Bottom"
$sideNav.Controls.Add($lblSideInfo)

function Update-SidebarNavigation {
    $palette = Get-AghrabPalette -Theme $script:CurrentTheme

    $pairs = @(
        @($btnNavHealth, $tabHealth),
        @($btnNavElk, $tabElk),
        @($btnNavScheduler, $tabScheduler),
        @($btnNavGallery, $tabGallery),
        @($btnNavAnalyze, $tabAnalyze),
        @($btnNavSecurity, $tabSecurity),
        @($btnNavSettings, $tabSettings)
    )

    foreach ($pair in $pairs) {
        $button = $pair[0]
        $page = $pair[1]
        $active = ($tabs.SelectedTab -eq $page)

        $button.FlatAppearance.BorderSize = 0
        $button.FlatAppearance.MouseDownBackColor = $palette.Selection

        if ($active) {
            $button.BackColor = $(if ($script:CurrentTheme -eq "Dark") { $palette.Selection } else { [System.Drawing.Color]::FromArgb(223,244,242) })
            $button.ForeColor = $palette.Accent
            $button.FlatAppearance.MouseOverBackColor = $(if ($script:CurrentTheme -eq "Dark") { $palette.Selection } else { [System.Drawing.Color]::FromArgb(214,240,237) })
            $button.Font = New-Object System.Drawing.Font("Segoe UI Semibold",10.25,[System.Drawing.FontStyle]::Bold)
        }
        else {
            $button.BackColor = $palette.Sidebar
            $button.ForeColor = $palette.Text
            $button.FlatAppearance.MouseOverBackColor = $palette.Surface2
            $button.Font = New-Object System.Drawing.Font("Segoe UI",10.25)
        }

        $iconKind = $(
            if ($button -eq $btnNavHealth) { "health" }
            elseif ($button -eq $btnNavElk) { "profiles" }
            elseif ($button -eq $btnNavScheduler) { "timer" }
            elseif ($button -eq $btnNavGallery) { "gallery" }
            elseif ($button -eq $btnNavAnalyze) { "ai" }
            elseif ($button -eq $btnNavSecurity) { "shield" }
            elseif ($button -eq $btnNavSettings) { "settings" }
            else { "dot" }
        )

        $iconColor = $(if ($active) { $palette.Accent } else { $(if ($script:CurrentTheme -eq "Dark") { $palette.Muted } else { [System.Drawing.Color]::FromArgb(82,98,112) }) })
        Set-AghrabButtonIcon -Button $button -Kind $iconKind -Color $iconColor

        Set-RoundedControlRegion -Control $button -Radius 10
    }

    $lblSideNav.ForeColor = $palette.Muted
    $lblSideInfo.ForeColor = $palette.Muted
    $sideNav.BackColor = $palette.Sidebar
}

$btnNavHealth.Add_Click({
    $tabs.SelectedTab = $tabHealth
    Refresh-HealthManagerProfiles
    Refresh-HealthCenter
    Update-SidebarNavigation
})
$btnNavElk.Add_Click({ $tabs.SelectedTab = $tabElk; Update-SidebarNavigation })
$btnNavScheduler.Add_Click({ $tabs.SelectedTab = $tabScheduler; Refresh-SchedulerProfiles; Update-SchedulerStateUi; Update-SidebarNavigation })
$btnNavGallery.Add_Click({ $tabs.SelectedTab = $tabGallery; Update-SidebarNavigation })
$btnNavAnalyze.Add_Click({ $tabs.SelectedTab = $tabAnalyze; Update-SidebarNavigation })
$btnNavSecurity.Add_Click({ $tabs.SelectedTab = $tabSecurity; Update-SecurityCenter; Update-SidebarNavigation })
$btnNavSettings.Add_Click({ $tabs.SelectedTab = $tabSettings; Update-SidebarNavigation })
$tabs.Add_SelectedIndexChanged({
    try {
        if (-not (Test-AghrabUiPageAllowed -Page $tabs.SelectedTab)) {
            $tabs.SelectedTab = $tabGallery
        }
    }
    catch {}

    Update-SidebarNavigation
})

$font = New-Object System.Drawing.Font("Segoe UI",10)

# ---------------- CAPTURE TAB ----------------
$lblBrowser = New-Object System.Windows.Forms.Label
$lblBrowser.Text = "Browser:"
$lblBrowser.Font = $font
$lblBrowser.Location = New-Object System.Drawing.Point(16,20)
$lblBrowser.AutoSize = $true
$tabCapture.Controls.Add($lblBrowser)

$txtBrowser = New-Object System.Windows.Forms.TextBox
$txtBrowser.Location = New-Object System.Drawing.Point(90,16)
$txtBrowser.Size = New-Object System.Drawing.Size(645,28)
$txtBrowser.Anchor = "Top,Left,Right"
$tabCapture.Controls.Add($txtBrowser)

$btnDetect = New-Object System.Windows.Forms.Button
$btnDetect.Text = "Auto Detect"
$btnDetect.Location = New-Object System.Drawing.Point(745,14)
$btnDetect.Size = New-Object System.Drawing.Size(96,32)
$btnDetect.Anchor = "Top,Right"
Style-SecondaryButton $btnDetect
$tabCapture.Controls.Add($btnDetect)

$btnBrowserBrowse = New-Object System.Windows.Forms.Button
$btnBrowserBrowse.Text = "Browse..."
$btnBrowserBrowse.Location = New-Object System.Drawing.Point(849,14)
$btnBrowserBrowse.Size = New-Object System.Drawing.Size(101,32)
$btnBrowserBrowse.Anchor = "Top,Right"
Style-SecondaryButton $btnBrowserBrowse
$tabCapture.Controls.Add($btnBrowserBrowse)

$lblBrowserStatus = New-Object System.Windows.Forms.Label
$lblBrowserStatus.Location = New-Object System.Drawing.Point(90,48)
$lblBrowserStatus.Size = New-Object System.Drawing.Size(800,20)
$tabCapture.Controls.Add($lblBrowserStatus)

$lblUrls = New-Object System.Windows.Forms.Label
$lblUrls.Text = "URL / IP list (one per line):"
$lblUrls.Font = $font
$lblUrls.ForeColor = $Navy
$lblUrls.Location = New-Object System.Drawing.Point(16,76)
$lblUrls.AutoSize = $true
$tabCapture.Controls.Add($lblUrls)

$txtUrls = New-Object System.Windows.Forms.TextBox
$txtUrls.Multiline = $true
$txtUrls.ScrollBars = "Both"
$txtUrls.WordWrap = $false
$txtUrls.Font = New-Object System.Drawing.Font("Consolas",10)
$txtUrls.Location = New-Object System.Drawing.Point(16,103)
$txtUrls.Size = New-Object System.Drawing.Size(934,210)
$txtUrls.Anchor = "Top,Left,Right"
$tabCapture.Controls.Add($txtUrls)

$btnImport = New-Object System.Windows.Forms.Button
$btnImport.Text = "Import TXT"
$btnImport.Location = New-Object System.Drawing.Point(16,323)
$btnImport.Size = New-Object System.Drawing.Size(110,32)
Style-SecondaryButton $btnImport
$tabCapture.Controls.Add($btnImport)

$btnClear = New-Object System.Windows.Forms.Button
$btnClear.Text = "Clear"
$btnClear.Location = New-Object System.Drawing.Point(136,323)
$btnClear.Size = New-Object System.Drawing.Size(80,32)
Style-SecondaryButton $btnClear
$tabCapture.Controls.Add($btnClear)

$lblOutput = New-Object System.Windows.Forms.Label
$lblOutput.Text = "Output folder:"
$lblOutput.Font = $font
$lblOutput.Location = New-Object System.Drawing.Point(16,374)
$lblOutput.AutoSize = $true
$tabCapture.Controls.Add($lblOutput)

$txtOutput = New-Object System.Windows.Forms.TextBox
$desktop = [Environment]::GetFolderPath("Desktop")
$txtOutput.Text = Join-Path $desktop "aghrab"
$txtOutput.Location = New-Object System.Drawing.Point(126,370)
$txtOutput.Size = New-Object System.Drawing.Size(705,28)
$txtOutput.Anchor = "Top,Left,Right"
$tabCapture.Controls.Add($txtOutput)

$btnBrowse = New-Object System.Windows.Forms.Button
$btnBrowse.Text = "Browse"
$btnBrowse.Location = New-Object System.Drawing.Point(839,368)
$btnBrowse.Size = New-Object System.Drawing.Size(111,32)
$btnBrowse.Anchor = "Top,Right"
Style-SecondaryButton $btnBrowse
$tabCapture.Controls.Add($btnBrowse)

$lblTimeout = New-Object System.Windows.Forms.Label
$lblTimeout.Text = "Timeout:"
$lblTimeout.Location = New-Object System.Drawing.Point(16,418)
$lblTimeout.AutoSize = $true
$tabCapture.Controls.Add($lblTimeout)

$numTimeout = New-Object System.Windows.Forms.NumericUpDown
$numTimeout.Minimum = 5
$numTimeout.Maximum = 180
$numTimeout.Value = 30
$numTimeout.Location = New-Object System.Drawing.Point(84,414)
$numTimeout.Size = New-Object System.Drawing.Size(72,28)
$tabCapture.Controls.Add($numTimeout)

$lblSec = New-Object System.Windows.Forms.Label
$lblSec.Text = "sec"
$lblSec.Location = New-Object System.Drawing.Point(164,418)
$lblSec.AutoSize = $true
$tabCapture.Controls.Add($lblSec)

$lblWaitAfterLoad = New-Object System.Windows.Forms.Label
$lblWaitAfterLoad.Text = "Wait after load:"
$lblWaitAfterLoad.Location = New-Object System.Drawing.Point(220,418)
$lblWaitAfterLoad.AutoSize = $true
$tabCapture.Controls.Add($lblWaitAfterLoad)

$numWaitAfterLoad = New-Object System.Windows.Forms.NumericUpDown
$numWaitAfterLoad.Minimum = 0
$numWaitAfterLoad.Maximum = 60
$numWaitAfterLoad.Value = 8
$numWaitAfterLoad.Location = New-Object System.Drawing.Point(322,414)
$numWaitAfterLoad.Size = New-Object System.Drawing.Size(60,28)
$tabCapture.Controls.Add($numWaitAfterLoad)

$lblWaitSec = New-Object System.Windows.Forms.Label
$lblWaitSec.Text = "sec"
$lblWaitSec.Location = New-Object System.Drawing.Point(388,418)
$lblWaitSec.AutoSize = $true
$tabCapture.Controls.Add($lblWaitSec)

$lblWidth = New-Object System.Windows.Forms.Label
$lblWidth.Text = "Width:"
$lblWidth.Location = New-Object System.Drawing.Point(16,455)
$lblWidth.AutoSize = $true
$tabCapture.Controls.Add($lblWidth)

$numWidth = New-Object System.Windows.Forms.NumericUpDown
$numWidth.Minimum = 800
$numWidth.Maximum = 7680
$numWidth.Value = 1920
$numWidth.Location = New-Object System.Drawing.Point(66,451)
$numWidth.Size = New-Object System.Drawing.Size(90,28)
$tabCapture.Controls.Add($numWidth)

$lblHeight = New-Object System.Windows.Forms.Label
$lblHeight.Text = "Height:"
$lblHeight.Location = New-Object System.Drawing.Point(190,455)
$lblHeight.AutoSize = $true
$tabCapture.Controls.Add($lblHeight)

$numHeight = New-Object System.Windows.Forms.NumericUpDown
$numHeight.Minimum = 600
$numHeight.Maximum = 12000
$numHeight.Value = 1080
$numHeight.Location = New-Object System.Drawing.Point(250,451)
$numHeight.Size = New-Object System.Drawing.Size(90,28)
$tabCapture.Controls.Add($numHeight)

$chkIgnoreCert = New-Object System.Windows.Forms.CheckBox
$chkIgnoreCert.Text = "Ignore HTTPS certificate errors"
$chkIgnoreCert.Checked = $true
$chkIgnoreCert.Location = New-Object System.Drawing.Point(390,453)
$chkIgnoreCert.AutoSize = $true
$tabCapture.Controls.Add($chkIgnoreCert)

$lblScrollDelay = New-Object System.Windows.Forms.Label
$lblScrollDelay.Text = "Scroll delay:"
$lblScrollDelay.Location = New-Object System.Drawing.Point(650,455)
$lblScrollDelay.AutoSize = $true
$tabCapture.Controls.Add($lblScrollDelay)

$numScrollDelay = New-Object System.Windows.Forms.NumericUpDown
$numScrollDelay.Minimum = 100
$numScrollDelay.Maximum = 5000
$numScrollDelay.Increment = 100
$numScrollDelay.Value = 900
$numScrollDelay.Location = New-Object System.Drawing.Point(735,451)
$numScrollDelay.Size = New-Object System.Drawing.Size(72,28)
$tabCapture.Controls.Add($numScrollDelay)

$lblScrollDelayMs = New-Object System.Windows.Forms.Label
$lblScrollDelayMs.Text = "ms"
$lblScrollDelayMs.Location = New-Object System.Drawing.Point(814,455)
$lblScrollDelayMs.AutoSize = $true
$tabCapture.Controls.Add($lblScrollDelayMs)

$chkFullPage = New-Object System.Windows.Forms.CheckBox
$chkFullPage.Text = "Full Page (auto-scroll)"
$chkFullPage.Checked = $true
$chkFullPage.Location = New-Object System.Drawing.Point(440,416)
$chkFullPage.AutoSize = $true
$tabCapture.Controls.Add($chkFullPage)

$lblFinalSettle = New-Object System.Windows.Forms.Label
$lblFinalSettle.Text = "Final settle:"
$lblFinalSettle.Location = New-Object System.Drawing.Point(650,418)
$lblFinalSettle.AutoSize = $true
$tabCapture.Controls.Add($lblFinalSettle)

$numFinalSettle = New-Object System.Windows.Forms.NumericUpDown
$numFinalSettle.Minimum = 0
$numFinalSettle.Maximum = 30
$numFinalSettle.Value = 3
$numFinalSettle.Location = New-Object System.Drawing.Point(730,414)
$numFinalSettle.Size = New-Object System.Drawing.Size(58,28)
$tabCapture.Controls.Add($numFinalSettle)

$lblFinalSettleSec = New-Object System.Windows.Forms.Label
$lblFinalSettleSec.Text = "sec"
$lblFinalSettleSec.Location = New-Object System.Drawing.Point(795,418)
$lblFinalSettleSec.AutoSize = $true
$tabCapture.Controls.Add($lblFinalSettleSec)


$btnStart = New-Object System.Windows.Forms.Button
$btnStart.Text = "START SCREENSHOT"
$btnStart.Font = New-Object System.Drawing.Font("Segoe UI",10,[System.Drawing.FontStyle]::Bold)
$btnStart.Location = New-Object System.Drawing.Point(16,497)
$btnStart.Size = New-Object System.Drawing.Size(175,44)
Style-PrimaryButton $btnStart
$tabCapture.Controls.Add($btnStart)

$btnStop = New-Object System.Windows.Forms.Button
$btnStop.Text = "STOP"
$btnStop.Font = New-Object System.Drawing.Font("Segoe UI",10,[System.Drawing.FontStyle]::Bold)
$btnStop.Location = New-Object System.Drawing.Point(201,497)
$btnStop.Size = New-Object System.Drawing.Size(95,44)
$btnStop.Enabled = $false
$btnStop.FlatStyle = "Flat"
$btnStop.FlatAppearance.BorderSize = 0
$btnStop.BackColor = [System.Drawing.Color]::FromArgb(210,58,58)
$btnStop.ForeColor = [System.Drawing.Color]::White
$btnStop.Cursor = [System.Windows.Forms.Cursors]::Hand
$tabCapture.Controls.Add($btnStop)

$btnOpenOutput = New-Object System.Windows.Forms.Button
$btnOpenOutput.Text = "Open Output"
$btnOpenOutput.Location = New-Object System.Drawing.Point(306,497)
$btnOpenOutput.Size = New-Object System.Drawing.Size(115,44)
Style-SecondaryButton $btnOpenOutput
$tabCapture.Controls.Add($btnOpenOutput)

$progress = New-Object System.Windows.Forms.ProgressBar
$progress.Style = [System.Windows.Forms.ProgressBarStyle]::Continuous
$progress.Location = New-Object System.Drawing.Point(436,506)
$progress.Size = New-Object System.Drawing.Size(514,26)
$progress.Anchor = "Top,Left,Right"
$tabCapture.Controls.Add($progress)

$lblStatus = New-Object System.Windows.Forms.Label
$lblStatus.Text = "Ready"
$lblStatus.ForeColor = $Navy
$lblStatus.Location = New-Object System.Drawing.Point(16,555)
$lblStatus.Size = New-Object System.Drawing.Size(934,22)
$lblStatus.Anchor = "Top,Left,Right"
$tabCapture.Controls.Add($lblStatus)

$txtLog = New-Object System.Windows.Forms.TextBox
$txtLog.Multiline = $true
$txtLog.ReadOnly = $true
$txtLog.ScrollBars = "Vertical"
$txtLog.Font = New-Object System.Drawing.Font("Consolas",9)
$txtLog.Location = New-Object System.Drawing.Point(16,583)
$txtLog.Size = New-Object System.Drawing.Size(934,90)
$txtLog.Anchor = "Top,Bottom,Left,Right"
$tabCapture.Controls.Add($txtLog)


# ---------------- ELK PROFILES TAB ----------------
$lblElkProfiles = New-Object System.Windows.Forms.Label
$lblElkProfiles.Text = "Profiles"
$lblElkProfiles.Font = $font
$lblElkProfiles.ForeColor = $Navy
$lblElkProfiles.Location = New-Object System.Drawing.Point(16,18)
$lblElkProfiles.AutoSize = $true
$lblElkProfiles.Tag = "section"
$lblElkProfiles.Font = New-Object System.Drawing.Font("Segoe UI",10,[System.Drawing.FontStyle]::Bold)
$tabElk.Controls.Add($lblElkProfiles)

$lstElkProfiles = New-Object System.Windows.Forms.ListBox
$lstElkProfiles.Location = New-Object System.Drawing.Point(16,44)
$lstElkProfiles.Size = New-Object System.Drawing.Size(205,245)
$lstElkProfiles.Font = New-Object System.Drawing.Font("Segoe UI",9.5)
$tabElk.Controls.Add($lstElkProfiles)

$btnElkNewProfile = New-Object System.Windows.Forms.Button
$btnElkNewProfile.Text = "New Profile"
$btnElkNewProfile.Location = New-Object System.Drawing.Point(16,299)
$btnElkNewProfile.Size = New-Object System.Drawing.Size(95,32)
Style-SecondaryButton $btnElkNewProfile
$tabElk.Controls.Add($btnElkNewProfile)

$btnElkDeleteProfile = New-Object System.Windows.Forms.Button
$btnElkDeleteProfile.Text = "Delete Profile"
$btnElkDeleteProfile.Location = New-Object System.Drawing.Point(121,299)
$btnElkDeleteProfile.Size = New-Object System.Drawing.Size(100,32)
$btnElkDeleteProfile.FlatStyle = "Flat"
$btnElkDeleteProfile.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(210,58,58)
$btnElkDeleteProfile.BackColor = [System.Drawing.Color]::White
$btnElkDeleteProfile.ForeColor = [System.Drawing.Color]::FromArgb(180,35,35)
$tabElk.Controls.Add($btnElkDeleteProfile)

$lblElkHint = New-Object System.Windows.Forms.Label
$lblElkHint.Text = "Manual login:`r`n1. Open Login Browser`r`n2. Login / solve CAPTCHA`r`n3. KEEP browser open`r`n4. Capture All`r`nSession is reused while valid."
$lblElkHint.Location = New-Object System.Drawing.Point(16,350)
$lblElkHint.Size = New-Object System.Drawing.Size(205,100)
$lblElkHint.ForeColor = [System.Drawing.Color]::DimGray
$tabElk.Controls.Add($lblElkHint)

$grpElkAuth = New-Object System.Windows.Forms.GroupBox
$grpElkAuth.Text = "Authentication"
$grpElkAuth.Location = New-Object System.Drawing.Point(245,92)
$grpElkAuth.Size = New-Object System.Drawing.Size(680,95)
$tabElk.Controls.Add($grpElkAuth)

$chkElkAutoLogin = New-Object System.Windows.Forms.CheckBox
$chkElkAutoLogin.Text = "Auto Login before Capture"
$chkElkAutoLogin.Location = New-Object System.Drawing.Point(12,32)
$chkElkAutoLogin.Size = New-Object System.Drawing.Size(190,22)
$grpElkAuth.Controls.Add($chkElkAutoLogin)

$lblElkAuthUser = New-Object System.Windows.Forms.Label
$lblElkAuthUser.Text = "Username:"
$lblElkAuthUser.Location = New-Object System.Drawing.Point(210,20)
$lblElkAuthUser.AutoSize = $true
$grpElkAuth.Controls.Add($lblElkAuthUser)

$txtElkAuthUser = New-Object System.Windows.Forms.TextBox
$txtElkAuthUser.Location = New-Object System.Drawing.Point(210,42)
$txtElkAuthUser.Size = New-Object System.Drawing.Size(145,26)
$grpElkAuth.Controls.Add($txtElkAuthUser)

$lblElkAuthPassword = New-Object System.Windows.Forms.Label
$lblElkAuthPassword.Text = "Password:"
$lblElkAuthPassword.Location = New-Object System.Drawing.Point(370,20)
$lblElkAuthPassword.AutoSize = $true
$grpElkAuth.Controls.Add($lblElkAuthPassword)

$txtElkAuthPassword = New-Object System.Windows.Forms.TextBox
$txtElkAuthPassword.Location = New-Object System.Drawing.Point(370,42)
$txtElkAuthPassword.Size = New-Object System.Drawing.Size(145,26)
$txtElkAuthPassword.UseSystemPasswordChar = $true
$grpElkAuth.Controls.Add($txtElkAuthPassword)

$btnElkTestLogin = New-Object System.Windows.Forms.Button
$btnElkTestLogin.Text = "Test Auto Login"
$btnElkTestLogin.Location = New-Object System.Drawing.Point(535,35)
$btnElkTestLogin.Size = New-Object System.Drawing.Size(128,32)
Style-SecondaryButton $btnElkTestLogin
$grpElkAuth.Controls.Add($btnElkTestLogin)

$btnElkContinueCaptcha = New-Object System.Windows.Forms.Button
$btnElkContinueCaptcha.Text = "Continue CAPTCHA"
$btnElkContinueCaptcha.Location = New-Object System.Drawing.Point(535,66)
$btnElkContinueCaptcha.Size = New-Object System.Drawing.Size(128,22)
$btnElkContinueCaptcha.Enabled = $false
Style-SecondaryButton $btnElkContinueCaptcha
$grpElkAuth.Controls.Add($btnElkContinueCaptcha)

$lblElkProfileName = New-Object System.Windows.Forms.Label
$lblElkProfileName.Text = "Profile name:"
$lblElkProfileName.Location = New-Object System.Drawing.Point(245,20)
$lblElkProfileName.AutoSize = $true
$tabElk.Controls.Add($lblElkProfileName)

$txtElkProfileName = New-Object System.Windows.Forms.TextBox
$txtElkProfileName.Location = New-Object System.Drawing.Point(340,16)
$txtElkProfileName.Size = New-Object System.Drawing.Size(250,28)
$tabElk.Controls.Add($txtElkProfileName)

$lblElkKibanaUrl = New-Object System.Windows.Forms.Label
$lblElkKibanaUrl.Text = "Kibana URL:"
$lblElkKibanaUrl.Location = New-Object System.Drawing.Point(245,57)
$lblElkKibanaUrl.AutoSize = $true
$tabElk.Controls.Add($lblElkKibanaUrl)

$txtElkKibanaUrl = New-Object System.Windows.Forms.TextBox
$txtElkKibanaUrl.Location = New-Object System.Drawing.Point(340,53)
$txtElkKibanaUrl.Size = New-Object System.Drawing.Size(585,28)
$txtElkKibanaUrl.Anchor = "Top,Left,Right"
$tabElk.Controls.Add($txtElkKibanaUrl)

$btnElkSaveProfile = New-Object System.Windows.Forms.Button
$btnElkSaveProfile.Text = "Save Profile"
$btnElkSaveProfile.Location = New-Object System.Drawing.Point(610,14)
$btnElkSaveProfile.Size = New-Object System.Drawing.Size(100,32)
Style-SecondaryButton $btnElkSaveProfile
$tabElk.Controls.Add($btnElkSaveProfile)

$btnElkLoginBrowser = New-Object System.Windows.Forms.Button
$btnElkLoginBrowser.Text = "Login Browser"
$btnElkLoginBrowser.Location = New-Object System.Drawing.Point(720,14)
$btnElkLoginBrowser.Size = New-Object System.Drawing.Size(112,32)
Style-SecondaryButton $btnElkLoginBrowser
$tabElk.Controls.Add($btnElkLoginBrowser)

$lblElkSessionStatus = New-Object System.Windows.Forms.Label
$lblElkSessionStatus.Text = "Session: not connected"
$lblElkSessionStatus.Location = New-Object System.Drawing.Point(610,48)
$lblElkSessionStatus.Size = New-Object System.Drawing.Size(315,22)
$lblElkSessionStatus.ForeColor = [System.Drawing.Color]::DarkRed
$tabElk.Controls.Add($lblElkSessionStatus)

$btnElkCaptureAll = New-Object System.Windows.Forms.Button
$btnElkCaptureAll.Text = "Capture All Dashboards"
$btnElkCaptureAll.Location = New-Object System.Drawing.Point(245,200)
$btnElkCaptureAll.Size = New-Object System.Drawing.Size(180,40)
Style-PrimaryButton $btnElkCaptureAll
$tabElk.Controls.Add($btnElkCaptureAll)

$btnElkStop = New-Object System.Windows.Forms.Button
$btnElkStop.Text = "STOP"
$btnElkStop.Location = New-Object System.Drawing.Point(435,200)
$btnElkStop.Size = New-Object System.Drawing.Size(90,40)
$btnElkStop.Enabled = $false
$btnElkStop.FlatStyle = "Flat"
$btnElkStop.FlatAppearance.BorderSize = 0
$btnElkStop.BackColor = [System.Drawing.Color]::FromArgb(210,58,58)
$btnElkStop.ForeColor = [System.Drawing.Color]::White
$tabElk.Controls.Add($btnElkStop)

$lblElkWait = New-Object System.Windows.Forms.Label
$lblElkWait.Text = "Load wait:"
$lblElkWait.Location = New-Object System.Drawing.Point(550,210)
$lblElkWait.AutoSize = $true
$tabElk.Controls.Add($lblElkWait)

$numElkWait = New-Object System.Windows.Forms.NumericUpDown
$numElkWait.Minimum = 0
$numElkWait.Maximum = 60
$numElkWait.Value = 12
$numElkWait.Location = New-Object System.Drawing.Point(620,206)
$numElkWait.Size = New-Object System.Drawing.Size(55,28)
$tabElk.Controls.Add($numElkWait)

$lblElkWaitSec = New-Object System.Windows.Forms.Label
$lblElkWaitSec.Text = "sec"
$lblElkWaitSec.Location = New-Object System.Drawing.Point(680,210)
$lblElkWaitSec.AutoSize = $true
$tabElk.Controls.Add($lblElkWaitSec)

$lblElkTimeout = New-Object System.Windows.Forms.Label
$lblElkTimeout.Text = "Timeout:"
$lblElkTimeout.Location = New-Object System.Drawing.Point(735,210)
$lblElkTimeout.AutoSize = $true
$tabElk.Controls.Add($lblElkTimeout)

$numElkTimeout = New-Object System.Windows.Forms.NumericUpDown
$numElkTimeout.Minimum = 10
$numElkTimeout.Maximum = 180
$numElkTimeout.Value = 60
$numElkTimeout.Location = New-Object System.Drawing.Point(795,206)
$numElkTimeout.Size = New-Object System.Drawing.Size(60,28)
$tabElk.Controls.Add($numElkTimeout)

$lblElkTimeoutSec = New-Object System.Windows.Forms.Label
$lblElkTimeoutSec.Text = "sec"
$lblElkTimeoutSec.Location = New-Object System.Drawing.Point(860,210)
$lblElkTimeoutSec.AutoSize = $true
$tabElk.Controls.Add($lblElkTimeoutSec)

$lblElkScroll = New-Object System.Windows.Forms.Label
$lblElkScroll.Text = "Scroll:"
$lblElkScroll.Location = New-Object System.Drawing.Point(245,255)
$lblElkScroll.AutoSize = $true
$tabElk.Controls.Add($lblElkScroll)

$numElkScrollDelay = New-Object System.Windows.Forms.NumericUpDown
$numElkScrollDelay.Minimum = 100
$numElkScrollDelay.Maximum = 5000
$numElkScrollDelay.Increment = 100
$numElkScrollDelay.Value = 1200
$numElkScrollDelay.Location = New-Object System.Drawing.Point(295,251)
$numElkScrollDelay.Size = New-Object System.Drawing.Size(75,28)
$tabElk.Controls.Add($numElkScrollDelay)

$lblElkScrollMs = New-Object System.Windows.Forms.Label
$lblElkScrollMs.Text = "ms"
$lblElkScrollMs.Location = New-Object System.Drawing.Point(375,255)
$lblElkScrollMs.AutoSize = $true
$tabElk.Controls.Add($lblElkScrollMs)

$lblElkSettle = New-Object System.Windows.Forms.Label
$lblElkSettle.Text = "Final settle:"
$lblElkSettle.Location = New-Object System.Drawing.Point(435,255)
$lblElkSettle.AutoSize = $true
$tabElk.Controls.Add($lblElkSettle)

$numElkFinalSettle = New-Object System.Windows.Forms.NumericUpDown
$numElkFinalSettle.Minimum = 0
$numElkFinalSettle.Maximum = 30
$numElkFinalSettle.Value = 5
$numElkFinalSettle.Location = New-Object System.Drawing.Point(520,251)
$numElkFinalSettle.Size = New-Object System.Drawing.Size(55,28)
$tabElk.Controls.Add($numElkFinalSettle)

$lblElkSettleSec = New-Object System.Windows.Forms.Label
$lblElkSettleSec.Text = "sec"
$lblElkSettleSec.Location = New-Object System.Drawing.Point(580,255)
$lblElkSettleSec.AutoSize = $true
$tabElk.Controls.Add($lblElkSettleSec)

$lblElkDashboards = New-Object System.Windows.Forms.Label
$lblElkDashboards.Text = "Dashboards"
$lblElkDashboards.Font = $font
$lblElkDashboards.ForeColor = $Navy
$lblElkDashboards.Location = New-Object System.Drawing.Point(245,292)
$lblElkDashboards.AutoSize = $true
$lblElkDashboards.Tag = "section"
$lblElkDashboards.Font = New-Object System.Drawing.Font("Segoe UI",10,[System.Drawing.FontStyle]::Bold)
$tabElk.Controls.Add($lblElkDashboards)

$lvElkDashboards = New-Object System.Windows.Forms.ListView
$lvElkDashboards.Location = New-Object System.Drawing.Point(245,320)
$lvElkDashboards.Size = New-Object System.Drawing.Size(680,175)
$lvElkDashboards.View = "Details"
$lvElkDashboards.FullRowSelect = $true
$lvElkDashboards.MultiSelect = $false
$lvElkDashboards.GridLines = $false
$lvElkDashboards.Anchor = "Top,Left,Right"
$lvElkDashboards.OwnerDraw = $false
$lvElkDashboards.HeaderStyle = [System.Windows.Forms.ColumnHeaderStyle]::Nonclickable
$lvElkDashboards.HideSelection = $false
[void]$lvElkDashboards.Columns.Add("Dashboard",140)
[void]$lvElkDashboards.Columns.Add("Time Range",105)
[void]$lvElkDashboards.Columns.Add("URL / Relative Path",220)
[void]$lvElkDashboards.Columns.Add("Index",95)
[void]$lvElkDashboards.Columns.Add("Expected Fields",100)
$tabElk.Controls.Add($lvElkDashboards)

$lvElkDashboards.Add_DrawColumnHeader({
    param($sender,$e)
    try {
        $p = Get-AghrabPalette -Theme $script:CurrentTheme
        $bg = New-Object System.Drawing.SolidBrush($p.Surface2)
        $pen = New-Object System.Drawing.Pen($p.Border)
        try {
            $e.Graphics.FillRectangle($bg,$e.Bounds)
            $e.Graphics.DrawRectangle($pen,$e.Bounds.X,$e.Bounds.Y,$e.Bounds.Width-1,$e.Bounds.Height-1)
            $r = New-Object System.Drawing.Rectangle($e.Bounds.X+8,$e.Bounds.Y,$e.Bounds.Width-12,$e.Bounds.Height)
            [System.Windows.Forms.TextRenderer]::DrawText(
                $e.Graphics,
                [string]$e.Header.Text,
                (New-Object System.Drawing.Font("Segoe UI Semibold",9)),
                $r,
                $p.Text,
                [System.Windows.Forms.TextFormatFlags]::Left -bor
                [System.Windows.Forms.TextFormatFlags]::VerticalCenter -bor
                [System.Windows.Forms.TextFormatFlags]::EndEllipsis
            )
        } finally {
            $bg.Dispose()
            $pen.Dispose()
        }
    } catch {}
})

$lvElkDashboards.Add_DrawItem({
    param($sender,$e)
    # Details view is drawn in DrawSubItem.
})

$lvElkDashboards.Add_DrawSubItem({
    param($sender,$e)
    try {
        $p = Get-AghrabPalette -Theme $script:CurrentTheme
        $selected = $e.Item.Selected
        $back = $(if ($selected) { $p.Selection } else { $p.Input })
        $brush = New-Object System.Drawing.SolidBrush($back)
        $pen = New-Object System.Drawing.Pen($p.BorderSoft)
        try {
            $e.Graphics.FillRectangle($brush,$e.Bounds)
            $e.Graphics.DrawRectangle($pen,$e.Bounds.X,$e.Bounds.Y,$e.Bounds.Width-1,$e.Bounds.Height-1)
            $r = New-Object System.Drawing.Rectangle($e.Bounds.X+8,$e.Bounds.Y,$e.Bounds.Width-12,$e.Bounds.Height)
            [System.Windows.Forms.TextRenderer]::DrawText(
                $e.Graphics,
                [string]$e.SubItem.Text,
                $sender.Font,
                $r,
                $p.Text,
                [System.Windows.Forms.TextFormatFlags]::Left -bor
                [System.Windows.Forms.TextFormatFlags]::VerticalCenter -bor
                [System.Windows.Forms.TextFormatFlags]::EndEllipsis
            )
        } finally {
            $brush.Dispose()
            $pen.Dispose()
        }
    } catch {}
})

$lblElkDashboardName = New-Object System.Windows.Forms.Label
$lblElkDashboardName.Text = "Name:"
$lblElkDashboardName.Location = New-Object System.Drawing.Point(245,510)
$lblElkDashboardName.AutoSize = $true
$tabElk.Controls.Add($lblElkDashboardName)

$txtElkDashboardName = New-Object System.Windows.Forms.TextBox
$txtElkDashboardName.Location = New-Object System.Drawing.Point(295,506)
$txtElkDashboardName.Size = New-Object System.Drawing.Size(235,28)
$tabElk.Controls.Add($txtElkDashboardName)

$lblElkTimeRange = New-Object System.Windows.Forms.Label
$lblElkTimeRange.Text = "Time Range:"
$lblElkTimeRange.Location = New-Object System.Drawing.Point(550,510)
$lblElkTimeRange.AutoSize = $true
$tabElk.Controls.Add($lblElkTimeRange)

$cmbElkTimeRange = New-Object System.Windows.Forms.ComboBox
$cmbElkTimeRange.Location = New-Object System.Drawing.Point(625,506)
$cmbElkTimeRange.Size = New-Object System.Drawing.Size(300,28)
$cmbElkTimeRange.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList

foreach ($preset in Get-ElkTimeRangePresets) {
    [void]$cmbElkTimeRange.Items.Add($preset)
}

$cmbElkTimeRange.SelectedItem = "Last 1 hour"
$tabElk.Controls.Add($cmbElkTimeRange)

$lblElkDashboardUrl = New-Object System.Windows.Forms.Label
$lblElkDashboardUrl.Text = "URL:"
$lblElkDashboardUrl.Location = New-Object System.Drawing.Point(245,548)
$lblElkDashboardUrl.AutoSize = $true
$tabElk.Controls.Add($lblElkDashboardUrl)

$txtElkDashboardUrl = New-Object System.Windows.Forms.TextBox
$txtElkDashboardUrl.Location = New-Object System.Drawing.Point(295,544)
$txtElkDashboardUrl.Size = New-Object System.Drawing.Size(630,28)
$txtElkDashboardUrl.Anchor = "Top,Left,Right"
$tabElk.Controls.Add($txtElkDashboardUrl)

$lblElkDashboardIndex = New-Object System.Windows.Forms.Label
$lblElkDashboardIndex.Text = "ES Index:"
$lblElkDashboardIndex.Location = New-Object System.Drawing.Point(245,582)
$lblElkDashboardIndex.AutoSize = $true
$tabElk.Controls.Add($lblElkDashboardIndex)

$txtElkDashboardIndex = New-Object System.Windows.Forms.TextBox
$txtElkDashboardIndex.Location = New-Object System.Drawing.Point(295,578)
$txtElkDashboardIndex.Size = New-Object System.Drawing.Size(180,28)
$tabElk.Controls.Add($txtElkDashboardIndex)

$lblElkExpectedFields = New-Object System.Windows.Forms.Label
$lblElkExpectedFields.Text = "Expected Fields:"
$lblElkExpectedFields.Location = New-Object System.Drawing.Point(490,582)
$lblElkExpectedFields.AutoSize = $true
$tabElk.Controls.Add($lblElkExpectedFields)

$txtElkExpectedFields = New-Object System.Windows.Forms.TextBox
$txtElkExpectedFields.Location = New-Object System.Drawing.Point(590,578)
$txtElkExpectedFields.Size = New-Object System.Drawing.Size(335,28)
$txtElkExpectedFields.Anchor = "Top,Left,Right"
$tabElk.Controls.Add($txtElkExpectedFields)

$btnElkAddDashboard = New-Object System.Windows.Forms.Button
$btnElkAddDashboard.Text = "Add / Update"
$btnElkAddDashboard.Location = New-Object System.Drawing.Point(245,582)
$btnElkAddDashboard.Size = New-Object System.Drawing.Size(115,32)
Style-SecondaryButton $btnElkAddDashboard
$tabElk.Controls.Add($btnElkAddDashboard)

$btnElkDeleteDashboard = New-Object System.Windows.Forms.Button
$btnElkDeleteDashboard.Text = "Delete Dashboard"
$btnElkDeleteDashboard.Location = New-Object System.Drawing.Point(370,582)
$btnElkDeleteDashboard.Size = New-Object System.Drawing.Size(130,32)
$btnElkDeleteDashboard.FlatStyle = "Flat"
$btnElkDeleteDashboard.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(210,58,58)
$btnElkDeleteDashboard.BackColor = [System.Drawing.Color]::White
$btnElkDeleteDashboard.ForeColor = [System.Drawing.Color]::FromArgb(180,35,35)
$tabElk.Controls.Add($btnElkDeleteDashboard)

$elkProgress = New-Object System.Windows.Forms.ProgressBar
$elkProgress.Style = [System.Windows.Forms.ProgressBarStyle]::Continuous
$elkProgress.Location = New-Object System.Drawing.Point(515,586)
$elkProgress.Size = New-Object System.Drawing.Size(410,12)
$elkProgress.Anchor = "Top,Left,Right"
$tabElk.Controls.Add($elkProgress)

$txtElkLog = New-Object System.Windows.Forms.TextBox
$txtElkLog.Multiline = $true
$txtElkLog.ReadOnly = $true
$txtElkLog.ScrollBars = "Vertical"
$txtElkLog.Font = New-Object System.Drawing.Font("Consolas",9)
$txtElkLog.Location = New-Object System.Drawing.Point(245,620)
$txtElkLog.Size = New-Object System.Drawing.Size(680,38)
$txtElkLog.Anchor = "Top,Bottom,Left,Right"
$tabElk.Controls.Add($txtElkLog)


# ---------------- ELK CARD LAYOUT ----------------
$cardProfiles = New-Object System.Windows.Forms.Panel
$cardProfiles.Location = New-Object System.Drawing.Point(8,10)
$cardProfiles.Size = New-Object System.Drawing.Size(220,685)
Initialize-AghrabCard -Card $cardProfiles
$tabElk.Controls.Add($cardProfiles)
$cardProfiles.SendToBack()

$cardConnection = New-Object System.Windows.Forms.Panel
$cardConnection.Location = New-Object System.Drawing.Point(238,10)
$cardConnection.Size = New-Object System.Drawing.Size(710,80)
Initialize-AghrabCard -Card $cardConnection
$tabElk.Controls.Add($cardConnection)
$cardConnection.SendToBack()

$cardAuth = New-Object System.Windows.Forms.Panel
$cardAuth.Location = New-Object System.Drawing.Point(238,100)
$cardAuth.Size = New-Object System.Drawing.Size(710,110)
Initialize-AghrabCard -Card $cardAuth
$tabElk.Controls.Add($cardAuth)
$cardAuth.SendToBack()

$cardCapture = New-Object System.Windows.Forms.Panel
$cardCapture.Location = New-Object System.Drawing.Point(238,220)
$cardCapture.Size = New-Object System.Drawing.Size(710,120)
Initialize-AghrabCard -Card $cardCapture
$tabElk.Controls.Add($cardCapture)
$cardCapture.SendToBack()

$cardDashboards = New-Object System.Windows.Forms.Panel
$cardDashboards.Location = New-Object System.Drawing.Point(238,350)
$cardDashboards.Size = New-Object System.Drawing.Size(710,345)
Initialize-AghrabCard -Card $cardDashboards
$tabElk.Controls.Add($cardDashboards)
$cardDashboards.SendToBack()

function New-CardTitle {
    param(
        [System.Windows.Forms.Panel]$Parent,
        [string]$Text
    )
    $l = New-Object System.Windows.Forms.Label
    $l.Text = $Text
    $l.Font = New-Object System.Drawing.Font("Segoe UI Semibold",10)
    $l.Location = New-Object System.Drawing.Point(14,10)
    $l.AutoSize = $true
    $l.Tag = "section"
    $Parent.Controls.Add($l)
    return $l
}

[void](New-CardTitle -Parent $cardProfiles -Text "Profiles")
[void](New-CardTitle -Parent $cardConnection -Text "Connection")
[void](New-CardTitle -Parent $cardAuth -Text "Authentication")
[void](New-CardTitle -Parent $cardCapture -Text "Capture Settings")
[void](New-CardTitle -Parent $cardDashboards -Text "Dashboards")

# Profiles card
$cardProfiles.Controls.Add($lstElkProfiles)
$lstElkProfiles.Location = New-Object System.Drawing.Point(14,42)
$lstElkProfiles.Size = New-Object System.Drawing.Size(190,245)

$cardProfiles.Controls.Add($btnElkNewProfile)
$btnElkNewProfile.Location = New-Object System.Drawing.Point(14,299)
$btnElkNewProfile.Size = New-Object System.Drawing.Size(90,34)

$cardProfiles.Controls.Add($btnElkDeleteProfile)
$btnElkDeleteProfile.Location = New-Object System.Drawing.Point(112,299)
$btnElkDeleteProfile.Size = New-Object System.Drawing.Size(92,34)

$cardProfiles.Controls.Add($lblElkHint)
$lblElkHint.Location = New-Object System.Drawing.Point(14,350)
$lblElkHint.Size = New-Object System.Drawing.Size(190,120)

$btnElkTransferCenter = New-Object System.Windows.Forms.Button
$btnElkTransferCenter.Text = "Import / Export"
$btnElkTransferCenter.Location = New-Object System.Drawing.Point(14,486)
$btnElkTransferCenter.Size = New-Object System.Drawing.Size(190,36)
Style-PrimaryButton $btnElkTransferCenter
$cardProfiles.Controls.Add($btnElkTransferCenter)

$lblElkTransferHint = New-Object System.Windows.Forms.Label
$lblElkTransferHint.Text = "Portable transfer for profiles and dashboards"
$lblElkTransferHint.Location = New-Object System.Drawing.Point(14,530)
$lblElkTransferHint.Size = New-Object System.Drawing.Size(190,42)
$lblElkTransferHint.Tag = "muted"
$cardProfiles.Controls.Add($lblElkTransferHint)

$btnElkTransferCenter.Add_Click({
    Show-AghrabTransferCenter
})

$lblElkProfiles.Visible = $false

# Connection card
foreach ($c in @(
    $lblElkProfileName,$txtElkProfileName,$lblElkKibanaUrl,$txtElkKibanaUrl,
    $btnElkSaveProfile,$btnElkLoginBrowser,$lblElkSessionStatus
)) {
    $cardConnection.Controls.Add($c)
}
$lblElkProfileName.Location = New-Object System.Drawing.Point(14,34)
$txtElkProfileName.Location = New-Object System.Drawing.Point(100,30)
$txtElkProfileName.Size = New-Object System.Drawing.Size(235,28)
$btnElkSaveProfile.Location = New-Object System.Drawing.Point(350,27)
$btnElkLoginBrowser.Location = New-Object System.Drawing.Point(584,27)
$lblElkSessionStatus.Location = New-Object System.Drawing.Point(510,60)
$lblElkSessionStatus.Size = New-Object System.Drawing.Size(186,24)
$lblElkSessionStatus.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
$lblElkSessionStatus.AutoEllipsis = $true
$lblElkKibanaUrl.Location = New-Object System.Drawing.Point(14,62)
$txtElkKibanaUrl.Location = New-Object System.Drawing.Point(100,58)
$txtElkKibanaUrl.Size = New-Object System.Drawing.Size(400,28)

$btnElkFieldVerify = New-Object System.Windows.Forms.Button
$btnElkFieldVerify.Text = "Field Verification"
$btnElkFieldVerify.Location = New-Object System.Drawing.Point(458,27)
$btnElkFieldVerify.Size = New-Object System.Drawing.Size(118,32)
Style-SecondaryButton $btnElkFieldVerify
$cardConnection.Controls.Add($btnElkFieldVerify)
$btnElkFieldVerify.Add_Click({ Show-ElasticsearchVerificationDialog })

$elkConnectionToolTip = New-Object System.Windows.Forms.ToolTip
$elkConnectionToolTip.AutoPopDelay = 10000
$elkConnectionToolTip.SetToolTip(
    $btnElkFieldVerify,
    "Configure profile-level Elasticsearch URL, API Key, time field and verification window."
)

# Authentication card (replace old GroupBox shell)
foreach ($c in @(
    $chkElkAutoLogin,$lblElkAuthUser,$txtElkAuthUser,$lblElkAuthPassword,
    $txtElkAuthPassword,$btnElkTestLogin,$btnElkContinueCaptcha
)) {
    $cardAuth.Controls.Add($c)
}
$grpElkAuth.Visible = $false
$chkElkAutoLogin.Location = New-Object System.Drawing.Point(14,46)
$lblElkAuthUser.Location = New-Object System.Drawing.Point(215,28)
$txtElkAuthUser.Location = New-Object System.Drawing.Point(215,50)
$txtElkAuthUser.Size = New-Object System.Drawing.Size(140,27)
$lblElkAuthPassword.Location = New-Object System.Drawing.Point(370,28)
$txtElkAuthPassword.Location = New-Object System.Drawing.Point(370,50)
$txtElkAuthPassword.Size = New-Object System.Drawing.Size(140,27)
$btnElkTestLogin.Location = New-Object System.Drawing.Point(530,39)
$btnElkTestLogin.Size = New-Object System.Drawing.Size(150,32)
$btnElkContinueCaptcha.Location = New-Object System.Drawing.Point(530,74)
$btnElkContinueCaptcha.Size = New-Object System.Drawing.Size(150,25)

# Capture settings card
foreach ($c in @(
    $btnElkCaptureAll,$btnElkStop,$lblElkWait,$numElkWait,$lblElkWaitSec,
    $lblElkTimeout,$numElkTimeout,$lblElkTimeoutSec,$lblElkScroll,$numElkScrollDelay,
    $lblElkScrollMs,$lblElkSettle,$numElkFinalSettle,$lblElkSettleSec
)) {
    $cardCapture.Controls.Add($c)
}
$btnElkCaptureAll.Location = New-Object System.Drawing.Point(14,38)
$btnElkCaptureAll.Size = New-Object System.Drawing.Size(195,38)
$btnElkCaptureAll.AutoEllipsis = $true
$btnElkStop.Location = New-Object System.Drawing.Point(204,38)
$btnElkStop.Size = New-Object System.Drawing.Size(80,38)
$lblElkWait.Location = New-Object System.Drawing.Point(305,44)
$numElkWait.Location = New-Object System.Drawing.Point(370,40)
$lblElkWaitSec.Location = New-Object System.Drawing.Point(430,44)
$lblElkTimeout.Location = New-Object System.Drawing.Point(475,44)
$numElkTimeout.Location = New-Object System.Drawing.Point(535,40)
$lblElkTimeoutSec.Location = New-Object System.Drawing.Point(600,44)
$lblElkScroll.Location = New-Object System.Drawing.Point(305,82)
$numElkScrollDelay.Location = New-Object System.Drawing.Point(355,78)
$lblElkScrollMs.Location = New-Object System.Drawing.Point(435,82)
$lblElkSettle.Location = New-Object System.Drawing.Point(475,82)
$numElkFinalSettle.Location = New-Object System.Drawing.Point(555,78)
$lblElkSettleSec.Location = New-Object System.Drawing.Point(615,82)

# Dashboards card
foreach ($c in @(
    $lvElkDashboards,$lblElkDashboardName,$txtElkDashboardName,$lblElkTimeRange,
    $cmbElkTimeRange,$lblElkDashboardUrl,$txtElkDashboardUrl,
    $lblElkDashboardIndex,$txtElkDashboardIndex,$lblElkExpectedFields,$txtElkExpectedFields,
    $btnElkAddDashboard,$btnElkDeleteDashboard,$elkProgress,$txtElkLog
)) {
    $cardDashboards.Controls.Add($c)
}
$lblElkDashboards.Visible = $false
$lvElkDashboards.Location = New-Object System.Drawing.Point(14,40)
$lvElkDashboards.Size = New-Object System.Drawing.Size(680,125)
$lvElkDashboards.Anchor = "Top,Left,Right"

$lblElkDashboardName.Location = New-Object System.Drawing.Point(14,181)
$txtElkDashboardName.Location = New-Object System.Drawing.Point(64,177)
$txtElkDashboardName.Size = New-Object System.Drawing.Size(215,28)
$lblElkTimeRange.Location = New-Object System.Drawing.Point(300,181)
$cmbElkTimeRange.Location = New-Object System.Drawing.Point(380,177)
$cmbElkTimeRange.Size = New-Object System.Drawing.Size(314,28)

$lblElkDashboardUrl.Location = New-Object System.Drawing.Point(14,217)
$txtElkDashboardUrl.Location = New-Object System.Drawing.Point(64,213)
$txtElkDashboardUrl.Size = New-Object System.Drawing.Size(630,28)
$txtElkDashboardUrl.Anchor = "Top,Left,Right"

$lblElkDashboardIndex.Location = New-Object System.Drawing.Point(14,253)
$txtElkDashboardIndex.Location = New-Object System.Drawing.Point(75,249)
$txtElkDashboardIndex.Size = New-Object System.Drawing.Size(150,28)

$lblElkExpectedFields.Location = New-Object System.Drawing.Point(238,253)
$txtElkExpectedFields.Location = New-Object System.Drawing.Point(335,249)
$txtElkExpectedFields.Size = New-Object System.Drawing.Size(359,28)
$txtElkExpectedFields.Anchor = "Top,Left,Right"

# Visual hints for per-dashboard Field Verification inputs.
$lblDashboardIndexPlaceholder = New-Object System.Windows.Forms.Label
$lblDashboardIndexPlaceholder.Text = "e.g. logs-suricata-*"
$lblDashboardIndexPlaceholder.Location = New-Object System.Drawing.Point(81,254)
$lblDashboardIndexPlaceholder.Size = New-Object System.Drawing.Size(135,18)
$lblDashboardIndexPlaceholder.BackColor = (Get-AghrabPalette -Theme $script:CurrentTheme).Input
$lblDashboardIndexPlaceholder.ForeColor = (Get-AghrabPalette -Theme $script:CurrentTheme).Muted
$lblDashboardIndexPlaceholder.Cursor = [System.Windows.Forms.Cursors]::IBeam
$cardDashboards.Controls.Add($lblDashboardIndexPlaceholder)
$lblDashboardIndexPlaceholder.BringToFront()

$refreshDashboardIndexPlaceholder = {
    $lblDashboardIndexPlaceholder.Visible = [string]::IsNullOrWhiteSpace($txtElkDashboardIndex.Text)
}
$txtElkDashboardIndex.Add_TextChanged({ & $refreshDashboardIndexPlaceholder })
$txtElkDashboardIndex.Add_Enter({ $lblDashboardIndexPlaceholder.Visible = $false })
$txtElkDashboardIndex.Add_Leave({ & $refreshDashboardIndexPlaceholder })
$lblDashboardIndexPlaceholder.Add_Click({
    $txtElkDashboardIndex.Focus()
    $lblDashboardIndexPlaceholder.Visible = $false
})
& $refreshDashboardIndexPlaceholder

$lblExpectedFieldsPlaceholder = New-Object System.Windows.Forms.Label
$lblExpectedFieldsPlaceholder.Text = "e.g. source.ip, destination.ip, event.action"
$lblExpectedFieldsPlaceholder.Location = New-Object System.Drawing.Point(341,254)
$lblExpectedFieldsPlaceholder.Size = New-Object System.Drawing.Size(335,18)
$lblExpectedFieldsPlaceholder.BackColor = (Get-AghrabPalette -Theme $script:CurrentTheme).Input
$lblExpectedFieldsPlaceholder.ForeColor = (Get-AghrabPalette -Theme $script:CurrentTheme).Muted
$lblExpectedFieldsPlaceholder.Cursor = [System.Windows.Forms.Cursors]::IBeam
$cardDashboards.Controls.Add($lblExpectedFieldsPlaceholder)
$lblExpectedFieldsPlaceholder.BringToFront()

$refreshExpectedFieldsPlaceholder = {
    $lblExpectedFieldsPlaceholder.Visible = [string]::IsNullOrWhiteSpace($txtElkExpectedFields.Text)
}
$txtElkExpectedFields.Add_TextChanged({ & $refreshExpectedFieldsPlaceholder })
$txtElkExpectedFields.Add_Enter({ $lblExpectedFieldsPlaceholder.Visible = $false })
$txtElkExpectedFields.Add_Leave({ & $refreshExpectedFieldsPlaceholder })
$lblExpectedFieldsPlaceholder.Add_Click({
    $txtElkExpectedFields.Focus()
    $lblExpectedFieldsPlaceholder.Visible = $false
})
& $refreshExpectedFieldsPlaceholder

$lblElkFieldHelp = New-Object System.Windows.Forms.Label
$lblElkFieldHelp.Text = "Optional: direct Elasticsearch verification for this dashboard."
$lblElkFieldHelp.Font = New-Object System.Drawing.Font("Segoe UI",8)
$lblElkFieldHelp.Location = New-Object System.Drawing.Point(14,281)
$lblElkFieldHelp.Size = New-Object System.Drawing.Size(520,18)
$lblElkFieldHelp.AutoEllipsis = $true
$lblElkFieldHelp.Tag = "muted"
$cardDashboards.Controls.Add($lblElkFieldHelp)

$btnSuggestFields = New-Object System.Windows.Forms.Button
$btnSuggestFields.Text = "Suggest Fields"
$btnSuggestFields.Location = New-Object System.Drawing.Point(466,276)
$btnSuggestFields.Size = New-Object System.Drawing.Size(118,26)
Style-SecondaryButton $btnSuggestFields
$cardDashboards.Controls.Add($btnSuggestFields)

$btnDashboardFieldHelp = New-Object System.Windows.Forms.Button
$btnDashboardFieldHelp.Text = "Field Help"
$btnDashboardFieldHelp.Location = New-Object System.Drawing.Point(594,276)
$btnDashboardFieldHelp.Size = New-Object System.Drawing.Size(100,26)
Style-SecondaryButton $btnDashboardFieldHelp
$cardDashboards.Controls.Add($btnDashboardFieldHelp)
$btnDashboardFieldHelp.Add_Click({ Show-DashboardFieldHelp })

$btnElkAddDashboard.Location = New-Object System.Drawing.Point(14,305)
$btnElkDeleteDashboard.Location = New-Object System.Drawing.Point(140,305)

$btnVerifyFieldsNow = New-Object System.Windows.Forms.Button
$btnVerifyFieldsNow.Text = "Verify Fields Now"
$btnVerifyFieldsNow.Location = New-Object System.Drawing.Point(280,305)
$btnVerifyFieldsNow.Size = New-Object System.Drawing.Size(140,32)
Style-PrimaryButton $btnVerifyFieldsNow
$cardDashboards.Controls.Add($btnVerifyFieldsNow)

$elkProgress.Location = New-Object System.Drawing.Point(430,316)
$elkProgress.Size = New-Object System.Drawing.Size(264,10)
$elkProgress.Anchor = "Top,Left,Right"

$txtElkLog.Location = New-Object System.Drawing.Point(14,334)
$txtElkLog.Size = New-Object System.Drawing.Size(680,10)
$txtElkLog.Anchor = "Top,Left,Right"

$elkFieldToolTip = New-Object System.Windows.Forms.ToolTip
$elkFieldToolTip.AutoPopDelay = 12000
$elkFieldToolTip.InitialDelay = 300
$elkFieldToolTip.ReshowDelay = 200
$elkFieldToolTip.SetToolTip(
    $txtElkDashboardIndex,
    "Optional. Elasticsearch index/data stream used by this dashboard, e.g. logs-suricata-* or logs-firewall-*."
)
$elkFieldToolTip.SetToolTip(
    $txtElkExpectedFields,
    "Optional. Fields RAQEB should verify in recent Elasticsearch documents, comma-separated. Example: source.ip, destination.ip, event.action"
)
$elkFieldToolTip.SetToolTip(
    $btnVerifyFieldsNow,
    "Directly test the current ES Index and Expected Fields. No Kibana browser, screenshot or AI is used."
)
$elkFieldToolTip.SetToolTip(
    $btnSuggestFields,
    "Sample real Elasticsearch documents and suggest useful Expected Fields for this dashboard."
)

Update-ElkAuthUiState



# ---------------- Health Summary Report ----------------
function Get-HealthSummaryReportData {
    $records = @(
        Get-HealthInventory |
        Sort-Object @{Expression={ Get-HealthStatusRank -Status ([string]$_.Status) }}, Profile, Dashboard
    )

    $total = $records.Count
    $healthy = @($records | Where-Object { [string]$_.Status -eq "Healthy" }).Count
    $warning = @($records | Where-Object { [string]$_.Status -eq "Warning" }).Count
    $critical = @($records | Where-Object { [string]$_.Status -eq "Critical" }).Count
    $unknown = @($records | Where-Object { [string]$_.Status -eq "Unknown" }).Count

    $known = $total - $unknown
    $coverage = 0
    if ($total -gt 0) {
        $coverage = [Math]::Round(($known / [double]$total) * 100, 1)
    }

    $dataSide = @($records | Where-Object { [string]$_.Correlation -eq "DATA-SIDE SIGNAL" }).Count
    $dashboardSide = @($records | Where-Object { [string]$_.Correlation -eq "DASHBOARD-SIDE SIGNAL" }).Count
    $fieldGap = @($records | Where-Object { [string]$_.Correlation -eq "FIELD GAP" }).Count
    $verifyErrors = @(
        $records |
        Where-Object {
            [string]$_.Correlation -in @("VERIFY ERROR","VERIFY NOT READY","INDEX NOT SET")
        }
    ).Count

    $totalNoData = 0
    $totalErrors = 0
    foreach ($r in $records) {
        try {
            $n = [int]$r.NoDataCount
            if ($n -gt 0) { $totalNoData += $n }
        }
        catch {}

        try {
            $e = [int]$r.Errors
            if ($e -gt 0) { $totalErrors += $e }
        }
        catch {}
    }

    $assessment = ""
    if ($total -eq 0) {
        $assessment = "No dashboards are currently configured."
    }
    elseif ($critical -gt 0) {
        $assessment = (
            $critical.ToString() + " dashboard(s) are Critical. " +
            "Review these first, then evaluate Warning dashboards."
        )
    }
    elseif ($warning -gt 0) {
        $assessment = (
            "No Critical dashboards are present, but " +
            $warning.ToString() + " dashboard(s) require review."
        )
    }
    elseif ($unknown -gt 0) {
        $assessment = (
            "No active Warning/Critical dashboard is present. " +
            $unknown.ToString() + " dashboard(s) are still Unknown and should be checked."
        )
    }
    else {
        $assessment = "All configured dashboards are currently Healthy."
    }

    $actions = New-Object System.Collections.Generic.List[string]

    if ($critical -gt 0) {
        $actions.Add("Prioritize Critical dashboards and use Details / Recheck to confirm the current state.")
    }
    if ($dataSide -gt 0) {
        $actions.Add("DATA-SIDE SIGNAL detected: check source delivery, ingestion, parsing, mappings and recent documents.")
    }
    if ($dashboardSide -gt 0) {
        $actions.Add("DASHBOARD-SIDE SIGNAL detected: check Data View, KQL, visualization filters and dashboard time range.")
    }
    if ($fieldGap -gt 0) {
        $actions.Add("FIELD GAP detected: review Expected Fields and the parser/mapping that should populate them.")
    }
    if ($verifyErrors -gt 0) {
        $actions.Add("Field Verify is not fully ready on one or more dashboards; review Elasticsearch connection/index settings.")
    }
    if ($unknown -gt 0) {
        $actions.Add("Recheck Unknown dashboards to improve health coverage.")
    }
    if ($actions.Count -eq 0 -and $total -gt 0) {
        $actions.Add("No immediate corrective action is indicated by the current health records.")
    }

    $issues = @(
        $records |
        Where-Object { [string]$_.Status -in @("Critical","Warning","Unknown") } |
        Select-Object -First 15
    )

    $profiles = @()
    foreach ($group in @($records | Group-Object Profile | Sort-Object Name)) {
        $groupRecords = @($group.Group)
        $profiles += [PSCustomObject]@{
            Profile = [string]$group.Name
            Total = $groupRecords.Count
            Healthy = @($groupRecords | Where-Object { $_.Status -eq "Healthy" }).Count
            Warning = @($groupRecords | Where-Object { $_.Status -eq "Warning" }).Count
            Critical = @($groupRecords | Where-Object { $_.Status -eq "Critical" }).Count
            Unknown = @($groupRecords | Where-Object { $_.Status -eq "Unknown" }).Count
        }
    }

    return [PSCustomObject]@{
        Generated = (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
        Records = @($records)
        Issues = @($issues)
        Profiles = @($profiles)
        Total = $total
        Healthy = $healthy
        Warning = $warning
        Critical = $critical
        Unknown = $unknown
        Coverage = $coverage
        TotalNoData = $totalNoData
        TotalErrors = $totalErrors
        DataSide = $dataSide
        DashboardSide = $dashboardSide
        FieldGap = $fieldGap
        VerifyErrors = $verifyErrors
        Assessment = $assessment
        Actions = @($actions)
    }
}

function Format-HealthSummaryReportText {
    param($Summary)

    $lines = New-Object System.Collections.Generic.List[string]

    $lines.Add("RAQEB SENTINEL PRO - HEALTH SUMMARY REPORT")
    $lines.Add(("Generated: " + [string]$Summary.Generated))
    $lines.Add(("Scope: All configured dashboards"))
    $lines.Add(("=" * 72))
    $lines.Add("")

    $lines.Add("HEALTH OVERVIEW")
    $lines.Add(("-" * 72))
    $lines.Add(("Total Dashboards : " + [string]$Summary.Total))
    $lines.Add(("Healthy          : " + [string]$Summary.Healthy))
    $lines.Add(("Warning          : " + [string]$Summary.Warning))
    $lines.Add(("Critical         : " + [string]$Summary.Critical))
    $lines.Add(("Unknown          : " + [string]$Summary.Unknown))
    $lines.Add(("Checked Coverage : " + [string]$Summary.Coverage + "%"))
    $lines.Add(("No Data Panels   : " + [string]$Summary.TotalNoData))
    $lines.Add(("Visible Errors   : " + [string]$Summary.TotalErrors))
    $lines.Add("")

    $lines.Add("AUTOMATED ASSESSMENT")
    $lines.Add(("-" * 72))
    $lines.Add([string]$Summary.Assessment)
    $lines.Add("")

    $lines.Add("CORRELATION SIGNALS")
    $lines.Add(("-" * 72))
    $lines.Add(("DATA-SIDE SIGNAL      : " + [string]$Summary.DataSide))
    $lines.Add(("DASHBOARD-SIDE SIGNAL : " + [string]$Summary.DashboardSide))
    $lines.Add(("FIELD GAP             : " + [string]$Summary.FieldGap))
    $lines.Add(("VERIFY ISSUE          : " + [string]$Summary.VerifyErrors))
    $lines.Add("")

    $lines.Add("MAIN ISSUES")
    $lines.Add(("-" * 72))

    if (@($Summary.Issues).Count -eq 0) {
        $lines.Add("No Warning, Critical or Unknown dashboards.")
    }
    else {
        foreach ($r in @($Summary.Issues)) {
            $noData = Convert-HealthCountText -Value $r.NoDataCount
            $errors = Convert-HealthCountText -Value $r.Errors
            $fieldSummary = [string]$r.FieldSummary
            if ([string]::IsNullOrWhiteSpace($fieldSummary)) { $fieldSummary = "-" }

            $correlation = [string]$r.Correlation
            if ([string]::IsNullOrWhiteSpace($correlation)) { $correlation = "-" }

            $lines.Add(
                "[" + [string]$r.Status + "] " +
                [string]$r.Dashboard +
                "  |  Profile: " + [string]$r.Profile
            )
            $lines.Add(
                "    No Data: " + $noData +
                "  |  Errors: " + $errors +
                "  |  Fields: " + $fieldSummary
            )
            $lines.Add(
                "    Correlation: " + $correlation +
                "  |  Last Check: " + [string]$r.LastCheck
            )
        }
    }

    $lines.Add("")
    $lines.Add("PROFILE BREAKDOWN")
    $lines.Add(("-" * 72))

    if (@($Summary.Profiles).Count -eq 0) {
        $lines.Add("No profiles available.")
    }
    else {
        foreach ($p in @($Summary.Profiles)) {
            $lines.Add(
                [string]$p.Profile +
                " | Total " + [string]$p.Total +
                " | Healthy " + [string]$p.Healthy +
                " | Warning " + [string]$p.Warning +
                " | Critical " + [string]$p.Critical +
                " | Unknown " + [string]$p.Unknown
            )
        }
    }

    $lines.Add("")
    $lines.Add("RECOMMENDED ACTIONS")
    $lines.Add(("-" * 72))

    $index = 1
    foreach ($action in @($Summary.Actions)) {
        $lines.Add(([string]$index + ". " + [string]$action))
        $index++
    }

    return ($lines -join "`r`n")
}

function Convert-HealthSummaryToHtml {
    param($Summary)

    function H([string]$Value) {
        if ($null -eq $Value) { return "" }
        return [System.Net.WebUtility]::HtmlEncode($Value)
    }

    $statusRows = New-Object System.Text.StringBuilder

    foreach ($r in @($Summary.Issues)) {
        $noData = Convert-HealthCountText -Value $r.NoDataCount
        $errors = Convert-HealthCountText -Value $r.Errors
        $fieldSummary = [string]$r.FieldSummary
        if ([string]::IsNullOrWhiteSpace($fieldSummary)) { $fieldSummary = "-" }
        $correlation = [string]$r.Correlation
        if ([string]::IsNullOrWhiteSpace($correlation)) { $correlation = "-" }

        [void]$statusRows.AppendLine(
            "<tr>" +
            "<td><strong>" + (H ([string]$r.Status)) + "</strong></td>" +
            "<td>" + (H ([string]$r.Dashboard)) + "</td>" +
            "<td>" + (H ([string]$r.Profile)) + "</td>" +
            "<td>" + (H $noData) + "</td>" +
            "<td>" + (H $errors) + "</td>" +
            "<td>" + (H $fieldSummary) + "</td>" +
            "<td>" + (H $correlation) + "</td>" +
            "<td>" + (H ([string]$r.LastCheck)) + "</td>" +
            "</tr>"
        )
    }

    if (@($Summary.Issues).Count -eq 0) {
        [void]$statusRows.AppendLine(
            '<tr><td colspan="8">No Warning, Critical or Unknown dashboards.</td></tr>'
        )
    }

    $profileRows = New-Object System.Text.StringBuilder
    foreach ($p in @($Summary.Profiles)) {
        [void]$profileRows.AppendLine(
            "<tr>" +
            "<td>" + (H ([string]$p.Profile)) + "</td>" +
            "<td>" + [string]$p.Total + "</td>" +
            "<td>" + [string]$p.Healthy + "</td>" +
            "<td>" + [string]$p.Warning + "</td>" +
            "<td>" + [string]$p.Critical + "</td>" +
            "<td>" + [string]$p.Unknown + "</td>" +
            "</tr>"
        )
    }

    $actionHtml = New-Object System.Text.StringBuilder
    foreach ($a in @($Summary.Actions)) {
        [void]$actionHtml.AppendLine("<li>" + (H ([string]$a)) + "</li>")
    }

    $html = @"
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>RAQEB Health Summary</title>
<style>
body{font-family:Segoe UI,Arial,sans-serif;background:#0f1720;color:#e6edf3;margin:0;padding:28px}
.wrap{max-width:1180px;margin:auto}
h1{font-size:26px;margin:0 0 4px} .muted{color:#9aa7b2}
.cards{display:grid;grid-template-columns:repeat(5,1fr);gap:12px;margin:24px 0}
.card{background:#18232f;border:1px solid #2c3b49;border-radius:10px;padding:16px}
.num{font-size:28px;font-weight:700}.label{color:#9aa7b2;font-size:13px;margin-top:5px}
section{background:#18232f;border:1px solid #2c3b49;border-radius:10px;padding:18px;margin:14px 0}
table{width:100%;border-collapse:collapse;font-size:13px}
th,td{border-bottom:1px solid #2c3b49;text-align:left;padding:9px 8px;vertical-align:top}
th{color:#9aa7b2} ul{line-height:1.7}
.good{color:#54c77a}.warn{color:#f0b44c}.bad{color:#ef6461}.accent{color:#4fb3ff}
</style>
</head>
<body>
<div class="wrap">
<h1>RAQEB Sentinel Pro - Health Summary Report</h1>
<div class="muted">Generated: $(H ([string]$Summary.Generated)) &nbsp; | &nbsp; Scope: All configured dashboards</div>

<div class="cards">
<div class="card"><div class="num accent">$($Summary.Total)</div><div class="label">Total Dashboards</div></div>
<div class="card"><div class="num good">$($Summary.Healthy)</div><div class="label">Healthy</div></div>
<div class="card"><div class="num warn">$($Summary.Warning)</div><div class="label">Warning</div></div>
<div class="card"><div class="num bad">$($Summary.Critical)</div><div class="label">Critical</div></div>
<div class="card"><div class="num">$($Summary.Unknown)</div><div class="label">Unknown</div></div>
</div>

<section>
<h2>Automated Assessment</h2>
<p>$(H ([string]$Summary.Assessment))</p>
<p class="muted">
Checked coverage: $($Summary.Coverage)% |
No Data panels: $($Summary.TotalNoData) |
Visible errors: $($Summary.TotalErrors)
</p>
</section>

<section>
<h2>Correlation Signals</h2>
<table>
<tr><th>DATA-SIDE SIGNAL</th><th>DASHBOARD-SIDE SIGNAL</th><th>FIELD GAP</th><th>VERIFY ISSUE</th></tr>
<tr><td>$($Summary.DataSide)</td><td>$($Summary.DashboardSide)</td><td>$($Summary.FieldGap)</td><td>$($Summary.VerifyErrors)</td></tr>
</table>
</section>

<section>
<h2>Main Issues</h2>
<table>
<tr><th>Status</th><th>Dashboard</th><th>Profile</th><th>No Data</th><th>Errors</th><th>Field Health</th><th>Correlation</th><th>Last Check</th></tr>
$($statusRows.ToString())
</table>
</section>

<section>
<h2>Profile Breakdown</h2>
<table>
<tr><th>Profile</th><th>Total</th><th>Healthy</th><th>Warning</th><th>Critical</th><th>Unknown</th></tr>
$($profileRows.ToString())
</table>
</section>

<section>
<h2>Recommended Actions</h2>
<ul>
$($actionHtml.ToString())
</ul>
</section>
</div>
</body>
</html>
"@

    return $html
}

function Export-HealthSummaryCsv {
    param(
        $Summary,
        [string]$Path
    )

    $rows = @(
        foreach ($r in @($Summary.Records)) {
            [PSCustomObject]@{
                Status = [string]$r.Status
                Dashboard = [string]$r.Dashboard
                Profile = [string]$r.Profile
                LastCheck = [string]$r.LastCheck
                NoData = Convert-HealthCountText -Value $r.NoDataCount
                Errors = Convert-HealthCountText -Value $r.Errors
                FieldHealth = [string]$r.FieldSummary
                Correlation = [string]$r.Correlation
                Confidence = [string]$r.Confidence
                VerificationIndex = [string]$r.VerificationIndex
                Message = [string]$r.Message
            }
        }
    )

    $rows | Export-Csv -LiteralPath $Path -NoTypeInformation -Encoding UTF8
}

function Show-HealthSummaryReport {
    $summary = Get-HealthSummaryReportData
    $reportText = Format-HealthSummaryReportText -Summary $summary

    $palette = Get-AghrabPalette -Theme $script:CurrentTheme

    $dialog = New-Object System.Windows.Forms.Form
    $dialog.Text = "RAQEB Health Summary Report"
    $dialog.StartPosition = "CenterParent"
    $dialog.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::Sizable
    $dialog.MinimumSize = New-Object System.Drawing.Size(920,650)
    $dialog.Size = New-Object System.Drawing.Size(1050,730)
    $dialog.Font = New-Object System.Drawing.Font("Segoe UI",9)
    $dialog.BackColor = $palette.Background
    $dialog.ForeColor = $palette.Text

    $title = New-Object System.Windows.Forms.Label
    $title.Text = "Health Summary Report"
    $title.Font = New-Object System.Drawing.Font("Segoe UI Semibold",17,[System.Drawing.FontStyle]::Bold)
    $title.Location = New-Object System.Drawing.Point(22,16)
    $title.Size = New-Object System.Drawing.Size(420,34)
    $dialog.Controls.Add($title)

    $sub = New-Object System.Windows.Forms.Label
    $sub.Text = "Generated: " + [string]$summary.Generated + "   |   Scope: All configured dashboards"
    $sub.Location = New-Object System.Drawing.Point(24,51)
    $sub.Size = New-Object System.Drawing.Size(760,22)
    $sub.ForeColor = $palette.Muted
    $dialog.Controls.Add($sub)

    function Add-SummaryMetric {
        param(
            [int]$Left,
            [string]$Name,
            [string]$Value,
            [System.Drawing.Color]$ValueColor
        )

        $panel = New-Object System.Windows.Forms.Panel
        $panel.Location = New-Object System.Drawing.Point($Left,84)
        $panel.Size = New-Object System.Drawing.Size(178,76)
        $panel.BackColor = $palette.Surface
        $panel.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
        $dialog.Controls.Add($panel)

        $valueLabel = New-Object System.Windows.Forms.Label
        $valueLabel.Text = $Value
        $valueLabel.Font = New-Object System.Drawing.Font("Segoe UI Semibold",19,[System.Drawing.FontStyle]::Bold)
        $valueLabel.Location = New-Object System.Drawing.Point(12,8)
        $valueLabel.Size = New-Object System.Drawing.Size(145,31)
        $valueLabel.ForeColor = $ValueColor
        $panel.Controls.Add($valueLabel)

        $nameLabel = New-Object System.Windows.Forms.Label
        $nameLabel.Text = $Name
        $nameLabel.Location = New-Object System.Drawing.Point(13,47)
        $nameLabel.Size = New-Object System.Drawing.Size(150,20)
        $nameLabel.ForeColor = $palette.Muted
        $panel.Controls.Add($nameLabel)
    }

    Add-SummaryMetric -Left 24  -Name "Total Dashboards" -Value ([string]$summary.Total)    -ValueColor $palette.Accent
    Add-SummaryMetric -Left 218 -Name "Healthy"          -Value ([string]$summary.Healthy)  -ValueColor $palette.Success
    Add-SummaryMetric -Left 412 -Name "Warning"          -Value ([string]$summary.Warning)  -ValueColor $palette.Warning
    Add-SummaryMetric -Left 606 -Name "Critical"         -Value ([string]$summary.Critical) -ValueColor $palette.Danger
    Add-SummaryMetric -Left 800 -Name "Unknown"          -Value ([string]$summary.Unknown)  -ValueColor $palette.Muted

    $txt = New-Object System.Windows.Forms.TextBox
    $txt.Multiline = $true
    $txt.ReadOnly = $true
    $txt.ScrollBars = "Both"
    $txt.WordWrap = $false
    $txt.Font = New-Object System.Drawing.Font("Consolas",9)
    $txt.Location = New-Object System.Drawing.Point(24,178)
    $txt.Size = New-Object System.Drawing.Size(970,430)
    $txt.Anchor = "Top,Bottom,Left,Right"
    $txt.BackColor = $palette.Input
    $txt.ForeColor = $palette.Text
    $txt.Text = $reportText
    $dialog.Controls.Add($txt)

    $btnHtml = New-Object System.Windows.Forms.Button
    $btnHtml.Text = "Export HTML"
    $btnHtml.Location = New-Object System.Drawing.Point(24,625)
    $btnHtml.Size = New-Object System.Drawing.Size(115,34)
    $btnHtml.Anchor = "Bottom,Left"
    Style-PrimaryButton $btnHtml
    $dialog.Controls.Add($btnHtml)

    $btnTxt = New-Object System.Windows.Forms.Button
    $btnTxt.Text = "Export TXT"
    $btnTxt.Location = New-Object System.Drawing.Point(149,625)
    $btnTxt.Size = New-Object System.Drawing.Size(105,34)
    $btnTxt.Anchor = "Bottom,Left"
    Style-SecondaryButton $btnTxt
    $dialog.Controls.Add($btnTxt)

    $btnCsv = New-Object System.Windows.Forms.Button
    $btnCsv.Text = "Export CSV"
    $btnCsv.Location = New-Object System.Drawing.Point(264,625)
    $btnCsv.Size = New-Object System.Drawing.Size(105,34)
    $btnCsv.Anchor = "Bottom,Left"
    Style-SecondaryButton $btnCsv
    $dialog.Controls.Add($btnCsv)

    $btnCopy = New-Object System.Windows.Forms.Button
    $btnCopy.Text = "Copy Summary"
    $btnCopy.Location = New-Object System.Drawing.Point(379,625)
    $btnCopy.Size = New-Object System.Drawing.Size(120,34)
    $btnCopy.Anchor = "Bottom,Left"
    Style-SecondaryButton $btnCopy
    $dialog.Controls.Add($btnCopy)

    $btnClose = New-Object System.Windows.Forms.Button
    $btnClose.Text = "Close"
    $btnClose.Location = New-Object System.Drawing.Point(894,625)
    $btnClose.Size = New-Object System.Drawing.Size(100,34)
    $btnClose.Anchor = "Bottom,Right"
    Style-SecondaryButton $btnClose
    $dialog.Controls.Add($btnClose)

    $btnHtml.Add_Click({
        $save = New-Object System.Windows.Forms.SaveFileDialog
        $save.Filter = "HTML Report (*.html)|*.html"
        $save.FileName = "RAQEB-Health-Summary-" + (Get-Date -Format "yyyyMMdd-HHmmss") + ".html"

        if ($save.ShowDialog($dialog) -eq [System.Windows.Forms.DialogResult]::OK) {
            Convert-HealthSummaryToHtml -Summary $summary |
                Set-Content -LiteralPath $save.FileName -Encoding UTF8 -Force
            Start-Process $save.FileName
        }
    })

    $btnTxt.Add_Click({
        $save = New-Object System.Windows.Forms.SaveFileDialog
        $save.Filter = "Text Report (*.txt)|*.txt"
        $save.FileName = "RAQEB-Health-Summary-" + (Get-Date -Format "yyyyMMdd-HHmmss") + ".txt"

        if ($save.ShowDialog($dialog) -eq [System.Windows.Forms.DialogResult]::OK) {
            $reportText | Set-Content -LiteralPath $save.FileName -Encoding UTF8 -Force
        }
    })

    $btnCsv.Add_Click({
        $save = New-Object System.Windows.Forms.SaveFileDialog
        $save.Filter = "CSV Report (*.csv)|*.csv"
        $save.FileName = "RAQEB-Health-Summary-" + (Get-Date -Format "yyyyMMdd-HHmmss") + ".csv"

        if ($save.ShowDialog($dialog) -eq [System.Windows.Forms.DialogResult]::OK) {
            Export-HealthSummaryCsv -Summary $summary -Path $save.FileName
        }
    })

    $btnCopy.Add_Click({
        try {
            [System.Windows.Forms.Clipboard]::SetText($reportText)
        }
        catch {}
    })

    $btnClose.Add_Click({
        $dialog.Close()
    })

    [void]$dialog.ShowDialog($form)
}


# ---------------- HEALTH CENTER TAB ----------------
$lblHealthTitle = New-Object System.Windows.Forms.Label
$lblHealthTitle.Text = "Operations Health Center"
$lblHealthTitle.Font = New-Object System.Drawing.Font("Segoe UI Semibold",18.5,[System.Drawing.FontStyle]::Bold)
$lblHealthTitle.Location = New-Object System.Drawing.Point(24,18)
$lblHealthTitle.AutoSize = $true
$tabHealth.Controls.Add($lblHealthTitle)

$lblHealthSubtitle = New-Object System.Windows.Forms.Label
$lblHealthSubtitle.Text = "Live operational view of every configured Kibana dashboard"
$lblHealthSubtitle.Font = New-Object System.Drawing.Font("Segoe UI",9.5)
$lblHealthSubtitle.Location = New-Object System.Drawing.Point(26,49)
$lblHealthSubtitle.AutoSize = $true
$tabHealth.Controls.Add($lblHealthSubtitle)

$btnHealthSummary = New-Object System.Windows.Forms.Button
$btnHealthSummary.Text = "Health Summary"
$btnHealthSummary.Location = New-Object System.Drawing.Point(610,20)
$btnHealthSummary.Size = New-Object System.Drawing.Size(132,34)
Style-PrimaryButton $btnHealthSummary
Set-AghrabButtonIcon -Button $btnHealthSummary -Kind "health" -Color $Blue
$tabHealth.Controls.Add($btnHealthSummary)

$btnHealthSummary.Add_Click({
    Show-HealthSummaryReport
})

$lblHealthLastUpdated = New-Object System.Windows.Forms.Label
$lblHealthLastUpdated.Text = "Updated: -"
$lblHealthLastUpdated.Location = New-Object System.Drawing.Point(760,28)
$lblHealthLastUpdated.Size = New-Object System.Drawing.Size(175,22)
$lblHealthLastUpdated.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
$tabHealth.Controls.Add($lblHealthLastUpdated)

function New-HealthMetricCard {
    param([int]$Left,[string]$Title)

    $panel = New-Object System.Windows.Forms.Panel
    $panel.Location = New-Object System.Drawing.Point($Left,78)
    $panel.Size = New-Object System.Drawing.Size(166,80)
    Initialize-AghrabCard -Card $panel
    $tabHealth.Controls.Add($panel)

    $accent = New-Object System.Windows.Forms.Panel
    $accent.Location = New-Object System.Drawing.Point(0,0)
    $accent.Size = New-Object System.Drawing.Size(166,3)
    $panel.Controls.Add($accent)

    $icon = New-Object System.Windows.Forms.PictureBox
    $icon.Location = New-Object System.Drawing.Point(13,16)
    $icon.Size = New-Object System.Drawing.Size(24,24)
    $icon.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::CenterImage
    $panel.Controls.Add($icon)

    $value = New-Object System.Windows.Forms.Label
    $value.Text = "0"
    $value.Font = New-Object System.Drawing.Font("Segoe UI Semibold",22,[System.Drawing.FontStyle]::Bold)
    $value.Location = New-Object System.Drawing.Point(49,9)
    $value.Size = New-Object System.Drawing.Size(103,37)
    $panel.Controls.Add($value)

    $label = New-Object System.Windows.Forms.Label
    $label.Text = $Title
    $label.Font = New-Object System.Drawing.Font("Segoe UI Semibold",8.5)
    $label.Location = New-Object System.Drawing.Point(14,52)
    $label.Size = New-Object System.Drawing.Size(138,20)
    $label.Tag = "muted"
    $panel.Controls.Add($label)

    return [PSCustomObject]@{ Panel=$panel; Value=$value; Label=$label; Icon=$icon; Accent=$accent }
}

$metricTotal = New-HealthMetricCard -Left 24 -Title "Total Dashboards"
$metricHealthy = New-HealthMetricCard -Left 204 -Title "Healthy"
$metricWarning = New-HealthMetricCard -Left 384 -Title "Warning"
$metricCritical = New-HealthMetricCard -Left 564 -Title "Critical"
$metricUnknown = New-HealthMetricCard -Left 744 -Title "Unknown"

$cardHealthTotal = $metricTotal.Panel
$cardHealthHealthy = $metricHealthy.Panel
$cardHealthWarning = $metricWarning.Panel
$cardHealthCritical = $metricCritical.Panel
$cardHealthUnknown = $metricUnknown.Panel

$lblHealthTotalValue = $metricTotal.Value
$lblHealthHealthyValue = $metricHealthy.Value
$lblHealthWarningValue = $metricWarning.Value
$lblHealthCriticalValue = $metricCritical.Value
$lblHealthUnknownValue = $metricUnknown.Value

$lblHealthTotalIcon = $metricTotal.Icon
$lblHealthHealthyIcon = $metricHealthy.Icon
$lblHealthWarningIcon = $metricWarning.Icon
$lblHealthCriticalIcon = $metricCritical.Icon
$lblHealthUnknownIcon = $metricUnknown.Icon

$barHealthTotal = $metricTotal.Accent
$barHealthHealthy = $metricHealthy.Accent
$barHealthWarning = $metricWarning.Accent
$barHealthCritical = $metricCritical.Accent
$barHealthUnknown = $metricUnknown.Accent

$cardHealthManager = New-Object System.Windows.Forms.Panel
$cardHealthManager.Location = New-Object System.Drawing.Point(24,166)
$cardHealthManager.Size = New-Object System.Drawing.Size(921,78)
Initialize-AghrabCard -Card $cardHealthManager
$tabHealth.Controls.Add($cardHealthManager)

$lblHealthManagerTitle = New-Object System.Windows.Forms.Label
$lblHealthManagerTitle.Text = "Dashboard Manager"
$lblHealthManagerTitle.Font = New-Object System.Drawing.Font("Segoe UI Semibold",10.5,[System.Drawing.FontStyle]::Bold)
$lblHealthManagerTitle.Location = New-Object System.Drawing.Point(14,9)
$lblHealthManagerTitle.AutoSize = $true
$lblHealthManagerTitle.Tag = "section"
$cardHealthManager.Controls.Add($lblHealthManagerTitle)

$lblHealthShowing = New-Object System.Windows.Forms.Label
$lblHealthShowing.Text = "Showing 0 of 0"
$lblHealthShowing.Location = New-Object System.Drawing.Point(156,10)
$lblHealthShowing.Size = New-Object System.Drawing.Size(116,22)
$lblHealthShowing.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$lblHealthShowing.Font = New-Object System.Drawing.Font("Segoe UI Semibold",8)
$lblHealthShowing.Tag = "healthCountBadge"
$cardHealthManager.Controls.Add($lblHealthShowing)
Set-RoundedControlRegion -Control $lblHealthShowing -Radius 10

$cmbHealthProfile = New-Object System.Windows.Forms.ComboBox
$cmbHealthProfile.Location = New-Object System.Drawing.Point(14,40)
$cmbHealthProfile.Size = New-Object System.Drawing.Size(155,28)
$cmbHealthProfile.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$cardHealthManager.Controls.Add($cmbHealthProfile)

$lblHealthSearchHint = New-Object System.Windows.Forms.Label
$lblHealthSearchHint.Text = "FILTERS"
$lblHealthSearchHint.Location = New-Object System.Drawing.Point(365,11)
$lblHealthSearchHint.Size = New-Object System.Drawing.Size(70,18)
$lblHealthSearchHint.Font = New-Object System.Drawing.Font("Segoe UI Semibold",7.5)
$lblHealthSearchHint.Tag = "muted"
$cardHealthManager.Controls.Add($lblHealthSearchHint)

$panelHealthSearch = New-Object System.Windows.Forms.Panel
$panelHealthSearch.Location = New-Object System.Drawing.Point(177,38)
$panelHealthSearch.Size = New-Object System.Drawing.Size(180,30)
$panelHealthSearch.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
$panelHealthSearch.Tag = "searchbox"
$cardHealthManager.Controls.Add($panelHealthSearch)

# Native magnifying-glass icon: no external icon/font dependency.
$panelHealthSearch.Add_Paint({
    param($sender,$e)
    try {
        $p = Get-AghrabPalette -Theme $script:CurrentTheme
        $pen = New-Object System.Drawing.Pen($p.Muted,1.6)
        try {
            $e.Graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
            $e.Graphics.DrawEllipse($pen,9,8,10,10)
            $e.Graphics.DrawLine($pen,18,17,23,22)
        }
        finally {
            $pen.Dispose()
        }
    }
    catch {}
})

$txtHealthSearch = New-Object System.Windows.Forms.TextBox
$txtHealthSearch.Location = New-Object System.Drawing.Point(30,5)
$txtHealthSearch.Size = New-Object System.Drawing.Size(122,20)
$txtHealthSearch.BorderStyle = [System.Windows.Forms.BorderStyle]::None
$txtHealthSearch.Text = ""
$panelHealthSearch.Controls.Add($txtHealthSearch)

$lblHealthSearchPlaceholder = New-Object System.Windows.Forms.Label
$lblHealthSearchPlaceholder.Text = "Search dashboards..."
$lblHealthSearchPlaceholder.Location = New-Object System.Drawing.Point(31,5)
$lblHealthSearchPlaceholder.Size = New-Object System.Drawing.Size(121,20)
$lblHealthSearchPlaceholder.ForeColor = (Get-AghrabPalette -Theme $script:CurrentTheme).Muted
$lblHealthSearchPlaceholder.BackColor = [System.Drawing.Color]::Transparent
$lblHealthSearchPlaceholder.Cursor = [System.Windows.Forms.Cursors]::IBeam
$panelHealthSearch.Controls.Add($lblHealthSearchPlaceholder)
$lblHealthSearchPlaceholder.BringToFront()

$btnHealthSearchClear = New-Object System.Windows.Forms.Button
$btnHealthSearchClear.Text = "×"
$btnHealthSearchClear.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
$btnHealthSearchClear.FlatAppearance.BorderSize = 0
$btnHealthSearchClear.Location = New-Object System.Drawing.Point(153,2)
$btnHealthSearchClear.Size = New-Object System.Drawing.Size(24,24)
$btnHealthSearchClear.Font = New-Object System.Drawing.Font("Segoe UI",11)
$btnHealthSearchClear.Cursor = [System.Windows.Forms.Cursors]::Hand
$btnHealthSearchClear.Visible = $false
$panelHealthSearch.Controls.Add($btnHealthSearchClear)

$cmbHealthStatus = New-Object System.Windows.Forms.ComboBox
$cmbHealthStatus.Location = New-Object System.Drawing.Point(365,40)
$cmbHealthStatus.Size = New-Object System.Drawing.Size(125,28)
$cmbHealthStatus.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
[void]$cmbHealthStatus.Items.Add("All Statuses")
[void]$cmbHealthStatus.Items.Add("Healthy")
[void]$cmbHealthStatus.Items.Add("Warning")
[void]$cmbHealthStatus.Items.Add("Critical")
[void]$cmbHealthStatus.Items.Add("Unknown")
$cmbHealthStatus.SelectedIndex = 0
$cardHealthManager.Controls.Add($cmbHealthStatus)

$healthManagerSeparator = New-Object System.Windows.Forms.Panel
$healthManagerSeparator.Location = New-Object System.Drawing.Point(493,37)
$healthManagerSeparator.Size = New-Object System.Drawing.Size(1,32)
$cardHealthManager.Controls.Add($healthManagerSeparator)

$btnHealthSync = New-Object System.Windows.Forms.Button
$btnHealthSync.Text = "Sync / Refresh"
$btnHealthSync.Location = New-Object System.Drawing.Point(500,37)
$btnHealthSync.Size = New-Object System.Drawing.Size(104,32)
Style-PrimaryButton $btnHealthSync
$cardHealthManager.Controls.Add($btnHealthSync)

$btnHealthManage = New-Object System.Windows.Forms.Button
$btnHealthManage.Text = "Add / Manage"
$btnHealthManage.Location = New-Object System.Drawing.Point(610,37)
$btnHealthManage.Size = New-Object System.Drawing.Size(105,32)
Style-SecondaryButton $btnHealthManage
$cardHealthManager.Controls.Add($btnHealthManage)

$btnHealthHistory = New-Object System.Windows.Forms.Button
$btnHealthHistory.Text = "History CSV"
$btnHealthHistory.Location = New-Object System.Drawing.Point(721,37)
$btnHealthHistory.Size = New-Object System.Drawing.Size(88,32)
Style-SecondaryButton $btnHealthHistory
$cardHealthManager.Controls.Add($btnHealthHistory)

$btnHealthViewMode = New-Object System.Windows.Forms.Button
$btnHealthViewMode.Text = "Table View"
$btnHealthViewMode.Location = New-Object System.Drawing.Point(815,37)
$btnHealthViewMode.Size = New-Object System.Drawing.Size(94,32)
Style-SecondaryButton $btnHealthViewMode
$cardHealthManager.Controls.Add($btnHealthViewMode)

$flowHealthCards = New-Object System.Windows.Forms.FlowLayoutPanel
$flowHealthCards.Location = New-Object System.Drawing.Point(24,254)
$flowHealthCards.Size = New-Object System.Drawing.Size(921,288)
$flowHealthCards.FlowDirection = [System.Windows.Forms.FlowDirection]::LeftToRight
$flowHealthCards.WrapContents = $true
$flowHealthCards.AutoScroll = $true
$flowHealthCards.Padding = New-Object System.Windows.Forms.Padding(0,4,0,8)
$tabHealth.Controls.Add($flowHealthCards)

$lvHealth = New-Object System.Windows.Forms.ListView
$lvHealth.Location = New-Object System.Drawing.Point(24,254)
$lvHealth.Size = New-Object System.Drawing.Size(921,288)
$lvHealth.View = "Details"
$lvHealth.FullRowSelect = $true
$lvHealth.MultiSelect = $false
$lvHealth.HideSelection = $false
$lvHealth.OwnerDraw = $false
$lvHealth.Font = New-Object System.Drawing.Font("Segoe UI",9)
[void]$lvHealth.Columns.Add("Status",90)
[void]$lvHealth.Columns.Add("Dashboard",185)
[void]$lvHealth.Columns.Add("Profile",125)
[void]$lvHealth.Columns.Add("Last Check",145)
[void]$lvHealth.Columns.Add("No Data",70)
[void]$lvHealth.Columns.Add("Errors",55)
[void]$lvHealth.Columns.Add("Field Health",125)
[void]$lvHealth.Columns.Add("Confidence",95)
$tabHealth.Controls.Add($lvHealth)

$lvHealth.Add_DrawColumnHeader({
    param($sender,$e)
    try {
        $p = Get-AghrabPalette -Theme $script:CurrentTheme
        $bg = New-Object System.Drawing.SolidBrush($p.Surface2)
        $pen = New-Object System.Drawing.Pen($p.Border)
        try {
            $e.Graphics.FillRectangle($bg,$e.Bounds)
            $e.Graphics.DrawRectangle($pen,$e.Bounds.X,$e.Bounds.Y,$e.Bounds.Width-1,$e.Bounds.Height-1)
            $r = New-Object System.Drawing.Rectangle($e.Bounds.X+8,$e.Bounds.Y,$e.Bounds.Width-12,$e.Bounds.Height)
            [System.Windows.Forms.TextRenderer]::DrawText(
                $e.Graphics,[string]$e.Header.Text,
                (New-Object System.Drawing.Font("Segoe UI Semibold",9)),
                $r,$p.Text,
                [System.Windows.Forms.TextFormatFlags]::Left -bor
                [System.Windows.Forms.TextFormatFlags]::VerticalCenter -bor
                [System.Windows.Forms.TextFormatFlags]::EndEllipsis
            )
        } finally { $bg.Dispose(); $pen.Dispose() }
    } catch {}
})

$lvHealth.Add_DrawItem({ param($sender,$e) })

$lvHealth.Add_DrawSubItem({
    param($sender,$e)
    try {
        $p = Get-AghrabPalette -Theme $script:CurrentTheme
        $selected = $e.Item.Selected
        $back = $(if ($selected) { $p.Selection } else { $p.Input })
        $brush = New-Object System.Drawing.SolidBrush($back)
        $pen = New-Object System.Drawing.Pen($p.BorderSoft)
        try {
            $e.Graphics.FillRectangle($brush,$e.Bounds)
            $e.Graphics.DrawLine($pen,$e.Bounds.Left,$e.Bounds.Bottom-1,$e.Bounds.Right,$e.Bounds.Bottom-1)

            $fore = $p.Text
            if ($e.ColumnIndex -eq 0) {
                $status = [string]$e.SubItem.Text
                $fore = $(
                    if ($status -eq "Healthy") { $p.Success }
                    elseif ($status -eq "Warning") { $p.Warning }
                    elseif ($status -eq "Critical") { $p.Danger }
                    else { $p.Muted }
                )
            }

            $r = New-Object System.Drawing.Rectangle($e.Bounds.X+8,$e.Bounds.Y,$e.Bounds.Width-12,$e.Bounds.Height)
            [System.Windows.Forms.TextRenderer]::DrawText(
                $e.Graphics,[string]$e.SubItem.Text,$sender.Font,$r,$fore,
                [System.Windows.Forms.TextFormatFlags]::Left -bor
                [System.Windows.Forms.TextFormatFlags]::VerticalCenter -bor
                [System.Windows.Forms.TextFormatFlags]::EndEllipsis
            )
        } finally { $brush.Dispose(); $pen.Dispose() }
    } catch {}
})

$cardHealthDetail = New-Object System.Windows.Forms.Panel
$cardHealthDetail.Location = New-Object System.Drawing.Point(24,552)
$cardHealthDetail.Size = New-Object System.Drawing.Size(921,143)
Initialize-AghrabCard -Card $cardHealthDetail
$tabHealth.Controls.Add($cardHealthDetail)

$lblHealthDetailTitle = New-Object System.Windows.Forms.Label
$lblHealthDetailTitle.Text = "Select a dashboard"
$lblHealthDetailTitle.Font = New-Object System.Drawing.Font("Segoe UI Semibold",12,[System.Drawing.FontStyle]::Bold)
$lblHealthDetailTitle.Location = New-Object System.Drawing.Point(16,12)
$lblHealthDetailTitle.Size = New-Object System.Drawing.Size(420,26)
$cardHealthDetail.Controls.Add($lblHealthDetailTitle)

$lblHealthDetailStatus = New-Object System.Windows.Forms.Label
$lblHealthDetailStatus.Text = "Status: -"
$lblHealthDetailStatus.Font = New-Object System.Drawing.Font("Segoe UI Semibold",10)
$lblHealthDetailStatus.Location = New-Object System.Drawing.Point(700,14)
$lblHealthDetailStatus.Size = New-Object System.Drawing.Size(195,24)
$lblHealthDetailStatus.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
$cardHealthDetail.Controls.Add($lblHealthDetailStatus)

$lblHealthDetailMeta = New-Object System.Windows.Forms.Label
$lblHealthDetailMeta.Text = ""
$lblHealthDetailMeta.Location = New-Object System.Drawing.Point(16,42)
$lblHealthDetailMeta.Size = New-Object System.Drawing.Size(880,22)
$cardHealthDetail.Controls.Add($lblHealthDetailMeta)

$lblHealthNoDataTitle = New-Object System.Windows.Forms.Label
$lblHealthNoDataTitle.Text = "Panel Health / No Data"
$lblHealthNoDataTitle.Font = New-Object System.Drawing.Font("Segoe UI Semibold",9)
$lblHealthNoDataTitle.Location = New-Object System.Drawing.Point(16,68)
$lblHealthNoDataTitle.AutoSize = $true
$lblHealthNoDataTitle.Tag = "section"
$cardHealthDetail.Controls.Add($lblHealthNoDataTitle)

$txtHealthNoData = New-Object System.Windows.Forms.TextBox
$txtHealthNoData.Multiline = $true
$txtHealthNoData.ReadOnly = $true
$txtHealthNoData.ScrollBars = "Vertical"
$txtHealthNoData.Location = New-Object System.Drawing.Point(16,88)
$txtHealthNoData.Size = New-Object System.Drawing.Size(275,42)
$cardHealthDetail.Controls.Add($txtHealthNoData)

$lblHealthFieldsTitle = New-Object System.Windows.Forms.Label
$lblHealthFieldsTitle.Text = "Field Verification"
$lblHealthFieldsTitle.Font = New-Object System.Drawing.Font("Segoe UI Semibold",9)
$lblHealthFieldsTitle.Location = New-Object System.Drawing.Point(310,68)
$lblHealthFieldsTitle.AutoSize = $true
$lblHealthFieldsTitle.Tag = "section"
$cardHealthDetail.Controls.Add($lblHealthFieldsTitle)

$txtHealthFields = New-Object System.Windows.Forms.TextBox
$txtHealthFields.Multiline = $true
$txtHealthFields.ReadOnly = $true
$txtHealthFields.ScrollBars = "Vertical"
$txtHealthFields.Location = New-Object System.Drawing.Point(310,88)
$txtHealthFields.Size = New-Object System.Drawing.Size(285,42)
$cardHealthDetail.Controls.Add($txtHealthFields)

$lblHealthDiagnosisTitle = New-Object System.Windows.Forms.Label
$lblHealthDiagnosisTitle.Text = "Diagnosis / Correlation"
$lblHealthDiagnosisTitle.Font = New-Object System.Drawing.Font("Segoe UI Semibold",9)
$lblHealthDiagnosisTitle.Location = New-Object System.Drawing.Point(614,68)
$lblHealthDiagnosisTitle.AutoSize = $true
$lblHealthDiagnosisTitle.Tag = "section"
$cardHealthDetail.Controls.Add($lblHealthDiagnosisTitle)

$txtHealthDiagnosis = New-Object System.Windows.Forms.TextBox
$txtHealthDiagnosis.Multiline = $true
$txtHealthDiagnosis.ReadOnly = $true
$txtHealthDiagnosis.ScrollBars = "Vertical"
$txtHealthDiagnosis.Location = New-Object System.Drawing.Point(614,88)
$txtHealthDiagnosis.Size = New-Object System.Drawing.Size(290,42)
$cardHealthDetail.Controls.Add($txtHealthDiagnosis)

# Kept for compatibility with older theme/update code.
$lblHealthDetailMessage = New-Object System.Windows.Forms.Label
$lblHealthDetailMessage.Text = ""
$lblHealthDetailMessage.Visible = $false
$cardHealthDetail.Controls.Add($lblHealthDetailMessage)

$btnHealthSync.Add_Click({
    Sync-HealthDashboardInventory -ShowMessage
})

$btnHealthManage.Add_Click({
    Open-HealthDashboardManager
})

$btnHealthViewMode.Add_Click({
    if ($script:HealthViewMode -eq "Cards") {
        Set-HealthViewMode -Mode "Table"
    }
    else {
        Set-HealthViewMode -Mode "Cards"
    }
})

$cmbHealthProfile.Add_SelectedIndexChanged({
    if (-not $script:LoadingHealthManagerUi) {
        Refresh-HealthCenter
    }
})

$cmbHealthStatus.Add_SelectedIndexChanged({
    if (-not $script:LoadingHealthManagerUi) {
        Refresh-HealthCenter
    }
})

$txtHealthSearch.Add_TextChanged({
    $hasText = -not [string]::IsNullOrWhiteSpace($txtHealthSearch.Text)
    $lblHealthSearchPlaceholder.Visible = -not $hasText
    $btnHealthSearchClear.Visible = $hasText

    if (-not $script:LoadingHealthManagerUi) {
        Refresh-HealthCenter
    }
})

$txtHealthSearch.Add_GotFocus({
    if ([string]::IsNullOrWhiteSpace($txtHealthSearch.Text)) {
        $lblHealthSearchPlaceholder.Visible = $false
    }
})

$txtHealthSearch.Add_LostFocus({
    if ([string]::IsNullOrWhiteSpace($txtHealthSearch.Text)) {
        $lblHealthSearchPlaceholder.Visible = $true
    }
})

$txtHealthSearch.Add_KeyDown({
    param($sender,$e)

    if ($e.KeyCode -eq [System.Windows.Forms.Keys]::Escape) {
        $txtHealthSearch.Clear()
        $e.SuppressKeyPress = $true
    }
})

$lblHealthSearchPlaceholder.Add_Click({
    $lblHealthSearchPlaceholder.Visible = $false
    $txtHealthSearch.Focus()
})

$panelHealthSearch.Add_Click({
    $txtHealthSearch.Focus()
})

$btnHealthSearchClear.Add_Click({
    $txtHealthSearch.Clear()
    $txtHealthSearch.Focus()
})

$btnHealthHistory.Add_Click({
    try {
        $path = Get-HealthHistoryFile
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
            [System.Windows.Forms.MessageBox]::Show($form,"No health history has been recorded yet.","RAQEB Sentinel Pro")
            return
        }
        Start-Process $path
    } catch {
        [System.Windows.Forms.MessageBox]::Show($form,$_.Exception.Message,"RAQEB Sentinel Pro")
    }
})

$lvHealth.Add_SelectedIndexChanged({ Show-SelectedHealthDetail })
Set-HealthViewMode -Mode "Cards"


# ---------------- AUTOMATIC CAPTURE TAB ----------------
$lblSchedulerTitle = New-Object System.Windows.Forms.Label
$lblSchedulerTitle.Text = "Automatic Capture"
$lblSchedulerTitle.Font = New-Object System.Drawing.Font("Segoe UI Semibold",18,[System.Drawing.FontStyle]::Bold)
$lblSchedulerTitle.Location = New-Object System.Drawing.Point(24,18)
$lblSchedulerTitle.AutoSize = $true
$tabScheduler.Controls.Add($lblSchedulerTitle)

$lblSchedulerSubtitle = New-Object System.Windows.Forms.Label
$lblSchedulerSubtitle.Text = "Hands-free Kibana capture and optional Local AI health analysis"
$lblSchedulerSubtitle.Font = New-Object System.Drawing.Font("Segoe UI",9.5)
$lblSchedulerSubtitle.Location = New-Object System.Drawing.Point(26,49)
$lblSchedulerSubtitle.AutoSize = $true
$tabScheduler.Controls.Add($lblSchedulerSubtitle)

$cardSchedulerMain = New-Object System.Windows.Forms.Panel
$cardSchedulerMain.Location = New-Object System.Drawing.Point(24,82)
$cardSchedulerMain.Size = New-Object System.Drawing.Size(921,190)
Initialize-AghrabCard -Card $cardSchedulerMain
$tabScheduler.Controls.Add($cardSchedulerMain)

$chkSchedulerEnabled = New-Object System.Windows.Forms.CheckBox
$chkSchedulerEnabled.Text = "Enable Automatic Capture"
$chkSchedulerEnabled.Font = New-Object System.Drawing.Font("Segoe UI Semibold",11)
$chkSchedulerEnabled.Location = New-Object System.Drawing.Point(18,18)
$chkSchedulerEnabled.AutoSize = $true
$cardSchedulerMain.Controls.Add($chkSchedulerEnabled)

$lblSchedulerOnOff = New-Object System.Windows.Forms.Label
$lblSchedulerOnOff.Text = "Automatic Capture is OFF"
$lblSchedulerOnOff.Font = New-Object System.Drawing.Font("Segoe UI Semibold",9.5)
$lblSchedulerOnOff.Location = New-Object System.Drawing.Point(690,18)
$lblSchedulerOnOff.Size = New-Object System.Drawing.Size(205,24)
$lblSchedulerOnOff.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
$cardSchedulerMain.Controls.Add($lblSchedulerOnOff)

$lblSchedulerProfile = New-Object System.Windows.Forms.Label
$lblSchedulerProfile.Text = "Profile"
$lblSchedulerProfile.Location = New-Object System.Drawing.Point(18,62)
$lblSchedulerProfile.AutoSize = $true
$cardSchedulerMain.Controls.Add($lblSchedulerProfile)

$cmbSchedulerProfile = New-Object System.Windows.Forms.ComboBox
$cmbSchedulerProfile.Location = New-Object System.Drawing.Point(18,84)
$cmbSchedulerProfile.Size = New-Object System.Drawing.Size(260,28)
$cmbSchedulerProfile.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$cardSchedulerMain.Controls.Add($cmbSchedulerProfile)

$lblSchedulerInterval = New-Object System.Windows.Forms.Label
$lblSchedulerInterval.Text = "Run every"
$lblSchedulerInterval.Location = New-Object System.Drawing.Point(300,62)
$lblSchedulerInterval.AutoSize = $true
$cardSchedulerMain.Controls.Add($lblSchedulerInterval)

$numSchedulerInterval = New-Object System.Windows.Forms.NumericUpDown
$numSchedulerInterval.Minimum = 1
$numSchedulerInterval.Maximum = 1440
$numSchedulerInterval.Value = 30
$numSchedulerInterval.Location = New-Object System.Drawing.Point(300,84)
$numSchedulerInterval.Size = New-Object System.Drawing.Size(80,28)
$cardSchedulerMain.Controls.Add($numSchedulerInterval)

$lblSchedulerMinutes = New-Object System.Windows.Forms.Label
$lblSchedulerMinutes.Text = "minutes"
$lblSchedulerMinutes.Location = New-Object System.Drawing.Point(388,89)
$lblSchedulerMinutes.AutoSize = $true
$cardSchedulerMain.Controls.Add($lblSchedulerMinutes)

$chkSchedulerAi = New-Object System.Windows.Forms.CheckBox
$chkSchedulerAi.Text = "Run Local AI after each capture"
$chkSchedulerAi.Checked = $true
$chkSchedulerAi.Location = New-Object System.Drawing.Point(490,84)
$chkSchedulerAi.AutoSize = $true
$cardSchedulerMain.Controls.Add($chkSchedulerAi)

$btnSchedulerSave = New-Object System.Windows.Forms.Button
$btnSchedulerSave.Text = "Save Schedule"
$btnSchedulerSave.Location = New-Object System.Drawing.Point(18,136)
$btnSchedulerSave.Size = New-Object System.Drawing.Size(125,36)
Style-PrimaryButton $btnSchedulerSave
$cardSchedulerMain.Controls.Add($btnSchedulerSave)

$btnSchedulerRunNow = New-Object System.Windows.Forms.Button
$btnSchedulerRunNow.Text = "Run Now"
$btnSchedulerRunNow.Location = New-Object System.Drawing.Point(153,136)
$btnSchedulerRunNow.Size = New-Object System.Drawing.Size(105,36)
Style-SecondaryButton $btnSchedulerRunNow
$cardSchedulerMain.Controls.Add($btnSchedulerRunNow)

$lblSchedulerRequirement = New-Object System.Windows.Forms.Label
$lblSchedulerRequirement.Text = "Uses saved session + Auto Login. If CAPTCHA appears, automation pauses for manual completion and then resumes."
$lblSchedulerRequirement.Location = New-Object System.Drawing.Point(285,139)
$lblSchedulerRequirement.Size = New-Object System.Drawing.Size(610,34)
$cardSchedulerMain.Controls.Add($lblSchedulerRequirement)

$lblSchedulerCredential = New-Object System.Windows.Forms.Label
$lblSchedulerCredential.Text = "Saved Credentials:"
$lblSchedulerCredential.Location = New-Object System.Drawing.Point(690,57)
$lblSchedulerCredential.AutoSize = $true
$cardSchedulerMain.Controls.Add($lblSchedulerCredential)

$lblSchedulerCredentialValue = New-Object System.Windows.Forms.Label
$lblSchedulerCredentialValue.Text = "-"
$lblSchedulerCredentialValue.Font = New-Object System.Drawing.Font("Segoe UI Semibold",9)
$lblSchedulerCredentialValue.Location = New-Object System.Drawing.Point(690,80)
$lblSchedulerCredentialValue.Size = New-Object System.Drawing.Size(200,22)
$cardSchedulerMain.Controls.Add($lblSchedulerCredentialValue)

$lblSchedulerCredentialHint = New-Object System.Windows.Forms.Label
$lblSchedulerCredentialHint.Text = ""
$lblSchedulerCredentialHint.Location = New-Object System.Drawing.Point(690,103)
$lblSchedulerCredentialHint.Size = New-Object System.Drawing.Size(205,32)
$cardSchedulerMain.Controls.Add($lblSchedulerCredentialHint)

function New-SchedulerStatusCard {
    param(
        [int]$Left,
        [string]$Title,
        [int]$Width = 142
    )

    $p = New-Object System.Windows.Forms.Panel
    $p.Location = New-Object System.Drawing.Point($Left,288)
    $p.Size = New-Object System.Drawing.Size($Width,88)
    Initialize-AghrabCard -Card $p
    $tabScheduler.Controls.Add($p)

    $t = New-Object System.Windows.Forms.Label
    $t.Text = $Title
    $t.Location = New-Object System.Drawing.Point(12,10)
    $t.Size = New-Object System.Drawing.Size(($Width - 24),20)
    $p.Controls.Add($t)

    $v = New-Object System.Windows.Forms.Label
    $v.Text = "-"
    $v.Font = New-Object System.Drawing.Font("Segoe UI Semibold",11,[System.Drawing.FontStyle]::Bold)
    $v.Location = New-Object System.Drawing.Point(12,38)
    $v.Size = New-Object System.Drawing.Size(($Width - 24),34)
    $v.AutoEllipsis = $true
    $p.Controls.Add($v)

    return [PSCustomObject]@{ Panel=$p; Value=$v }
}

$schedulerLastCard = New-SchedulerStatusCard -Left 24 -Title "Last Run"
$schedulerNextCard = New-SchedulerStatusCard -Left 177 -Title "Next Run"
$schedulerSuccessCard = New-SchedulerStatusCard -Left 330 -Title "Success"
$schedulerPartialCard = New-SchedulerStatusCard -Left 483 -Title "Partial"
$schedulerFailedCard = New-SchedulerStatusCard -Left 636 -Title "Failed"
$schedulerAiCard = New-SchedulerStatusCard -Left 789 -Title "AI Status"

$cardSchedulerLast = $schedulerLastCard.Panel
$cardSchedulerNext = $schedulerNextCard.Panel
$cardSchedulerSuccess = $schedulerSuccessCard.Panel
$cardSchedulerPartial = $schedulerPartialCard.Panel
$cardSchedulerFailed = $schedulerFailedCard.Panel
$cardSchedulerAi = $schedulerAiCard.Panel

$lblSchedulerLastValue = $schedulerLastCard.Value
$lblSchedulerNextValue = $schedulerNextCard.Value
$lblSchedulerSuccessValue = $schedulerSuccessCard.Value
$lblSchedulerPartialValue = $schedulerPartialCard.Value
$lblSchedulerFailedValue = $schedulerFailedCard.Value
$lblSchedulerAiValue = $schedulerAiCard.Value

$cardSchedulerOutput = New-Object System.Windows.Forms.Panel
$cardSchedulerOutput.Location = New-Object System.Drawing.Point(24,392)
$cardSchedulerOutput.Size = New-Object System.Drawing.Size(921,108)
Initialize-AghrabCard -Card $cardSchedulerOutput
$tabScheduler.Controls.Add($cardSchedulerOutput)

$lblSchedulerOutputTitle = New-Object System.Windows.Forms.Label
$lblSchedulerOutputTitle.Text = "Output"
$lblSchedulerOutputTitle.Font = New-Object System.Drawing.Font("Segoe UI Semibold",10)
$lblSchedulerOutputTitle.Location = New-Object System.Drawing.Point(16,12)
$lblSchedulerOutputTitle.AutoSize = $true
$lblSchedulerOutputTitle.Tag = "section"
$cardSchedulerOutput.Controls.Add($lblSchedulerOutputTitle)

$txtSchedulerOutput = New-Object System.Windows.Forms.TextBox
$txtSchedulerOutput.Location = New-Object System.Drawing.Point(16,42)
$txtSchedulerOutput.Size = New-Object System.Drawing.Size(700,28)
$txtSchedulerOutput.ReadOnly = $true
$cardSchedulerOutput.Controls.Add($txtSchedulerOutput)

$btnSchedulerBrowseOutput = New-Object System.Windows.Forms.Button
$btnSchedulerBrowseOutput.Text = "Change Folder"
$btnSchedulerBrowseOutput.Location = New-Object System.Drawing.Point(730,40)
$btnSchedulerBrowseOutput.Size = New-Object System.Drawing.Size(120,32)
Style-SecondaryButton $btnSchedulerBrowseOutput
$cardSchedulerOutput.Controls.Add($btnSchedulerBrowseOutput)

$lblSchedulerOutputHint = New-Object System.Windows.Forms.Label
$lblSchedulerOutputHint.Text = "PNG screenshots + _RAQEB_Health\\HealthHistory.csv + AutomaticCapture.log"
$lblSchedulerOutputHint.Location = New-Object System.Drawing.Point(16,77)
$lblSchedulerOutputHint.Size = New-Object System.Drawing.Size(820,20)
$cardSchedulerOutput.Controls.Add($lblSchedulerOutputHint)

$cardSchedulerLog = New-Object System.Windows.Forms.Panel
$cardSchedulerLog.Location = New-Object System.Drawing.Point(24,516)
$cardSchedulerLog.Size = New-Object System.Drawing.Size(921,139)
Initialize-AghrabCard -Card $cardSchedulerLog
$tabScheduler.Controls.Add($cardSchedulerLog)

$lblSchedulerLogTitle = New-Object System.Windows.Forms.Label
$lblSchedulerLogTitle.Text = "Automatic Capture Activity"
$lblSchedulerLogTitle.Font = New-Object System.Drawing.Font("Segoe UI Semibold",10)
$lblSchedulerLogTitle.Location = New-Object System.Drawing.Point(16,10)
$lblSchedulerLogTitle.AutoSize = $true
$lblSchedulerLogTitle.Tag = "section"
$cardSchedulerLog.Controls.Add($lblSchedulerLogTitle)

$txtSchedulerLog = New-Object System.Windows.Forms.TextBox
$txtSchedulerLog.Multiline = $true
$txtSchedulerLog.ReadOnly = $true
$txtSchedulerLog.ScrollBars = "Vertical"
$txtSchedulerLog.Font = New-Object System.Drawing.Font("Consolas",8.5)
$txtSchedulerLog.Location = New-Object System.Drawing.Point(16,36)
$txtSchedulerLog.Size = New-Object System.Drawing.Size(889,88)
$cardSchedulerLog.Controls.Add($txtSchedulerLog)

$btnSchedulerSave.Add_Click({ Save-SchedulerFromUi })
$btnSchedulerRunNow.Add_Click({ Invoke-AutomaticCaptureCycle -Interactive })
$cmbSchedulerProfile.Add_SelectedIndexChanged({ Update-SchedulerStateUi })
$chkSchedulerAi.Add_CheckedChanged({ Update-SchedulerStateUi })

$chkSchedulerEnabled.Add_CheckedChanged({
    if (-not $script:LoadingSchedulerUi) {
        Save-SchedulerFromUi
    }
})

$btnSchedulerBrowseOutput.Add_Click({
    $fbd = New-Object System.Windows.Forms.FolderBrowserDialog
    $fbd.Description = "Select RAQEB output folder"
    $fbd.SelectedPath = Get-OutputRoot

    if ($fbd.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        $txtOutput.Text = $fbd.SelectedPath
        $txtSchedulerOutput.Text = $fbd.SelectedPath
        Refresh-Gallery
        Refresh-HealthCenter
    }
})

$script:SchedulerTimer = New-Object System.Windows.Forms.Timer
$script:SchedulerTimer.Interval = 10000
$script:SchedulerTimer.Add_Tick({ Invoke-SchedulerTick })



# ---------------- GALLERY TAB ----------------
$lblGalleryTitle = New-Object System.Windows.Forms.Label
$lblGalleryTitle.Text = "Screenshot Gallery"
$lblGalleryTitle.Font = New-Object System.Drawing.Font("Segoe UI Semibold",16,[System.Drawing.FontStyle]::Bold)
$lblGalleryTitle.Location = New-Object System.Drawing.Point(16,8)
$lblGalleryTitle.AutoSize = $true
$tabGallery.Controls.Add($lblGalleryTitle)

$lblGallerySubtitle = New-Object System.Windows.Forms.Label
$lblGallerySubtitle.Text = "Browse dashboard captures, retention policies and visual history"
$lblGallerySubtitle.Font = New-Object System.Drawing.Font("Segoe UI",8.7)
$lblGallerySubtitle.Location = New-Object System.Drawing.Point(18,37)
$lblGallerySubtitle.AutoSize = $true
$lblGallerySubtitle.Tag = "muted"
$tabGallery.Controls.Add($lblGallerySubtitle)

$cardGalleryRoot = New-Object System.Windows.Forms.Panel
$cardGalleryRoot.Location = New-Object System.Drawing.Point(16,60)
$cardGalleryRoot.Size = New-Object System.Drawing.Size(934,42)
Initialize-AghrabCard -Card $cardGalleryRoot
$tabGallery.Controls.Add($cardGalleryRoot)

$cardGalleryAlbums = New-Object System.Windows.Forms.Panel
$cardGalleryAlbums.Location = New-Object System.Drawing.Point(8,112)
$cardGalleryAlbums.Size = New-Object System.Drawing.Size(256,470)
Initialize-AghrabCard -Card $cardGalleryAlbums
$tabGallery.Controls.Add($cardGalleryAlbums)

$cardGalleryMedia = New-Object System.Windows.Forms.Panel
$cardGalleryMedia.Location = New-Object System.Drawing.Point(266,112)
$cardGalleryMedia.Size = New-Object System.Drawing.Size(690,526)
Initialize-AghrabCard -Card $cardGalleryMedia
$tabGallery.Controls.Add($cardGalleryMedia)

$lblGalleryRoot = New-Object System.Windows.Forms.Label
$lblGalleryRoot.Text = "Albums root:"
$lblGalleryRoot.Font = $font
$lblGalleryRoot.Location = New-Object System.Drawing.Point(12,10)
$lblGalleryRoot.Size = New-Object System.Drawing.Size(130,22)
$lblGalleryRoot.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
$lblGalleryRoot.AutoEllipsis = $true
$cardGalleryRoot.Controls.Add($lblGalleryRoot)

$txtGalleryRoot = New-Object System.Windows.Forms.TextBox
$txtGalleryRoot.Location = New-Object System.Drawing.Point(150,7)
$txtGalleryRoot.Size = New-Object System.Drawing.Size(756,28)
$txtGalleryRoot.ReadOnly = $true
$txtGalleryRoot.Anchor = "Top,Left,Right"
$cardGalleryRoot.Controls.Add($txtGalleryRoot)

$btnGalleryRefresh = New-Object System.Windows.Forms.Button
$btnGalleryRefresh.Text = "Refresh"
$btnGalleryRefresh.Location = New-Object System.Drawing.Point(239,62)
$btnGalleryRefresh.Size = New-Object System.Drawing.Size(82,30)
$btnGalleryRefresh.Anchor = "Top,Left"
Style-SecondaryButton $btnGalleryRefresh
$cardGalleryMedia.Controls.Add($btnGalleryRefresh)

$btnGalleryOpenRoot = New-Object System.Windows.Forms.Button
$btnGalleryOpenRoot.Text = "Open Root"
$btnGalleryOpenRoot.Location = New-Object System.Drawing.Point(331,62)
$btnGalleryOpenRoot.Size = New-Object System.Drawing.Size(105,30)
$btnGalleryOpenRoot.Anchor = "Top,Left"
Style-SecondaryButton $btnGalleryOpenRoot
$cardGalleryMedia.Controls.Add($btnGalleryOpenRoot)

$lblAlbums = New-Object System.Windows.Forms.Label
$lblAlbums.Text = "Albums (sites)"
$lblAlbums.Font = $font
$lblAlbums.ForeColor = $Navy
$lblAlbums.Location = New-Object System.Drawing.Point(12,10)
$lblAlbums.AutoSize = $true
$cardGalleryAlbums.Controls.Add($lblAlbums)

$lstAlbums = New-Object System.Windows.Forms.ListBox
$lstAlbums.Location = New-Object System.Drawing.Point(12,76)
$lstAlbums.Size = New-Object System.Drawing.Size(232,176)
$lstAlbums.Anchor = "Top,Left"
$lstAlbums.Font = New-Object System.Drawing.Font("Segoe UI",9.5)
$cardGalleryAlbums.Controls.Add($lstAlbums)

$btnOpenAlbum = New-Object System.Windows.Forms.Button
$btnOpenAlbum.Text = "Open Album"
$btnOpenAlbum.Location = New-Object System.Drawing.Point(12,36)
$btnOpenAlbum.Size = New-Object System.Drawing.Size(110,32)
$btnOpenAlbum.Anchor = "Top,Left"
Style-SecondaryButton $btnOpenAlbum
$cardGalleryAlbums.Controls.Add($btnOpenAlbum)

$btnDeleteAlbum = New-Object System.Windows.Forms.Button
$btnDeleteAlbum.Text = "Delete Album"
$btnDeleteAlbum.Location = New-Object System.Drawing.Point(132,36)
$btnDeleteAlbum.Size = New-Object System.Drawing.Size(110,32)
$btnDeleteAlbum.Anchor = "Top,Left"
$btnDeleteAlbum.FlatStyle = "Flat"
$btnDeleteAlbum.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(210,58,58)
$btnDeleteAlbum.BackColor = [System.Drawing.Color]::White
$btnDeleteAlbum.ForeColor = [System.Drawing.Color]::FromArgb(180,35,35)
$btnDeleteAlbum.Cursor = [System.Windows.Forms.Cursors]::Hand
$cardGalleryAlbums.Controls.Add($btnDeleteAlbum)

# Per-album retention
$lblRetentionSectionHint = New-Object System.Windows.Forms.Label
$lblRetentionSectionHint.Text = "Policy for selected album:"
$lblRetentionSectionHint.Location = New-Object System.Drawing.Point(12,262)
$lblRetentionSectionHint.AutoSize = $true
$lblRetentionSectionHint.ForeColor = $Navy
$cardGalleryAlbums.Controls.Add($lblRetentionSectionHint)

$grpAlbumRetention = New-Object System.Windows.Forms.GroupBox
$grpAlbumRetention.Text = "Retention - Selected Album"
$grpAlbumRetention.Location = New-Object System.Drawing.Point(12,284)
$grpAlbumRetention.Size = New-Object System.Drawing.Size(232,174)
$grpAlbumRetention.Anchor = "Top,Left"
$grpAlbumRetention.Enabled = $false
$cardGalleryAlbums.Controls.Add($grpAlbumRetention)

$lblAlbumKeepDays = New-Object System.Windows.Forms.Label
$lblAlbumKeepDays.Text = "Keep days:"
$lblAlbumKeepDays.Location = New-Object System.Drawing.Point(12,30)
$lblAlbumKeepDays.AutoSize = $true
$grpAlbumRetention.Controls.Add($lblAlbumKeepDays)

$numAlbumKeepDays = New-Object System.Windows.Forms.NumericUpDown
$numAlbumKeepDays.Minimum = 0
$numAlbumKeepDays.Maximum = 3650
$numAlbumKeepDays.Value = 30
$numAlbumKeepDays.Location = New-Object System.Drawing.Point(115,26)
$numAlbumKeepDays.Size = New-Object System.Drawing.Size(90,28)
$grpAlbumRetention.Controls.Add($numAlbumKeepDays)

$lblAlbumMaxImages = New-Object System.Windows.Forms.Label
$lblAlbumMaxImages.Text = "Max images:"
$lblAlbumMaxImages.Location = New-Object System.Drawing.Point(12,66)
$lblAlbumMaxImages.AutoSize = $true
$grpAlbumRetention.Controls.Add($lblAlbumMaxImages)

$numAlbumMaxImages = New-Object System.Windows.Forms.NumericUpDown
$numAlbumMaxImages.Minimum = 0
$numAlbumMaxImages.Maximum = 100000
$numAlbumMaxImages.Increment = 50
$numAlbumMaxImages.Value = 500
$numAlbumMaxImages.Location = New-Object System.Drawing.Point(115,62)
$numAlbumMaxImages.Size = New-Object System.Drawing.Size(90,28)
$grpAlbumRetention.Controls.Add($numAlbumMaxImages)

$lblAlbumRetentionHint = New-Object System.Windows.Forms.Label
$lblAlbumRetentionHint.Text = "0 = unlimited"
$lblAlbumRetentionHint.Location = New-Object System.Drawing.Point(12,96)
$lblAlbumRetentionHint.AutoSize = $true
$lblAlbumRetentionHint.ForeColor = [System.Drawing.Color]::Gray
$grpAlbumRetention.Controls.Add($lblAlbumRetentionHint)

$btnSaveAlbumPolicy = New-Object System.Windows.Forms.Button
$btnSaveAlbumPolicy.Text = "Save Policy"
$btnSaveAlbumPolicy.Location = New-Object System.Drawing.Point(12,112)
$btnSaveAlbumPolicy.Size = New-Object System.Drawing.Size(95,32)
Style-SecondaryButton $btnSaveAlbumPolicy
$grpAlbumRetention.Controls.Add($btnSaveAlbumPolicy)

$btnCleanupAlbumNow = New-Object System.Windows.Forms.Button
$btnCleanupAlbumNow.Text = "Cleanup Now"
$btnCleanupAlbumNow.Location = New-Object System.Drawing.Point(115,112)
$btnCleanupAlbumNow.Size = New-Object System.Drawing.Size(105,32)
Style-SecondaryButton $btnCleanupAlbumNow
$grpAlbumRetention.Controls.Add($btnCleanupAlbumNow)

$lblAlbumRetentionStatus = New-Object System.Windows.Forms.Label
$lblAlbumRetentionStatus.Text = ""
$lblAlbumRetentionStatus.Location = New-Object System.Drawing.Point(12,148)
$lblAlbumRetentionStatus.Size = New-Object System.Drawing.Size(205,22)
$lblAlbumRetentionStatus.ForeColor = $Navy
$grpAlbumRetention.Controls.Add($lblAlbumRetentionStatus)


$lblShots = New-Object System.Windows.Forms.Label
$lblShots.Text = "Screenshots"
$lblShots.Font = $font
$lblShots.ForeColor = $Navy
$lblShots.Location = New-Object System.Drawing.Point(14,10)
$lblShots.AutoSize = $true
$cardGalleryMedia.Controls.Add($lblShots)

$lblShotsHint = New-Object System.Windows.Forms.Label
$lblShotsHint.Text = "Select an image to preview below"
$lblShotsHint.Font = New-Object System.Drawing.Font("Segoe UI",8)
$lblShotsHint.Location = New-Object System.Drawing.Point(14,32)
$lblShotsHint.AutoSize = $true
$lblShotsHint.ForeColor = [System.Drawing.Color]::Gray
$cardGalleryMedia.Controls.Add($lblShotsHint)

$lblGallerySelectedAlbum = New-Object System.Windows.Forms.Label
$lblGallerySelectedAlbum.Text = "No album selected"
$lblGallerySelectedAlbum.Font = New-Object System.Drawing.Font("Segoe UI Semibold",9)
$lblGallerySelectedAlbum.Location = New-Object System.Drawing.Point(430,12)
$lblGallerySelectedAlbum.Size = New-Object System.Drawing.Size(235,20)
$lblGallerySelectedAlbum.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
$cardGalleryMedia.Controls.Add($lblGallerySelectedAlbum)

$lblGalleryImageCount = New-Object System.Windows.Forms.Label
$lblGalleryImageCount.Text = Convert-AghrabUiText -Text "0 captures" -Language $script:CurrentLanguage
$lblGalleryImageCount.Font = New-Object System.Drawing.Font("Segoe UI",8)
$lblGalleryImageCount.Location = New-Object System.Drawing.Point(500,34)
$lblGalleryImageCount.Size = New-Object System.Drawing.Size(165,18)
$lblGalleryImageCount.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
$lblGalleryImageCount.Tag = "muted"
$cardGalleryMedia.Controls.Add($lblGalleryImageCount)

$script:GalleryThumbList = New-Object System.Windows.Forms.ImageList
$script:GalleryThumbList.ImageSize = New-Object System.Drawing.Size(160,90)
$script:GalleryThumbList.ColorDepth = [System.Windows.Forms.ColorDepth]::Depth32Bit
$script:GalleryHoverIndex = -1

$lvImages = New-Object System.Windows.Forms.ListView
$lvImages.Location = New-Object System.Drawing.Point(14,102)
$lvImages.Size = New-Object System.Drawing.Size(384,390)
$lvImages.Anchor = "Top,Bottom,Left"
$lvImages.View = [System.Windows.Forms.View]::LargeIcon
$lvImages.MultiSelect = $false
$lvImages.HideSelection = $false
$lvImages.ShowItemToolTips = $true
$lvImages.LabelWrap = $true
$lvImages.AutoArrange = $true
$lvImages.Scrollable = $true
$lvImages.LargeImageList = $script:GalleryThumbList
$lvImages.Font = New-Object System.Drawing.Font("Segoe UI Semibold",8.6)
$lvImages.OwnerDraw = $false
$lvImages.BackColor = [System.Drawing.Color]::White
$cardGalleryMedia.Controls.Add($lvImages)

# Dedicated preview card. This makes Gallery feel like a media browser
# instead of two old ListView/TextBox surfaces stacked vertically.
$panelGalleryPreview = New-Object System.Windows.Forms.Panel
$panelGalleryPreview.Location = New-Object System.Drawing.Point(410,102)
$panelGalleryPreview.Size = New-Object System.Drawing.Size(266,390)
Initialize-AghrabCard -Card $panelGalleryPreview
$cardGalleryMedia.Controls.Add($panelGalleryPreview)

$lblPreview = New-Object System.Windows.Forms.Label
$lblPreview.Text = "Selected Capture"
$lblPreview.Font = New-Object System.Drawing.Font("Segoe UI Semibold",10,[System.Drawing.FontStyle]::Bold)
$lblPreview.Location = New-Object System.Drawing.Point(12,12)
$lblPreview.Size = New-Object System.Drawing.Size(180,22)
$panelGalleryPreview.Controls.Add($lblPreview)

$lblPreviewBadge = New-Object System.Windows.Forms.Label
$lblPreviewBadge.Text = "PREVIEW"
$lblPreviewBadge.Font = New-Object System.Drawing.Font("Segoe UI Semibold",7.5,[System.Drawing.FontStyle]::Bold)
$lblPreviewBadge.Location = New-Object System.Drawing.Point(190,11)
$lblPreviewBadge.Size = New-Object System.Drawing.Size(62,22)
$lblPreviewBadge.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$lblPreviewBadge.Tag = "galleryBadge"
$panelGalleryPreview.Controls.Add($lblPreviewBadge)
Set-RoundedControlRegion -Control $lblPreviewBadge -Radius 10

$picPreview = New-Object System.Windows.Forms.PictureBox
$picPreview.Location = New-Object System.Drawing.Point(12,45)
$picPreview.Size = New-Object System.Drawing.Size(242,245)
$picPreview.BorderStyle = [System.Windows.Forms.BorderStyle]::None
$picPreview.BackColor = [System.Drawing.Color]::White
$picPreview.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::Zoom
$panelGalleryPreview.Controls.Add($picPreview)

$lblPreviewInfo = New-Object System.Windows.Forms.Label
$lblPreviewInfo.Text = Convert-AghrabUiText -Text "No image selected" -Language $script:CurrentLanguage
$lblPreviewInfo.Location = New-Object System.Drawing.Point(12,302)
$lblPreviewInfo.Size = New-Object System.Drawing.Size(242,66)
$lblPreviewInfo.Font = New-Object System.Drawing.Font("Segoe UI",8.2)
$lblPreviewInfo.AutoEllipsis = $true
$lblPreviewInfo.Tag = "muted"
$panelGalleryPreview.Controls.Add($lblPreviewInfo)

$btnOpenImage = New-Object System.Windows.Forms.Button
$btnOpenImage.Text = "Open Image"
$btnOpenImage.Location = New-Object System.Drawing.Point(14,62)
$btnOpenImage.Size = New-Object System.Drawing.Size(100,30)
$btnOpenImage.Anchor = "Top,Left"
Style-SecondaryButton $btnOpenImage
$cardGalleryMedia.Controls.Add($btnOpenImage)

$btnDeleteImage = New-Object System.Windows.Forms.Button
$btnDeleteImage.Text = "Delete Image"
$btnDeleteImage.Location = New-Object System.Drawing.Point(124,62)
$btnDeleteImage.Size = New-Object System.Drawing.Size(105,30)
$btnDeleteImage.Anchor = "Top,Left"
$btnDeleteImage.FlatStyle = "Flat"
$btnDeleteImage.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(210,58,58)
$btnDeleteImage.BackColor = [System.Drawing.Color]::White
$btnDeleteImage.ForeColor = [System.Drawing.Color]::FromArgb(180,35,35)
$btnDeleteImage.Cursor = [System.Windows.Forms.Cursors]::Hand
$cardGalleryMedia.Controls.Add($btnDeleteImage)

$galleryToolbarLine = New-Object System.Windows.Forms.Panel
$galleryToolbarLine.Location = New-Object System.Drawing.Point(14,98)
$galleryToolbarLine.Size = New-Object System.Drawing.Size(662,1)
$galleryToolbarLine.Anchor = "Top,Left,Right"
$galleryToolbarLine.BackColor = [System.Drawing.Color]::FromArgb(218,226,235)
$cardGalleryMedia.Controls.Add($galleryToolbarLine)



function Update-GalleryPreviewLayout {
    if ($null -eq $cardGalleryMedia -or $null -eq $panelGalleryPreview) {
        return
    }

    # Stable media-browser layout: thumbnail grid left, preview card right.
    $lvImages.Location = New-Object System.Drawing.Point(14,102)
    $lvImages.Size = New-Object System.Drawing.Size(384,[Math]::Max(260,$cardGalleryMedia.ClientSize.Height - 136))

    $panelGalleryPreview.Location = New-Object System.Drawing.Point(410,102)
    $panelGalleryPreview.Size = New-Object System.Drawing.Size(
        [Math]::Max(250,$cardGalleryMedia.ClientSize.Width - 424),
        $lvImages.Height
    )

    $previewWidth = [Math]::Max(220,$panelGalleryPreview.ClientSize.Width - 24)
    $picPreview.Size = New-Object System.Drawing.Size($previewWidth,245)
    $lblPreviewInfo.Size = New-Object System.Drawing.Size($previewWidth,72)
}


Update-GalleryPreviewLayout


# ---------------- ANALYZE TAB - V2 ----------------
$lblAnalyzePageTitle = New-Object System.Windows.Forms.Label
$lblAnalyzePageTitle.Text = "AI Visual Analysis"
$lblAnalyzePageTitle.Font = New-Object System.Drawing.Font("Segoe UI Semibold",16,[System.Drawing.FontStyle]::Bold)
$lblAnalyzePageTitle.Location = New-Object System.Drawing.Point(18,8)
$lblAnalyzePageTitle.AutoSize = $true
$lblAnalyzePageTitle.Tag = "section"
$tabAnalyze.Controls.Add($lblAnalyzePageTitle)

$lblAnalyzePageSubtitle = New-Object System.Windows.Forms.Label
$lblAnalyzePageSubtitle.Text = "Compare dashboard captures, inspect visual health and run local AI analysis"
$lblAnalyzePageSubtitle.Font = New-Object System.Drawing.Font("Segoe UI",8.7)
$lblAnalyzePageSubtitle.Location = New-Object System.Drawing.Point(20,38)
$lblAnalyzePageSubtitle.AutoSize = $true
$lblAnalyzePageSubtitle.Tag = "muted"
$tabAnalyze.Controls.Add($lblAnalyzePageSubtitle)

# ---- Analysis controls card
$cardAnalyzeControls = New-Object System.Windows.Forms.Panel
$cardAnalyzeControls.Location = New-Object System.Drawing.Point(18,62)
$cardAnalyzeControls.Size = New-Object System.Drawing.Size(927,62)
Initialize-AghrabCard -Card $cardAnalyzeControls
$tabAnalyze.Controls.Add($cardAnalyzeControls)

$lblAnalyzeAlbum = New-Object System.Windows.Forms.Label
$lblAnalyzeAlbum.Text = "Album"
$lblAnalyzeAlbum.Font = New-Object System.Drawing.Font("Segoe UI Semibold",8)
$lblAnalyzeAlbum.Location = New-Object System.Drawing.Point(14,8)
$lblAnalyzeAlbum.Size = New-Object System.Drawing.Size(60,18)
$lblAnalyzeAlbum.Tag = "muted"
$cardAnalyzeControls.Controls.Add($lblAnalyzeAlbum)

$cmbAnalyzeAlbum = New-Object System.Windows.Forms.ComboBox
$cmbAnalyzeAlbum.Location = New-Object System.Drawing.Point(14,27)
$cmbAnalyzeAlbum.Size = New-Object System.Drawing.Size(300,28)
$cmbAnalyzeAlbum.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$cardAnalyzeControls.Controls.Add($cmbAnalyzeAlbum)

$btnAnalyzeRefresh = New-Object System.Windows.Forms.Button
$btnAnalyzeRefresh.Text = "Refresh"
$btnAnalyzeRefresh.Location = New-Object System.Drawing.Point(323,25)
$btnAnalyzeRefresh.Size = New-Object System.Drawing.Size(90,30)
Style-SecondaryButton $btnAnalyzeRefresh
$cardAnalyzeControls.Controls.Add($btnAnalyzeRefresh)

$lblAnalyzeThreshold = New-Object System.Windows.Forms.Label
$lblAnalyzeThreshold.Text = "Pixel Threshold"
$lblAnalyzeThreshold.Font = New-Object System.Drawing.Font("Segoe UI Semibold",8)
$lblAnalyzeThreshold.Location = New-Object System.Drawing.Point(435,8)
$lblAnalyzeThreshold.Size = New-Object System.Drawing.Size(100,18)
$lblAnalyzeThreshold.Tag = "muted"
$cardAnalyzeControls.Controls.Add($lblAnalyzeThreshold)

$numAnalyzeThreshold = New-Object System.Windows.Forms.NumericUpDown
$numAnalyzeThreshold.Minimum = 5
$numAnalyzeThreshold.Maximum = 100
$numAnalyzeThreshold.Value = 28
$numAnalyzeThreshold.Location = New-Object System.Drawing.Point(435,27)
$numAnalyzeThreshold.Size = New-Object System.Drawing.Size(70,28)
$cardAnalyzeControls.Controls.Add($numAnalyzeThreshold)

$btnAnalyzeLatest = New-Object System.Windows.Forms.Button
$btnAnalyzeLatest.Text = "Pixel Compare"
$btnAnalyzeLatest.Location = New-Object System.Drawing.Point(520,25)
$btnAnalyzeLatest.Size = New-Object System.Drawing.Size(130,30)
Style-PrimaryButton $btnAnalyzeLatest
Set-AghrabButtonIcon -Button $btnAnalyzeLatest -Kind "bolt" -Color $Blue
$cardAnalyzeControls.Controls.Add($btnAnalyzeLatest)

$lblAnalyzeResult = New-Object System.Windows.Forms.Label
$lblAnalyzeResult.Text = "Ready for visual comparison"
$lblAnalyzeResult.Font = New-Object System.Drawing.Font("Segoe UI Semibold",8.5)
$lblAnalyzeResult.Location = New-Object System.Drawing.Point(666,19)
$lblAnalyzeResult.Size = New-Object System.Drawing.Size(245,34)
$lblAnalyzeResult.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
$lblAnalyzeResult.AutoEllipsis = $true
$cardAnalyzeControls.Controls.Add($lblAnalyzeResult)

# ---- Local AI control card
$grpAi = New-Object System.Windows.Forms.Panel
$grpAi.Tag = "card"
$grpAi.Location = New-Object System.Drawing.Point(18,132)
$grpAi.Size = New-Object System.Drawing.Size(927,112)
Initialize-AghrabCard -Card $grpAi
$tabAnalyze.Controls.Add($grpAi)

$picAnalyzeAi = New-Object System.Windows.Forms.PictureBox
$picAnalyzeAi.Location = New-Object System.Drawing.Point(14,14)
$picAnalyzeAi.Size = New-Object System.Drawing.Size(28,28)
$picAnalyzeAi.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::CenterImage
$picAnalyzeAi.Image = Get-AghrabIconImage -Kind "ai" -FallbackColor $Blue -Size 28
$grpAi.Controls.Add($picAnalyzeAi)

$lblAnalyzeAiTitle = New-Object System.Windows.Forms.Label
$lblAnalyzeAiTitle.Text = "Local Vision AI"
$lblAnalyzeAiTitle.Font = New-Object System.Drawing.Font("Segoe UI Semibold",10.5,[System.Drawing.FontStyle]::Bold)
$lblAnalyzeAiTitle.Location = New-Object System.Drawing.Point(50,10)
$lblAnalyzeAiTitle.Size = New-Object System.Drawing.Size(155,22)
$grpAi.Controls.Add($lblAnalyzeAiTitle)

$lblAiModel = New-Object System.Windows.Forms.Label
$lblAiModel.Text = "Qwen2.5-VL-3B Q4_K_M  •  CPU-first  •  16 GB profile"
$lblAiModel.Location = New-Object System.Drawing.Point(50,34)
$lblAiModel.Size = New-Object System.Drawing.Size(350,20)
$lblAiModel.Tag = "muted"
$grpAi.Controls.Add($lblAiModel)

$panelAnalyzeAiState = New-Object System.Windows.Forms.Panel
$panelAnalyzeAiState.Location = New-Object System.Drawing.Point(400,14)
$panelAnalyzeAiState.Size = New-Object System.Drawing.Size(180,46)
Set-RoundedControlRegion -Control $panelAnalyzeAiState -Radius 10
$grpAi.Controls.Add($panelAnalyzeAiState)

$lblAnalyzeAiStateTitle = New-Object System.Windows.Forms.Label
$lblAnalyzeAiStateTitle.Text = "AI STATUS"
$lblAnalyzeAiStateTitle.Font = New-Object System.Drawing.Font("Segoe UI Semibold",7)
$lblAnalyzeAiStateTitle.Location = New-Object System.Drawing.Point(10,4)
$lblAnalyzeAiStateTitle.Size = New-Object System.Drawing.Size(125,14)
$panelAnalyzeAiState.Controls.Add($lblAnalyzeAiStateTitle)

$lblAiStatus = New-Object System.Windows.Forms.Label
$lblAiStatus.Text = "Status: checking..."
$lblAiStatus.Font = New-Object System.Drawing.Font("Segoe UI Semibold",8.5,[System.Drawing.FontStyle]::Bold)
$lblAiStatus.Location = New-Object System.Drawing.Point(10,19)
$lblAiStatus.Size = New-Object System.Drawing.Size(160,22)
$lblAiStatus.AutoEllipsis = $true
$panelAnalyzeAiState.Controls.Add($lblAiStatus)

$btnAiStart = New-Object System.Windows.Forms.Button
$btnAiStart.Text = "Start AI"
$btnAiStart.Location = New-Object System.Drawing.Point(594,18)
$btnAiStart.Size = New-Object System.Drawing.Size(86,32)
Style-SecondaryButton $btnAiStart
$grpAi.Controls.Add($btnAiStart)

$btnAiStop = New-Object System.Windows.Forms.Button
$btnAiStop.Text = "Stop AI"
$btnAiStop.Location = New-Object System.Drawing.Point(688,18)
$btnAiStop.Size = New-Object System.Drawing.Size(86,32)
Style-SecondaryButton $btnAiStop
$grpAi.Controls.Add($btnAiStop)

# Compatibility-only controls. Existing backend event wiring still references
# these variables, but they are intentionally hidden from Analyze V2.
$btnAiTest = New-Object System.Windows.Forms.Button
$btnAiTest.Text = "Test AI"
$btnAiTest.Location = New-Object System.Drawing.Point(0,0)
$btnAiTest.Size = New-Object System.Drawing.Size(1,1)
$btnAiTest.Visible = $false
$grpAi.Controls.Add($btnAiTest)

$btnAiOpenFolder = New-Object System.Windows.Forms.Button
$btnAiOpenFolder.Text = "Open AI Folder"
$btnAiOpenFolder.Location = New-Object System.Drawing.Point(0,0)
$btnAiOpenFolder.Size = New-Object System.Drawing.Size(1,1)
$btnAiOpenFolder.Visible = $false
$grpAi.Controls.Add($btnAiOpenFolder)

# AI actions live below status card but remain the main actions.
$btnAiLatest = New-Object System.Windows.Forms.Button
$btnAiLatest.Text = "AI Analyze"
$btnAiLatest.Location = New-Object System.Drawing.Point(577,54)
$btnAiLatest.Size = New-Object System.Drawing.Size(132,1)
$btnAiLatest.Visible = $false
$grpAi.Controls.Add($btnAiLatest)

$btnAiCompare = New-Object System.Windows.Forms.Button
$btnAiCompare.Text = "AI Compare"
$btnAiCompare.Location = New-Object System.Drawing.Point(714,54)
$btnAiCompare.Size = New-Object System.Drawing.Size(132,1)
$btnAiCompare.Visible = $false
$grpAi.Controls.Add($btnAiCompare)

$lblAnalyzeAiActions = New-Object System.Windows.Forms.Label
$lblAnalyzeAiActions.Text = "ANALYSIS ACTIONS"
$lblAnalyzeAiActions.Font = New-Object System.Drawing.Font("Segoe UI Semibold",7)
$lblAnalyzeAiActions.Location = New-Object System.Drawing.Point(400,72)
$lblAnalyzeAiActions.Size = New-Object System.Drawing.Size(180,18)
$lblAnalyzeAiActions.Tag = "muted"
$grpAi.Controls.Add($lblAnalyzeAiActions)

# Primary AI actions stay inside Local Vision AI card. Text-only buttons
# avoid WinForms image/text wrapping on the user's DPI/layout.
$btnAnalyzeAiLatest = New-Object System.Windows.Forms.Button
$btnAnalyzeAiLatest.Text = "AI Analyze Latest"
$btnAnalyzeAiLatest.Location = New-Object System.Drawing.Point(590,66)
$btnAnalyzeAiLatest.Size = New-Object System.Drawing.Size(150,32)
$btnAnalyzeAiLatest.AutoEllipsis = $true
$btnAnalyzeAiLatest.Font = New-Object System.Drawing.Font("Segoe UI Semibold",9)
Style-PrimaryButton $btnAnalyzeAiLatest
$grpAi.Controls.Add($btnAnalyzeAiLatest)

$btnAnalyzeAiCompare = New-Object System.Windows.Forms.Button
$btnAnalyzeAiCompare.Text = "AI Compare Last 2"
$btnAnalyzeAiCompare.Location = New-Object System.Drawing.Point(748,66)
$btnAnalyzeAiCompare.Size = New-Object System.Drawing.Size(164,32)
$btnAnalyzeAiCompare.AutoEllipsis = $true
$btnAnalyzeAiCompare.Font = New-Object System.Drawing.Font("Segoe UI Semibold",9)
Style-PrimaryButton $btnAnalyzeAiCompare
$grpAi.Controls.Add($btnAnalyzeAiCompare)

# ---- Before / After media cards
$grpAnalyzeBefore = New-Object System.Windows.Forms.Panel
$grpAnalyzeBefore.Tag = "card"
$grpAnalyzeBefore.Location = New-Object System.Drawing.Point(18,252)
$grpAnalyzeBefore.Size = New-Object System.Drawing.Size(455,198)
Initialize-AghrabCard -Card $grpAnalyzeBefore
$tabAnalyze.Controls.Add($grpAnalyzeBefore)

$lblBeforeBadge = New-Object System.Windows.Forms.Label
$lblBeforeBadge.Text = "BASELINE"
$lblBeforeBadge.Font = New-Object System.Drawing.Font("Segoe UI Semibold",7.5,[System.Drawing.FontStyle]::Bold)
$lblBeforeBadge.Location = New-Object System.Drawing.Point(12,10)
$lblBeforeBadge.Size = New-Object System.Drawing.Size(72,22)
$lblBeforeBadge.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$lblBeforeBadge.Tag = "analysisBadge"
$grpAnalyzeBefore.Controls.Add($lblBeforeBadge)
Set-RoundedControlRegion -Control $lblBeforeBadge -Radius 10

$lblAnalyzeBefore = New-Object System.Windows.Forms.Label
$lblAnalyzeBefore.Text = "No baseline image"
$lblAnalyzeBefore.Font = New-Object System.Drawing.Font("Segoe UI Semibold",8.3)
$lblAnalyzeBefore.Location = New-Object System.Drawing.Point(92,10)
$lblAnalyzeBefore.Size = New-Object System.Drawing.Size(347,22)
$lblAnalyzeBefore.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
$lblAnalyzeBefore.AutoEllipsis = $true
$grpAnalyzeBefore.Controls.Add($lblAnalyzeBefore)

$picAnalyzeBefore = New-Object System.Windows.Forms.PictureBox
$picAnalyzeBefore.Location = New-Object System.Drawing.Point(12,40)
$picAnalyzeBefore.Size = New-Object System.Drawing.Size(431,146)
$picAnalyzeBefore.BorderStyle = [System.Windows.Forms.BorderStyle]::None
$picAnalyzeBefore.BackColor = [System.Drawing.Color]::White
$picAnalyzeBefore.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::Zoom
$grpAnalyzeBefore.Controls.Add($picAnalyzeBefore)

$grpAnalyzeAfter = New-Object System.Windows.Forms.Panel
$grpAnalyzeAfter.Tag = "card"
$grpAnalyzeAfter.Location = New-Object System.Drawing.Point(490,252)
$grpAnalyzeAfter.Size = New-Object System.Drawing.Size(455,198)
Initialize-AghrabCard -Card $grpAnalyzeAfter
$tabAnalyze.Controls.Add($grpAnalyzeAfter)

$lblAfterBadge = New-Object System.Windows.Forms.Label
$lblAfterBadge.Text = "LATEST"
$lblAfterBadge.Font = New-Object System.Drawing.Font("Segoe UI Semibold",7.5,[System.Drawing.FontStyle]::Bold)
$lblAfterBadge.Location = New-Object System.Drawing.Point(12,10)
$lblAfterBadge.Size = New-Object System.Drawing.Size(62,22)
$lblAfterBadge.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$lblAfterBadge.Tag = "analysisBadge"
$grpAnalyzeAfter.Controls.Add($lblAfterBadge)
Set-RoundedControlRegion -Control $lblAfterBadge -Radius 10

$lblAnalyzeAfter = New-Object System.Windows.Forms.Label
$lblAnalyzeAfter.Text = "No latest image"
$lblAnalyzeAfter.Font = New-Object System.Drawing.Font("Segoe UI Semibold",8.3)
$lblAnalyzeAfter.Location = New-Object System.Drawing.Point(82,10)
$lblAnalyzeAfter.Size = New-Object System.Drawing.Size(357,22)
$lblAnalyzeAfter.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
$lblAnalyzeAfter.AutoEllipsis = $true
$grpAnalyzeAfter.Controls.Add($lblAnalyzeAfter)

$picAnalyzeAfter = New-Object System.Windows.Forms.PictureBox
$picAnalyzeAfter.Location = New-Object System.Drawing.Point(12,40)
$picAnalyzeAfter.Size = New-Object System.Drawing.Size(431,146)
$picAnalyzeAfter.BorderStyle = [System.Windows.Forms.BorderStyle]::None
$picAnalyzeAfter.BackColor = [System.Drawing.Color]::White
$picAnalyzeAfter.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::Zoom
$grpAnalyzeAfter.Controls.Add($picAnalyzeAfter)

# ---- AI summary KPI strip
$cardAnalyzeKpis = New-Object System.Windows.Forms.Panel
$cardAnalyzeKpis.Location = New-Object System.Drawing.Point(18,458)
$cardAnalyzeKpis.Size = New-Object System.Drawing.Size(927,60)
Initialize-AghrabCard -Card $cardAnalyzeKpis
$tabAnalyze.Controls.Add($cardAnalyzeKpis)

function New-AnalyzeMetric {
    param(
        [int]$Left,
        [int]$Width,
        [string]$Title
    )

    $p = New-Object System.Windows.Forms.Panel
    $p.Location = New-Object System.Drawing.Point($Left,7)
    $p.Size = New-Object System.Drawing.Size($Width,46)
    $p.Tag = "analysisMetric"
    Set-RoundedControlRegion -Control $p -Radius 9
    $cardAnalyzeKpis.Controls.Add($p)

    $t = New-Object System.Windows.Forms.Label
    $t.Text = $Title
    $t.Font = New-Object System.Drawing.Font("Segoe UI Semibold",7.2)
    $t.Location = New-Object System.Drawing.Point(9,4)
    $t.Size = New-Object System.Drawing.Size(($Width-18),14)
    $t.Tag = "muted"
    $p.Controls.Add($t)

    $v = New-Object System.Windows.Forms.Label
    $v.Text = "-"
    $v.Font = New-Object System.Drawing.Font("Segoe UI Semibold",10,[System.Drawing.FontStyle]::Bold)
    $v.Location = New-Object System.Drawing.Point(9,20)
    $v.Size = New-Object System.Drawing.Size(($Width-18),20)
    $p.Controls.Add($v)

    return [PSCustomObject]@{ Panel=$p; Title=$t; Value=$v }
}

$metricAiOverall = New-AnalyzeMetric -Left 8   -Width 145 -Title "OVERALL"
$metricAiLoaded  = New-AnalyzeMetric -Left 160 -Width 135 -Title "DASHBOARD LOADED"
$metricAiEmpty   = New-AnalyzeMetric -Left 302 -Width 135 -Title "EMPTY PANELS"
$metricAiData    = New-AnalyzeMetric -Left 444 -Width 135 -Title "WITH DATA"
$metricAiErrors  = New-AnalyzeMetric -Left 586 -Width 135 -Title "ERRORS"
$metricAiConf    = New-AnalyzeMetric -Left 728 -Width 190 -Title "AI CONFIDENCE"

$cardAiSocStatus = $metricAiOverall.Panel
$cardAiSocLoaded = $metricAiLoaded.Panel
$cardAiSocEmpty = $metricAiEmpty.Panel
$cardAiSocData = $metricAiData.Panel
$cardAiSocErrors = $metricAiErrors.Panel
$cardAiSocConfidence = $metricAiConf.Panel

$lblAiSocStatus = $metricAiOverall.Value
$lblAiSocLoaded = $metricAiLoaded.Value
$lblAiSocEmpty = $metricAiEmpty.Value
$lblAiSocData = $metricAiData.Value
$lblAiSocErrors = $metricAiErrors.Value
$lblAiSocConfidence = $metricAiConf.Value

# ---- Structured report + No Data Inspector
$cardAiReport = New-Object System.Windows.Forms.Panel
$cardAiReport.Location = New-Object System.Drawing.Point(18,526)
$cardAiReport.Size = New-Object System.Drawing.Size(927,178)
$cardAiReport.Anchor = "Top,Left"
Initialize-AghrabCard -Card $cardAiReport
$tabAnalyze.Controls.Add($cardAiReport)

$lblAiResult = New-Object System.Windows.Forms.Label
$lblAiResult.Text = "Analysis Report"
$lblAiResult.Font = New-Object System.Drawing.Font("Segoe UI Semibold",10,[System.Drawing.FontStyle]::Bold)
$lblAiResult.Location = New-Object System.Drawing.Point(12,10)
$lblAiResult.Size = New-Object System.Drawing.Size(145,22)
$lblAiResult.Tag = "section"
$cardAiReport.Controls.Add($lblAiResult)

$btnCopyAiReport = New-Object System.Windows.Forms.Button
$btnCopyAiReport.Text = "Copy"
$btnCopyAiReport.Location = New-Object System.Drawing.Point(489,7)
$btnCopyAiReport.Size = New-Object System.Drawing.Size(58,27)
Style-SecondaryButton $btnCopyAiReport
$cardAiReport.Controls.Add($btnCopyAiReport)

$btnSaveAiReport = New-Object System.Windows.Forms.Button
$btnSaveAiReport.Text = "Save"
$btnSaveAiReport.Location = New-Object System.Drawing.Point(553,7)
$btnSaveAiReport.Size = New-Object System.Drawing.Size(58,27)
Style-SecondaryButton $btnSaveAiReport
$cardAiReport.Controls.Add($btnSaveAiReport)

$txtAiResult = New-Object System.Windows.Forms.TextBox
$txtAiResult.Multiline = $true
$txtAiResult.ReadOnly = $true
$txtAiResult.ScrollBars = "Vertical"
$txtAiResult.Font = New-Object System.Drawing.Font("Consolas",8.7)
$txtAiResult.Location = New-Object System.Drawing.Point(12,38)
$txtAiResult.Size = New-Object System.Drawing.Size(599,127)
$txtAiResult.Text = "AI is local and optional. Select an album and run AI Analyze Latest."
$cardAiReport.Controls.Add($txtAiResult)

$panelNoDataInspector = New-Object System.Windows.Forms.Panel
$panelNoDataInspector.Location = New-Object System.Drawing.Point(623,8)
$panelNoDataInspector.Size = New-Object System.Drawing.Size(292,157)
$panelNoDataInspector.BorderStyle = [System.Windows.Forms.BorderStyle]::None
$panelNoDataInspector.Tag = "card"
Set-RoundedControlRegion -Control $panelNoDataInspector -Radius 9
$cardAiReport.Controls.Add($panelNoDataInspector)

$lblNoDataTitle = New-Object System.Windows.Forms.Label
$lblNoDataTitle.Text = "No Data Inspector"
$lblNoDataTitle.Font = New-Object System.Drawing.Font("Segoe UI Semibold",9.5,[System.Drawing.FontStyle]::Bold)
$lblNoDataTitle.Location = New-Object System.Drawing.Point(10,8)
$lblNoDataTitle.Size = New-Object System.Drawing.Size(160,22)
$lblNoDataTitle.Tag = "section"
$panelNoDataInspector.Controls.Add($lblNoDataTitle)

$lblNoDataCount = New-Object System.Windows.Forms.Label
$lblNoDataCount.Text = "Count: -"
$lblNoDataCount.Font = New-Object System.Drawing.Font("Segoe UI Semibold",8)
$lblNoDataCount.Location = New-Object System.Drawing.Point(194,8)
$lblNoDataCount.Size = New-Object System.Drawing.Size(84,22)
$lblNoDataCount.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
$panelNoDataInspector.Controls.Add($lblNoDataCount)

$lstNoDataPanels = New-Object System.Windows.Forms.ListBox
$lstNoDataPanels.Location = New-Object System.Drawing.Point(10,36)
$lstNoDataPanels.Size = New-Object System.Drawing.Size(268,109)
$lstNoDataPanels.Font = New-Object System.Drawing.Font("Segoe UI",8.8)
$panelNoDataInspector.Controls.Add($lstNoDataPanels)

Update-NoDataInspector

# Wire the visible action buttons to the original backend buttons/functions.
$btnAnalyzeAiLatest.Add_Click({ Invoke-AiAnalyzeLatest })
$btnAnalyzeAiCompare.Add_Click({ Invoke-AiCompareLastTwo })

$btnCopyAiReport.Add_Click({
    try {
        if (-not [string]::IsNullOrWhiteSpace($txtAiResult.Text)) {
            [System.Windows.Forms.Clipboard]::SetText($txtAiResult.Text)
        }
    } catch {}
})

$btnSaveAiReport.Add_Click({
    if ([string]::IsNullOrWhiteSpace($txtAiResult.Text)) { return }

    $save = New-Object System.Windows.Forms.SaveFileDialog
    $save.Filter = "Text Report (*.txt)|*.txt"
    $save.FileName = "RAQEB-Analysis-" + (Get-Date -Format "yyyyMMdd-HHmmss") + ".txt"

    if ($save.ShowDialog($form) -eq [System.Windows.Forms.DialogResult]::OK) {
        $txtAiResult.Text | Set-Content -LiteralPath $save.FileName -Encoding UTF8 -Force
    }
})

$tabAnalyze.Add_Resize({
    try {
        # Keep the Analyze workspace centered and bounded.
        $workspaceWidth = 927
        $left = [Math]::Max(18,[Math]::Floor(($tabAnalyze.ClientSize.Width - $workspaceWidth) / 2))

        foreach ($control in @(
            $cardAnalyzeControls,$grpAi,$cardAnalyzeKpis,$cardAiReport
        )) {
            if ($null -ne $control) { $control.Left = $left }
        }

        $grpAnalyzeBefore.Left = $left
        $grpAnalyzeAfter.Left = $left + 472

    }
    catch {}
})


# ---------------- SECURITY TAB ----------------
$lblSecurityTitle = New-Object System.Windows.Forms.Label
$lblSecurityTitle.Text = "Security Center"
$lblSecurityTitle.Font = New-Object System.Drawing.Font("Segoe UI Semibold",16,[System.Drawing.FontStyle]::Bold)
$lblSecurityTitle.Location = New-Object System.Drawing.Point(24,20)
$lblSecurityTitle.AutoSize = $true
$lblSecurityTitle.Tag = "section"
$tabSecurity.Controls.Add($lblSecurityTitle)

$lblSecuritySubtitle = New-Object System.Windows.Forms.Label
$lblSecuritySubtitle.Text = "Local protection, integrity, sessions and security audit for RAQEB Sentinel"
$lblSecuritySubtitle.Location = New-Object System.Drawing.Point(26,54)
$lblSecuritySubtitle.Size = New-Object System.Drawing.Size(760,22)
$tabSecurity.Controls.Add($lblSecuritySubtitle)

$cardSecurityStatus = New-Object System.Windows.Forms.Panel
$cardSecurityStatus.Location = New-Object System.Drawing.Point(24,88)
$cardSecurityStatus.Size = New-Object System.Drawing.Size(560,300)
Initialize-AghrabCard -Card $cardSecurityStatus
$tabSecurity.Controls.Add($cardSecurityStatus)

$lblSecurityStatusTitle = New-Object System.Windows.Forms.Label
$lblSecurityStatusTitle.Text = "Protection Status"
$lblSecurityStatusTitle.Font = New-Object System.Drawing.Font("Segoe UI Semibold",10)
$lblSecurityStatusTitle.Location = New-Object System.Drawing.Point(16,14)
$lblSecurityStatusTitle.AutoSize = $true
$lblSecurityStatusTitle.Tag = "section"
$cardSecurityStatus.Controls.Add($lblSecurityStatusTitle)

function New-SecurityStatusRow {
    param(
        [string]$Name,
        [int]$Top
    )

    $label = New-Object System.Windows.Forms.Label
    $label.Text = $Name
    $label.Location = New-Object System.Drawing.Point(18,$Top)
    $label.Size = New-Object System.Drawing.Size(170,22)
    $cardSecurityStatus.Controls.Add($label)

    $value = New-Object System.Windows.Forms.Label
    $value.Text = "Checking..."
    $value.Location = New-Object System.Drawing.Point(200,$Top)
    $value.Size = New-Object System.Drawing.Size(335,22)
    $value.Font = New-Object System.Drawing.Font("Segoe UI Semibold",9)
    $cardSecurityStatus.Controls.Add($value)

    return $value
}

$lblSecCredentials = New-SecurityStatusRow -Name "Credential Storage" -Top 52
$lblSecAiServer = New-SecurityStatusRow -Name "AI Server" -Top 88
$lblSecSessions = New-SecurityStatusRow -Name "Browser Sessions" -Top 124
$lblSecCache = New-SecurityStatusRow -Name "Temporary AI Cache" -Top 160
$lblSecIntegrity = New-SecurityStatusRow -Name "File Integrity" -Top 196
$lblSecAudit = New-SecurityStatusRow -Name "Security Audit Log" -Top 232

$cardSecurityActions = New-Object System.Windows.Forms.Panel
$cardSecurityActions.Location = New-Object System.Drawing.Point(600,88)
$cardSecurityActions.Size = New-Object System.Drawing.Size(345,300)
Initialize-AghrabCard -Card $cardSecurityActions
$tabSecurity.Controls.Add($cardSecurityActions)

$lblSecurityActionsTitle = New-Object System.Windows.Forms.Label
$lblSecurityActionsTitle.Text = "Security Actions"
$lblSecurityActionsTitle.Font = New-Object System.Drawing.Font("Segoe UI Semibold",10)
$lblSecurityActionsTitle.Location = New-Object System.Drawing.Point(16,14)
$lblSecurityActionsTitle.AutoSize = $true
$lblSecurityActionsTitle.Tag = "section"
$cardSecurityActions.Controls.Add($lblSecurityActionsTitle)

$btnSecurityCheck = New-Object System.Windows.Forms.Button
$btnSecurityCheck.Text = "Run Security Check"
$btnSecurityCheck.Location = New-Object System.Drawing.Point(18,52)
$btnSecurityCheck.Size = New-Object System.Drawing.Size(305,38)
Style-PrimaryButton $btnSecurityCheck
$cardSecurityActions.Controls.Add($btnSecurityCheck)

$btnClearSessions = New-Object System.Windows.Forms.Button
$btnClearSessions.Text = "Clear Saved Sessions"
$btnClearSessions.Location = New-Object System.Drawing.Point(18,102)
$btnClearSessions.Size = New-Object System.Drawing.Size(305,36)
Style-SecondaryButton $btnClearSessions
$cardSecurityActions.Controls.Add($btnClearSessions)

$btnClearAiCache = New-Object System.Windows.Forms.Button
$btnClearAiCache.Text = "Clear AI Cache"
$btnClearAiCache.Location = New-Object System.Drawing.Point(18,150)
$btnClearAiCache.Size = New-Object System.Drawing.Size(305,36)
Style-SecondaryButton $btnClearAiCache
$cardSecurityActions.Controls.Add($btnClearAiCache)

$btnOpenAudit = New-Object System.Windows.Forms.Button
$btnOpenAudit.Text = "Open Audit Log"
$btnOpenAudit.Location = New-Object System.Drawing.Point(18,198)
$btnOpenAudit.Size = New-Object System.Drawing.Size(305,36)
Style-SecondaryButton $btnOpenAudit
$cardSecurityActions.Controls.Add($btnOpenAudit)

$btnRefreshSecurity = New-Object System.Windows.Forms.Button
$btnRefreshSecurity.Text = "Refresh Status"
$btnRefreshSecurity.Location = New-Object System.Drawing.Point(18,246)
$btnRefreshSecurity.Size = New-Object System.Drawing.Size(305,32)
Style-SecondaryButton $btnRefreshSecurity
$cardSecurityActions.Controls.Add($btnRefreshSecurity)

$cardSecurityAudit = New-Object System.Windows.Forms.Panel
$cardSecurityAudit.Location = New-Object System.Drawing.Point(24,404)
$cardSecurityAudit.Size = New-Object System.Drawing.Size(921,245)
Initialize-AghrabCard -Card $cardSecurityAudit
$tabSecurity.Controls.Add($cardSecurityAudit)

$lblSecurityAuditTitle = New-Object System.Windows.Forms.Label
$lblSecurityAuditTitle.Text = "Recent Security Activity"
$lblSecurityAuditTitle.Font = New-Object System.Drawing.Font("Segoe UI Semibold",10)
$lblSecurityAuditTitle.Location = New-Object System.Drawing.Point(16,12)
$lblSecurityAuditTitle.AutoSize = $true
$lblSecurityAuditTitle.Tag = "section"
$cardSecurityAudit.Controls.Add($lblSecurityAuditTitle)

$txtSecurityAudit = New-Object System.Windows.Forms.TextBox
$txtSecurityAudit.Multiline = $true
$txtSecurityAudit.ReadOnly = $true
$txtSecurityAudit.ScrollBars = "Vertical"
$txtSecurityAudit.Font = New-Object System.Drawing.Font("Consolas",8.5)
$txtSecurityAudit.Location = New-Object System.Drawing.Point(16,42)
$txtSecurityAudit.Size = New-Object System.Drawing.Size(889,185)
$txtSecurityAudit.Anchor = "Top,Left,Right"
$cardSecurityAudit.Controls.Add($txtSecurityAudit)

function Update-SecurityAuditPreview {
    if ($null -eq $txtSecurityAudit) { return }

    try {
        if (Test-Path -LiteralPath $script:SecurityAuditFile -PathType Leaf) {
            $lines = @(Get-Content -LiteralPath $script:SecurityAuditFile -Tail 25 -ErrorAction SilentlyContinue)
            $txtSecurityAudit.Text = ($lines -join "`r`n")
        }
        else {
            $txtSecurityAudit.Text = "No security events recorded yet."
        }
    }
    catch {
        $txtSecurityAudit.Text = "Could not read security audit log."
    }
}

function Update-SecurityCenter {
    if ($null -eq $lblSecCredentials) { return }

    $palette = Get-AghrabPalette -Theme $script:CurrentTheme

    $lblSecCredentials.Text = "Protected - Windows DPAPI (Current User)"
    $lblSecCredentials.ForeColor = $palette.Success

    if (Test-AiServerReady) {
        if ($script:AiBaseUrl -like "http://127.0.0.1:*") {
            $lblSecAiServer.Text = "Local Only - 127.0.0.1"
            $lblSecAiServer.ForeColor = $palette.Success
        }
        else {
            $lblSecAiServer.Text = "Attention - non-local endpoint"
            $lblSecAiServer.ForeColor = $palette.Danger
        }
    }
    else {
        $lblSecAiServer.Text = "Stopped - configured for localhost only"
        $lblSecAiServer.ForeColor = $palette.Muted
    }

    $sessionCount = 0
    foreach ($sessionRoot in @(
        (Join-Path $script:AghrabConfigDir "browser-profiles"),
        (Join-Path $script:AghrabConfigDir "auto-login-sessions")
    )) {
        if (Test-Path -LiteralPath $sessionRoot -PathType Container) {
            $sessionCount += @(Get-ChildItem -LiteralPath $sessionRoot -Directory -ErrorAction SilentlyContinue).Count
        }
    }
    $lblSecSessions.Text = "$sessionCount saved browser session folder(s)"
    $lblSecSessions.ForeColor = $(if ($sessionCount -gt 0) { $palette.Warning } else { $palette.Success })

    $aiPaths = Get-AiPaths
    $cacheStats = Get-SecurityFolderStats -Path $aiPaths.CacheDir
    $cacheMb = [Math]::Round(($cacheStats.Bytes / 1MB),2)
    $lblSecCache.Text = "$($cacheStats.Files) temp file(s) - $cacheMb MB"
    $lblSecCache.ForeColor = $(if ($cacheStats.Files -gt 0) { $palette.Warning } else { $palette.Success })

    $lblSecIntegrity.Text = $script:LastIntegrityStatus
    $lblSecIntegrity.ForeColor = $(
        if ($script:LastIntegrityStatus -eq "Verified") { $palette.Success }
        elseif ($script:LastIntegrityStatus -eq "Attention") { $palette.Danger }
        elseif ($script:LastIntegrityStatus -eq "Baseline created") { $palette.Warning }
        else { $palette.Muted }
    )
    $lblSecIntegrity.Tag = $script:LastIntegrityDetail

    $auditCount = 0
    try {
        if (Test-Path -LiteralPath $script:SecurityAuditFile -PathType Leaf) {
            $auditCount = @(Get-Content -LiteralPath $script:SecurityAuditFile -ErrorAction SilentlyContinue).Count
        }
    } catch {}
    $lblSecAudit.Text = "Enabled - $auditCount event(s)"
    $lblSecAudit.ForeColor = $palette.Success

    Update-SecurityAuditPreview
}

$btnSecurityCheck.Add_Click({
    try {
        $btnSecurityCheck.Enabled = $false
        $btnSecurityCheck.Text = "Checking..."
        $script:LastIntegrityStatus = "Checking..."
        Update-SecurityCenter
        $form.Refresh()

        $check = Invoke-AghrabIntegrityCheck
        Update-SecurityCenter

        $lines = @()
        $lines += "Security Check: " + [string]$check.Status
        $lines += ""
        foreach ($r in $check.Results) {
            $lines += ([string]$r.Name + " : " + [string]$r.State)
        }

        [System.Windows.Forms.MessageBox]::Show(
            $form,
            ($lines -join "`r`n"),
            "RAQEB Sentinel Security",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            $(if ($check.Status -eq "Attention") { [System.Windows.Forms.MessageBoxIcon]::Warning } else { [System.Windows.Forms.MessageBoxIcon]::Information })
        )
    }
    catch {
        Write-SecurityAudit -Action "SECURITY_CHECK_ERROR" -Detail $_.Exception.Message
        [System.Windows.Forms.MessageBox]::Show($form,$_.Exception.Message,"RAQEB Sentinel Security")
    }
    finally {
        $btnSecurityCheck.Text = "Run Security Check"
        $btnSecurityCheck.Enabled = $true
        Update-SecurityCenter
    }
})

$btnClearSessions.Add_Click({
    $answer = [System.Windows.Forms.MessageBox]::Show(
        $form,
        "This will close the current Kibana browser session and delete saved Kibana/Keycloak browser sessions.`r`n`r`nContinue?",
        "Clear Saved Sessions",
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Warning
    )

    if ($answer -eq [System.Windows.Forms.DialogResult]::Yes) {
        try {
            $removed = Clear-AghrabSavedSessions
            Update-SecurityCenter
            [System.Windows.Forms.MessageBox]::Show($form,"Saved sessions cleared. Folders removed: $removed","RAQEB Sentinel")
        }
        catch {
            [System.Windows.Forms.MessageBox]::Show($form,$_.Exception.Message,"RAQEB Sentinel")
        }
    }
})

$btnClearAiCache.Add_Click({
    try {
        $removed = Clear-AghrabAiCache
        Update-SecurityCenter
        [System.Windows.Forms.MessageBox]::Show($form,"AI temporary cache cleared. Files removed: $removed","RAQEB Sentinel")
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show($form,$_.Exception.Message,"RAQEB Sentinel")
    }
})

$btnOpenAudit.Add_Click({
    try {
        New-Item -ItemType Directory -Force -Path $script:AghrabConfigDir | Out-Null
        if (-not (Test-Path -LiteralPath $script:SecurityAuditFile -PathType Leaf)) {
            "RAQEB Sentinel Security Audit" | Set-Content -LiteralPath $script:SecurityAuditFile -Encoding UTF8
        }
        Start-Process notepad.exe -ArgumentList ('"' + $script:SecurityAuditFile + '"')
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show($form,$_.Exception.Message,"RAQEB Sentinel")
    }
})

$btnRefreshSecurity.Add_Click({ Update-SecurityCenter })

# ---------------- Product Info / Support Package ----------------
function ConvertTo-AghrabSupportSafeText {
    param([string]$Text)

    if ($null -eq $Text) {
        return ""
    }

    $safe = [string]$Text

    # Credentials / authorization material.
    $safe = $safe -replace '(?im)(Authorization\s*[:=]\s*)(.+)$', '$1[REDACTED]'
    $safe = $safe -replace '(?im)(Api[\s_-]*Key\s*[:=]\s*)(.+)$', '$1[REDACTED]'
    $safe = $safe -replace '(?im)(Password\s*[:=]\s*)(.+)$', '$1[REDACTED]'
    $safe = $safe -replace '(?im)(Secret\s*[:=]\s*)(.+)$', '$1[REDACTED]'
    $safe = $safe -replace '(?im)(Token\s*[:=]\s*)(.+)$', '$1[REDACTED]'
    $safe = $safe -replace '(?im)("encoded"\s*:\s*")[^"]+(")', '$1[REDACTED]$2'
    $safe = $safe -replace '(?i)(ApiKey\s+)[A-Za-z0-9+/=_-]{8,}', '$1[REDACTED]'
    $safe = $safe -replace '(?i)(PSDPAPI:)[A-Za-z0-9+/=_-]+', '$1[REDACTED]'

    # Credentials embedded inside a URL.
    $safe = $safe -replace '(?i)(https?://)[^/\s:@]+:[^@\s/]+@', '$1[REDACTED]@'

    return $safe
}

function Get-AghrabSupportProfileSummary {
    $items = @()

    foreach ($profile in @($script:ElkProfiles)) {
        $kibanaHost = ""
        $esHost = ""

        try {
            if (-not [string]::IsNullOrWhiteSpace([string]$profile.KibanaUrl)) {
                $kibanaHost = ([Uri][string]$profile.KibanaUrl).Authority
            }
        }
        catch {
            $kibanaHost = "configured"
        }

        try {
            if (-not [string]::IsNullOrWhiteSpace([string]$profile.ElasticsearchUrl)) {
                $esHost = ([Uri][string]$profile.ElasticsearchUrl).Authority
            }
        }
        catch {
            $esHost = "configured"
        }

        $dashboards = @()
        foreach ($dashboard in @($profile.Dashboards)) {
            $expectedCount = 0
            try {
                $expectedCount = @(
                    Split-ExpectedFields -Text ([string]$dashboard.ExpectedFields)
                ).Count
            }
            catch {}

            $dashboards += [PSCustomObject][ordered]@{
                Name = [string]$dashboard.Name
                TimeRange = [string]$dashboard.TimeRange
                IndexPattern = [string]$dashboard.IndexPattern
                ExpectedFieldCount = $expectedCount
            }
        }

        $items += [PSCustomObject][ordered]@{
            Name = [string]$profile.Name
            KibanaHost = $kibanaHost
            AutoLoginEnabled = [bool]$profile.AutoLoginEnabled
            UsernameConfigured = -not [string]::IsNullOrWhiteSpace([string]$profile.Username)
            SavedPasswordPresent = -not [string]::IsNullOrWhiteSpace([string]$profile.PasswordProtected)
            FieldVerificationEnabled = [bool]$profile.FieldVerifyEnabled
            ElasticsearchHost = $esHost
            ApiKeyPresent = -not [string]::IsNullOrWhiteSpace([string]$profile.FieldVerifyApiKeyProtected)
            TimeField = [string]$profile.FieldVerifyTimeField
            VerificationWindowMinutes = [int]$profile.FieldVerifyWindowMinutes
            IgnoreTls = [bool]$profile.FieldVerifyIgnoreTls
            DashboardCount = @($profile.Dashboards).Count
            Dashboards = $dashboards
        }
    }

    return @($items)
}

function Get-AghrabSupportSystemInfo {
    $osCaption = [Environment]::OSVersion.VersionString
    $osBuild = [Environment]::OSVersion.Version.ToString()
    $computerName = [Environment]::MachineName

    try {
        $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
        if (-not [string]::IsNullOrWhiteSpace([string]$os.Caption)) {
            $osCaption = [string]$os.Caption
        }
        if (-not [string]::IsNullOrWhiteSpace([string]$os.BuildNumber)) {
            $osBuild = [string]$os.BuildNumber
        }
    }
    catch {}

    $browserPath = ""
    try { $browserPath = [string]$txtBrowser.Text } catch {}

    $aiPackState = $(if (Test-AiPackInstalled) { "Installed" } else { "Not installed" })
    $aiServerState = $(if (Test-AiServerReady) { "Ready" } else { "Stopped" })

    return [PSCustomObject][ordered]@{
        Product = "RAQEB Sentinel Pro"
        Version = $AppVersion
        ExportedAt = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss zzz")
        ComputerName = $computerName
        Windows = $osCaption
        WindowsBuild = $osBuild
        Is64BitOS = [Environment]::Is64BitOperatingSystem
        PowerShellVersion = [string]$PSVersionTable.PSVersion
        DotNetClrVersion = [string]$PSVersionTable.CLRVersion
        ProcessorCount = [Environment]::ProcessorCount
        BrowserPath = $browserPath
        AiPack = $aiPackState
        AiServer = $aiServerState
        Theme = [string]$script:CurrentTheme
        ConfigRoot = [string]$script:AghrabConfigDir
        OutputRoot = $(try { [string](Get-OutputRoot) } catch { "" })
    }
}

function Export-AghrabSupportPackage {
    param([string]$OutputPath)

    if ([string]::IsNullOrWhiteSpace($OutputPath)) {
        throw "Support package output path is empty."
    }

    $stamp = Get-Date -Format "yyyyMMdd-HHmmss"
    $tempRoot = Join-Path $env:TEMP ("RAQEB-Support-" + $stamp)

    if (Test-Path -LiteralPath $tempRoot) {
        Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
    }

    New-Item -ItemType Directory -Force -Path $tempRoot | Out-Null

    try {
        $systemInfo = Get-AghrabSupportSystemInfo
        $licenseState = Get-AghrabLicenseState
        $profileSummary = @(Get-AghrabSupportProfileSummary)
        $scheduler = Get-AutomaticCaptureSettings
        $settings = Get-AghrabSettings

        # Product / system info.
        $systemInfo |
            ConvertTo-Json -Depth 6 |
            Set-Content -LiteralPath (Join-Path $tempRoot "system-info.json") -Encoding UTF8

        # License summary only. The signed .lic itself is intentionally excluded.
        [PSCustomObject][ordered]@{
            Status = [string]$licenseState.Status
            Customer = [string]$licenseState.Customer
            Edition = [string]$licenseState.Edition
            LicenseId = [string]$licenseState.LicenseId
            Issued = [string]$licenseState.Issued
            Expires = [string]$licenseState.Expires
            DaysRemaining = [string]$licenseState.DaysRemaining
            MachineId = [string]$licenseState.MachineId
            Detail = [string]$licenseState.Detail
        } |
            ConvertTo-Json -Depth 5 |
            Set-Content -LiteralPath (Join-Path $tempRoot "license-summary.json") -Encoding UTF8

        # Sanitized profile inventory. Never copy elk-profiles.json itself.
        $profileSummary |
            ConvertTo-Json -Depth 10 |
            Set-Content -LiteralPath (Join-Path $tempRoot "profiles-summary.json") -Encoding UTF8

        # Safe app settings and scheduler state.
        [PSCustomObject][ordered]@{
            Theme = [string]$settings.Theme
            HealthAlertsEnabled = [bool]$settings.HealthAlertsEnabled
            HealthAlertWarning = [bool]$settings.HealthAlertWarning
            HealthAlertCritical = [bool]$settings.HealthAlertCritical
            HealthAlertRecovery = [bool]$settings.HealthAlertRecovery
        } |
            ConvertTo-Json -Depth 5 |
            Set-Content -LiteralPath (Join-Path $tempRoot "settings-summary.json") -Encoding UTF8

        [PSCustomObject][ordered]@{
            Enabled = [bool]$scheduler.Enabled
            ProfileName = [string]$scheduler.ProfileName
            IntervalMinutes = [int]$scheduler.IntervalMinutes
            RunAi = [bool]$scheduler.RunAi
            LastRun = [string]$scheduler.LastRun
            LastSuccess = [int]$scheduler.LastSuccess
            LastPartial = [int]$scheduler.LastPartial
            LastFailed = [int]$scheduler.LastFailed
        } |
            ConvertTo-Json -Depth 5 |
            Set-Content -LiteralPath (Join-Path $tempRoot "automatic-capture-summary.json") -Encoding UTF8

        # Current runtime health / integrity overview.
        $healthFile = Get-HealthHistoryFile
        $healthLines = @()
        if (Test-Path -LiteralPath $healthFile -PathType Leaf) {
            $healthLines = @(
                Get-Content -LiteralPath $healthFile -Tail 500 -ErrorAction SilentlyContinue
            )
        }
        if ($healthLines.Count -gt 0) {
            ($healthLines -join "`r`n") |
                Set-Content -LiteralPath (Join-Path $tempRoot "health-history-tail.csv") -Encoding UTF8
        }

        [PSCustomObject][ordered]@{
            IntegrityStatus = [string]$script:LastIntegrityStatus
            IntegrityDetail = [string]$script:LastIntegrityDetail
            SchedulerBusy = [bool]$script:SchedulerBusy
            CaptureBusy = [bool]$script:CaptureBusy
            LastSchedulerSummary = [string]$script:SchedulerLastSummary
        } |
            ConvertTo-Json -Depth 4 |
            Set-Content -LiteralPath (Join-Path $tempRoot "runtime-summary.json") -Encoding UTF8

        # Logs: only bounded tails, then redact credential-like values.
        if (Test-Path -LiteralPath $script:SecurityAuditFile -PathType Leaf) {
            $audit = @(
                Get-Content -LiteralPath $script:SecurityAuditFile -Tail 300 -ErrorAction SilentlyContinue
            ) -join "`r`n"

            ConvertTo-AghrabSupportSafeText -Text $audit |
                Set-Content -LiteralPath (Join-Path $tempRoot "security-audit-tail.log") -Encoding UTF8
        }

        $startupError = Join-Path $BaseDir "aghrab-startup-error.log"
        if (Test-Path -LiteralPath $startupError -PathType Leaf) {
            $startupText = Get-Content -LiteralPath $startupError -Raw -ErrorAction SilentlyContinue
            ConvertTo-AghrabSupportSafeText -Text $startupText |
                Set-Content -LiteralPath (Join-Path $tempRoot "startup-error.log") -Encoding UTF8
        }

        try {
            $aiPaths = Get-AiPaths

            foreach ($logName in @(
                "llama-server.stdout.log",
                "llama-server.stderr.log"
            )) {
                $source = Join-Path $aiPaths.LogsDir $logName
                if (Test-Path -LiteralPath $source -PathType Leaf) {
                    $tail = @(
                        Get-Content -LiteralPath $source -Tail 250 -ErrorAction SilentlyContinue
                    ) -join "`r`n"

                    ConvertTo-AghrabSupportSafeText -Text $tail |
                        Set-Content -LiteralPath (Join-Path $tempRoot $logName) -Encoding UTF8
                }
            }
        }
        catch {}

        $readme = @(
            "RAQEB Sentinel Pro - Support Package"
            "Generated: " + (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
            ""
            "This package is designed for troubleshooting."
            ""
            "Intentionally NOT included:"
            "- Saved passwords / DPAPI credential files"
            "- Elasticsearch API Key values"
            "- Original elk-profiles.json"
            "- Browser session folders / cookies"
            "- License .lic file"
            "- Screenshots"
            "- AI model files"
            ""
            "Log files are limited to recent tail lines and passed through credential redaction."
        ) -join "`r`n"

        $readme |
            Set-Content -LiteralPath (Join-Path $tempRoot "README-SUPPORT.txt") -Encoding UTF8

        if (Test-Path -LiteralPath $OutputPath -PathType Leaf) {
            Remove-Item -LiteralPath $OutputPath -Force
        }

        Compress-Archive `
            -Path (Join-Path $tempRoot "*") `
            -DestinationPath $OutputPath `
            -CompressionLevel Optimal `
            -Force

        Write-SecurityAudit `
            -Action "SUPPORT_PACKAGE_EXPORT" `
            -Detail ("Support package exported: " + [System.IO.Path]::GetFileName($OutputPath))

        return $OutputPath
    }
    finally {
        try {
            if (Test-Path -LiteralPath $tempRoot) {
                Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
            }
        }
        catch {}
    }
}

function Show-AghrabAboutDialog {
    $palette = Get-AghrabPalette -Theme $script:CurrentTheme
    $license = Get-AghrabLicenseState

    $dialog = New-Object System.Windows.Forms.Form
    $dialog.Text = "About RAQEB Sentinel Pro"
    $dialog.StartPosition = "CenterParent"
    $dialog.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
    $dialog.MaximizeBox = $false
    $dialog.MinimizeBox = $false
    $dialog.ShowIcon = $false
    $dialog.ClientSize = New-Object System.Drawing.Size(700,500)
    $dialog.Font = New-Object System.Drawing.Font("Segoe UI",9)
    $dialog.BackColor = $palette.Background
    $dialog.ForeColor = $palette.Text

    $logo = New-Object System.Windows.Forms.PictureBox
    $logo.Location = New-Object System.Drawing.Point(28,24)
    $logo.Size = New-Object System.Drawing.Size(76,76)
    $logo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::Zoom
    $logoFile = Join-Path $BaseDir "aghrab-icon.png"
    if (Test-Path -LiteralPath $logoFile -PathType Leaf) {
        try { $logo.Image = [System.Drawing.Image]::FromFile($logoFile) } catch {}
    }
    $dialog.Controls.Add($logo)

    $title = New-Object System.Windows.Forms.Label
    $title.Text = "RAQEB Sentinel Pro"
    $title.Font = New-Object System.Drawing.Font(
        "Segoe UI Semibold",
        20,
        [System.Drawing.FontStyle]::Bold
    )
    $title.Location = New-Object System.Drawing.Point(122,24)
    $title.Size = New-Object System.Drawing.Size(520,36)
    $dialog.Controls.Add($title)

    $subtitle = New-Object System.Windows.Forms.Label
    $subtitle.Text = "Visual SOC Intelligence | Dashboard Monitoring | Local AI"
    $subtitle.Location = New-Object System.Drawing.Point(125,65)
    $subtitle.Size = New-Object System.Drawing.Size(520,24)
    $subtitle.ForeColor = $palette.Muted
    $dialog.Controls.Add($subtitle)

    $version = New-Object System.Windows.Forms.Label
    $version.Text = "Version " + $AppVersion + "  |  Commercial Build"
    $version.Font = New-Object System.Drawing.Font("Segoe UI Semibold",9.5)
    $version.Location = New-Object System.Drawing.Point(125,91)
    $version.Size = New-Object System.Drawing.Size(520,22)
    $dialog.Controls.Add($version)

    $panel = New-Object System.Windows.Forms.Panel
    $panel.Location = New-Object System.Drawing.Point(28,130)
    $panel.Size = New-Object System.Drawing.Size(644,260)
    $panel.Tag = "card"
    $panel.BackColor = $palette.Surface
    Set-RoundedControlRegion -Control $panel -Radius 12
    $dialog.Controls.Add($panel)

    $rows = @(
        @("License Status", [string]$license.Status),
        @("Licensed To", [string]$license.Customer),
        @("Edition", [string]$license.Edition),
        @("License ID", [string]$license.LicenseId),
        @("Valid Until", [string]$license.Expires),
        @("Days Remaining", [string]$license.DaysRemaining),
        @("Machine ID", [string]$license.MachineId)
    )

    $top = 18
    foreach ($row in $rows) {
        $name = New-Object System.Windows.Forms.Label
        $name.Text = [string]$row[0]
        $name.Location = New-Object System.Drawing.Point(18,$top)
        $name.Size = New-Object System.Drawing.Size(145,24)
        $name.ForeColor = $palette.Muted
        $panel.Controls.Add($name)

        $value = New-Object System.Windows.Forms.Label
        $value.Text = [string]$row[1]
        $value.Location = New-Object System.Drawing.Point(175,$top)
        $value.Size = New-Object System.Drawing.Size(445,24)
        $value.Font = New-Object System.Drawing.Font("Segoe UI Semibold",9)
        $value.AutoEllipsis = $true
        $panel.Controls.Add($value)

        if ([string]$row[0] -eq "License Status") {
            $value.ForeColor = $(
                if ([string]$license.Status -eq "LICENSED") {
                    $palette.Success
                }
                else {
                    $palette.Warning
                }
            )
        }

        $top += 32
    }

    $supportNote = New-Object System.Windows.Forms.Label
    $supportNote.Text = "7-day Full Trial unlocks every feature. After Trial expiry, Gallery, License Activation and Product/Support remain available. Support ZIP excludes credentials, API Keys, sessions and screenshots."
    $supportNote.Location = New-Object System.Drawing.Point(30,410)
    $supportNote.Size = New-Object System.Drawing.Size(640,42)
    $supportNote.ForeColor = $palette.Muted
    $dialog.Controls.Add($supportNote)

    $btnCopyMachine = New-Object System.Windows.Forms.Button
    $btnCopyMachine.Text = "Copy Machine ID"
    $btnCopyMachine.Location = New-Object System.Drawing.Point(28,458)
    $btnCopyMachine.Size = New-Object System.Drawing.Size(140,30)
    Style-SecondaryButton $btnCopyMachine
    $dialog.Controls.Add($btnCopyMachine)

    $btnClose = New-Object System.Windows.Forms.Button
    $btnClose.Text = "Close"
    $btnClose.Location = New-Object System.Drawing.Point(572,458)
    $btnClose.Size = New-Object System.Drawing.Size(100,30)
    Style-PrimaryButton $btnClose
    $dialog.Controls.Add($btnClose)

    $btnCopyMachine.Add_Click({
        try {
            [System.Windows.Forms.Clipboard]::SetText([string]$license.MachineId)
        } catch {}
    })

    $btnClose.Add_Click({ $dialog.Close() })

    [void]$dialog.ShowDialog($form)
}


# ---------------- SETTINGS TAB ----------------
$grpAppearance = New-Object System.Windows.Forms.GroupBox
$grpAppearance.Text = "Appearance & Theme"
$grpAppearance.Tag = "card"
$grpAppearance.Location = New-Object System.Drawing.Point(24,24)
$grpAppearance.Size = New-Object System.Drawing.Size(520,190)
$tabSettings.Controls.Add($grpAppearance)

$lblThemeMode = New-Object System.Windows.Forms.Label
$lblThemeMode.Text = "Background mode:"
$lblThemeMode.Location = New-Object System.Drawing.Point(18,32)
$lblThemeMode.AutoSize = $true
$grpAppearance.Controls.Add($lblThemeMode)

$cmbThemeMode = New-Object System.Windows.Forms.ComboBox
$cmbThemeMode.Location = New-Object System.Drawing.Point(150,28)
$cmbThemeMode.Size = New-Object System.Drawing.Size(180,28)
$cmbThemeMode.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
[void]$cmbThemeMode.Items.Add("Light")
[void]$cmbThemeMode.Items.Add("Dark")
$grpAppearance.Controls.Add($cmbThemeMode)

$lblLanguage = New-Object System.Windows.Forms.Label
$lblLanguage.Text = "Language:"
$lblLanguage.Location = New-Object System.Drawing.Point(18,72)
$lblLanguage.AutoSize = $true
$grpAppearance.Controls.Add($lblLanguage)

$cmbLanguage = New-Object System.Windows.Forms.ComboBox
$cmbLanguage.Location = New-Object System.Drawing.Point(150,68)
$cmbLanguage.Size = New-Object System.Drawing.Size(180,28)
$cmbLanguage.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
[void]$cmbLanguage.Items.Add("English")
[void]$cmbLanguage.Items.Add("فارسی")
$grpAppearance.Controls.Add($cmbLanguage)

$lblPersianFont = New-Object System.Windows.Forms.Label
$lblPersianFont.Text = "Persian font:"
$lblPersianFont.Location = New-Object System.Drawing.Point(342,72)
$lblPersianFont.Size = New-Object System.Drawing.Size(76,22)
$grpAppearance.Controls.Add($lblPersianFont)

$cmbPersianFont = New-Object System.Windows.Forms.ComboBox
$cmbPersianFont.Location = New-Object System.Drawing.Point(414,68)
$cmbPersianFont.Size = New-Object System.Drawing.Size(88,28)
$cmbPersianFont.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
[void]$cmbPersianFont.Items.Add("Tahoma")
[void]$cmbPersianFont.Items.Add("B Koodak")
$grpAppearance.Controls.Add($cmbPersianFont)

$lblThemeHint = New-Object System.Windows.Forms.Label
$lblThemeHint.Text = "Elastic Dark uses sidebar navigation, card-based sections, rounded controls and fully dark data surfaces."
$lblThemeHint.Location = New-Object System.Drawing.Point(18,108)
$lblThemeHint.Size = New-Object System.Drawing.Size(470,30)
$lblThemeHint.AutoEllipsis = $true
$grpAppearance.Controls.Add($lblThemeHint)

$lblThemePreview = New-Object System.Windows.Forms.Label
$lblThemePreview.Text = "Preview:"
$lblThemePreview.Location = New-Object System.Drawing.Point(350,32)
$lblThemePreview.AutoSize = $true
$grpAppearance.Controls.Add($lblThemePreview)

$panelThemePreview = New-Object System.Windows.Forms.Panel
$panelThemePreview.Location = New-Object System.Drawing.Point(405,27)
$panelThemePreview.Size = New-Object System.Drawing.Size(82,30)
$panelThemePreview.BackColor = [System.Drawing.Color]::FromArgb(17,24,33)
$grpAppearance.Controls.Add($panelThemePreview)

$previewAccent = New-Object System.Windows.Forms.Panel
$previewAccent.Location = New-Object System.Drawing.Point(6,6)
$previewAccent.Size = New-Object System.Drawing.Size(22,18)
$previewAccent.BackColor = [System.Drawing.Color]::FromArgb(46,168,255)
$panelThemePreview.Controls.Add($previewAccent)

$previewSurface = New-Object System.Windows.Forms.Panel
$previewSurface.Location = New-Object System.Drawing.Point(34,6)
$previewSurface.Size = New-Object System.Drawing.Size(18,18)
$previewSurface.BackColor = [System.Drawing.Color]::FromArgb(24,34,45)
$panelThemePreview.Controls.Add($previewSurface)

$previewText = New-Object System.Windows.Forms.Panel
$previewText.Location = New-Object System.Drawing.Point(58,6)
$previewText.Size = New-Object System.Drawing.Size(18,18)
$previewText.BackColor = [System.Drawing.Color]::FromArgb(230,237,243)
$panelThemePreview.Controls.Add($previewText)

$btnApplyTheme = New-Object System.Windows.Forms.Button
$btnApplyTheme.Text = "Apply"
$btnApplyTheme.Location = New-Object System.Drawing.Point(18,143)
$btnApplyTheme.Size = New-Object System.Drawing.Size(95,30)
Style-PrimaryButton $btnApplyTheme
$grpAppearance.Controls.Add($btnApplyTheme)

$btnSaveTheme = New-Object System.Windows.Forms.Button
$btnSaveTheme.Text = "Save Settings"
$btnSaveTheme.Location = New-Object System.Drawing.Point(125,143)
$btnSaveTheme.Size = New-Object System.Drawing.Size(120,30)
Style-SecondaryButton $btnSaveTheme
$grpAppearance.Controls.Add($btnSaveTheme)

$grpHealthAlerts = New-Object System.Windows.Forms.GroupBox
$grpHealthAlerts.Text = "Health Alerts"
$grpHealthAlerts.Tag = "card"
$grpHealthAlerts.Location = New-Object System.Drawing.Point(570,24)
$grpHealthAlerts.Size = New-Object System.Drawing.Size(375,286)
$tabSettings.Controls.Add($grpHealthAlerts)

$chkHealthAlertsEnabled = New-Object System.Windows.Forms.CheckBox
$chkHealthAlertsEnabled.Text = "Enable desktop health alerts"
$chkHealthAlertsEnabled.Location = New-Object System.Drawing.Point(18,30)
$chkHealthAlertsEnabled.AutoSize = $true
$grpHealthAlerts.Controls.Add($chkHealthAlertsEnabled)

$lblHealthAlertHint = New-Object System.Windows.Forms.Label
$lblHealthAlertHint.Text = "Alerts fire only when a dashboard status changes, so repeated cycles do not create notification spam."
$lblHealthAlertHint.Location = New-Object System.Drawing.Point(18,58)
$lblHealthAlertHint.Size = New-Object System.Drawing.Size(335,42)
$lblHealthAlertHint.AutoEllipsis = $true
$grpHealthAlerts.Controls.Add($lblHealthAlertHint)

$chkHealthAlertWarning = New-Object System.Windows.Forms.CheckBox
$chkHealthAlertWarning.Text = "Notify when status becomes Warning"
$chkHealthAlertWarning.Location = New-Object System.Drawing.Point(18,108)
$chkHealthAlertWarning.AutoSize = $true
$grpHealthAlerts.Controls.Add($chkHealthAlertWarning)

$chkHealthAlertCritical = New-Object System.Windows.Forms.CheckBox
$chkHealthAlertCritical.Text = "Notify when status becomes Critical"
$chkHealthAlertCritical.Location = New-Object System.Drawing.Point(18,138)
$chkHealthAlertCritical.AutoSize = $true
$grpHealthAlerts.Controls.Add($chkHealthAlertCritical)

$chkHealthAlertRecovery = New-Object System.Windows.Forms.CheckBox
$chkHealthAlertRecovery.Text = "Notify when Warning/Critical recovers to Healthy"
$chkHealthAlertRecovery.Location = New-Object System.Drawing.Point(18,168)
$chkHealthAlertRecovery.AutoSize = $true
$grpHealthAlerts.Controls.Add($chkHealthAlertRecovery)

$btnHealthAlertTest = New-Object System.Windows.Forms.Button
$btnHealthAlertTest.Text = "Test Notification"
$btnHealthAlertTest.Location = New-Object System.Drawing.Point(18,210)
$btnHealthAlertTest.Size = New-Object System.Drawing.Size(145,34)
Style-SecondaryButton $btnHealthAlertTest
$grpHealthAlerts.Controls.Add($btnHealthAlertTest)

$lblHealthAlertStatus = New-Object System.Windows.Forms.Label
$lblHealthAlertStatus.Text = "State: OFF"
$lblHealthAlertStatus.Location = New-Object System.Drawing.Point(180,218)
$lblHealthAlertStatus.Size = New-Object System.Drawing.Size(165,22)
$grpHealthAlerts.Controls.Add($lblHealthAlertStatus)

function Update-HealthAlertSettingsUi {
    $enabled = [bool]$chkHealthAlertsEnabled.Checked

    $chkHealthAlertWarning.Enabled = $enabled
    $chkHealthAlertCritical.Enabled = $enabled
    $chkHealthAlertRecovery.Enabled = $enabled
    $btnHealthAlertTest.Enabled = $enabled

    $palette = Get-AghrabPalette -Theme $script:CurrentTheme
    $stateText = $(if ($enabled) { "State: ON" } else { "State: OFF" })
    $lblHealthAlertStatus.Text = Convert-AghrabUiText `
        -Text $stateText `
        -Language $script:CurrentLanguage
    $lblHealthAlertStatus.ForeColor = $(if ($enabled) { $palette.Success } else { $palette.Muted })
}

function Save-HealthAlertUiToRuntime {
    $script:HealthAlertsEnabled = [bool]$chkHealthAlertsEnabled.Checked
    $script:HealthAlertWarning = [bool]$chkHealthAlertWarning.Checked
    $script:HealthAlertCritical = [bool]$chkHealthAlertCritical.Checked
    $script:HealthAlertRecovery = [bool]$chkHealthAlertRecovery.Checked
    Update-HealthAlertSettingsUi
}

$chkHealthAlertsEnabled.Add_CheckedChanged({
    Save-HealthAlertUiToRuntime
})

$chkHealthAlertWarning.Add_CheckedChanged({
    Save-HealthAlertUiToRuntime
})

$chkHealthAlertCritical.Add_CheckedChanged({
    Save-HealthAlertUiToRuntime
})

$chkHealthAlertRecovery.Add_CheckedChanged({
    Save-HealthAlertUiToRuntime
})

$btnHealthAlertTest.Add_Click({
    Save-HealthAlertUiToRuntime
    Save-AghrabSettings -Theme $script:CurrentTheme
    Test-HealthAlertNotification
})

$grpAppInfo = New-Object System.Windows.Forms.GroupBox
$grpAppInfo.Text = "Product & Support"
$grpAppInfo.Tag = "card"
$grpAppInfo.Location = New-Object System.Drawing.Point(24,230)
$grpAppInfo.Size = New-Object System.Drawing.Size(520,140)
$tabSettings.Controls.Add($grpAppInfo)

$lblAppInfo = New-Object System.Windows.Forms.Label
$lblAppInfo.Text = "RAQEB Sentinel Pro v$AppVersion | Commercial Build`r`nVisual SOC monitoring, portable profile transfer, local AI and signed offline licensing."
$lblAppInfo.Location = New-Object System.Drawing.Point(18,28)
$lblAppInfo.Size = New-Object System.Drawing.Size(480,48)
$lblAppInfo.AutoEllipsis = $true
$grpAppInfo.Controls.Add($lblAppInfo)

$btnAboutAghrab = New-Object System.Windows.Forms.Button
$btnAboutAghrab.Text = "About RAQEB"
$btnAboutAghrab.Location = New-Object System.Drawing.Point(18,88)
$btnAboutAghrab.Size = New-Object System.Drawing.Size(145,32)
Style-SecondaryButton $btnAboutAghrab
$grpAppInfo.Controls.Add($btnAboutAghrab)

$btnExportSupport = New-Object System.Windows.Forms.Button
$btnExportSupport.Text = "Export Support Package"
$btnExportSupport.Location = New-Object System.Drawing.Point(175,88)
$btnExportSupport.Size = New-Object System.Drawing.Size(180,32)
Style-PrimaryButton $btnExportSupport
$grpAppInfo.Controls.Add($btnExportSupport)

$lblSupportSafe = New-Object System.Windows.Forms.Label
$lblSupportSafe.Text = "Available after Trial too - sanitized ZIP"
$lblSupportSafe.Location = New-Object System.Drawing.Point(365,93)
$lblSupportSafe.Size = New-Object System.Drawing.Size(130,30)
$lblSupportSafe.Tag = "muted"
$grpAppInfo.Controls.Add($lblSupportSafe)

$btnAboutAghrab.Add_Click({
    Show-AghrabAboutDialog
})

$btnExportSupport.Add_Click({
    $save = New-Object System.Windows.Forms.SaveFileDialog
    $save.Title = "Export RAQEB Support Package"
    $save.Filter = "ZIP Archive (*.zip)|*.zip"
    $save.FileName = (
        "RAQEB-Support-" +
        (Get-Date -Format "yyyyMMdd-HHmmss") +
        ".zip"
    )

    if ($save.ShowDialog($form) -ne [System.Windows.Forms.DialogResult]::OK) {
        return
    }

    $oldText = $btnExportSupport.Text
    $btnExportSupport.Text = "Exporting..."
    $btnExportSupport.Enabled = $false
    $form.Cursor = [System.Windows.Forms.Cursors]::WaitCursor

    try {
        [System.Windows.Forms.Application]::DoEvents()

        $resultPath = Export-AghrabSupportPackage -OutputPath $save.FileName

        [System.Windows.Forms.MessageBox]::Show(
            $form,
            (
                "Support Package created successfully.`r`n`r`n" +
                $resultPath + "`r`n`r`n" +
                "Passwords, API Keys, browser sessions and screenshots were excluded."
            ),
            "RAQEB Sentinel Pro",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show(
            $form,
            "Support Package export failed.`r`n`r`n" + $_.Exception.Message,
            "RAQEB Sentinel Pro",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    }
    finally {
        $btnExportSupport.Text = $oldText
        $btnExportSupport.Enabled = $true
        $form.Cursor = [System.Windows.Forms.Cursors]::Default
    }
})

$grpLicense = New-Object System.Windows.Forms.GroupBox
$grpLicense.Text = "License"
$grpLicense.Tag = "card"
$grpLicense.Location = New-Object System.Drawing.Point(24,385)
$grpLicense.Size = New-Object System.Drawing.Size(921,300)
$tabSettings.Controls.Add($grpLicense)

$lblLicenseTitle = New-Object System.Windows.Forms.Label
$lblLicenseTitle.Text = "RAQEB Activation Center | 7-Day Full Trial + Professional License"
$lblLicenseTitle.Font = New-Object System.Drawing.Font(
    "Segoe UI Semibold",
    10.5,
    [System.Drawing.FontStyle]::Bold
)
$lblLicenseTitle.Location = New-Object System.Drawing.Point(18,28)
$lblLicenseTitle.Size = New-Object System.Drawing.Size(560,28)
$lblLicenseTitle.AutoEllipsis = $true
$grpLicense.Controls.Add($lblLicenseTitle)

$lblLicenseHint = New-Object System.Windows.Forms.Label
$lblLicenseHint.Text = "Copy this Machine ID and send it to your RAQEB supplier. Import the signed .lic file you receive."
$lblLicenseHint.Location = New-Object System.Drawing.Point(18,56)
$lblLicenseHint.Size = New-Object System.Drawing.Size(865,34)
$lblLicenseHint.AutoEllipsis = $true
$lblLicenseHint.Tag = "muted"
$grpLicense.Controls.Add($lblLicenseHint)

$lblLicenseStatus = New-Object System.Windows.Forms.Label
$lblLicenseStatus.Text = "Status"
$lblLicenseStatus.Location = New-Object System.Drawing.Point(18,102)
$lblLicenseStatus.Size = New-Object System.Drawing.Size(90,20)
$grpLicense.Controls.Add($lblLicenseStatus)

$lblLicenseStatusValue = New-Object System.Windows.Forms.Label
$lblLicenseStatusValue.Text = "UNLICENSED"
$lblLicenseStatusValue.Font = New-Object System.Drawing.Font(
    "Segoe UI Semibold",
    10,
    [System.Drawing.FontStyle]::Bold
)
$lblLicenseStatusValue.Location = New-Object System.Drawing.Point(115,100)
$lblLicenseStatusValue.Size = New-Object System.Drawing.Size(175,24)
$grpLicense.Controls.Add($lblLicenseStatusValue)

$lblLicenseCustomer = New-Object System.Windows.Forms.Label
$lblLicenseCustomer.Text = "Customer"
$lblLicenseCustomer.Location = New-Object System.Drawing.Point(18,136)
$lblLicenseCustomer.Size = New-Object System.Drawing.Size(90,20)
$grpLicense.Controls.Add($lblLicenseCustomer)

$lblLicenseCustomerValue = New-Object System.Windows.Forms.Label
$lblLicenseCustomerValue.Text = "-"
$lblLicenseCustomerValue.Location = New-Object System.Drawing.Point(115,136)
$lblLicenseCustomerValue.Size = New-Object System.Drawing.Size(250,20)
$grpLicense.Controls.Add($lblLicenseCustomerValue)

$lblLicenseEdition = New-Object System.Windows.Forms.Label
$lblLicenseEdition.Text = "Edition"
$lblLicenseEdition.Location = New-Object System.Drawing.Point(18,168)
$lblLicenseEdition.Size = New-Object System.Drawing.Size(90,20)
$grpLicense.Controls.Add($lblLicenseEdition)

$lblLicenseEditionValue = New-Object System.Windows.Forms.Label
$lblLicenseEditionValue.Text = "-"
$lblLicenseEditionValue.Location = New-Object System.Drawing.Point(115,168)
$lblLicenseEditionValue.Size = New-Object System.Drawing.Size(250,20)
$grpLicense.Controls.Add($lblLicenseEditionValue)

$lblLicenseId = New-Object System.Windows.Forms.Label
$lblLicenseId.Text = "License ID"
$lblLicenseId.Location = New-Object System.Drawing.Point(18,200)
$lblLicenseId.Size = New-Object System.Drawing.Size(90,20)
$grpLicense.Controls.Add($lblLicenseId)

$lblLicenseIdValue = New-Object System.Windows.Forms.Label
$lblLicenseIdValue.Text = "-"
$lblLicenseIdValue.Location = New-Object System.Drawing.Point(115,200)
$lblLicenseIdValue.Size = New-Object System.Drawing.Size(250,20)
$grpLicense.Controls.Add($lblLicenseIdValue)

$lblLicenseExpiry = New-Object System.Windows.Forms.Label
$lblLicenseExpiry.Text = "Expires"
$lblLicenseExpiry.Location = New-Object System.Drawing.Point(400,102)
$lblLicenseExpiry.Size = New-Object System.Drawing.Size(80,20)
$grpLicense.Controls.Add($lblLicenseExpiry)

$lblLicenseExpiryValue = New-Object System.Windows.Forms.Label
$lblLicenseExpiryValue.Text = "-"
$lblLicenseExpiryValue.Location = New-Object System.Drawing.Point(490,102)
$lblLicenseExpiryValue.Size = New-Object System.Drawing.Size(175,20)
$grpLicense.Controls.Add($lblLicenseExpiryValue)

$lblLicenseDays = New-Object System.Windows.Forms.Label
$lblLicenseDays.Text = "Days left"
$lblLicenseDays.Location = New-Object System.Drawing.Point(400,136)
$lblLicenseDays.Size = New-Object System.Drawing.Size(80,20)
$grpLicense.Controls.Add($lblLicenseDays)

$lblLicenseDaysValue = New-Object System.Windows.Forms.Label
$lblLicenseDaysValue.Text = "-"
$lblLicenseDaysValue.Location = New-Object System.Drawing.Point(490,136)
$lblLicenseDaysValue.Size = New-Object System.Drawing.Size(175,20)
$grpLicense.Controls.Add($lblLicenseDaysValue)

$lblLicenseAccess = New-Object System.Windows.Forms.Label
$lblLicenseAccess.Text = "Access"
$lblLicenseAccess.Location = New-Object System.Drawing.Point(18,232)
$lblLicenseAccess.Size = New-Object System.Drawing.Size(90,20)
$grpLicense.Controls.Add($lblLicenseAccess)

$lblLicenseAccessValue = New-Object System.Windows.Forms.Label
$lblLicenseAccessValue.Text = "-"
$lblLicenseAccessValue.Location = New-Object System.Drawing.Point(115,232)
$lblLicenseAccessValue.Size = New-Object System.Drawing.Size(650,20)
$lblLicenseAccessValue.Font = New-Object System.Drawing.Font("Segoe UI Semibold",9)
$grpLicense.Controls.Add($lblLicenseAccessValue)

$lblMachineIdTitle = New-Object System.Windows.Forms.Label
$lblMachineIdTitle.Text = "Machine ID"
$lblMachineIdTitle.Location = New-Object System.Drawing.Point(400,168)
$lblMachineIdTitle.Size = New-Object System.Drawing.Size(80,20)
$grpLicense.Controls.Add($lblMachineIdTitle)

$txtLicenseMachineId = New-Object System.Windows.Forms.TextBox
$txtLicenseMachineId.Location = New-Object System.Drawing.Point(490,164)
$txtLicenseMachineId.Size = New-Object System.Drawing.Size(260,28)
$txtLicenseMachineId.ReadOnly = $true
$grpLicense.Controls.Add($txtLicenseMachineId)

$btnCopyMachineId = New-Object System.Windows.Forms.Button
$btnCopyMachineId.Text = "Copy"
$btnCopyMachineId.Location = New-Object System.Drawing.Point(760,163)
$btnCopyMachineId.Size = New-Object System.Drawing.Size(90,30)
Style-SecondaryButton $btnCopyMachineId
$grpLicense.Controls.Add($btnCopyMachineId)

$btnImportLicense = New-Object System.Windows.Forms.Button
$btnImportLicense.Text = "Import License"
$btnImportLicense.Location = New-Object System.Drawing.Point(400,205)
$btnImportLicense.Size = New-Object System.Drawing.Size(140,34)
Style-PrimaryButton $btnImportLicense
$grpLicense.Controls.Add($btnImportLicense)

$btnOpenLicenseFolder = New-Object System.Windows.Forms.Button
$btnOpenLicenseFolder.Text = "License Folder"
$btnOpenLicenseFolder.Location = New-Object System.Drawing.Point(550,205)
$btnOpenLicenseFolder.Size = New-Object System.Drawing.Size(125,34)
Style-SecondaryButton $btnOpenLicenseFolder
$grpLicense.Controls.Add($btnOpenLicenseFolder)

$btnRefreshLicense = New-Object System.Windows.Forms.Button
$btnRefreshLicense.Text = "Refresh"
$btnRefreshLicense.Location = New-Object System.Drawing.Point(685,205)
$btnRefreshLicense.Size = New-Object System.Drawing.Size(95,34)
Style-SecondaryButton $btnRefreshLicense
$grpLicense.Controls.Add($btnRefreshLicense)

$lblLicenseDetail = New-Object System.Windows.Forms.Label
$lblLicenseDetail.Text = ""
$lblLicenseDetail.Location = New-Object System.Drawing.Point(18,264)
$lblLicenseDetail.Size = New-Object System.Drawing.Size(865,24)
$lblLicenseDetail.AutoEllipsis = $true
$lblLicenseDetail.Tag = "muted"
$grpLicense.Controls.Add($lblLicenseDetail)

$btnCopyMachineId.Add_Click({
    try {
        [System.Windows.Forms.Clipboard]::SetText(
            [string]$txtLicenseMachineId.Text
        )
        $lblLicenseDetail.Text = "Machine ID copied to clipboard."
    }
    catch {}
})

$btnImportLicense.Add_Click({
    $dlg = New-Object System.Windows.Forms.OpenFileDialog
    $dlg.Title = "Import RAQEB License"
    $dlg.Filter = "RAQEB License (*.lic)|*.lic|All files (*.*)|*.*"

    if ($dlg.ShowDialog($form) -ne [System.Windows.Forms.DialogResult]::OK) {
        return
    }

    try {
        $state = Import-AghrabLicense -SourcePath $dlg.FileName
        Update-AghrabLicenseUi | Out-Null

        [System.Windows.Forms.MessageBox]::Show(
            $form,
            (
                "License imported.`r`n`r`n" +
                "Status: " + [string]$state.Status + "`r`n" +
                "Customer: " + [string]$state.Customer + "`r`n" +
                "Edition: " + [string]$state.Edition
            ),
            "RAQEB Sentinel Pro",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        )
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show(
            $form,
            "License import failed.`r`n`r`n" + $_.Exception.Message,
            "RAQEB Sentinel Pro",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        )
    }
})

$btnOpenLicenseFolder.Add_Click({
    try {
        New-Item -ItemType Directory -Path $script:AghrabLicenseDir -Force |
            Out-Null
        Start-Process explorer.exe -ArgumentList (
            '"' + $script:AghrabLicenseDir + '"'
        )
    }
    catch {}
})

$btnRefreshLicense.Add_Click({
    Update-AghrabLicenseUi | Out-Null
})


$btnApplyTheme.Add_Click({
    $selected = [string]$cmbThemeMode.SelectedItem
    if ([string]::IsNullOrWhiteSpace($selected)) {
        $selected = "Light"
    }

    $language = Get-AghrabSelectedLanguage
    $persianFont = Get-AghrabSelectedPersianFont
    $script:CurrentPersianFont = $persianFont

    if (
        $language -eq "Persian" -and
        $persianFont -eq "B Koodak" -and
        -not (Test-AghrabFontInstalled -FontName "B Koodak")
    ) {
        [System.Windows.Forms.MessageBox]::Show(
            $form,
            "B Koodak is not installed on this Windows.`r`nTahoma will be used as a safe fallback.",
            "RAQEB Persian Font",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
    }

    Apply-AghrabTheme -Theme $selected
    Apply-AghrabLanguage -Language $language
})

$btnSaveTheme.Add_Click({
    $selected = [string]$cmbThemeMode.SelectedItem
    if ([string]::IsNullOrWhiteSpace($selected)) {
        $selected = "Light"
    }

    $language = Get-AghrabSelectedLanguage
    $persianFont = Get-AghrabSelectedPersianFont
    $script:CurrentPersianFont = $persianFont

    Apply-AghrabTheme -Theme $selected
    Apply-AghrabLanguage -Language $language
    Save-HealthAlertUiToRuntime
    Save-AghrabSettings `
        -Theme $selected `
        -Language $language `
        -PersianFont $persianFont

    [System.Windows.Forms.MessageBox]::Show(
        $form,
        $(if ($language -eq "Persian") { "تنظیمات ذخیره شد." } else { "Settings saved." }),
        "aghrab",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Information
    )
})


# ---------------- Gallery helper functions ----------------
function Get-OutputRoot {
    return $txtOutput.Text.Trim()
}

function Clear-ImagePreview {
    try {
        if ($picPreview.Image -ne $null) {
            $old = $picPreview.Image
            $picPreview.Image = $null
            $old.Dispose()
        }
    } catch {}
    $lblPreviewInfo.Text = "No image selected"
}


function Update-GalleryImageListLayout {
    if ($null -eq $lvImages) { return }

    # LargeIcon mode lays screenshots out side-by-side automatically.
    # Keep a bounded browser pane and let ListView handle vertical scrolling.
    try {
        if ($null -ne $cardGalleryMedia) {
            $lvImages.Height = [Math]::Max(260, $cardGalleryMedia.ClientSize.Height - 136)
            $panelGalleryPreview.Height = $lvImages.Height
        }
    }
    catch {}
}

function Load-AlbumImages([string]$albumName) {
    $lvImages.BeginUpdate()

    try {
        $lvImages.Items.Clear()
        $script:GalleryHoverIndex = -1

        if ($null -ne $script:GalleryThumbList) {
            try { $script:GalleryThumbList.Dispose() } catch {}
        }

        $script:GalleryThumbList = New-Object System.Windows.Forms.ImageList
        $script:GalleryThumbList.ImageSize = New-Object System.Drawing.Size(160,90)
        $script:GalleryThumbList.ColorDepth = [System.Windows.Forms.ColorDepth]::Depth32Bit
        $lvImages.LargeImageList = $script:GalleryThumbList

        Clear-ImagePreview

        if ($null -ne $lblGallerySelectedAlbum) {
            $lblGallerySelectedAlbum.Text = $(if ([string]::IsNullOrWhiteSpace($albumName)) { Convert-AghrabUiText -Text "No album selected" -Language $script:CurrentLanguage } else { $albumName })
        }
        if ($null -ne $lblGalleryImageCount) {
            $lblGalleryImageCount.Text = "0 captures"
        }

        if ([string]::IsNullOrWhiteSpace($albumName)) {
            return
        }

        $root = Get-OutputRoot
        if ([string]::IsNullOrWhiteSpace($root) -or -not (Test-Path -LiteralPath $root)) {
            return
        }

        $albumPath = Join-Path $root $albumName
        if (-not (Test-Path -LiteralPath $albumPath -PathType Container)) {
            return
        }

        $files = @(
            Get-ChildItem -LiteralPath $albumPath -File -Filter *.png -ErrorAction SilentlyContinue |
            Sort-Object LastWriteTime -Descending
        )

        if ($null -ne $lblGalleryImageCount) {
            $lblGalleryImageCount.Text = Convert-AghrabUiText -Text ([string]$files.Count + $(if ($files.Count -eq 1) { " capture" } else { " captures" })) -Language $script:CurrentLanguage
        }

        foreach ($file in $files) {
            $imageIndex = -1

            try {
                $bytes = [System.IO.File]::ReadAllBytes($file.FullName)
                $ms = New-Object System.IO.MemoryStream(,$bytes)
                $source = [System.Drawing.Image]::FromStream($ms)
                $bitmap = New-Object System.Drawing.Bitmap($source)

                $source.Dispose()
                $ms.Dispose()

                $thumb = New-Object System.Drawing.Bitmap(160,90)
                $g = [System.Drawing.Graphics]::FromImage($thumb)

                try {
                    $p = Get-AghrabPalette -Theme $script:CurrentTheme
                    $g.Clear($p.Input)
                    $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
                    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
                    $g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality

                    $ratio = [Math]::Min(156.0 / $bitmap.Width, 86.0 / $bitmap.Height)
                    $dw = [Math]::Max(1,[int]($bitmap.Width * $ratio))
                    $dh = [Math]::Max(1,[int]($bitmap.Height * $ratio))
                    $dx = [int]((160 - $dw) / 2)
                    $dy = [int]((90 - $dh) / 2)

                    $g.DrawImage(
                        $bitmap,
                        (New-Object System.Drawing.Rectangle($dx,$dy,$dw,$dh))
                    )

                    $borderPen = New-Object System.Drawing.Pen($p.BorderSoft,1)
                    try { $g.DrawRectangle($borderPen,0,0,159,89) }
                    finally { $borderPen.Dispose() }
                }
                finally {
                    $g.Dispose()
                    $bitmap.Dispose()
                }

                $imageIndex = $script:GalleryThumbList.Images.Add($thumb)
            }
            catch {
                $imageIndex = -1
            }

            # Compact media-tile caption. Full details remain in tooltip/preview.
            $displayName = $file.LastWriteTime.ToString("MM-dd  HH:mm:ss")
            $item = New-Object System.Windows.Forms.ListViewItem($displayName)

            if ($imageIndex -ge 0) {
                $item.ImageIndex = $imageIndex
            }

            $item.Tag = $file.FullName
            $item.ToolTipText =
                "Captured: " + $file.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss.fff") + "`r`n" +
                "File: " + $file.Name + "`r`n" +
                ("Size: {0:N1} KB" -f ($file.Length / 1KB))

            [void]$lvImages.Items.Add($item)
        }

        if ($lvImages.Items.Count -gt 0) {
            $lvImages.Items[0].Selected = $true
            $lvImages.Items[0].Focused = $true
        }
    }
    finally {
        $lvImages.EndUpdate()
        Update-GalleryImageListLayout
        $lvImages.Invalidate()
    }
}

function Refresh-Gallery {
    $root = Get-OutputRoot
    $txtGalleryRoot.Text = $root
    $lstAlbums.Items.Clear()
    $lvImages.Items.Clear()

    if ($null -ne $lblGallerySelectedAlbum) { $lblGallerySelectedAlbum.Text = "No album selected" }
    if ($null -ne $lblGalleryImageCount) { $lblGalleryImageCount.Text = "0 captures" }

    Clear-ImagePreview
    Update-GalleryImageListLayout

    if ([string]::IsNullOrWhiteSpace($root) -or -not (Test-Path -LiteralPath $root -PathType Container)) {
        $grpAlbumRetention.Enabled = $false
        $lblAlbumRetentionStatus.Text = ""
        return
    }

    $albums = Get-ChildItem -LiteralPath $root -Directory -ErrorAction SilentlyContinue |
              Sort-Object Name

    foreach ($album in $albums) {
        [void]$lstAlbums.Items.Add($album.Name)
    }

    if ($lstAlbums.Items.Count -gt 0) {
        $lstAlbums.SelectedIndex = 0
    }
}

function Show-SelectedImage {
    Clear-ImagePreview

    if ($lvImages.SelectedItems.Count -eq 0) {
        return
    }

    $path = [string]$lvImages.SelectedItems[0].Tag
    if ([string]::IsNullOrWhiteSpace($path) -or -not (Test-Path -LiteralPath $path -PathType Leaf)) {
        return
    }

    try {
        $bytes = [System.IO.File]::ReadAllBytes($path)
        $ms = New-Object System.IO.MemoryStream(,$bytes)
        $source = [System.Drawing.Image]::FromStream($ms)
        $img = New-Object System.Drawing.Bitmap($source)
        $source.Dispose()
        $ms.Dispose()
        $picPreview.Image = $img

        $file = Get-Item -LiteralPath $path
        $album = ""
        if ($lstAlbums.SelectedItem) { $album = $lstAlbums.SelectedItem.ToString() }

        $lblPreviewInfo.Text =
            "Album: " + $album + "`r`n" +
            "Captured: " + $file.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss") + "`r`n" +
            "Size: " + ("{0:N1} KB" -f ($file.Length / 1KB)) + "`r`n" +
            "File: " + $file.Name
    } catch {
        $lblPreviewInfo.Text = "Cannot load preview: $($_.Exception.Message)"
    }
}


function Load-SelectedAlbumRetention {
    if (-not $lstAlbums.SelectedItem) {
        $grpAlbumRetention.Enabled = $false
        $lblAlbumRetentionStatus.Text = ""
        return
    }

    $albumName = $lstAlbums.SelectedItem.ToString()
    $albumPath = Join-Path (Get-OutputRoot) $albumName

    if (-not (Test-Path -LiteralPath $albumPath -PathType Container)) {
        $grpAlbumRetention.Enabled = $false
        $lblAlbumRetentionStatus.Text = ""
        return
    }

    $policy = Ensure-AlbumRetentionPolicy -AlbumPath $albumPath

    $numAlbumKeepDays.Value = [Math]::Min(
        [decimal]$numAlbumKeepDays.Maximum,
        [Math]::Max([decimal]0, [decimal]$policy.KeepDays)
    )

    $numAlbumMaxImages.Value = [Math]::Min(
        [decimal]$numAlbumMaxImages.Maximum,
        [Math]::Max([decimal]0, [decimal]$policy.MaxPerAlbum)
    )

    $count = @(
        Get-ChildItem -LiteralPath $albumPath -File -Filter *.png -ErrorAction SilentlyContinue
    ).Count

    $grpAlbumRetention.Enabled = $true
    $lblAlbumRetentionStatus.Text = Convert-AghrabUiText -Text ("Current images: " + [string]$count) -Language $script:CurrentLanguage
}


# ---------------- Analysis helpers ----------------
function New-ScaledBitmap {
    param(
        [string]$Path,
        [int]$Width = 640,
        [int]$Height = 360
    )

    $bytes = [System.IO.File]::ReadAllBytes($Path)
    $ms = New-Object System.IO.MemoryStream(,$bytes)
    $source = [System.Drawing.Image]::FromStream($ms)

    try {
        $bmp = New-Object System.Drawing.Bitmap($Width, $Height)
        $g = [System.Drawing.Graphics]::FromImage($bmp)

        try {
            $g.Clear([System.Drawing.Color]::White)
            $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBilinear
            $g.DrawImage(
                $source,
                (New-Object System.Drawing.Rectangle(0, 0, $Width, $Height))
            )
        } finally {
            $g.Dispose()
        }

        return $bmp
    } finally {
        $source.Dispose()
        $ms.Dispose()
    }
}

function Compare-Screenshots {
    param(
        [string]$BeforePath,
        [string]$AfterPath,
        [int]$Threshold = 28
    )

    if (-not (Test-Path -LiteralPath $BeforePath -PathType Leaf)) {
        throw "Before image not found."
    }

    if (-not (Test-Path -LiteralPath $AfterPath -PathType Leaf)) {
        throw "After image not found."
    }

    # Normalize both screenshots to a fixed analysis canvas so even full-page
    # screenshots with different original dimensions can be compared quickly.
    $width = 640
    $height = 360
    $before = New-ScaledBitmap -Path $BeforePath -Width $width -Height $height
    $after = New-ScaledBitmap -Path $AfterPath -Width $width -Height $height

    $changed = 0
    $sampled = 0
    $totalDifference = 0L
    $step = 2

    try {
        for ($y = 0; $y -lt $height; $y += $step) {
            for ($x = 0; $x -lt $width; $x += $step) {
                $c1 = $before.GetPixel($x, $y)
                $c2 = $after.GetPixel($x, $y)

                $diff = (
                    [Math]::Abs([int]$c1.R - [int]$c2.R) +
                    [Math]::Abs([int]$c1.G - [int]$c2.G) +
                    [Math]::Abs([int]$c1.B - [int]$c2.B)
                ) / 3

                $totalDifference += $diff
                $sampled++

                if ($diff -ge $Threshold) {
                    $changed++
                }
            }

            if (($y % 20) -eq 0) {
                [System.Windows.Forms.Application]::DoEvents()
            }
        }

        $changePercent = 0.0
        $avgDifference = 0.0

        if ($sampled -gt 0) {
            $changePercent = ($changed * 100.0) / $sampled
            $avgDifference = $totalDifference / [double]$sampled
        }

        $level = "No Change"
        if ($changePercent -ge 25) {
            $level = "Major Change"
        }
        elseif ($changePercent -ge 8) {
            $level = "Moderate Change"
        }
        elseif ($changePercent -ge 2) {
            $level = "Minor Change"
        }

        return [PSCustomObject]@{
            ChangePercent = [Math]::Round($changePercent, 2)
            AverageDifference = [Math]::Round($avgDifference, 2)
            ChangedSamples = $changed
            TotalSamples = $sampled
            Level = $level
        }
    } finally {
        $before.Dispose()
        $after.Dispose()
    }
}

function Load-ImageClone {
    param([string]$Path)

    $bytes = [System.IO.File]::ReadAllBytes($Path)
    $ms = New-Object System.IO.MemoryStream(,$bytes)
    $source = [System.Drawing.Image]::FromStream($ms)

    try {
        return (New-Object System.Drawing.Bitmap($source))
    } finally {
        $source.Dispose()
        $ms.Dispose()
    }
}

function Clear-AnalysisPreview {
    foreach ($picture in @($picAnalyzeBefore, $picAnalyzeAfter)) {
        try {
            if ($picture.Image -ne $null) {
                $img = $picture.Image
                $picture.Image = $null
                $img.Dispose()
            }
        } catch {}
    }
}

function Refresh-AnalyzeAlbums {
    $cmbAnalyzeAlbum.Items.Clear()
    Clear-AnalysisPreview
    $lblAnalyzeResult.Text = Convert-AghrabUiText -Text "Select an album and click Analyze Latest." -Language $script:CurrentLanguage

    $root = Get-OutputRoot
    if ([string]::IsNullOrWhiteSpace($root) -or -not (Test-Path -LiteralPath $root -PathType Container)) {
        return
    }

    $albums = Get-ChildItem -LiteralPath $root -Directory -ErrorAction SilentlyContinue |
              Sort-Object Name

    foreach ($album in $albums) {
        [void]$cmbAnalyzeAlbum.Items.Add($album.Name)
    }

    if ($cmbAnalyzeAlbum.Items.Count -gt 0) {
        $cmbAnalyzeAlbum.SelectedIndex = 0
    }
}

function Analyze-SelectedAlbum {
    if (-not $cmbAnalyzeAlbum.SelectedItem) {
        [System.Windows.Forms.MessageBox]::Show(
            "Select an album first.",
            "aghrab"
        )
        return
    }

    $albumName = $cmbAnalyzeAlbum.SelectedItem.ToString()
    $albumPath = Join-Path (Get-OutputRoot) $albumName

    $files = @(
        Get-ChildItem -LiteralPath $albumPath -File -Filter *.png -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending
    )

    if ($files.Count -lt 2) {
        [System.Windows.Forms.MessageBox]::Show(
            "At least two screenshots are required for analysis.",
            "aghrab"
        )
        return
    }

    $afterFile = $files[0]
    $beforeFile = $files[1]

    $lblAnalyzeResult.Text = "Analyzing..."
    $form.Refresh()

    try {
        $threshold = [int]$numAnalyzeThreshold.Value
        $result = Compare-Screenshots `
            -BeforePath $beforeFile.FullName `
            -AfterPath $afterFile.FullName `
            -Threshold $threshold

        Clear-AnalysisPreview
        $picAnalyzeBefore.Image = Load-ImageClone -Path $beforeFile.FullName
        $picAnalyzeAfter.Image = Load-ImageClone -Path $afterFile.FullName

        $lblAnalyzeBefore.Text =
            "Before: " + $beforeFile.Name + "  |  " +
            $beforeFile.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss")

        $lblAnalyzeAfter.Text =
            "After: " + $afterFile.Name + "  |  " +
            $afterFile.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss")

        $lblAnalyzeResult.Text =
            "Change: $($result.ChangePercent)%   |   " +
            "Level: $($result.Level)   |   " +
            "Average pixel difference: $($result.AverageDifference)"

        if ($result.Level -eq "Major Change") {
            $lblAnalyzeResult.ForeColor = [System.Drawing.Color]::DarkRed
        }
        elseif ($result.Level -eq "Moderate Change") {
            $lblAnalyzeResult.ForeColor = [System.Drawing.Color]::DarkOrange
        }
        elseif ($result.Level -eq "Minor Change") {
            $lblAnalyzeResult.ForeColor = [System.Drawing.Color]::DarkGoldenrod
        }
        else {
            $lblAnalyzeResult.ForeColor = [System.Drawing.Color]::DarkGreen
        }
    } catch {
        $lblAnalyzeResult.Text = "Analysis failed: $($_.Exception.Message)"
        $lblAnalyzeResult.ForeColor = [System.Drawing.Color]::DarkRed
    }
}

# ---------------- Standard helper functions ----------------
function Update-BrowserStatus {
    $path = $txtBrowser.Text.Trim()
    if ($path -and (Test-Path -LiteralPath $path -PathType Leaf)) {
        $lblBrowserStatus.Text = "Detected: $(Get-BrowserName $path)"
        $lblBrowserStatus.ForeColor = [System.Drawing.Color]::DarkGreen
    } else {
        $lblBrowserStatus.Text = "Browser not selected"
        $lblBrowserStatus.ForeColor = [System.Drawing.Color]::DarkRed
    }
}

function Auto-Detect-Browser {
    $found = Get-InstalledBrowserPath
    if ($found) { $txtBrowser.Text = $found } else { $txtBrowser.Text = "" }
    Update-BrowserStatus
}

# ---------------- Events ----------------
$btnDetect.Add_Click({
    Auto-Detect-Browser
    if ([string]::IsNullOrWhiteSpace($txtBrowser.Text)) {
        [System.Windows.Forms.MessageBox]::Show(
            "Edge / Chrome / Brave / Chromium was not found automatically.`r`nUse Browse and select the browser EXE.",
            "Browser not found"
        )
    }
})

$btnBrowserBrowse.Add_Click({
    $ofd = New-Object System.Windows.Forms.OpenFileDialog
    $ofd.Filter = "Chromium browsers (*.exe)|msedge.exe;chrome.exe;brave.exe;chromium.exe|All EXE files (*.exe)|*.exe"
    $ofd.Title = "Select Edge / Chrome / Brave / Chromium executable"
    if ($ofd.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        $txtBrowser.Text = $ofd.FileName
        Update-BrowserStatus
    }
})

$txtBrowser.Add_TextChanged({ Update-BrowserStatus })

$btnImport.Add_Click({
    $ofd = New-Object System.Windows.Forms.OpenFileDialog
    $ofd.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*"
    if ($ofd.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        try { $txtUrls.Text = [System.IO.File]::ReadAllText($ofd.FileName) }
        catch { [System.Windows.Forms.MessageBox]::Show("Failed to read file.`r`n$($_.Exception.Message)") }
    }
})

$btnClear.Add_Click({ $txtUrls.Clear() })

$btnBrowse.Add_Click({
    $fbd = New-Object System.Windows.Forms.FolderBrowserDialog
    $fbd.SelectedPath = $txtOutput.Text
    if ($fbd.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        $txtOutput.Text = $fbd.SelectedPath
        Refresh-Gallery
    }
})

$btnOpenOutput.Add_Click({
    $path = Get-OutputRoot
    if (-not (Test-Path -LiteralPath $path)) {
        try { New-Item -ItemType Directory -Force -Path $path | Out-Null } catch {}
    }
    if (Test-Path -LiteralPath $path) { Start-Process explorer.exe $path }
})

$btnGalleryRefresh.Add_Click({ Refresh-Gallery })

$btnGalleryOpenRoot.Add_Click({
    $path = Get-OutputRoot
    if (-not (Test-Path -LiteralPath $path)) {
        try { New-Item -ItemType Directory -Force -Path $path | Out-Null } catch {}
    }
    if (Test-Path -LiteralPath $path) { Start-Process explorer.exe $path }
})

$btnOpenAlbum.Add_Click({
    if ($lstAlbums.SelectedItem) {
        $albumPath = Join-Path (Get-OutputRoot) $lstAlbums.SelectedItem.ToString()
        if (Test-Path -LiteralPath $albumPath) { Start-Process explorer.exe $albumPath }
    }
})

$btnDeleteAlbum.Add_Click({
    if (-not $lstAlbums.SelectedItem) {
        [System.Windows.Forms.MessageBox]::Show(
            "Select an album first.",
            "aghrab"
        )
        return
    }

    $albumName = $lstAlbums.SelectedItem.ToString()
    $albumPath = Join-Path (Get-OutputRoot) $albumName

    if (-not (Test-Path -LiteralPath $albumPath -PathType Container)) {
        Refresh-Gallery
        return
    }

    $imageCount = @(
        Get-ChildItem -LiteralPath $albumPath -File -Filter *.png -ErrorAction SilentlyContinue
    ).Count

    $answer = [System.Windows.Forms.MessageBox]::Show(
        "Delete this entire album permanently?`r`n`r`nAlbum: $albumName`r`nScreenshots: $imageCount`r`n`r`nThis cannot be undone.",
        "aghrab",
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Warning
    )

    if ($answer -eq [System.Windows.Forms.DialogResult]::Yes) {
        try {
            Clear-ImagePreview
            $lvImages.Items.Clear()

            if ($lvImages.LargeImageList -ne $null) {
                try { $lvImages.LargeImageList.Dispose() } catch {}
            }

            Remove-Item -LiteralPath $albumPath -Recurse -Force
            Write-SecurityAudit -Action "ALBUM_DELETE" -Detail ("Album deleted: " + $albumName)
            Refresh-Gallery
        } catch {
            [System.Windows.Forms.MessageBox]::Show(
                "Could not delete the album.`r`n`r`n$($_.Exception.Message)",
                "aghrab"
            )
        }
    }
})

$btnOpenImage.Add_Click({
    if ($lvImages.SelectedItems.Count -gt 0) {
        $path = [string]$lvImages.SelectedItems[0].Tag
        if (Test-Path -LiteralPath $path) { Start-Process $path }
    }
})

$btnDeleteImage.Add_Click({
    if ($lvImages.SelectedItems.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show(
            "Select a screenshot first.",
            "aghrab"
        )
        return
    }

    $path = [string]$lvImages.SelectedItems[0].Tag

    if ([string]::IsNullOrWhiteSpace($path) -or -not (Test-Path -LiteralPath $path -PathType Leaf)) {
        return
    }

    $answer = [System.Windows.Forms.MessageBox]::Show(
        "Delete this screenshot permanently?`r`n`r`n$([System.IO.Path]::GetFileName($path))",
        "aghrab",
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Warning
    )

    if ($answer -eq [System.Windows.Forms.DialogResult]::Yes) {
        try {
            Clear-ImagePreview
            Remove-Item -LiteralPath $path -Force
            Write-SecurityAudit -Action "SCREENSHOT_DELETE" -Detail ("Screenshot deleted: " + [System.IO.Path]::GetFileName($path))

            if ($lstAlbums.SelectedItem) {
                Load-AlbumImages $lstAlbums.SelectedItem.ToString()
            }
        } catch {
            [System.Windows.Forms.MessageBox]::Show(
                "Could not delete the screenshot.`r`n`r`n$($_.Exception.Message)",
                "aghrab"
            )
        }
    }
})

$lstAlbums.Add_SelectedIndexChanged({
    if ($lstAlbums.SelectedItem) {
        Load-AlbumImages $lstAlbums.SelectedItem.ToString()
        Load-SelectedAlbumRetention
    } else {
        $lvImages.Items.Clear()
        Clear-ImagePreview
        $grpAlbumRetention.Enabled = $false
        $lblAlbumRetentionStatus.Text = ""
    }
})

$tabGallery.Add_Resize({
    Update-GalleryImageListLayout
    Update-GalleryPreviewLayout
})

$lvImages.Add_SelectedIndexChanged({ Show-SelectedImage })
$lvImages.Add_DoubleClick({
    if ($lvImages.SelectedItems.Count -gt 0) {
        $path = [string]$lvImages.SelectedItems[0].Tag
        if (Test-Path -LiteralPath $path) { Start-Process $path }
    }
})

$txtOutput.Add_TextChanged({ $txtGalleryRoot.Text = Get-OutputRoot })

$btnSaveAlbumPolicy.Add_Click({
    if (-not $lstAlbums.SelectedItem) {
        return
    }

    $albumName = $lstAlbums.SelectedItem.ToString()
    $albumPath = Join-Path (Get-OutputRoot) $albumName

    try {
        $policy = Save-AlbumRetentionPolicy `
            -AlbumPath $albumPath `
            -KeepDays ([int]$numAlbumKeepDays.Value) `
            -MaxPerAlbum ([int]$numAlbumMaxImages.Value)

        $lblAlbumRetentionStatus.Text =
            "Saved: $($policy.KeepDays)d / max $($policy.MaxPerAlbum)"

        [System.Windows.Forms.MessageBox]::Show(
            "Retention policy saved for:`r`n$albumName",
            "aghrab"
        )
    } catch {
        [System.Windows.Forms.MessageBox]::Show(
            "Could not save the album policy.`r`n`r`n$($_.Exception.Message)",
            "aghrab"
        )
    }
})

$btnCleanupAlbumNow.Add_Click({
    if (-not $lstAlbums.SelectedItem) {
        return
    }

    $albumName = $lstAlbums.SelectedItem.ToString()
    $albumPath = Join-Path (Get-OutputRoot) $albumName

    try {
        [void](Save-AlbumRetentionPolicy `
            -AlbumPath $albumPath `
            -KeepDays ([int]$numAlbumKeepDays.Value) `
            -MaxPerAlbum ([int]$numAlbumMaxImages.Value))

        $result = Apply-AlbumSavedRetentionPolicy -AlbumPath $albumPath

        Load-AlbumImages $albumName
        Load-SelectedAlbumRetention

        [System.Windows.Forms.MessageBox]::Show(
            "Album cleanup finished.`r`n`r`nRemoved by age: $($result.RemovedByAge)`r`nRemoved by limit: $($result.RemovedByLimit)`r`nRemaining: $($result.Remaining)",
            "aghrab"
        )
    } catch {
        [System.Windows.Forms.MessageBox]::Show(
            "Could not clean up the album.`r`n`r`n$($_.Exception.Message)",
            "aghrab"
        )
    }
})


$lstElkProfiles.Add_SelectedIndexChanged({
    if ($lstElkProfiles.SelectedItem) {
        $selectedProfileName = $lstElkProfiles.SelectedItem.ToString()
        Load-ElkProfileEditor -ProfileName $selectedProfileName

        if (Test-ElkLiveSession -ProfileName $selectedProfileName) {
            $lblElkSessionStatus.Text = "Session: connected"
            $lblElkSessionStatus.ForeColor = [System.Drawing.Color]::DarkGreen
        }
        else {
            $lblElkSessionStatus.Text = "Session: not connected"
            $lblElkSessionStatus.ForeColor = [System.Drawing.Color]::DarkRed
        }
    }
})

$btnElkNewProfile.Add_Click({
    Clear-ElkProfileEditor
    $txtElkProfileName.Focus()
})

$btnElkDeleteProfile.Add_Click({
    if (-not $lstElkProfiles.SelectedItem) {
        return
    }

    $name = $lstElkProfiles.SelectedItem.ToString()

    $answer = [System.Windows.Forms.MessageBox]::Show(
        "Delete profile '$name'?`r`n`r`nThe saved Kibana browser session is NOT deleted.",
        "aghrab",
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Warning
    )

    if ($answer -eq [System.Windows.Forms.DialogResult]::Yes) {
        $script:ElkProfiles = @(
            $script:ElkProfiles | Where-Object { $_.Name -ne $name }
        )

        if ($script:ElkProfiles.Count -eq 0) {
            $script:ElkProfiles = @(New-DefaultElkProfile)
        }

        Save-ElkProfiles
        Refresh-ElkProfileList
    }
})

$btnElkSaveProfile.Add_Click({
    [void](Save-CurrentElkProfile)
})

$lvElkDashboards.Add_SelectedIndexChanged({
    $item = Get-SelectedElkDashboardItem

    if ($item) {
        $txtElkDashboardName.Text = $item.Text
        $cmbElkTimeRange.SelectedItem = Normalize-ElkTimeRangeLabel -Label ([string]$item.SubItems[1].Text)
        $txtElkDashboardUrl.Text = $item.SubItems[2].Text
        $txtElkDashboardIndex.Text = $(if ($item.SubItems.Count -gt 3) { [string]$item.SubItems[3].Text } else { "" })
        $txtElkExpectedFields.Text = $(if ($item.SubItems.Count -gt 4) { [string]$item.SubItems[4].Text } else { "" })
    }
})

$lvElkDashboards.Add_DoubleClick({
    $item = Get-SelectedElkDashboardItem

    if ($item) {
        $txtElkDashboardName.Text = $item.Text
        $cmbElkTimeRange.SelectedItem = Normalize-ElkTimeRangeLabel -Label ([string]$item.SubItems[1].Text)
        $txtElkDashboardUrl.Text = $item.SubItems[2].Text
        $txtElkDashboardIndex.Text = $(if ($item.SubItems.Count -gt 3) { [string]$item.SubItems[3].Text } else { "" })
        $txtElkExpectedFields.Text = $(if ($item.SubItems.Count -gt 4) { [string]$item.SubItems[4].Text } else { "" })
        $txtElkDashboardName.Focus()
    }
})

$btnSuggestFields.Add_Click({
    $indexPattern = $txtElkDashboardIndex.Text.Trim()

    if ([string]::IsNullOrWhiteSpace($indexPattern)) {
        [System.Windows.Forms.MessageBox]::Show(
            $form,
            "Enter ES Index / Data Stream first.`r`n`r`nExample: logs-suricata-*",
            "RAQEB - Suggest Fields",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        )
        $txtElkDashboardIndex.Focus()
        return
    }

    $profileForSuggest = [PSCustomObject]@{
        ElasticsearchUrl = [string]$script:EditorElasticsearchUrl
        FieldVerifyApiKeyProtected = [string]$script:EditorFieldVerifyApiKeyProtected
        FieldVerifyTimeField = [string]$script:EditorFieldVerifyTimeField
        FieldVerifyWindowMinutes = [int]$script:EditorFieldVerifyWindowMinutes
        FieldVerifyIgnoreTls = [bool]$script:EditorFieldVerifyIgnoreTls
    }

    $oldText = $btnSuggestFields.Text
    $btnSuggestFields.Text = "Loading..."
    $btnSuggestFields.Enabled = $false
    $form.Cursor = [System.Windows.Forms.Cursors]::WaitCursor

    try {
        [System.Windows.Forms.Application]::DoEvents()

        $suggestion = Get-ElasticsearchSuggestedFields `
            -Profile $profileForSuggest `
            -IndexPattern $indexPattern

        $form.Cursor = [System.Windows.Forms.Cursors]::Default

        $selected = Show-SuggestedFieldsDialog `
            -SuggestionResult $suggestion `
            -CurrentFields $txtElkExpectedFields.Text

        if (-not [string]::IsNullOrWhiteSpace($selected)) {
            $txtElkExpectedFields.Text = $selected
            $txtElkExpectedFields.Focus()
            $txtElkExpectedFields.SelectionStart = $txtElkExpectedFields.Text.Length
        }
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show(
            $form,
            "Could not suggest fields.`r`n`r`n" + $_.Exception.Message +
            "`r`n`r`nCheck Elasticsearch URL, API Key, TLS setting and ES Index.",
            "RAQEB - Suggest Fields",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        )
    }
    finally {
        $btnSuggestFields.Text = $oldText
        $btnSuggestFields.Enabled = $true
        $form.Cursor = [System.Windows.Forms.Cursors]::Default
    }
})


$btnVerifyFieldsNow.Add_Click({
    $dashboardName = $txtElkDashboardName.Text.Trim()
    if ([string]::IsNullOrWhiteSpace($dashboardName)) {
        $selected = Get-SelectedElkDashboardItem
        if ($null -ne $selected) {
            $dashboardName = [string]$selected.Text
        }
    }
    if ([string]::IsNullOrWhiteSpace($dashboardName)) {
        $dashboardName = "(Current dashboard)"
    }

    $indexPattern = $txtElkDashboardIndex.Text.Trim()
    $expectedFields = $txtElkExpectedFields.Text.Trim()

    if ([string]::IsNullOrWhiteSpace($indexPattern)) {
        [System.Windows.Forms.MessageBox]::Show(
            $form,
            "Enter ES Index / Data Stream first.`r`n`r`nExample: logs-suricata-*",
            "RAQEB - Verify Fields Now",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        )
        $txtElkDashboardIndex.Focus()
        return
    }

    if ([string]::IsNullOrWhiteSpace($expectedFields)) {
        [System.Windows.Forms.MessageBox]::Show(
            $form,
            "Enter at least one Expected Field first.`r`n`r`nExample: source.ip, destination.ip, event.action",
            "RAQEB - Verify Fields Now",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        )
        $txtElkExpectedFields.Focus()
        return
    }

    $profileForVerify = [PSCustomObject]@{
        FieldVerifyEnabled = [bool]$script:EditorFieldVerifyEnabled
        ElasticsearchUrl = [string]$script:EditorElasticsearchUrl
        FieldVerifyApiKeyProtected = [string]$script:EditorFieldVerifyApiKeyProtected
        FieldVerifyTimeField = [string]$script:EditorFieldVerifyTimeField
        FieldVerifyWindowMinutes = [int]$script:EditorFieldVerifyWindowMinutes
        FieldVerifyIgnoreTls = [bool]$script:EditorFieldVerifyIgnoreTls
    }

    $dashboardForVerify = [PSCustomObject]@{
        Name = $dashboardName
        IndexPattern = $indexPattern
        ExpectedFields = $expectedFields
    }

    $oldText = $btnVerifyFieldsNow.Text
    $btnVerifyFieldsNow.Text = "Verifying..."
    $btnVerifyFieldsNow.Enabled = $false
    $form.Cursor = [System.Windows.Forms.Cursors]::WaitCursor

    try {
        [System.Windows.Forms.Application]::DoEvents()

        $result = Invoke-ElasticsearchManualFieldVerification `
            -Profile $profileForVerify `
            -Dashboard $dashboardForVerify

        Show-ManualFieldVerificationResult -Result $result
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show(
            $form,
            "Verification failed.`r`n`r`n" + $_.Exception.Message,
            "RAQEB - Verify Fields Now",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        )
    }
    finally {
        $btnVerifyFieldsNow.Text = $oldText
        $btnVerifyFieldsNow.Enabled = $true
        $form.Cursor = [System.Windows.Forms.Cursors]::Default
    }
})


$btnElkAddDashboard.Add_Click({
    $name = $txtElkDashboardName.Text.Trim()
    $url = $txtElkDashboardUrl.Text.Trim()
    $indexPattern = $txtElkDashboardIndex.Text.Trim()
    $expectedFields = $txtElkExpectedFields.Text.Trim()
    $timeRange = Normalize-ElkTimeRangeLabel -Label ([string]$cmbElkTimeRange.SelectedItem)

    if ([string]::IsNullOrWhiteSpace($name) -or [string]::IsNullOrWhiteSpace($url)) {
        [System.Windows.Forms.MessageBox]::Show(
            "Dashboard name and URL are required.",
            "aghrab"
        )
        return
    }

    $selected = Get-SelectedElkDashboardItem

    if ($selected) {
        $selected.Text = $name
        $selected.SubItems[1].Text = $timeRange
        $selected.SubItems[2].Text = $url
        while ($selected.SubItems.Count -lt 5) { [void]$selected.SubItems.Add("") }
        $selected.SubItems[3].Text = $indexPattern
        $selected.SubItems[4].Text = $expectedFields
        $selected.Selected = $false
    }
    else {
        $item = New-Object System.Windows.Forms.ListViewItem($name)
        [void]$item.SubItems.Add($timeRange)
        [void]$item.SubItems.Add($url)
        [void]$item.SubItems.Add($indexPattern)
        [void]$item.SubItems.Add($expectedFields)
        [void]$lvElkDashboards.Items.Add($item)
    }

    $txtElkDashboardName.Text = ""
    $txtElkDashboardUrl.Text = ""
    $txtElkDashboardIndex.Text = ""
    $txtElkExpectedFields.Text = ""
    $cmbElkTimeRange.SelectedItem = "Last 1 hour"
})

$btnElkDeleteDashboard.Add_Click({
    $selected = Get-SelectedElkDashboardItem

    if ($selected) {
        $lvElkDashboards.Items.Remove($selected)
        $txtElkDashboardName.Text = ""
        $txtElkDashboardUrl.Text = ""
        $txtElkDashboardIndex.Text = ""
        $txtElkExpectedFields.Text = ""
        $cmbElkTimeRange.SelectedItem = "Last 1 hour"
    }
})

$btnElkLoginBrowser.Add_Click({
    $profile = Save-CurrentElkProfile -Silent

    if (-not $profile) {
        return
    }

    $browser = $txtBrowser.Text.Trim()

    if (-not $browser -or -not (Test-Path -LiteralPath $browser -PathType Leaf)) {
        Auto-Detect-Browser
        $browser = $txtBrowser.Text.Trim()
    }

    if (-not $browser -or -not (Test-Path -LiteralPath $browser -PathType Leaf)) {
        [System.Windows.Forms.MessageBox]::Show(
            "Browser not found. Select Edge/Chrome in the Capture tab first.",
            "aghrab"
        )
        return
    }

    try {
        $session = Start-ElkLiveSession `
            -Browser $browser `
            -Profile $profile

        $lblElkSessionStatus.Text =
            "Session: browser open - login and KEEP it open"
        $lblElkSessionStatus.ForeColor = [System.Drawing.Color]::DarkGreen

        if ($session.AlreadyRunning) {
            [System.Windows.Forms.MessageBox]::Show(
                "The authenticated browser session for this profile is already open.`r`n`r`nKeep it open and use Capture All Dashboards.",
                "aghrab"
            )
        }
        else {
            [System.Windows.Forms.MessageBox]::Show(
                "Login to Kibana/Keycloak in the browser that opened.`r`n`r`nIMPORTANT: DO NOT close that browser after login.`r`n`r`nReturn to aghrab and click Capture All Dashboards while the browser remains open.",
                "aghrab"
            )
        }
    }
    catch {
        $lblElkSessionStatus.Text = "Session: failed to start"
        $lblElkSessionStatus.ForeColor = [System.Drawing.Color]::DarkRed

        [System.Windows.Forms.MessageBox]::Show(
            "Could not start the authenticated browser session.`r`n`r`n$($_.Exception.Message)",
            "aghrab"
        )
    }
})


$chkElkAutoLogin.Add_CheckedChanged({
    Update-ElkAuthUiState

    # Keep the saved profile state synchronized with the visible checkbox.
    # Do not save while a profile is merely being loaded into the editor.
    try {
        if ($script:LoadingElkProfileEditor) { return }

        if (
            -not [string]::IsNullOrWhiteSpace([string]$script:EditingElkProfileName) -and
            $null -ne $txtElkProfileName -and
            [string]$txtElkProfileName.Text.Trim() -eq [string]$script:EditingElkProfileName
        ) {
            $p = Get-ElkProfileByName -Name ([string]$script:EditingElkProfileName)
            if ($null -ne $p) {
                $p.AutoLoginEnabled = [bool]$chkElkAutoLogin.Checked
                Save-ElkProfiles
                try { Update-SchedulerStateUi } catch {}
            }
        }
    }
    catch {}
})

$btnElkTestLogin.Add_Click({
    if (-not (Test-ElkAutoLoginFields -ShowMessage)) {
        return
    }

    $runtimeUsername = $txtElkAuthUser.Text.Trim()
    $runtimePassword = $txtElkAuthPassword.Text

    $profile = Save-CurrentElkProfile -Silent

    if (-not $profile) {
        return
    }

    if (-not [bool]$profile.AutoLoginEnabled) {
        [System.Windows.Forms.MessageBox]::Show(
            "Enable 'Auto Login before Capture' first.",
            "aghrab"
        )
        return
    }

    $browser = $txtBrowser.Text.Trim()

    if (-not $browser -or -not (Test-Path -LiteralPath $browser -PathType Leaf)) {
        Auto-Detect-Browser
        $browser = $txtBrowser.Text.Trim()
    }

    if (-not $browser -or -not (Test-Path -LiteralPath $browser -PathType Leaf)) {
        [System.Windows.Forms.MessageBox]::Show(
            "Browser not found. Select Edge/Chrome in the Capture tab first.",
            "aghrab"
        )
        return
    }

    try {
        $txtElkLog.AppendText("Testing Auto Login (SSO redirect-safe mode)...`r`n")

        $session = Start-ElkLiveSession -Browser $browser -Profile $profile
        $result = Ensure-ElkAutoLogin `
            -Port $session.Port `
            -Profile $profile `
            -UsernameOverride $runtimeUsername `
            -PasswordOverride $runtimePassword

        try {
            # A successful Auto Login is definitive proof that this profile is
            # configured for Auto Login. Persist the flag and credentials
            # explicitly so Automatic Capture cannot show a stale OFF state.
            $profile.AutoLoginEnabled = $true
            $profile.Username = $runtimeUsername

            if (-not [string]::IsNullOrWhiteSpace($runtimePassword)) {
                $savedProtected = Save-ElkProfileCredential `
                    -ProfileName ([string]$profile.Name) `
                    -PlainText $runtimePassword

                if (-not [string]::IsNullOrWhiteSpace($savedProtected)) {
                    $profile.PasswordProtected = $savedProtected
                }
            }

            $script:ElkProfiles = @(
                $script:ElkProfiles |
                Where-Object { [string]$_.Name -ne [string]$profile.Name }
            )
            $script:ElkProfiles += $profile
            Save-ElkProfiles

            try {
                Refresh-SchedulerProfiles
                if ($cmbSchedulerProfile.Items.Contains([string]$profile.Name)) {
                    $cmbSchedulerProfile.SelectedItem = [string]$profile.Name
                }
                Update-SchedulerStateUi
            }
            catch {}
        }
        catch {
            $txtElkLog.AppendText("Credential/state persistence warning -> $($_.Exception.Message)`r`n")
        }

        Clear-ElkCaptchaPending
        $lblElkSessionStatus.Text = "AUTO LOGIN SUCCESS"
        $lblElkSessionStatus.ForeColor = [System.Drawing.Color]::DarkGreen

        $txtElkLog.AppendText("AUTO LOGIN SUCCESS -> " + [string]$result.href + "`r`n")

        $form.WindowState = [System.Windows.Forms.FormWindowState]::Normal
        $form.Show()
        $form.Activate()
        $form.BringToFront()

        [System.Windows.Forms.MessageBox]::Show(
            $form,
            "AUTO LOGIN SUCCESS`r`n`r`nKibana authentication completed successfully.`r`nThe session is ready for Capture All Dashboards.",
            "aghrab",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        )
    }
    catch {
        if ($_.Exception.Message -eq "CAPTCHA_REQUIRED") {
            Set-ElkCaptchaPending -Mode "test" -ProfileName ([string]$profile.Name)
            return
        }

        Clear-ElkCaptchaPending
        $lblElkSessionStatus.Text = "Session: auto login failed"
        $lblElkSessionStatus.ForeColor = [System.Drawing.Color]::DarkRed
        $txtElkLog.AppendText("Auto Login ERROR -> $($_.Exception.Message)`r`n")

        if ($_.Exception.Message -match "Username or Password is incorrect") {
            Close-ElkLiveSession
        }

        $form.WindowState = [System.Windows.Forms.FormWindowState]::Normal
        $form.Show()
        $form.Activate()
        $form.BringToFront()

        [System.Windows.Forms.MessageBox]::Show(
            $form,
            "Auto Login failed.`r`n`r`n$($_.Exception.Message)",
            "aghrab",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        )
    }
})

$btnElkContinueCaptcha.Add_Click({
    if (-not $script:ElkCaptchaPending) { return }

    $pendingMode = [string]$script:ElkCaptchaPendingMode
    $pendingProfileName = [string]$script:ElkCaptchaPendingProfileName
    $pendingDashboardName = [string]$script:ElkCaptchaPendingDashboardName
    $isSchedulerResume = $pendingMode -in @("scheduler","scheduler-recheck")

    if ($isSchedulerResume) {
        $profile = Get-ElkProfileByName -Name $pendingProfileName
    }
    else {
        $profile = Save-CurrentElkProfile -Silent
    }

    if (-not $profile) {
        [System.Windows.Forms.MessageBox]::Show(
            $form,
            "The pending profile could not be found. Start the login again.",
            "RAQEB - CAPTCHA",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Warning
        ) | Out-Null
        Clear-ElkCaptchaPending
        return
    }

    if (-not (Test-ElkLiveSession -ProfileName ([string]$profile.Name))) {
        [System.Windows.Forms.MessageBox]::Show(
            $form,
            "The browser session was closed.`r`n`r`nStart Login Browser / Auto Login again. RAQEB cannot continue after the browser session is gone.",
            "RAQEB - CAPTCHA",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Warning
        ) | Out-Null
        Clear-ElkCaptchaPending
        return
    }

    $runtimeUsername = ""
    $runtimePassword = ""

    if (-not $isSchedulerResume) {
        $runtimeUsername = $txtElkAuthUser.Text.Trim()
        $runtimePassword = $txtElkAuthPassword.Text
    }

    $btnElkContinueCaptcha.Enabled = $false

    if ($null -ne $txtElkLog) {
        $txtElkLog.AppendText("Checking browser after manual CAPTCHA...`r`n")
    }

    try {
        $result = Ensure-ElkAutoLogin `
            -Port $script:ElkLivePort `
            -Profile $profile `
            -UsernameOverride $runtimeUsername `
            -PasswordOverride $runtimePassword `
            -ResumeAfterCaptcha

        $resumeMode = $pendingMode
        $resumeDashboard = $pendingDashboardName

        Clear-ElkCaptchaPending

        $lblElkSessionStatus.Text = "SESSION AUTHENTICATED - CAPTCHA COMPLETE"
        $lblElkSessionStatus.ForeColor = [System.Drawing.Color]::DarkGreen

        if ($null -ne $txtElkLog) {
            $txtElkLog.AppendText(
                "CAPTCHA completed -> authenticated session is ready and will be reused.`r`n"
            )
        }

        try {
            Write-SecurityAudit `
                -Action "CAPTCHA_MANUAL_COMPLETED" `
                -Detail ("Mode=" + $resumeMode + "; Profile=" + [string]$profile.Name)
        }
        catch {}

        if ($resumeMode -eq "capture") {
            $script:SkipNextAutoLogin = $true
            $btnElkCaptureAll.PerformClick()
            return
        }

        if ($resumeMode -in @("scheduler","scheduler-recheck")) {
            $script:SkipNextAutoLogin = $true

            try {
                if ($cmbSchedulerProfile.Items.Contains([string]$profile.Name)) {
                    $cmbSchedulerProfile.SelectedItem = [string]$profile.Name
                }
            }
            catch {}

            Write-SchedulerLog "Manual CAPTCHA completed. Resuming paused Automatic Capture."

            if ($resumeMode -eq "scheduler-recheck" -and
                -not [string]::IsNullOrWhiteSpace($resumeDashboard)) {
                Invoke-AutomaticCaptureCycle -DashboardName $resumeDashboard
            }
            else {
                Invoke-AutomaticCaptureCycle
            }

            return
        }

        $form.WindowState = [System.Windows.Forms.FormWindowState]::Normal
        $form.Show()
        $form.Activate()
        $form.BringToFront()

        [System.Windows.Forms.MessageBox]::Show(
            $form,
            (
                "CAPTCHA completed successfully.`r`n`r`n" +
                "RAQEB will reuse this authenticated browser session while it remains valid."
            ),
            "RAQEB - Login Ready",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
    }
    catch {
        if ($_.Exception.Message -eq "CAPTCHA_REQUIRED") {
            $script:ElkCaptchaPending = $true
            $script:ElkCaptchaPendingMode = $pendingMode
            $script:ElkCaptchaPendingProfileName = $pendingProfileName
            $script:ElkCaptchaPendingDashboardName = $pendingDashboardName

            $btnElkContinueCaptcha.Enabled = $true
            $lblElkSessionStatus.Text = "CAPTCHA: still waiting"
            $lblElkSessionStatus.ForeColor = [System.Drawing.Color]::DarkOrange

            if ($null -ne $txtElkLog) {
                $txtElkLog.AppendText(
                    "CAPTCHA is still present. Complete it manually and click Continue CAPTCHA again.`r`n"
                )
            }

            [System.Windows.Forms.MessageBox]::Show(
                $form,
                "CAPTCHA is still present.`r`n`r`nComplete it in the open browser and click Continue CAPTCHA again.",
                "RAQEB - CAPTCHA",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Information
            ) | Out-Null

            try { Update-SchedulerStateUi } catch {}
            try { Update-HeaderStatus } catch {}
            return
        }

        Clear-ElkCaptchaPending
        $lblElkSessionStatus.Text = "Session: login failed after CAPTCHA"
        $lblElkSessionStatus.ForeColor = [System.Drawing.Color]::DarkRed

        if ($null -ne $txtElkLog) {
            $txtElkLog.AppendText(
                "Continue CAPTCHA ERROR -> " + $_.Exception.Message + "`r`n"
            )
        }

        if ($_.Exception.Message -match "Username or Password is incorrect") {
            Close-ElkLiveSession
        }

        [System.Windows.Forms.MessageBox]::Show(
            $form,
            "Login failed after CAPTCHA.`r`n`r`n$($_.Exception.Message)",
            "RAQEB",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    }
})

$btnElkStop.Add_Click({
    if (-not $script:StopRequested) {
        $script:StopRequested = $true
        $btnElkStop.Enabled = $false
        $txtElkLog.AppendText("STOP requested.`r`n")

        try {
            if ($script:CurrentProcess -and -not $script:CurrentProcess.HasExited) {
                $script:CurrentProcess.Kill()
            }
        } catch {}
    }
})

$btnElkCaptureAll.Add_Click({
    if (-not (Test-ElkAutoLoginFields -ShowMessage)) {
        return
    }

    $runtimeUsername = $txtElkAuthUser.Text.Trim()
    $runtimePassword = $txtElkAuthPassword.Text

    $profile = Save-CurrentElkProfile -Silent

    if (-not $profile) {
        return
    }

    $dashboards = @($profile.Dashboards)

    if ($dashboards.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show(
            "Add at least one dashboard first.",
            "aghrab"
        )
        return
    }

    $browser = $txtBrowser.Text.Trim()

    if (-not $browser -or -not (Test-Path -LiteralPath $browser -PathType Leaf)) {
        Auto-Detect-Browser
        $browser = $txtBrowser.Text.Trim()
    }

    if (-not $browser -or -not (Test-Path -LiteralPath $browser -PathType Leaf)) {
        [System.Windows.Forms.MessageBox]::Show(
            "Browser not found. Select Edge/Chrome in the Capture tab first.",
            "aghrab"
        )
        return
    }

    if ([bool]$profile.AutoLoginEnabled) {
        if ($script:SkipNextAutoLogin -and (Test-ElkLiveSession -ProfileName ([string]$profile.Name))) {
            $script:SkipNextAutoLogin = $false
            Clear-ElkCaptchaPending
            $lblElkSessionStatus.Text = "Session: connected (CAPTCHA completed)"
            $lblElkSessionStatus.ForeColor = [System.Drawing.Color]::DarkGreen
        }
        else {
        try {
            $txtElkLog.AppendText("Preparing Auto Login (SSO redirect-safe mode)...`r`n")
            $session = Start-ElkLiveSession -Browser $browser -Profile $profile
            $null = Ensure-ElkAutoLogin `
                -Port $session.Port `
                -Profile $profile `
                -UsernameOverride $runtimeUsername `
                -PasswordOverride $runtimePassword

            Clear-ElkCaptchaPending
            $lblElkSessionStatus.Text = "Session: connected (auto login / DevTools OK)"
            $lblElkSessionStatus.ForeColor = [System.Drawing.Color]::DarkGreen
        }
        catch {
            if ($_.Exception.Message -eq "CAPTCHA_REQUIRED") {
                Set-ElkCaptchaPending -Mode "capture" -ProfileName ([string]$profile.Name)
                return
            }

            $lblElkSessionStatus.Text = "Session: auto login failed"
            $lblElkSessionStatus.ForeColor = [System.Drawing.Color]::DarkRed

            if ($_.Exception.Message -match "Username or Password is incorrect") {
                Close-ElkLiveSession
            }

            $form.WindowState = [System.Windows.Forms.FormWindowState]::Normal
            $form.Show()
            $form.Activate()
            $form.BringToFront()

            [System.Windows.Forms.MessageBox]::Show(
                $form,
                "Auto Login failed before capture.`r`n`r`n$($_.Exception.Message)",
                "aghrab",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Error
            )
            return
        }
        }
    }
    else {
        if (-not (Test-ElkLiveSession -ProfileName ([string]$profile.Name))) {
            $lblElkSessionStatus.Text = "Session: not authenticated / browser closed"
            $lblElkSessionStatus.ForeColor = [System.Drawing.Color]::DarkRed

            [System.Windows.Forms.MessageBox]::Show(
                "No live authenticated Kibana session was found.`r`n`r`n1. Click Open Login Browser.`r`n2. Login to Kibana/Keycloak.`r`n3. KEEP that browser open.`r`n4. Then click Capture All Dashboards.`r`n`r`nOr enable Auto Login below.",
                "aghrab"
            )
            return
        }

        $lblElkSessionStatus.Text = "Session: connected"
        $lblElkSessionStatus.ForeColor = [System.Drawing.Color]::DarkGreen
    }

    $browser = $txtBrowser.Text.Trim()

    $outDir = Get-OutputRoot

    if ([string]::IsNullOrWhiteSpace($outDir)) {
        [System.Windows.Forms.MessageBox]::Show(
            "Select the Output folder in the Capture tab first.",
            "aghrab"
        )
        return
    }

    New-Item -ItemType Directory -Force -Path $outDir | Out-Null

    $script:CaptureBusy = $true
    $script:StopRequested = $false
    $script:CurrentProcess = $null
    $script:CsvReportPath = Join-Path $outDir "ScreenshotReport.csv"

    $btnElkCaptureAll.Enabled = $false
    $btnElkStop.Enabled = $true
    $elkProgress.Minimum = 0
    $elkProgress.Maximum = $dashboards.Count
    $elkProgress.Value = 0
    $txtElkLog.Clear()

    $success = 0
    $failed = 0
    $index = 0

    foreach ($dashboard in $dashboards) {
        if ($script:StopRequested) {
            break
        }

        $index++
        $name = [string]$dashboard.Name
        $timeRange = "Dashboard default"

        if ($null -ne $dashboard.TimeRange) {
            $timeRange = Normalize-ElkTimeRangeLabel -Label ([string]$dashboard.TimeRange)
        }

        $txtElkLog.AppendText("[$index/$($dashboards.Count)] $name | $timeRange`r`n")
        $tabElk.Refresh()

        try {
            $result = Capture-ElkDashboard `
                -Profile $profile `
                -Dashboard $dashboard `
                -Browser $browser `
                -OutputRoot $outDir `
                -LiveCdpPort $script:ElkLivePort

            $success++
            $txtElkLog.AppendText(
                "  OK -> $($result.Album)\$([System.IO.Path]::GetFileName($result.File))  [$($result.Width)x$($result.Height)] | fixed-width dashboard capture`r`n"
            )

            Write-CsvReportRow `
                -Url $result.Url `
                -Status "Success" `
                -ScreenshotPath $result.File `
                -Browser (Get-BrowserName $browser) `
                -Detail ("ELK profile: " + [string]$profile.Name + "; dashboard: " + $name + "; time range: " + $timeRange + "; auto login: " + [string][bool]$profile.AutoLoginEnabled)
        }
        catch {
            if ($script:StopRequested) {
                $txtElkLog.AppendText("  STOPPED`r`n")
                break
            }

            $failed++
            $detail = $_.Exception.Message
            $txtElkLog.AppendText("  ERROR -> $detail`r`n")

            $resolvedUrl = ""
            try {
                $resolvedUrl = Resolve-ElkDashboardUrl `
                    -KibanaUrl ([string]$profile.KibanaUrl) `
                    -DashboardUrl ([string]$dashboard.Url)

                $resolvedUrl = Apply-ElkTimeRangeToUrl `
                    -Url $resolvedUrl `
                    -TimeRange $timeRange
            } catch {}

            Write-CsvReportRow `
                -Url $resolvedUrl `
                -Status "Error" `
                -ScreenshotPath "" `
                -Browser (Get-BrowserName $browser) `
                -Detail ("ELK profile: " + [string]$profile.Name + "; dashboard: " + $name + "; time range: " + $timeRange + "; auto login: " + [string][bool]$profile.AutoLoginEnabled + "; " + $detail)
        }

        $elkProgress.Value = $index
        [System.Windows.Forms.Application]::DoEvents()
    }

    $btnElkCaptureAll.Enabled = $true
    $btnElkStop.Enabled = $false
    $script:CurrentProcess = $null
    $script:CaptureBusy = $false

    Refresh-Gallery
    Refresh-AnalyzeAlbums

    if ($script:StopRequested) {
        $txtElkLog.AppendText("Stopped. Success: $success | Failed: $failed`r`n")
    }
    else {
        $txtElkLog.AppendText("Finished. Success: $success | Failed: $failed`r`n")

        $form.WindowState = [System.Windows.Forms.FormWindowState]::Normal
        $form.Show()
        $form.Activate()
        $form.BringToFront()

        [System.Windows.Forms.MessageBox]::Show(
            $form,
            "CAPTURE COMPLETED`r`n`r`nSuccessful dashboards: $success`r`nFailed dashboards: $failed",
            "aghrab",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            $(if ($failed -eq 0) {
                [System.Windows.Forms.MessageBoxIcon]::Information
            } else {
                [System.Windows.Forms.MessageBoxIcon]::Warning
            })
        )
    }
})

$btnAnalyzeRefresh.Add_Click({
    Refresh-AnalyzeAlbums
})

$btnAnalyzeLatest.Add_Click({
    Analyze-SelectedAlbum
})

$btnAiStart.Add_Click({
    try {
        [void](Start-BuiltInAi)
        [System.Windows.Forms.MessageBox]::Show(
            $form,
            "Built-in AI is ready.",
            "aghrab",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        )
    }
    catch {
        Update-AiStatus
        [System.Windows.Forms.MessageBox]::Show(
            $form,
            $_.Exception.Message,
            "aghrab AI",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        )
    }
})

$btnAiStop.Add_Click({
    Stop-BuiltInAi
})

$btnAiTest.Add_Click({
    try {
        [void](Start-BuiltInAi)

        $body = @{
            model = "local-qwen2.5-vl-3b"
            temperature = 0
            max_tokens = 40
            messages = @(
                @{
                    role = "user"
                    content = "Reply with exactly: RAQEB AI READY"
                }
            )
        } | ConvertTo-Json -Depth 10 -Compress

        $response = Invoke-RestMethod `
            -Uri ($script:AiBaseUrl + "/v1/chat/completions") `
            -Method Post `
            -ContentType "application/json; charset=utf-8" `
            -Body $body `
            -TimeoutSec 120

        $reply = [string]$response.choices[0].message.content
        $txtAiResult.Text = "AI Test Response:`r`n" + $reply
        Update-AiStatus
    }
    catch {
        $txtAiResult.Text = "AI Test failed:`r`n" + $_.Exception.Message
        Update-AiStatus
    }
})

$btnAiLatest.Add_Click({
    Invoke-AiAnalyzeLatest
})

$btnAiCompare.Add_Click({
    Invoke-AiCompareLastTwo
})

$btnAiOpenFolder.Add_Click({
    $paths = Get-AiPaths
    New-Item -ItemType Directory -Force -Path $paths.Root | Out-Null
    Start-Process explorer.exe -ArgumentList ('"' + $paths.Root + '"')
})

$btnStop.Add_Click({
    if (-not $script:StopRequested) {
        $script:StopRequested = $true
        $btnStop.Enabled = $false
        $lblStatus.Text = "Stopping..."
        $txtLog.AppendText("STOP requested by user.`r`n")
        $form.Refresh()

        try {
            if ($script:CurrentProcess -and -not $script:CurrentProcess.HasExited) {
                $script:CurrentProcess.Kill()
            }
        } catch {}
    }
})

$btnStart.Add_Click({
    $browser = $txtBrowser.Text.Trim()

    if (-not $browser -or -not (Test-Path -LiteralPath $browser -PathType Leaf)) {
        Auto-Detect-Browser
        $browser = $txtBrowser.Text.Trim()
    }

    if (-not $browser -or -not (Test-Path -LiteralPath $browser -PathType Leaf)) {
        [System.Windows.Forms.MessageBox]::Show(
            "Browser not found.`r`nUse Browse and select msedge.exe, chrome.exe or brave.exe.",
            "Browser required","OK","Error"
        )
        return
    }

    $urls = @()
    foreach ($line in $txtUrls.Lines) {
        $u = $line.Trim()
        if ([string]::IsNullOrWhiteSpace($u)) { continue }
        if ($u.StartsWith("#")) { continue }
        if (-not ($u.StartsWith("http://") -or $u.StartsWith("https://"))) { $u = "https://" + $u }
        $urls += $u
    }

    if ($urls.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show("Enter at least one URL or IP.")
        return
    }

    $outDir = Get-OutputRoot
    if ([string]::IsNullOrWhiteSpace($outDir)) {
        [System.Windows.Forms.MessageBox]::Show("Select an output folder.")
        return
    }

    try { New-Item -ItemType Directory -Force -Path $outDir | Out-Null }
    catch {
        [System.Windows.Forms.MessageBox]::Show("Cannot create output folder.`r`n$($_.Exception.Message)")
        return
    }

    $script:StopRequested = $false
    $script:CurrentProcess = $null
    $script:CsvReportPath = Join-Path $outDir "ScreenshotReport.csv"

    $btnStart.Enabled = $false
    $btnStop.Enabled = $true
    $txtLog.Clear()
    $txtLog.AppendText("CSV Report -> $script:CsvReportPath`r`n")

    $initialCleanup = Apply-RetentionToAllAlbums -OutputRoot $outDir

    if (($initialCleanup.RemovedByAge + $initialCleanup.RemovedByLimit) -gt 0) {
        $txtLog.AppendText(
            "Retention cleanup -> albums $($initialCleanup.AlbumsChecked), removed by age $($initialCleanup.RemovedByAge), removed by limit $($initialCleanup.RemovedByLimit)`r`n"
        )
    }
    $progress.Minimum = 0
    $progress.Maximum = $urls.Count
    $progress.Value = 0

    $success = 0
    $failed = 0
    $stopped = $false
    $i = 0

    foreach ($url in $urls) {
        [System.Windows.Forms.Application]::DoEvents()

        if ($script:StopRequested) {
            $stopped = $true
            break
        }

        $i++
        $lblStatus.Text = "[$i/$($urls.Count)] $url"
        $form.Refresh()

        $urlFolderName = Safe-UrlFolderName $url
        $urlFolder = Join-Path $outDir $urlFolderName

        try {
            New-Item -ItemType Directory -Force -Path $urlFolder | Out-Null
            [void](Ensure-AlbumRetentionPolicy -AlbumPath $urlFolder)
        } catch {
            $failed++
            $detail = "Cannot create URL folder: " + $_.Exception.Message
            $txtLog.AppendText("  ERROR -> $detail`r`n")
            Write-CsvReportRow -Url $url -Status "Error" -ScreenshotPath "" -Browser (Get-BrowserName $browser) -Detail $detail
            $progress.Value = $i
            $form.Refresh()
            continue
        }

        $timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss-fff"
        $file = Join-Path $urlFolder ($timestamp + ".png")

        $profileDir = Join-Path $env:TEMP ("aghrab-Headless-" + [guid]::NewGuid().ToString("N"))
        try { New-Item -ItemType Directory -Force -Path $profileDir | Out-Null } catch {}

        $modeText = "Viewport"
        if ($chkFullPage.Checked) { $modeText = "Full Page / Auto-scroll" }

        $txtLog.AppendText("[$i/$($urls.Count)] $url  [$modeText | load wait $([int]$numWaitAfterLoad.Value)s | scroll $([int]$numScrollDelay.Value)ms | settle $([int]$numFinalSettle.Value)s]`r`n")
        $form.Refresh()

        try {
            if ($chkFullPage.Checked) {
                $dimensions = Capture-FullPageScreenshot `
                    -Browser $browser `
                    -Url $url `
                    -File $file `
                    -ProfileDir $profileDir `
                    -Width ([int]$numWidth.Value) `
                    -Height ([int]$numHeight.Value) `
                    -IgnoreCertificateErrors ([bool]$chkIgnoreCert.Checked) `
                    -WaitAfterLoadMs ([int]$numWaitAfterLoad.Value * 1000) `
                    -ScrollDelayMs ([int]$numScrollDelay.Value) `
                    -FinalSettleMs ([int]$numFinalSettle.Value * 1000) `
                    -TimeoutMs ([int]$numTimeout.Value * 1000)

                if ($script:StopRequested) {
                    $stopped = $true
                    $txtLog.AppendText("  STOPPED`r`n")
                    Write-CsvReportRow -Url $url -Status "Stopped" -ScreenshotPath "" -Browser (Get-BrowserName $browser) -Detail "Stopped by user"
                }
                elseif (Test-Path -LiteralPath $file) {
                    $success++
                    $relativePath = "$urlFolderName\$([System.IO.Path]::GetFileName($file))"
                    $detail = "Full page: $($dimensions.Width)x$($dimensions.Height)"
                    $txtLog.AppendText("  OK -> $relativePath  [$detail]`r`n")
                    Write-CsvReportRow -Url $url -Status "Success" -ScreenshotPath $file -Browser (Get-BrowserName $browser) -Detail $detail
                    $retention = Apply-AlbumSavedRetentionPolicy -AlbumPath $urlFolder

                    if (($retention.RemovedByAge + $retention.RemovedByLimit) -gt 0) {
                        $txtLog.AppendText(
                            "  Retention -> removed age $($retention.RemovedByAge), limit $($retention.RemovedByLimit), remaining $($retention.Remaining)`r`n"
                        )
                    }
                }
                else {
                    $failed++
                    $detail = "Full-page capture finished but no screenshot file was created"
                    $txtLog.AppendText("  FAILED -> $detail`r`n")
                    Write-CsvReportRow -Url $url -Status "Failed" -ScreenshotPath "" -Browser (Get-BrowserName $browser) -Detail $detail
                }
            }
            else {
                $args = New-Object System.Collections.Generic.List[string]
                $args.Add("--headless=new")
                $args.Add("--disable-gpu")
                $args.Add("--hide-scrollbars")
                $args.Add("--no-first-run")
                $args.Add("--no-default-browser-check")
                $args.Add("--disable-extensions")
                $args.Add("--disable-background-networking")
                $args.Add("--disable-component-update")
                $args.Add("--window-size=$([int]$numWidth.Value),$([int]$numHeight.Value)")
                $args.Add('--user-data-dir="' + $profileDir + '"')
                $args.Add('--screenshot="' + $file + '"')
                $args.Add("--virtual-time-budget=$([Math]::Max(3000, ([int]$numWaitAfterLoad.Value * 1000)))")

                if ($chkIgnoreCert.Checked) {
                    $args.Add("--ignore-certificate-errors")
                    $args.Add("--allow-insecure-localhost")
                }

                $args.Add($url)

                $p = Start-Process -FilePath $browser -ArgumentList $args.ToArray() -PassThru -WindowStyle Hidden
                $script:CurrentProcess = $p
                $timeoutMs = [int]$numTimeout.Value * 1000
                $watch = [System.Diagnostics.Stopwatch]::StartNew()

                while (-not $p.HasExited -and $watch.ElapsedMilliseconds -lt $timeoutMs -and -not $script:StopRequested) {
                    [System.Windows.Forms.Application]::DoEvents()
                    Start-Sleep -Milliseconds 100
                }

                if ($script:StopRequested) {
                    try {
                        if (-not $p.HasExited) { $p.Kill() }
                    } catch {}

                    $stopped = $true
                    $txtLog.AppendText("  STOPPED`r`n")
                    Write-CsvReportRow -Url $url -Status "Stopped" -ScreenshotPath "" -Browser (Get-BrowserName $browser) -Detail "Stopped by user"
                }
                elseif (-not $p.HasExited) {
                    try { $p.Kill() } catch {}
                    $failed++
                    $txtLog.AppendText("  TIMEOUT`r`n")
                    Write-CsvReportRow -Url $url -Status "Timeout" -ScreenshotPath "" -Browser (Get-BrowserName $browser) -Detail ("Timeout after " + [int]$numTimeout.Value + " seconds")
                }
                else {
                    for ($waitStep = 0; $waitStep -lt 7; $waitStep++) {
                        [System.Windows.Forms.Application]::DoEvents()
                        if ($script:StopRequested) { break }
                        Start-Sleep -Milliseconds 100
                    }

                    if ($script:StopRequested) {
                        $stopped = $true
                        $txtLog.AppendText("  STOPPED`r`n")
                        Write-CsvReportRow -Url $url -Status "Stopped" -ScreenshotPath "" -Browser (Get-BrowserName $browser) -Detail "Stopped by user"
                    }
                    elseif (Test-Path -LiteralPath $file) {
                        $success++
                        $relativePath = "$urlFolderName\$([System.IO.Path]::GetFileName($file))"
                        $txtLog.AppendText("  OK -> $relativePath`r`n")
                        Write-CsvReportRow -Url $url -Status "Success" -ScreenshotPath $file -Browser (Get-BrowserName $browser) -Detail "Viewport capture"
                        $retention = Apply-AlbumSavedRetentionPolicy -AlbumPath $urlFolder

                        if (($retention.RemovedByAge + $retention.RemovedByLimit) -gt 0) {
                            $txtLog.AppendText(
                                "  Retention -> removed age $($retention.RemovedByAge), limit $($retention.RemovedByLimit), remaining $($retention.Remaining)`r`n"
                            )
                        }
                    }
                    else {
                        $failed++
                        $exitCode = ""
                        try { $exitCode = $p.ExitCode } catch {}
                        $detail = "No screenshot created. Browser exit code: $exitCode"
                        $txtLog.AppendText("  FAILED -> $detail`r`n")
                        Write-CsvReportRow -Url $url -Status "Failed" -ScreenshotPath "" -Browser (Get-BrowserName $browser) -Detail $detail
                    }
                }
            }
        } catch {
            if ($script:StopRequested) {
                $stopped = $true
                $txtLog.AppendText("  STOPPED`r`n")
                Write-CsvReportRow -Url $url -Status "Stopped" -ScreenshotPath "" -Browser (Get-BrowserName $browser) -Detail "Stopped by user"
            } else {
                $failed++
                $detail = $_.Exception.Message
                $txtLog.AppendText("  ERROR -> $detail`r`n")
                Write-CsvReportRow -Url $url -Status "Error" -ScreenshotPath "" -Browser (Get-BrowserName $browser) -Detail $detail
            }
        } finally {
            $script:CurrentProcess = $null
            try { Remove-Item -LiteralPath $profileDir -Recurse -Force -ErrorAction SilentlyContinue } catch {}
        }

        $progress.Value = $i
        $form.Refresh()

        if ($stopped -or $script:StopRequested) {
            $stopped = $true
            break
        }
    }

    $btnStart.Enabled = $true
    $btnStop.Enabled = $false
    $script:CurrentProcess = $null

    Refresh-Gallery
    Refresh-AnalyzeAlbums

    if ($stopped -or $script:StopRequested) {
        $lblStatus.Text = "Stopped - Success: $success | Failed: $failed"
        [System.Windows.Forms.MessageBox]::Show(
            "Stopped by user.`r`nSuccess: $success`r`nFailed: $failed`r`n`r`nCSV Report:`r`n$script:CsvReportPath",
            "aghrab"
        )
    } else {
        $lblStatus.Text = "Finished - Success: $success | Failed: $failed"
        [System.Windows.Forms.MessageBox]::Show(
            "Finished.`r`nSuccess: $success`r`nFailed: $failed`r`n`r`nCSV Report:`r`n$script:CsvReportPath",
            "aghrab"
        )
    }
})

Load-ElkProfiles
Refresh-ElkProfileList
Auto-Detect-Browser
Refresh-Gallery
Refresh-AnalyzeAlbums
Refresh-SchedulerProfiles
Load-SchedulerUi
Refresh-HealthManagerProfiles
Refresh-HealthCenter
Update-AiStatus
Write-SecurityAudit -Action "APP_START" -Detail ("RAQEB Sentinel Pro v" + $AppVersion + " started.")
Update-SecurityCenter

$startupSettings = Get-AghrabSettings
$startupTheme = [string]$startupSettings.Theme
if ($startupTheme -ne "Dark") {
    $startupTheme = "Light"
}

$startupLanguage = [string]$startupSettings.Language
if ($startupLanguage -notin @("English","Persian")) {
    $startupLanguage = "English"
}

$startupPersianFont = [string]$startupSettings.PersianFont
if ($startupPersianFont -notin @("Tahoma","B Koodak")) {
    $startupPersianFont = "Tahoma"
}

$script:CurrentLanguage = $startupLanguage
$script:CurrentPersianFont = $startupPersianFont

$script:HealthAlertsEnabled = [bool]$startupSettings.HealthAlertsEnabled
$script:HealthAlertWarning = [bool]$startupSettings.HealthAlertWarning
$script:HealthAlertCritical = [bool]$startupSettings.HealthAlertCritical
$script:HealthAlertRecovery = [bool]$startupSettings.HealthAlertRecovery

$chkHealthAlertsEnabled.Checked = $script:HealthAlertsEnabled
$chkHealthAlertWarning.Checked = $script:HealthAlertWarning
$chkHealthAlertCritical.Checked = $script:HealthAlertCritical
$chkHealthAlertRecovery.Checked = $script:HealthAlertRecovery
Update-HealthAlertSettingsUi

$cmbThemeMode.SelectedItem = $startupTheme
$cmbLanguage.SelectedItem = $(if ($startupLanguage -eq "Persian") { "فارسی" } else { "English" })
$cmbPersianFont.SelectedItem = $startupPersianFont

# Stable startup policy:
# always show the main window first in English/LTR. A saved Persian choice is
# still shown in Settings, but it is not auto-applied until the user clicks
# Apply or Save Settings. This prevents a broken RTL preference from creating
# a startup crash loop.
$script:CurrentLanguage = "English"

Apply-AghrabTheme -Theme $startupTheme
Set-AghrabMainWorkspaceDirection -Language "English"
Update-AghrabMainFormCaptions -Language "English"

$tabs.SelectedTab = $tabHealth
Refresh-HealthCenter
Update-SchedulerStateUi
$script:SchedulerTimer.Start()
Update-SidebarNavigation
try { Update-AghrabLicenseUi | Out-Null } catch {}

$script:EntitlementTimer = New-Object System.Windows.Forms.Timer
$script:EntitlementTimer.Interval = 60000
$script:EntitlementTimer.Add_Tick({
    try { Update-AghrabLicenseUi | Out-Null } catch {}
})
$script:EntitlementTimer.Start()


$form.Add_FormClosing({
    try { $script:SchedulerTimer.Stop() } catch {}
    try {
        if ($null -ne $script:EntitlementTimer) {
            $script:EntitlementTimer.Stop()
            $script:EntitlementTimer.Dispose()
            $script:EntitlementTimer = $null
        }
    } catch {}
    try { Save-SchedulerFromUi } catch {}
    try {
        Save-AghrabSettings `
            -Theme $script:CurrentTheme `
            -Language $script:CurrentLanguage `
            -PersianFont $script:CurrentPersianFont
    } catch {}
    try { Write-SecurityAudit -Action "APP_STOP" -Detail "RAQEB Sentinel Pro closing." } catch {}
    try { Stop-BuiltInAi } catch {}
    try {
        if ($null -ne $script:HealthNotifyIcon) {
            $script:HealthNotifyIcon.Visible = $false
            $script:HealthNotifyIcon.Dispose()
            $script:HealthNotifyIcon = $null
        }
    }
    catch {}
})

[void]$form.ShowDialog()

@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist "%~dp0payload\Start-AGHRAB.ps1" (
 echo ERROR: payload\Start-AGHRAB.ps1 was not found.
 echo Please extract the full ZIP before running RAQEB.
 pause
 exit /b 1
)
rem Portable ZIP mode only. Installed RAQEB uses RAQEB.exe + RemoteSigned.
start "" powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0payload\Start-AGHRAB.ps1"

﻿param()

$ErrorActionPreference = "Stop"

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$PrepareScript = Join-Path $Root "Prepare-AI-Pack.ps1"

Write-Host ""
Write-Host "===============================================" -ForegroundColor Cyan
Write-Host " aghrab Full Offline AI Package Builder" -ForegroundColor Cyan
Write-Host "===============================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "This process will:" -ForegroundColor White
Write-Host "  1. Download llama.cpp Windows CPU runtime"
Write-Host "  2. Download Qwen2.5-VL-3B Q4_K_M model"
Write-Host "  3. Download the vision mmproj file"
Write-Host "  4. Verify the required files"
Write-Host "  5. Create one FULL offline ZIP"
Write-Host ""
Write-Host "Expected download size: roughly 3 GB+" -ForegroundColor Yellow
Write-Host "The final ZIP can also be several GB." -ForegroundColor Yellow
Write-Host ""

if (-not (Test-Path -LiteralPath $PrepareScript -PathType Leaf)) {
    throw "Prepare-AI-Pack.ps1 was not found."
}

# Step 1: prepare/download AI pack
Write-Host "[1/3] Preparing AI Pack..." -ForegroundColor Cyan
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $PrepareScript -NoPause

if ($LASTEXITCODE -ne 0) {
    throw "Prepare-AI-Pack failed with exit code $LASTEXITCODE."
}

# Step 2: verify
Write-Host ""
Write-Host "[2/3] Verifying required files..." -ForegroundColor Cyan

$Required = @(
    (Join-Path $Root "payload\AI\runtime\llama-server.exe"),
    (Join-Path $Root "payload\AI\models\Qwen2.5-VL-3B-Instruct-Q4_K_M.gguf"),
    (Join-Path $Root "payload\AI\models\mmproj-Qwen2.5-VL-3B-Instruct-Q8_0.gguf"),
    (Join-Path $Root "Run-Portable.bat"),
    (Join-Path $Root "payload\ScreenshotTool.ps1")
)

$Missing = @()

foreach ($item in $Required) {
    if (-not (Test-Path -LiteralPath $item -PathType Leaf)) {
        $Missing += $item
    }
}

if ($Missing.Count -gt 0) {
    Write-Host ""
    Write-Host "Missing required files:" -ForegroundColor Red
    $Missing | ForEach-Object { Write-Host "  $_" -ForegroundColor Red }
    throw "Full package cannot be created because required files are missing."
}

Write-Host "Required files are present." -ForegroundColor Green

# Step 3: create ZIP outside the source folder
Write-Host ""
Write-Host "[3/3] Creating FULL offline ZIP..." -ForegroundColor Cyan

$Parent = Split-Path -Parent $Root
$FolderName = Split-Path -Leaf $Root
$ZipPath = Join-Path $Parent "raqeb-v7.6.3.6-FULL-OFFLINE-AI.zip"

if (Test-Path -LiteralPath $ZipPath) {
    Remove-Item -LiteralPath $ZipPath -Force
}

# Prefer Windows bsdtar. It handles large archives / Zip64 well.
$Tar = Get-Command tar.exe -ErrorAction SilentlyContinue

if ($Tar) {
    Push-Location $Parent
    try {
        & $Tar.Source -a -c -f $ZipPath $FolderName
        if ($LASTEXITCODE -ne 0) {
            throw "tar.exe failed with exit code $LASTEXITCODE."
        }
    }
    finally {
        Pop-Location
    }
}
else {
    # Fallback for older Windows.
    Add-Type -AssemblyName System.IO.Compression.FileSystem

    [System.IO.Compression.ZipFile]::CreateFromDirectory(
        $Root,
        $ZipPath,
        [System.IO.Compression.CompressionLevel]::Optimal,
        $true
    )
}

if (-not (Test-Path -LiteralPath $ZipPath -PathType Leaf)) {
    throw "ZIP creation finished without producing the expected file."
}

$SizeGB = [Math]::Round(
    (Get-Item -LiteralPath $ZipPath).Length / 1GB,
    2
)

Write-Host ""
Write-Host "===============================================" -ForegroundColor Green
Write-Host " FULL OFFLINE PACKAGE READY" -ForegroundColor Green
Write-Host "===============================================" -ForegroundColor Green
Write-Host ""
Write-Host "File:" -ForegroundColor White
Write-Host "  $ZipPath" -ForegroundColor Cyan
Write-Host "Size: $SizeGB GB"
Write-Host ""
Write-Host "Now copy this ZIP to the offline Windows PC." -ForegroundColor White
Write-Host "Extract it, then run:" -ForegroundColor White
Write-Host "  Run-Portable.bat" -ForegroundColor Yellow
Write-Host ""
Read-Host "Press Enter to close"

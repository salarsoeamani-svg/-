﻿param([switch]$NoPause)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$AiRoot = Join-Path $Root "payload\AI"
$RuntimeDir = Join-Path $AiRoot "runtime"
$ModelsDir = Join-Path $AiRoot "models"
$TempDir = Join-Path $AiRoot "_download"

$LlamaArchiveSha256 = "917f39c076402c421224824607397af20f53625a60defc20e8dd22446bf4c5d7"
$ModelSha256 = "d02fe9b69ad8cadbbd228e387667af66612c44bed29ffc8eb1e7caf9ac486c12"
$MmprojSha256 = "980c9b2f78c04e6cff93d277ada09e768394f112d75db3b4e9dea8a69f9fb904"

New-Item -ItemType Directory -Force -Path $RuntimeDir | Out-Null
New-Item -ItemType Directory -Force -Path $ModelsDir | Out-Null
New-Item -ItemType Directory -Force -Path $TempDir | Out-Null

function Get-Sha256Lower {
    param([string]$Path)
    return ((Get-FileHash -LiteralPath $Path -Algorithm SHA256 -ErrorAction Stop).Hash).ToLowerInvariant()
}

function Test-ExpectedSha256 {
    param([string]$Path,[string]$ExpectedSha256)
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $false }
    return ((Get-Sha256Lower -Path $Path) -eq $ExpectedSha256.ToLowerInvariant())
}

function Download-LargeFile {
    param([string]$Url,[string]$Destination,[long]$ExpectedMinBytes,[string]$ExpectedSha256)
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $Destination) | Out-Null

    if (Test-Path -LiteralPath $Destination -PathType Leaf) {
        $size = (Get-Item -LiteralPath $Destination).Length
        if ($size -ge $ExpectedMinBytes) {
            Write-Host "Existing file found. Verifying SHA256..." -ForegroundColor Cyan
            if (Test-ExpectedSha256 -Path $Destination -ExpectedSha256 $ExpectedSha256) {
                Write-Host "Existing file SHA256 VERIFIED." -ForegroundColor Green
                return
            }
            Write-Host "Existing file SHA256 mismatch. Deleting it." -ForegroundColor Red
            Remove-Item -LiteralPath $Destination -Force -ErrorAction Stop
        } else {
            Write-Host "Partial file found - trying resume..." -ForegroundColor Yellow
        }
    }

    Write-Host "Downloading: $Url" -ForegroundColor Cyan
    Write-Host "Expected SHA256: $ExpectedSha256"
    $curl = Get-Command curl.exe -ErrorAction SilentlyContinue
    if ($curl) {
        & $curl.Source @("-L","--fail","--retry","20","--retry-delay","5","--connect-timeout","30","--speed-time","180","--speed-limit","1024","-C","-","-o",$Destination,$Url)
        if ($LASTEXITCODE -ne 0) {
            Write-Host "Resume failed. Retrying from zero..." -ForegroundColor Yellow
            Remove-Item -LiteralPath $Destination -Force -ErrorAction SilentlyContinue
            & $curl.Source @("-L","--fail","--retry","20","--retry-delay","5","--connect-timeout","30","--speed-time","180","--speed-limit","1024","-o",$Destination,$Url)
            if ($LASTEXITCODE -ne 0) { throw "curl.exe failed after retries. Exit code: $LASTEXITCODE" }
        }
    } else {
        Write-Host "curl.exe not found. Falling back to BITS..." -ForegroundColor Yellow
        Import-Module BitsTransfer -ErrorAction Stop
        if (Test-Path -LiteralPath $Destination -PathType Leaf) { Remove-Item -LiteralPath $Destination -Force -ErrorAction SilentlyContinue }
        Start-BitsTransfer -Source $Url -Destination $Destination -ErrorAction Stop
    }

    if (-not (Test-Path -LiteralPath $Destination -PathType Leaf)) { throw "Download completed without creating the destination file." }
    if ((Get-Item -LiteralPath $Destination).Length -lt $ExpectedMinBytes) {
        Remove-Item -LiteralPath $Destination -Force -ErrorAction SilentlyContinue
        throw "Downloaded file is incomplete."
    }

    Write-Host "Verifying SHA256..." -ForegroundColor Cyan
    $actual = Get-Sha256Lower -Path $Destination
    if ($actual -ne $ExpectedSha256.ToLowerInvariant()) {
        Remove-Item -LiteralPath $Destination -Force -ErrorAction SilentlyContinue
        throw ("SECURITY CHECK FAILED: SHA256 mismatch.`r`nExpected: $ExpectedSha256`r`nActual:   $actual`r`nDownloaded file was deleted.")
    }
    Write-Host "SHA256 VERIFIED." -ForegroundColor Green
}

function Write-RuntimeManifest {
    param([string]$RuntimeDirectory,[string]$SourceArchive,[string]$SourceArchiveSha256)
    $files = New-Object System.Collections.Generic.List[object]
    Get-ChildItem -LiteralPath $RuntimeDirectory -File -ErrorAction Stop |
        Where-Object { $_.Name -notlike "PUT_*" -and $_.Name -ne "runtime-sha256.json" } |
        Sort-Object Name | ForEach-Object {
            $files.Add([PSCustomObject][ordered]@{ name=$_.Name; size=[long]$_.Length; sha256=(Get-Sha256Lower -Path $_.FullName) })
        }
    if ($files.Count -lt 1) { throw "No runtime files were found for the integrity manifest." }
    [PSCustomObject][ordered]@{
        format="RAQEB-AI-RUNTIME-MANIFEST"
        version=1
        source_archive=$SourceArchive
        source_archive_sha256=$SourceArchiveSha256.ToLowerInvariant()
        generated_utc=[DateTime]::UtcNow.ToString("o")
        files=$files.ToArray()
    } | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $RuntimeDirectory "runtime-sha256.json") -Encoding UTF8 -Force
    Write-Host "Runtime SHA256 manifest created." -ForegroundColor Green
}

Write-Host ""
Write-Host "RAQEB AI Pack - verified preparation" -ForegroundColor Cyan
Write-Host "Every downloaded artifact must pass its pinned SHA256." -ForegroundColor Yellow
Write-Host ""

Write-Host "[1/3] llama.cpp b10964 Windows x64 CPU..." -ForegroundColor Cyan
$assetName = "llama-b10964-bin-win-cpu-x64.zip"
$assetUrl = "https://github.com/ggml-org/llama.cpp/releases/download/b10964/llama-b10964-bin-win-cpu-x64.zip"
$runtimeZip = Join-Path $TempDir $assetName
Download-LargeFile -Url $assetUrl -Destination $runtimeZip -ExpectedMinBytes 5MB -ExpectedSha256 $LlamaArchiveSha256

$extractDir = Join-Path $TempDir "llama-runtime"
if (Test-Path -LiteralPath $extractDir) { Remove-Item -LiteralPath $extractDir -Recurse -Force }
Expand-Archive -LiteralPath $runtimeZip -DestinationPath $extractDir -Force
Get-ChildItem -LiteralPath $RuntimeDir -Force -ErrorAction SilentlyContinue | Where-Object { $_.Name -notlike "PUT_*" } | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
Get-ChildItem -LiteralPath $extractDir -File -Recurse | ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $RuntimeDir $_.Name) -Force }
if (-not (Test-Path -LiteralPath (Join-Path $RuntimeDir "llama-server.exe") -PathType Leaf)) { throw "llama-server.exe was not found after extracting the verified archive." }
Write-RuntimeManifest -RuntimeDirectory $RuntimeDir -SourceArchive $assetName -SourceArchiveSha256 $LlamaArchiveSha256

Write-Host "[2/3] Qwen2.5-VL-3B Q4_K_M..." -ForegroundColor Cyan
$modelUrl = "https://huggingface.co/ggml-org/Qwen2.5-VL-3B-Instruct-GGUF/resolve/main/Qwen2.5-VL-3B-Instruct-Q4_K_M.gguf?download=true"
$modelPath = Join-Path $ModelsDir "Qwen2.5-VL-3B-Instruct-Q4_K_M.gguf"
Download-LargeFile -Url $modelUrl -Destination $modelPath -ExpectedMinBytes 1500MB -ExpectedSha256 $ModelSha256

Write-Host "[3/3] Qwen2.5-VL multimodal projector..." -ForegroundColor Cyan
$mmprojUrl = "https://huggingface.co/ggml-org/Qwen2.5-VL-3B-Instruct-GGUF/resolve/main/mmproj-Qwen2.5-VL-3B-Instruct-Q8_0.gguf?download=true"
$mmprojPath = Join-Path $ModelsDir "mmproj-Qwen2.5-VL-3B-Instruct-Q8_0.gguf"
Download-LargeFile -Url $mmprojUrl -Destination $mmprojPath -ExpectedMinBytes 700MB -ExpectedSha256 $MmprojSha256

Write-Host ""
Write-Host "AI Pack is READY and SHA256 verified." -ForegroundColor Green
Write-Host "Runtime manifest: payload\AI\runtime\runtime-sha256.json"
Write-Host ""
if (-not $NoPause) { Read-Host "Press Enter to close" }

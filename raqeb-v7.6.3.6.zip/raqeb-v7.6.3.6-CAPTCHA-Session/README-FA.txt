﻿aghrab v5.9
===========

این نسخه یک Rebrand کامل از برنامه است و نام قابل مشاهده برنامه فقط aghrab است.

قابلیت اصلی جدید: ELK Profiles
-------------------------------
نمونه Profile پیش‌فرض:
Profile: ELK Production
Kibana URL: https://10.10.10.20:5601

روش استفاده:
1. وارد تب ELK Profiles شو.
2. Profile Name و Kibana URL را تنظیم کن.
3. Dashboardها را اضافه کن. URL می‌تواند کامل یا Relative باشد.

مثال:
SOC Overview
/app/dashboards#/view/<dashboard-id>

Firewall
/app/dashboards#/view/<dashboard-id>

Suricata
/app/dashboards#/view/<dashboard-id>

4. Save Profile را بزن.
5. Open Login Browser را بزن.
6. یک بار داخل Kibana Login کن و بعد مرورگر را کامل ببند.
7. Capture All Dashboards را بزن.

Session:
- رمز Kibana داخل aghrab ذخیره نمی‌شود.
- Session/Cookie مرورگر داخل Profile اختصاصی همان ELK Profile در AppData نگهداری می‌شود.
- بنابراین لازم نیست برای هر Dashboard دوباره Login انجام شود.

خروجی:
هر Dashboard Album جدا دارد، مثلاً:
ELK Production - SOC Overview
ELK Production - Firewall
ELK Production - Suricata

هر Album همچنان Retention مستقل، Gallery، Delete Image/Album و Analyze را دارد.

تنظیمات پیشنهادی ELK:
Load wait: 12 sec
Scroll delay: 1200 ms
Final settle: 5 sec
Timeout: 60 sec

فایل نصبی:
Build-Setup.bat

خروجی:
aghrab-Setup.exe


قابلیت جدید v5.1 - Time Range per Dashboard
---------------------------------------------
هر Dashboard داخل ELK Profile اکنون Time Range مستقل دارد.

Presetها:
- Dashboard default
- Last 15 minutes
- Last 30 minutes
- Last 1 hour
- Last 4 hours
- Last 12 hours
- Last 24 hours
- Last 7 days
- Last 30 days

نمونه:
SOC Overview | Last 1 hour
SOC Overview | Last 24 hours
SOC Overview | Last 7 days

می‌توان همان Dashboard URL را چند بار با Time Rangeهای مختلف اضافه کرد.

خروجی خودکار:
ELK Production - SOC Overview - 1H
ELK Production - SOC Overview - 24H
ELK Production - SOC Overview - 7D

نحوه اعمال Time Range:
- aghrab مقدار Time Picker را از طریق Kibana global state (_g) روی URL اعمال می‌کند.
- اگر URL قبلاً _g داشته باشد، برنامه تا حد ممکن فقط بخش time را جایگزین می‌کند
  تا global filterها و refresh settingهای موجود حفظ شوند.
- Dashboardهای قدیمی ساخته‌شده با v5.0 نیز سازگار هستند؛
  اگر TimeRange نداشته باشند با Dashboard default باز می‌شوند.

نکته:
بعد از ساخت/ویرایش Dashboardها حتماً Save Profile را بزنید.


رفع مهم v5.2 - Keycloak / SSO Live Session
-------------------------------------------
مشکل:
در بعضی Kibanaها مخصوصاً وقتی Keycloak/SSO استفاده می‌شود،
بعد از بستن Login Browser، Session در Browser Headless جدید قابل استفاده نیست
و Screenshot صفحه Welcome to Elastic/Login گرفته می‌شود.

روش جدید:
1. ELK Profile را انتخاب کنید.
2. Open Login Browser را بزنید.
3. داخل Kibana/Keycloak Login کنید.
4. Browser را نبندید.
5. به aghrab برگردید.
6. Capture All Dashboards را بزنید.
7. aghrab تمام Dashboardها را با همان Browser Session لاگین‌شده Capture می‌کند.

ویژگی‌ها:
- Session زنده همان Browser با Chrome DevTools Protocol استفاده می‌شود.
- Browser برای هر Dashboard بسته و دوباره باز نمی‌شود.
- Time Range مستقل هر Dashboard همچنان اعمال می‌شود.
- اگر صفحه Login/Welcome to Elastic تشخیص داده شود، Capture خطا می‌دهد
  و Screenshot اشتباه را به عنوان Dashboard موفق ثبت نمی‌کند.
- وضعیت Session در ELK Profiles نمایش داده می‌شود:
  Session: connected
  Session: not connected

نکته بسیار مهم:
تا پایان Capture All Dashboards، پنجره Login Browser را نبندید.


رفع مهم v5.2.1 - Kibana Dashboard Screenshot Width
---------------------------------------------------
مشکل:
در بعضی Dashboardهای Kibana، Page.getLayoutMetrics عرضی بسیار بزرگ‌تر
از Viewport واقعی گزارش می‌کند. نتیجه Screenshot شامل فضای سیاه/خالی
زیاد در سمت راست می‌شد.

رفع:
- عرض Screenshotهای ELK روی 1920px ثابت نگه داشته می‌شود.
- فقط ارتفاع Dashboard برای Full Page افزایش پیدا می‌کند.
- Auto Scroll همچنان برای Load شدن Panelهای پایین اجرا می‌شود.
- ارتفاع حداقل 1080px است.
- برای جلوگیری از Layout خراب، حداکثر ارتفاع Capture برابر 50000px است.

نتیجه مورد انتظار:
Dashboard تمام عرض تصویر را پر می‌کند و فضای سیاه بزرگ سمت راست حذف می‌شود.


قابلیت جدید v5.3 - Auto Login before Capture
----------------------------------------------
در ELK Profiles یک بخش Authentication اضافه شده است:

- Auto Login before Capture
- Username
- Password
- Test Auto Login

نحوه کار:
1. Profile را باز کنید.
2. گزینه Auto Login before Capture را فعال کنید.
3. Username و Password را وارد کنید.
4. Save Profile را بزنید.
5. برای تست، Test Auto Login را بزنید.
6. سپس Capture All Dashboards را بزنید.

نکات:
- رمز عبور به صورت Plain Text داخل فایل تنظیمات ذخیره نمی‌شود.
- رمز با Windows DPAPI برای همان کاربر ویندوز رمزگذاری می‌شود.
- اگر Auto Login غیرفعال باشد، روش دستی قبلی همچنان کار می‌کند.
- Auto Login برای صفحه Welcome to Elastic / Keycloak / فرم‌های لاگین معمول
  به صورت خودکار تلاش به کلیک روی دکمه ورود و ارسال فرم می‌کند.

اگر MFA / OTP / CAPTCHA فعال باشد:
- ورود کامل ممکن است همچنان به تعامل دستی نیاز داشته باشد.


رفع v5.3.1 - Browser DevTools / Auto Login
-------------------------------------------
خطای رفع‌شده:
Could not connect to browser DevTools

تغییرات:
- برای Auto Login از Browser Profile موقت و کاملاً جدید استفاده می‌شود.
- مشکل Lock شدن Profile یا اتصال Browser به Process قدیمی برطرف می‌شود.
- Chrome/Edge با --remote-debugging-port=0 اجرا می‌شود.
- Browser خودش یک Port آزاد انتخاب می‌کند.
- aghrab Port واقعی را از DevToolsActivePort می‌خواند.
- Profile موقت Auto Login بعد از پایان Session پاک می‌شود.
- Manual Login همچنان از Profile پایدار قبلی استفاده می‌کند.

این خطا ارتباطی با CAPTCHA ندارد و قبل از مرحله Username/Password رخ می‌داد.


رفع v5.3.2 - Auto Login UI / Empty Credentials
------------------------------------------------
- بخش Authentication از پایین ستون چپ به بالای صفحه ELK Profiles منتقل شد.
- Auto Login، Username، Password و Test Auto Login همیشه جلوی چشم هستند.
- اگر Username خالی باشد Browser باز نمی‌شود و Cursor روی Username می‌رود.
- اگر Password خالی باشد Browser باز نمی‌شود و Cursor روی Password می‌رود.
- Save Profile هنگام فعال بودن Auto Login دیگر Credential خالی را بی‌صدا ذخیره نمی‌کند.
- خطای نسخه قبل:
  Auto Login is enabled but Username/Password is empty
  اکنون قبل از اجرای Browser مدیریت می‌شود.


رفع v5.3.3 - Auto Login Credential Runtime Fix
------------------------------------------------
مشکل:
Username و Password داخل UI پر بودند، ولی Test Auto Login خطای Empty می‌داد.

علت:
Test/Capture پس از Save Profile دوباره Credential رمزگذاری‌شده Profile را
می‌خواند و در بعضی اجراها Password خالی برمی‌گشت.

رفع:
- Test Auto Login مستقیماً از Username/Password فعلی داخل UI استفاده می‌کند.
- Capture All Dashboards نیز مستقیماً از Credential فعلی UI استفاده می‌کند.
- نسخه DPAPI فقط برای ذخیره امن و استفاده در Sessionهای بعدی نگهداری می‌شود.
- Password واردشده هنگام Save/Refresh در UI حفظ می‌شود.


رفع v5.3.4 - Keycloak / SSO Redirect Safe Auto Login
------------------------------------------------------
مشکل رفع‌شده:
CDP error: Inspected target navigated or closed

این خطا زمانی دیده می‌شد که Login واقعاً موفق بود، اما Keycloak/Elastic
هنگام Redirect صفحه قبلی DevTools را از بین می‌برد.

تغییر:
- Auto Login دیگر یک JavaScript طولانی را در طول Redirect اجرا نمی‌کند.
- هر مرحله Login یک Action کوتاه است:
  1) تشخیص صفحه
  2) کلیک روی Log in with Elasticsearch
  3) اتصال مجدد به صفحه جدید
  4) پر کردن Username/Password
  5) Submit
  6) اتصال مجدد بعد از Redirect
  7) تشخیص Kibana authenticated
- خطای "Inspected target navigated or closed" اکنون Redirect طبیعی محسوب می‌شود.
- WebSocket بعد از هر Redirect مجدداً ساخته می‌شود.
- وقتی Kibana مثل /app/home یا /app/dashboards باز شود Login موفق ثبت می‌شود.


رفع v5.3.5 - Wrong Password Protection + Success Notification
---------------------------------------------------------------
1) جلوگیری از تکرار Login با Password اشتباه:
- Username/Password در هر Auto Login فقط یک بار Submit می‌شود.
- اگر Keycloak پیام Invalid credentials بدهد، Auto Login فوراً متوقف می‌شود.
- اگر بعد از Submit فرم Login همچنان باقی بماند، برنامه آن را Login ناموفق می‌داند.
- Browser Session در خطای Credential بسته می‌شود تا Account Lockout رخ ندهد.
- پیام واضح:
  Username or Password is incorrect.
  Login was attempted only once to protect the account from lockout.

2) پیام موفقیت:
- بعد از Test Auto Login موفق، پنجره aghrab به جلو می‌آید.
- پیام واضح AUTO LOGIN SUCCESS نمایش داده می‌شود.
- Session Status نیز به AUTO LOGIN SUCCESS تغییر می‌کند.

3) پایان Capture:
- بعد از Capture All Dashboards یک Summary نمایش داده می‌شود:
  Successful dashboards
  Failed dashboards


قابلیت جدید v5.4 - CAPTCHA Detect / Pause / Continue
-----------------------------------------------------
- CAPTCHA به صورت خودکار حل نمی‌شود.
- aghrab CAPTCHA را تشخیص می‌دهد و Login را Pause می‌کند.
- Username/Password را در فرم قرار می‌دهد ولی Submit نمی‌کند.
- دکمه Continue CAPTCHA فعال می‌شود.
- کاربر CAPTCHA را داخل Browser تکمیل می‌کند و Browser را باز نگه می‌دارد.
- سپس Continue CAPTCHA را می‌زند.
- aghrab همان Session را ادامه می‌دهد و فرم را فقط یک بار Submit می‌کند.
- اگر Capture All منتظر بوده باشد، بعد از Login موفق Capture خودکار ادامه پیدا می‌کند.


قابلیت جدید v5.5 - Built-in Local AI Preview
---------------------------------------------
مدل هدف برای سیستم 16GB RAM:
Qwen2.5-VL-3B-Instruct Q4_K_M + llama.cpp Windows x64 CPU

در تب Analyze:
- Start AI
- Stop AI
- Test AI
- AI Analyze Latest
- AI Compare Last 2
- Open AI Folder

AI Analyze Latest:
آخرین Screenshot آلبوم را به مدل Vision می‌دهد و وضعیت Dashboard،
پنل‌های خالی، خطاهای قابل مشاهده و نکات امنیتی را تحلیل می‌کند.

AI Compare Last 2:
دو Screenshot آخر را همراه نتیجه Pixel Compare به AI می‌دهد تا تغییرات
قابل مشاهده را توضیح دهد.

برای ساخت Offline AI Pack:
1. روی یک Windows دارای اینترنت فایل Prepare-AI-Pack.bat را اجرا کنید.
2. دانلود حدود 3GB+ انجام می‌شود.
3. کل پوشه aghrab را به سیستم Offline منتقل کنید.
4. Run-Portable.bat
5. Analyze -> Start AI -> Test AI

فایل‌های مورد انتظار:
payload\AI\runtime\llama-server.exe
payload\AI\models\Qwen2.5-VL-3B-Instruct-Q4_K_M.gguf
payload\AI\models\mmproj-Qwen2.5-VL-3B-Instruct-Q8_0.gguf

Python لازم نیست.


ساخت یک ZIP کامل و آفلاین
-------------------------
اگر می‌خواهید فقط یک بار روی سیستم اینترنت‌دار دانلود انجام شود و بعد یک ZIP کامل
برای همه سیستم‌های آفلاین داشته باشید، فقط این فایل را اجرا کنید:

Build-Full-Offline-Package.bat

این فایل به صورت خودکار:
1. llama.cpp را دانلود می‌کند.
2. مدل Qwen2.5-VL-3B Q4_K_M را دانلود می‌کند.
3. فایل mmproj را دانلود می‌کند.
4. وجود فایل‌های لازم را چک می‌کند.
5. در انتها این فایل را می‌سازد:

aghrab-v5.5.1-FULL-OFFLINE-AI.zip

بعد فقط همین ZIP بزرگ را به سیستم آفلاین منتقل کنید.
روی سیستم آفلاین هیچ دانلود، Python یا اینترنت لازم نیست.

نکته:
دانلود اولیه و ZIP نهایی چند گیگابایت حجم دارند.


رفع v5.5.2 - دانلود llama.cpp
------------------------------
خطای:
Could not find the Windows x64 CPU llama.cpp ZIP in the latest release

رفع شد.

علت:
نام Release و فایل‌های llama.cpp در GitHub در نسخه‌های مختلف تغییر می‌کند
(bxxxxx و vX.Y.Z).

روش جدید:
- 20 Release اخیر GitHub بررسی می‌شوند.
- هر Asset معتبر Windows x64 CPU با الگوی bin-win-cpu-x64.zip قبول می‌شود.
- اگر GitHub API جواب ندهد، از نسخه پایدار v0.4.1 به عنوان fallback استفاده می‌شود.
- بعد از دانلود، اندازه ZIP و وجود llama-server.exe نیز بررسی می‌شود.

برای ساخت نسخه آفلاین فقط:
Build-Full-Offline-Package.bat


رفع v5.5.3 - AI CPU Model Load
-------------------------------
برای سیستم‌های 16GB RAM و بدون GPU:

- --device none
- --no-mmproj-offload
- -ngl 0
- Context از 4096 به 2048 کاهش یافت
- Parallel = 1
- Warmup اولیه غیرفعال شد

Diagnostic:
اگر llama-server باز هم هنگام Load بسته شود، aghrab اکنون Exit Code و
80 خط آخر stderr و stdout را داخل AI Analysis نمایش می‌دهد.


رفع v5.5.4 - دانلود فایل‌های چندگیگی Hugging Face
---------------------------------------------------
مشکل:
Invoke-WebRequest هنگام دانلود مدل 2GB با خطای timeout متوقف می‌شد.

روش جدید:
- دانلود با curl.exe ویندوز انجام می‌شود.
- Resume فعال است: -C -
- Retry تا 20 بار
- اگر اینترنت قطع شود، اجرای دوباره Builder از فایل Partial ادامه می‌دهد.
- اگر Resume خراب باشد، یک بار از صفر Retry می‌شود.
- فایل Runtime حداقل 5MB بررسی می‌شود.
- مدل Qwen حداقل 1500MB بررسی می‌شود.
- mmproj حداقل 700MB بررسی می‌شود.
- فایل ناقص دیگر به اشتباه Complete شناخته نمی‌شود.

فقط Build-Full-Offline-Package.bat را دوباره اجرا کنید.
llama.cpp که قبلاً کامل دانلود شده دوباره دانلود نمی‌شود.


رفع v5.5.5 - Stable llama.cpp Runtime
--------------------------------------
هش مدل و mmproj صحیح بود، پس فایل‌های مدل خراب نیستند.

مشکل محتمل Runtime بود:
نسخه‌های قبلی Builder جدیدترین bXXXXX را می‌گرفتند که Pre-release / nightly است.

در v5.5.5:
- llama.cpp روی Stable v0.4.1 Pin شده است.
- Runtime قبلی bXXXXX پاک و با Stable Windows x64 CPU جایگزین می‌شود.
- مدل Qwen و mmproj اگر قبلاً کامل دانلود شده باشند دوباره دانلود نمی‌شوند.
- Command اجرای llama-server ساده‌تر شده است.

فقط Build-Full-Offline-Package.bat را دوباره اجرا کنید.


رفع v5.5.6 - لینک Stable llama.cpp
-----------------------------------
خطای curl 404 مربوط به URL اشتباه Runtime بود.

نسخه 0.4.1 پایدار با build b10964 منتشر شده و فایل Windows x64 CPU صحیح:
llama-b10964-bin-win-cpu-x64.zip

URL صحیح:
https://github.com/ggml-org/llama.cpp/releases/download/b10964/llama-b10964-bin-win-cpu-x64.zip

همچنین retry-all-errors حذف شد تا خطاهای دائمی مثل HTTP 404 بیهوده 20 بار تکرار نشوند.
خطاهای موقت شبکه همچنان با curl --retry دوباره تلاش می‌شوند.

مدل Qwen و mmproj سالم/کامل اگر از قبل موجود باشند دوباره دانلود نمی‌شوند.


رفع v5.5.7 - Vision Server Startup
-----------------------------------
تست دستی تایید کرد:

llama-cli.exe + Qwen2.5-VL-3B + mmproj
به صورت صحیح بالا می‌آید و:
modalities : text, vision, video

بنابراین مدل، mmproj، CPU و Runtime سالم هستند.

در v5.5.7 فرمان llama-server به حداقل گزینه‌های تاییدشده کاهش یافت:

-m <model>
--mmproj <mmproj>
--no-mmproj-offload
-c 2048
-ngl 0
--host 127.0.0.1
--port <dynamic>

گزینه‌های اضافی threads / parallel / no-warmup / device حذف شدند.
زمان انتظار Start AI نیز از 90 به 180 ثانیه افزایش یافت.
فرمان کامل اجراشده اکنون داخل AI Analysis چاپ می‌شود.


رفع v5.5.8 - Process Launch / CMD Wrapper
-----------------------------------------
تست دستی تایید کرد که llama-server.exe با مدل و mmproj سالم است.

مشکل باقی‌مانده مربوط به نحوه Launch داخل Windows PowerShell بود.

در v5.5.8:
- aghrab فایل logs\start-llama-server.cmd را می‌سازد.
- همان Command موفق CMD را دقیقاً اجرا می‌کند.
- stdout/stderr همچنان داخل logs ذخیره می‌شوند.
- Stop AI کل Process Tree را می‌بندد.
- در صورت Crash مسیر Wrapper نیز نمایش داده می‌شود.

مدل و mmproj نیازی به دانلود دوباره ندارند.


رفع v5.5.9 - AI Vision HTTP 400
--------------------------------
مشکل:
AI Server Ready بود و Test AI متنی کار می‌کرد، اما AI Analyze Latest با HTTP 400 Bad Request خطا می‌داد.

تغییر:
- Screenshot دیگر به صورت Base64 بزرگ داخل JSON ارسال نمی‌شود.
- aghrab یک JPEG موقت و Resize شده می‌سازد.
- مسیر Local همان فایل در image_url.url به llama-server ارسال می‌شود.
- بعد از Analysis فایل موقت پاک می‌شود.
- در صورت HTTP 400/500، متن واقعی Response خود llama-server نیز نمایش داده می‌شود.

Runtime/Model/mmproj نیاز به دانلود دوباره ندارند.


رفع v5.5.10 - Local Media / HTTP 500
-------------------------------------
برای فایل تصویر Local در llama-server:
- سرور با --media-path اجرا می‌شود.
- image_url.url با file:// شروع می‌شود.
- فقط نام Relative فایل زیر media-path ارسال می‌شود.

همچنین Context از 2048 به 8192 افزایش یافت تا Screenshotهای بلند Kibana
فضای بیشتری برای Vision tokens داشته باشند.

در صورت خطای HTTP، 40 خط آخر stderr سرور هم نمایش داده می‌شود.

مدل، runtime و mmproj نیاز به دانلود مجدد ندارند.


قابلیت جدید v5.6 - Structured SOC AI Analysis
----------------------------------------------
AI Analyze Latest اکنون خروجی JSON ساختاریافته می‌گیرد و خود aghrab آن را
به گزارش SOC خوانا تبدیل می‌کند.

Summary bar:
- Overall: Normal / Warning / Critical
- Loaded: YES / NO / Unknown
- Empty: count / Unknown
- With Data: count / Unknown
- Errors: count / Unknown
- Confidence: High / Medium / Low

قواعد قطعی برنامه:
- Login page => Critical
- Dashboard visibly not loaded => Critical
- Visible errors => حداقل Warning
- هر Empty Panel => حداقل Warning
- اگر Empty Panels > 0 و Panels With Data = 0 باشد، نتیجه نمی‌تواند Normal باشد.

گزارش شامل:
DASHBOARD HEALTH
FINDINGS
SECURITY OBSERVATIONS
POSSIBLE CAUSES
RECOMMENDED ACTION
SUMMARY
AI CONFIDENCE

AI Compare Last 2 نیز خروجی ساختاریافته شامل Important Changes،
Dashboard Issues، Security-Relevant Changes و Recommended Action می‌دهد.

مدل و Runtime نیاز به دانلود مجدد ندارند.


رفع v5.6.1 - SOC Analysis Consistency
--------------------------------------
نمونه مشکل:
AI می‌گفت:
All panels show "No results found"
اما همزمان:
Empty Panels = 0

در v5.6.1:
- اگر AI مطمئن باشد No Results وجود دارد ولی نتواند تعداد دقیق پنل‌ها را بشمارد:
  Empty Panels = Unknown
  نه 0
- اگر همه پنل‌ها No Results باشند:
  Panels With Data = 0
  Overall حداقل Warning
- No Results از Security Observations حذف می‌شود.
- اگر داده‌ای برای نتیجه امنیتی دیده نشود:
  No security conclusion can be made because no event data is visibly available.
- Possible Causes و Recommended Action برای ELK عملیاتی‌تر شده‌اند:
  Discover، آخرین timestamp، Filter/Time Range، Data Stream/Index و Ingestion Pipeline
- Summary دیگر خرابی Ingestion را قطعی فرض نمی‌کند.


رفع v5.6.2 - Analyze Before/After Layout
-----------------------------------------
مشکل:
در مانیتورهای Wide یا هنگام Maximize شدن برنامه، پنل After / Latest
به دلیل Anchor سمت راست بیش از حد کش می‌آمد.

رفع:
- Before و After همیشه هم‌اندازه هستند.
- هیچ‌کدام به تنهایی Stretch نمی‌شوند.
- در پنجره‌های عریض، دو پنل کنار هم و وسط صفحه قرار می‌گیرند.
- عرض هر پنل با Resize شدن برنامه به صورت متعادل تنظیم می‌شود.
- PictureBoxهای Before/After نیز متقارن باقی می‌مانند.


قابلیت جدید v5.7 - Settings / Dark Mode
----------------------------------------
- تب Capture از رابط کاربری حذف شد.
- تب Settings اضافه شد.
- Appearance > Background mode:
  Light
  Dark
- Dark mode پس‌زمینه مشکی/تیره را روی کل aghrab اعمال می‌کند.
- تنظیم Theme در:
  %APPDATA%\aghrab\settings.json
  ذخیره می‌شود.
- Theme انتخاب‌شده در اجرای بعدی برنامه نیز حفظ می‌شود.
- Apply برای اعمال فوری Theme
- Save Settings برای ذخیره Theme

تب‌های اصلی حالا:
ELK Profiles
Gallery
Analyze
Settings


رفع v5.7.1 - Professional Dark Theme
-------------------------------------
Dark Mode بازطراحی کامل شد.

Palette:
- Background: #0A0E14
- Header: #0C121A
- Surface: #111821
- Secondary Surface: #16202B
- Input: #0D141C
- Border: #2A3948
- Text: #E6EDF3
- Muted: #8B9AAA
- Accent: #2EA8FF
- Success: #3FB950
- Warning: #D29922
- Danger: #F85149

بهبودها:
- Header تیره و هماهنگ با برند
- Tabهای Owner Draw با Selected Accent Line
- GroupBoxهای تیره و یکدست
- Inputها، ComboBox، ListView و TextBox تیره
- Primary Button آبی با Hover/Pressed
- Secondary Button سطح تیره با Border حرفه‌ای
- STOP/Delete با Danger Red
- AI Analysis به شکل Dark Report Surface
- Gallery/Analyze preview با پس‌زمینه نزدیک به مشکی
- رنگ Statusها روی تم تیره خواناتر شده
- Settings دارای Theme Preview


رفع v5.7.2 - Visual Cleanup
----------------------------
- متن Tabها با TextRenderer بازنویسی شد تا همیشه خوانا باشد.
- Tabها Border و Accent واضح‌تری دارند.
- عرض و ارتفاع Tabها برای متن‌های ELK Profiles / Gallery / Analyze / Settings بهتر شد.
- عنوان‌های بخش‌های مهم مثل Profiles و Dashboards Bold و واضح‌تر شدند.
- عنوان GroupBoxها در Dark Theme خواناتر شدند.
- رنگ Text / Border / Surface در ELK Profiles متعادل‌تر شد.
- Listها و پنل‌های داده در Dark Theme خواناتر شدند.


قابلیت جدید v5.8 - Elastic Sidebar UI
--------------------------------------
بازطراحی رابط کاربری:

1) Sidebar-style navigation
- Headerهای قدیمی TabControl مخفی شده‌اند.
- Navigation سمت چپ:
  ELK Profiles
  Gallery
  Analyze
  Settings
- بخش فعال با Elastic Teal مشخص می‌شود.

2) Card-based sections
ELK Profiles به Cardهای جدا تقسیم شده:
- Profiles
- Connection
- Authentication
- Capture Settings
- Dashboards

3) Rounded modern buttons
- Primary / Secondary / Danger Buttonها دارای گوشه گرد هستند.
- Hover / Press state دارند.

4) Elastic / Kibana-like Dark Theme
Dark palette:
- Background: #070A0E
- Sidebar: #0D131A
- Surface: #121921
- Surface 2: #17202A
- Input: #0C1218
- Border: #34414E
- Text: #EBEEF2
- Accent: #00BFB3

5) Dashboard table
- Native white Windows header حذف شد.
- Header و Rows به صورت Owner Draw کاملاً Dark هستند.
- Selection نیز Dark/Teal شده است.

6) Progress bar
- ProgressBar سفید ویندوز با AghrabProgressBar تیره جایگزین شد.

فرم برای Sidebar عریض‌تر شده تا محتوای اصلی اندازه قبلی خود را حفظ کند.


رفع v5.9 - AI Analysis Layout
--------------------------------
مشکل:
AI Analysis به دلیل Right Anchor تا انتهای صفحه کش می‌آمد.

رفع:
- AI Analysis داخل یک Card مستقل قرار گرفت.
- عرض Card دقیقاً با مجموع Before + After برابر است.
- Card در مرکز صفحه قرار می‌گیرد.
- فقط ارتفاع AI Analysis با بزرگ شدن پنجره افزایش می‌یابد.
- TextBox داخلی فقط داخل Card خودش Resize می‌شود.
- دیگر AI Analysis تا انتهای مانیتور کش نمی‌آید.


رفع v5.9 - Gallery List Polish
--------------------------------
در بخش Gallery:
- لیست Screenshot ها به صورت عمودی (زیر هم) نمایش داده می‌شود.
- کنار هر مورد یک Badge دایره‌ای Teal قرار گرفته است.
- هر Screenshot شماره ترتیبی هم دارد (#001, #002, ...).
- دیگر نام فایل‌ها کنار هم و شلوغ نمایش داده نمی‌شوند.
- Preview پایین بدون تغییر باقی مانده است.


قابلیت‌های v5.9 - Sentinel UI Polish
-------------------------------------
Branding:
- نام نمایشی برنامه: AGHRAB Sentinel
- زیرعنوان: Visual SOC Intelligence | Dashboard Monitoring
- نسخه در Header با LOCAL AI نمایش داده می‌شود.
- مسیرهای داخلی و Config برای سازگاری همچنان aghrab باقی مانده‌اند.

Gallery:
- Thumbnail کوچک کنار هر Screenshot
- Badge دایره‌ای Teal با شماره ردیف
- Hover effect روی هر ردیف
- Selected item با Accent bar و Highlight مشخص
- Screenshot ها عمودی و مرتب زیر هم هستند.

Analyze:
- AI Analysis دیگر با ارتفاع پنجره تا بی‌نهایت کش نمی‌آید.
- ارتفاع Report ثابت 220px است.
- عرض Report حداکثر 1000px و همیشه وسط صفحه است.
- متن طولانی با Scroll داخلی قابل مشاهده است.


رفع v5.10.2
-----------
v5.10 اولیه کنار گذاشته شد و No Data Inspector دوباره روی پایه پایدار v5.9
با پیاده‌سازی ساده‌تر ساخته شد.

No Data Inspector:
- AI نام Panelهای No Data را برمی‌گرداند.
- Count در سمت راست Analyze نمایش داده می‌شود.
- نام Panelها در ListBox ساده و پایدار نمایش داده می‌شوند.
- گزارش متنی نیز بخش NO DATA PANELS دارد.
- اگر عنوان قابل خواندن نباشد: Unreadable panel
- صفر واقعی Data محسوب می‌شود.
- Loading به عنوان No Data ثبت نمی‌شود.


رفع v5.10.2 - Gallery ImageList Crash
--------------------------------------
خطای:
System.ArgumentException: Parameter is not valid
at System.Drawing.Image.get_Width()
at System.Windows.Forms.ImageList.CreateHandle()

علت:
Thumbnail بعد از اضافه شدن به ImageList بلافاصله Dispose می‌شد.
WinForms ImageList گاهی Native Handle را با تاخیر ایجاد می‌کند و در آن زمان
Bitmap قبلاً Dispose شده بود.

رفع:
Thumbnail بعد از Images.Add دیگر Dispose نمی‌شود.
عمر Thumbnail به ImageList سپرده می‌شود و هنگام جایگزینی/Dispose خود ImageList
آزاد خواهد شد.


رفع v5.10.3 - Gallery Date/Name
--------------------------------
- نام/تاریخ Screenshot ها دوباره نمایش داده می‌شود.
- خطای OwnerDraw مربوط به ItemIndex اصلاح شد و از e.Item.Index استفاده می‌شود.
- عنوان هر ردیف: yyyy-MM-dd HH:mm:ss
- Tooltip: زمان با میلی‌ثانیه + نام فایل + حجم
- Fallback رسم پیش‌فرض اضافه شد تا متن هیچ ردیفی نامرئی نماند.


رفع v5.10.4 - Gallery Toolbar Alignment
----------------------------------------
- عنوان Screenshots کوتاه و تمیز شد.
- Open Image / Delete Image / Refresh / Open Root در یک Toolbar منظم قرار گرفتند.
- دکمه‌ها دیگر روی عنوان Screenshots نمی‌افتند.
- فاصله عمودی بین Toolbar و لیست Screenshotها اصلاح شد.
- یک Hint کوچک برای Preview اضافه شد.


رفع v5.10.5 - Gallery Header/Toolbar Layout
--------------------------------------------
مشکل:
در عرض‌های کمتر، Hint و دکمه‌ها روی هم می‌افتادند.

رفع:
- Screenshots در ردیف اول.
- Hint در ردیف دوم.
- Open Image / Delete Image / Refresh / Open Root در ردیف سوم.
- List در ردیف مستقل پایین Toolbar.
- Separator بین Toolbar و List.
- Preview نیز کمی جابه‌جا شد تا فاصله‌ها یکنواخت شوند.


رفع v5.10.6 - Gallery Preview Size
-----------------------------------
مشکل:
Preview به علت Anchor=Top,Bottom,Left,Right با بزرگ شدن پنجره تا پایین صفحه کش می‌آمد.

رفع:
- Anchor عمودی Preview حذف شد.
- ارتفاع Preview ثابت و کنترل‌شده: 230px
- عرض Preview Responsive است ولی حداکثر 820px
- PreviewInfo نیز دیگر به Bottom متصل نیست.
- Resize فقط عرض را تا سقف تعیین‌شده تنظیم می‌کند، نه ارتفاع را.


قابلیت‌های امنیتی v5.11
------------------------
Security Center جدید:
- Credential Storage: نمایش DPAPI CurrentUser
- AI Server: بررسی Local Only روی 127.0.0.1
- Browser Sessions: شمارش Sessionهای ذخیره‌شده
- AI Cache: تعداد و حجم فایل‌های موقت
- File Integrity: SHA256
- Security Audit Log: ثبت فعالیت‌های حساس

Audit Log:
- App Start/Stop
- Profile Save
- Browser Session Open
- AI Start/Stop
- Screenshot/Album Delete
- Session/Cache Clear
- Integrity Check

Integrity Check:
- ScreenshotTool.ps1 و llama-server.exe با Baseline نسخه جاری بررسی می‌شوند.
- Model و mmproj با SHA256 شناخته‌شده بررسی می‌شوند.
- هنگام ارتقا نسخه، Baseline جدید برای همان نسخه ساخته می‌شود.

Security Actions:
- Run Security Check
- Clear Saved Sessions
- Clear AI Cache
- Open Audit Log
- Refresh Status

Sensitive Log Redaction:
- Password
- Authorization Bearer
- Cookie / Set-Cookie
- Token / API Key
- token/api_key در Query String
قبل از ذخیره در CSV/Audit مخفی می‌شوند.


رفع v5.11.1 - Security Check
-----------------------------
خطای:
Argument types do not match

علت:
Windows PowerShell 5.1 در بعضی حالت‌ها هنگام تبدیل
System.Collections.Generic.List[object]
با ساختار @($list) خطای Argument types do not match می‌دهد.

رفع:
- Get-AghrabIntegrityTargets از ToArray() استفاده می‌کند.
- Results در Integrity Check با ToArray() برگردانده می‌شود.
- Summary مربوط به Security Check از Array معمولی PowerShell استفاده می‌کند.


========================================================
AGHRAB Sentinel Pro v6.0 - Pro Operations
========================================================

قابلیت جدید: Health Center
---------------------------
صفحه اصلی برنامه اکنون Health Center است.

برای هر Dashboard:
- Healthy / Warning / Critical / Unknown
- آخرین زمان بررسی
- تعداد No Data Panel
- تعداد Error
- AI Confidence
- نام Panelهای بدون دیتا
- آخرین Screenshot
- پیام خلاصه Health

خروجی Health:
<Output>\_AGHRAB_Health\HealthStatus.json
<Output>\_AGHRAB_Health\HealthHistory.csv

قابلیت جدید: Automatic Capture
-------------------------------
Automatic Capture را می‌توان ON/OFF کرد.

تنظیمات:
- انتخاب ELK Profile
- اجرای خودکار هر X دقیقه
- اجرای Local AI بعد از هر Capture
- Run Now برای تست فوری
- انتخاب Output Folder
- Last Run / Next Run / Scheduler State

نکته:
Automatic Capture فعلاً زمانی کار می‌کند که AGHRAB Sentinel Pro باز باشد.
برای اجرای Unattended باید Auto Login در ELK Profile فعال باشد.

هر اجرای Automatic Capture:
1. Auto Login
2. Capture تمام Dashboardهای Profile
3. در صورت فعال بودن AI، تحلیل Health
4. آپدیت Health Center
5. ذخیره Screenshot
6. ثبت HealthHistory.csv
7. ثبت AutomaticCapture.log

وضعیت‌ها:
Healthy  = Dashboard با AI سالم تشخیص داده شده
Warning  = No Data / مشکل قابل مشاهده
Critical = Login Page / Capture Failure / Fatal Error
Unknown  = Capture انجام شده اما AI Health Analysis اجرا نشده یا نتیجه قطعی نیست

UI:
- Health Center صفحه پیش‌فرض است.
- Sidebar جدید:
  Health Center
  ELK Profiles
  Automatic Capture
  Gallery
  Analyze
  Security
  Settings
- Metric Cardهای Health
- Dashboard Health Table
- Dashboard Details
- Scheduler Status Cards
- Professional Operations layout

مسیرهای داخلی برنامه همچنان aghrab باقی مانده‌اند تا Profileها و تنظیمات قبلی خراب نشوند.


========================================================
v6.0.1 - Keycloak Automatic Capture Fix
========================================================

رفع مشکل Automatic Capture در صفحه Welcome to Elastic:

مشکل:
اگر Kibana هم Keycloak/SSO و هم گزینه
"Log in with Elasticsearch"
را نمایش می‌داد، Auto Login گزینه Elasticsearch
را قبل از Keycloak بررسی می‌کرد.

نتیجه:
Automatic Capture در مرحله Login متوقف می‌شد و
Popup اشتباه Success: 0 / Failed: 0 نشان می‌داد.

رفع:
- Keycloak / SSO / SAML / OIDC قبل از Elasticsearch انتخاب می‌شود.
- Providerهایی که نامشان داخل child element کارت Kibana است نیز تشخیص داده می‌شوند.
- Elasticsearch Login فقط fallback است.
- خطای Login در Popup نهایی نمایش داده می‌شود.
- اگر Login قبل از Capture شکست بخورد، Dashboardهای Skip شده Failed محاسبه می‌شوند.
- Scheduler Log مرحله تشخیص Kibana/Keycloak را ثبت می‌کند.


v6.0.2 - Credential Preflight
- Automatic Capture checks saved Auto Login credentials before opening the browser.
- Scheduler page shows Saved Credentials: SAVED / PASSWORD NOT SAVED / PASSWORD UNAVAILABLE.
- If credentials are missing, it tells you to go to ELK Profiles, enter password, Save Profile, then Test Auto Login.


========================================================
v6.0.3 - DPAPI Compatibility Fix
========================================================
رفع Crash هنگام Auto Login / Automatic Capture:
Unable to find type System.Security.Cryptography.ProtectedData

- ذخیره رمز جدید با ConvertFrom-SecureString و DPAPI کاربر فعلی ویندوز.
- دیگر Type مستقیم ProtectedData در کد اجرا استفاده نمی‌شود.
- رمزهای نسخه‌های قدیمی با Reflection خوانده می‌شوند.
- خطای Credential دیگر UI را Crash نمی‌کند.
- اگر رمز قدیمی قابل خواندن نبود، PASSWORD UNAVAILABLE نمایش داده می‌شود.

در صورت PASSWORD UNAVAILABLE:
ELK Profiles -> Password را دوباره وارد کن
-> Save Profile -> Test Auto Login


========================================================
AGHRAB Sentinel Pro v6.1 - Field Intelligence
========================================================

Health Center اکنون سه لایه دارد:
1) Dashboard Health
2) Panel Health / No Data
3) Expected Field Health + Correlation

Expected Fields:
برای هر Dashboard در ELK Profiles می‌توان موارد زیر را وارد کرد:
- Index Pattern
- Expected Fields

نمونه:
Index:
logs-firewall-*

Expected Fields:
source.ip, destination.ip, event.action, host.name

Fast Elasticsearch Field Verification:
در ELK Profiles روی Field Verify کلیک کن و:
- Elasticsearch URL
- API Key
- Time field (default: @timestamp)
- Verification window (default: 15 minutes)
را تنظیم کن.

طراحی Performance:
- Verification بعد از پایان Render و Screenshot اجرا می‌شود.
- روی سرعت Render/Scroll/Capture Kibana اثر مستقیم ندارد.
- برای هر Dashboard فقط یک Elasticsearch request ارسال می‌شود.
- size=0 است و هیچ Documentی دانلود نمی‌شود.
- track_total_hits=false است.
- تمام Expected Fields با filter aggregation در همان یک request بررسی می‌شوند.
- Timeout برابر 3 ثانیه است.
- حداکثر 20 Expected Field در هر Dashboard بررسی می‌شود.
- AI فقط همان یک تحلیل تصویری قبلی را انجام می‌دهد؛ برای Correlation درخواست دوم AI نداریم.

Correlation:
DATA-SIDE SIGNAL:
AI پنل خالی دیده و یک/چند Expected Field نیز در بازه اخیر Document ندارد.

DASHBOARD-SIDE SIGNAL:
AI پنل خالی دیده ولی Expected Fieldها Document دارند.
موارد قابل بررسی: Visualization Filter / Data View / KQL / Time Range.

FIELD GAP:
پنل لزوماً خالی تشخیص داده نشده، ولی Expected Field در بازه اخیر داده ندارد.

FIELDS ACTIVE:
تمام Expected Fieldهای تنظیم‌شده Document اخیر دارند.

امنیت:
API Key با Windows Current-User DPAPI ذخیره می‌شود.
برای اصل Least Privilege بهتر است API Key فقط روی Index Patternهای مورد نیاز read privilege داشته باشد.

History schema note:
HealthHistory-v6.1.csv برای خروجی جدید Field Intelligence استفاده می‌شود تا فایل قدیمی HealthHistory.csv بدون تغییر باقی بماند.


========================================================
v6.1.1 - Auto Login Credential Persistence Fix
========================================================

رفع مشکل:
Automatic Capture -> PASSWORD NOT SAVED
حتی بعد از Save Profile و Test Auto Login

علت اصلی:
برخی عملیات برنامه Save-CurrentElkProfile -Silent را اجرا می‌کردند.
اگر Password TextBox در آن لحظه خالی بود، مقدار PasswordProtected
می‌توانست با مقدار خالی جایگزین شود.

رفع:
- Password خالی دیگر Credential قبلی را پاک نمی‌کند.
- Auto Login Password علاوه بر elk-profiles.json در یک Credential Store
  جداگانه برای هر Profile ذخیره می‌شود:
  %APPDATA%\aghrab\credentials\<profile>.cred
- Credential Store همچنان با Windows Current-User DPAPI محافظت می‌شود.
- Scheduler اول JSON، سپس Credential Store و در آخر مقدار Runtime Editor
  را بررسی می‌کند.
- Test Auto Login موفق، Credential را مجدداً Persist می‌کند.
- بعد از Save Profile وضعیت Saved Credentials در Automatic Capture فوراً Refresh می‌شود.

برای تست:
ELK Profiles -> Password -> Save Profile -> Test Auto Login
Automatic Capture -> Saved Credentials باید SAVED شود.


========================================================
v6.1.2 - Elastic Login Selector Fix
========================================================

رفع مشکل صفحه:
Welcome to Elastic
Keycloak
Log in with Elasticsearch

مشکل:
در این صفحه عبارت Keycloak عنوان گروه/Provider است و لزوماً دکمه نیست.
نسخه قبلی ممکن بود عنوان Keycloak یا Card والد آن را به اشتباه Click کند
و روی همان صفحه باقی بماند.

رفع:
- اگر دکمه/لینک "Log in with Elasticsearch" دیده شود، همان Action اولویت اول است.
- عبارت Keycloak فقط وقتی Click می‌شود که خودش یک Control واقعی و Clickable باشد.
- SSO/SAML/OIDC همچنان پشتیبانی می‌شوند.
- مرحله انتخاب Provider در ELK Log و Automatic Capture Activity ثبت می‌شود.

انتظار:
Welcome to Elastic
-> Log in with Elasticsearch
-> Keycloak Login Form
-> Username / Password
-> Kibana


========================================================
v6.1.3 - CDP Real Click Fix
========================================================

رفع مشکل:
Welcome to Elastic نمایش داده می‌شود ولی AGHRAB روی
"Log in with Elasticsearch" کلیک نمی‌کند.

علت:
کلیک قبلی با JavaScript element.click() انجام می‌شد.
در بعضی نسخه‌های Kibana/EUI این کلیک synthetic می‌تواند توسط
event handling صفحه نادیده گرفته شود.

رفع:
- AGHRAB موقع پیدا کردن Provider مرکز واقعی Control را می‌گیرد.
- کلیک از طریق Chrome DevTools Protocol و Input.dispatchMouseEvent
  با mousePressed/mouseReleased فرستاده می‌شود.
- این رفتار شبیه کلیک واقعی Browser است و به فوکوس Windows Mouse وابسته نیست.
- همین روش برای Elasticsearch / Keycloak / SSO Provider استفاده می‌شود.
- بعد از Provider click زمان Redirect کمی بیشتر شده است.
- Timeout حالا Last action را هم نشان می‌دهد.

Log مورد انتظار:
Auto Login -> cdp-click-elasticsearch-login-dispatched


========================================================
v6.1.4 - Login Button Real Click Fix
========================================================

بعد از عبور از Welcome to Elastic، اگر Username/Password پر شود
ولی دکمه Login / Sign in زده نشود:

- Submit Login دیگر با element.click() انجام نمی‌شود.
- AGHRAB مرکز واقعی دکمه Login را پیدا می‌کند.
- با Chrome DevTools Protocol:
  mouseMoved
  mousePressed
  mouseReleased
  روی دکمه واقعی ارسال می‌شود.
- بعد از کلیک، وضعیت Submitted ثبت می‌شود تا رمز دوباره Submit نشود.
- همین روش بعد از حل دستی CAPTCHA برای Continue/Login هم استفاده می‌شود.

Log مورد انتظار:
Auto Login -> cdp-click-login-submit-dispatched


========================================================
v6.1.5 - Keycloak Enter Submit Fix
========================================================

رفع مشکل:
Username و Password داخل Keycloak پر می‌شوند، اما AGHRAB روی دکمه
Log in عمل نمی‌کند.

تغییر:
- بعد از پر کردن Credential، AGHRAB Password field را Focus می‌کند.
- به جای وابستگی به مختصات دکمه Login، یک Enter واقعی با
  Chrome DevTools Protocol Input.dispatchKeyEvent ارسال می‌شود.
- این روش به DPI Scaling، Browser Zoom و Hit Testing دکمه وابسته نیست.
- Login فقط یک بار Submit می‌شود تا Account Lockout ایجاد نشود.
- Continue CAPTCHA نیز بعد از حل دستی CAPTCHA از همین Enter trusted استفاده می‌کند.

Log مورد انتظار:
Auto Login -> cdp-enter-login-submit-dispatched


========================================================
v6.1.6 - Auto Login State Sync Fix
========================================================

رفع مشکل:
Test Auto Login موفق است ولی Automatic Capture نمایش می‌دهد:
AUTO LOGIN OFF

رفع:
- بعد از AUTO LOGIN SUCCESS، خود Profile صراحتاً با
  AutoLoginEnabled=true ذخیره می‌شود.
- Username و Password همان Profile دوباره Persist می‌شوند.
- Profile تست‌شده به صورت خودکار در Automatic Capture انتخاب می‌شود.
- وضعیت Scheduler فوراً Refresh می‌شود.
- Auto Login checkbox نیز با Profile ذخیره‌شده Sync می‌شود.
- UI دیگر عنوان Saved Credentials را با AUTO LOGIN OFF قاطی نمی‌کند.

نمایش جدید:
Auto Login / Credentials:
ENABLED | SAVED

و زیر آن نام Profile انتخابی نمایش داده می‌شود.


========================================================
v6.1.7 - AI Required Result Semantics
========================================================

اصلاح منطق Success در Automatic Capture:

اگر گزینه:
Run Local AI after each capture = ON

باشد، Success فقط وقتی ثبت می‌شود که:
- Screenshot موفق باشد
- Local AI آماده باشد
- AI Health Analysis نیز موفق باشد

اگر Screenshot گرفته شود ولی AI نصب/آماده نباشد:
Partial

اگر Screenshot گرفته شود ولی AI Analysis خطا بدهد:
Partial

اگر Local AI عمداً OFF باشد:
Screenshot موفق = Success

Popup جدید:
Success: X
Partial: Y
Failed: Z

Health Center برای AI unavailable:
Status = Unknown
Confidence = AI unavailable
Correlation = AI NOT AVAILABLE


========================================================
AGHRAB Sentinel Pro v6.2 - Pro Health / Operations UI
========================================================

Health Center:
- Dashboard Health card strip اضافه شد.
- هر Dashboard یک Card مستقل دارد:
  Status
  No Data count
  Field Health
  Last Check
  Details
  Open Screenshot
- Cardها bounded هستند و UI را تا انتهای صفحه Stretch نمی‌دهند.
- جدول Health قبلی حذف نشده و برای بررسی دقیق‌تر باقی مانده.
- Details همچنان Panel Health / Expected Field Health / Correlation را نشان می‌دهد.

Automatic Capture:
یک Operations Summary حرفه‌ای اضافه شد:
- Last Run
- Next Run
- Success
- Partial
- Failed
- AI Status

AI Status:
READY
STOPPED
NOT INSTALLED
OFF

Last cycle counters در automatic-capture.json ذخیره می‌شوند و بعد از Restart
هم در UI باقی می‌مانند.

Automatic Capture header هنگام اجرا:
Automatic Capture is RUNNING

هدف UI:
نمایش سریع وضعیت کل عملیات بدون نیاز به خواندن Log یا باز کردن چند صفحه.


========================================================
AGHRAB Sentinel Pro v6.3 - Health Dashboard Manager
========================================================

Health Center برای تعداد زیاد Dashboard بازطراحی شد.

Dashboard Manager:
- Profile Filter
- Search
- Status Filter
- Sync / Refresh
- Add / Manage
- History CSV
- Card View / Table View
- Showing X of Y

Sync / Refresh:
- ELK Profiles را دوباره از فایل می‌خواند.
- Dashboard جدید بلافاصله با Status=Unknown ظاهر می‌شود.
- Dashboard حذف‌شده از Health Center حذف می‌شود.
- Health record قدیمی Dashboardهای حذف‌شده از HealthStatus.json پاک می‌شود.

Add / Manage:
- کاربر را مستقیم به ELK Profiles می‌برد.
- اگر یک Profile خاص در Health Center انتخاب شده باشد همان Profile باز می‌شود.
- تعریف Dashboard فقط در ELK Profiles انجام می‌شود تا دو منبع تنظیمات جدا ایجاد نشود.

Dashboard Grid:
- Cardها 3 ستونه هستند.
- Wrap عمودی + Scroll برای تعداد زیاد Dashboard.
- دیگر یک ردیف افقی بی‌انتها نیست.
- هر Card:
  Status
  No Data
  Field Health
  Last Check
  Details
  Recheck
  Open Shot

Recheck:
- فقط همان Dashboard را دوباره Capture/Analyze می‌کند.
- از Automatic Capture engine موجود استفاده می‌کند.
- Profile مربوطه به‌صورت خودکار انتخاب می‌شود.

Card / Table:
- Cards نمای پیش‌فرض است.
- Table View برای بررسی فشرده تعداد زیاد Dashboardها باقی مانده است.

نکته معماری:
ELK Profiles = تعریف و مدیریت Dashboard
Health Center = Monitoring / Health / Recheck / Filter


========================================================
v6.3.1 - Dashboard List Visibility + Field Help
========================================================

رفع مشکل:
در ELK Profiles جدول Dashboardها و نام ستون‌ها/ردیف‌ها روی بعضی سیستم‌ها
به خاطر OwnerDraw سفارشی خالی دیده می‌شد.

رفع:
- Dashboard List به Native ListView rendering برگشت.
- Health Center Table View نیز همین اصلاح را دریافت کرد.
- نام Dashboard / Time Range / URL / ES Index / Expected Fields باید واضح دیده شوند.

شفاف‌سازی Field Intelligence:
ES Index:
Index / Data Stream Pattern مربوط به داده Dashboard.
مثال:
logs-suricata-*
logs-firewall-*

Expected Fields:
Fieldهایی که AGHRAB باید در داده‌های اخیر Elasticsearch بررسی کند.
مثال:
source.ip, destination.ip, event.action

این دو فیلد Optional هستند و فقط برای Field Verify / Correlation استفاده می‌شوند.
برای Capture و Visual AI اجباری نیستند.


========================================================
v6.3.2 - Analyze Bounded Layout Fix
========================================================

رفع مشکل Stretch در صفحه Analyze:
- AI Analysis دیگر با عرض پنجره کش نمی‌آید.
- No Data Inspector دیگر فضای خالی صفحه را پر نمی‌کند.
- کل AI Report اندازه ثابت و bounded دارد.
- در پنجره‌های بزرگ فقط در مرکز صفحه قرار می‌گیرد.
- ارتفاع نیز ثابت است و به پایین صفحه Stretch نمی‌شود.

ابعاد:
AI Report: 860 x 205
AI Analysis: 540 x 157
No Data Inspector: 284 x 157


========================================================
AGHRAB Sentinel Pro v6.4 - Dashboard Health History
========================================================

Health Center:
روی هر Dashboard Card دکمه History اضافه شد.

History:
- آخرین 100 Health Check همان Dashboard را داخل خود برنامه نمایش می‌دهد.
- Summary:
  Checks
  Healthy
  Warning
  Critical
  Unknown

ستون‌های History:
- Time
- Status
- No Data
- Errors
- Field Health
- Correlation
- Confidence
- Message

امکانات:
- Open Screenshot برای رکورد انتخابی
- Double Click روی رکورد برای باز کردن Screenshot
- Open Full CSV
- پنجره History مستقل و قابل Resize است.

هدف:
بدون باز کردن CSV بتوان دید یک Dashboard در طول زمان سالم بوده،
هشدار داشته یا Critical شده است.


========================================================
AGHRAB Sentinel Pro v6.4.2 - Health Search Polish
========================================================

English UI version.

Dashboard Manager improvements:
- Magnifying-glass search field
- Placeholder: Search dashboards...
- Live filtering while typing
- Clear X button
- ESC clears the search field

Search now checks:
- Dashboard Name
- Profile
- Status
- Field Health / Field Summary
- Correlation
- Verification Index

Profile and Status filters continue to work together with Search.


========================================================
AGHRAB Sentinel Pro v6.5 - Health Status Alerts
========================================================

New capability:
Windows desktop notifications for Dashboard health status changes.

Settings -> Health Alerts:
- Enable desktop health alerts
- Notify when status becomes Warning
- Notify when status becomes Critical
- Notify when Warning/Critical recovers to Healthy
- Test Notification

Anti-spam behavior:
Alerts are generated only when Status changes.
Example:
Healthy -> Warning   = Alert
Warning -> Warning   = No alert
Warning -> Critical  = Alert
Critical -> Healthy  = Recovery alert

Notification content:
- Dashboard
- Previous -> New status
- No Data count
- Correlation
- Profile

Clicking the Windows notification:
- brings AGHRAB to the foreground
- opens Health Center
- selects the related Dashboard

Alert settings are saved in:
%APPDATA%\aghrab\settings.json

Default:
Health Alerts = OFF
Warning = ON
Critical = ON
Recovery = ON


========================================================
AGHRAB Sentinel Pro v6.6 - Health Summary Report
========================================================

New feature:
Health Center -> Health Summary

The report summarizes ALL configured dashboards.

Summary metrics:
- Total Dashboards
- Healthy
- Warning
- Critical
- Unknown
- Checked Coverage
- Total No Data Panels
- Visible Errors

Automated Assessment:
A deterministic operational summary based on current Health Center data.
No extra Local AI request is required to build the report.

Correlation summary:
- DATA-SIDE SIGNAL
- DASHBOARD-SIDE SIGNAL
- FIELD GAP
- VERIFY ISSUE

Main Issues:
Up to 15 Critical / Warning / Unknown dashboards, ordered by health priority.

Profile Breakdown:
Health counts for each ELK Profile.

Recommended Actions:
Generated from the current correlation and health signals.

Export:
- HTML (formatted dark report)
- TXT
- CSV (full dashboard rows)
- Copy Summary to clipboard

The report does not change Dashboard health state. It is a read-only summary of
the latest stored Health Center results.


========================================================
AGHRAB Sentinel Pro v6.7 - Visual Refresh
========================================================

Visual / UX refresh:
- Operational status cards in Header: LOCAL AI / AUTOMATION / DASHBOARD HEALTH
- Sidebar glyphs + slim active accent rail + softer selected state
- Health KPI cards with semantic accent bar and icon
- Redesigned Dashboard cards with Status pill, Profile line, No Data badge,
  Field Health badge and stronger Recheck action
- Unified rounded buttons with Semibold typography and hover feedback
- Better Health Center empty state
- Health card area increased to 300 px so multiple rows feel less cramped

This release preserves the monitoring behavior from v6.6.


========================================================
AGHRAB Sentinel Pro v6.7.1 - Color & Sidebar Polish
========================================================

Based on direct UI review of v6.7.

Health color separation:
- Total: teal tint
- Healthy: green tint + 🟢
- Warning: amber tint + 🟡
- Critical: red tint + 🔴
- Unknown: neutral gray tint + ⚪
- Dashboard cards use the same semantic tinted backgrounds
- Status pills now include the matching emoji
- Hard black/native borders replaced by softer theme-aware borders

Sidebar:
- white clean surface in Light mode
- active navigation uses a soft accent pill instead of a rail
- meaningful emoji navigation:
  🩺 Health Center
  🗂 ELK Profiles
  ⏱ Automatic Capture
  🖼 Gallery
  🤖 Analyze
  🛡 Security
  ⚙ Settings

Meaningful emoji additions:
- ⚡ Pixel Compare
- 🤖 AI Analyze Latest
- 🤖 AI Compare Last 2
- 🤖 AI badge on a Dashboard card only when an AI confidence value exists

UI cleanup:
- fixed Dashboard Manager / Showing X of Y title overlap
- cleaner card borders
- semantic colors are visible at a glance without making the UI noisy


========================================================
AGHRAB Sentinel Pro v6.7.2 - Native Icon Fix
========================================================

Problem fixed:
Windows PowerShell / WinForms does not reliably render modern color emoji in
Buttons, Labels and GDI/GDI+ surfaces. On some Windows builds the result appears
as empty squares, circles, monochrome fallback glyphs or broken symbols.

This is not a Python issue. AGHRAB is PowerShell + WinForms.

Fix:
- removed Unicode emoji dependency from the operational UI
- added native vector-like icons drawn at runtime with System.Drawing
- Sidebar icons are now generated by AGHRAB itself
- Health KPI icons use native colored graphics
- Dashboard status pills use a real colored dot instead of emoji
- AI badge is a native "AI" badge
- Pixel Compare / AI buttons use drawn icons
- no external font or internet dependency

This gives consistent rendering on offline Windows systems.


========================================================
AGHRAB Sentinel Pro v6.7.3 - Color PNG Icon Pack
========================================================

UI icon pack added as real PNG assets:
- Health Center
- ELK Profiles
- Automatic Capture
- Gallery
- Analyze
- Security
- Settings
- Pixel Compare / Bolt
- Total / Healthy / Warning / Critical / Unknown

Why PNG:
PowerShell + WinForms does not reliably render modern color emoji.
These icons are real transparent PNG graphics, so the same visual is shown
on offline Windows systems regardless of emoji/font support.

Portable:
payload\icons is loaded directly.

Setup:
The installer copies payload\icons to:
%LOCALAPPDATA%\Programs\aghrab\icons

Install-Without-Setup:
The icons directory is copied automatically.

Fallback:
If an icon file is missing, AGHRAB falls back to its native System.Drawing icon
instead of showing a broken square.


========================================================
AGHRAB Sentinel Pro v6.7.4 - Large Sharp Sidebar Icons
========================================================

Sidebar polish:
- Sidebar source PNG icons regenerated at 128x128
- Thicker strokes and stronger contrast
- Icons displayed at 24px
- Menu text increased to 10.25pt
- Navigation item height increased to 46px
- Wider sidebar for cleaner spacing
- More visible active navigation pill
- Better inactive icon contrast

The icon pack remains fully offline and independent of Windows emoji support.


========================================================
AGHRAB Sentinel Pro v6.8 - Premium UI Refresh
========================================================

This release continues the visual/UX direction approved in v6.7.4.

HEADER
- larger premium operational status cards
- real PNG icon in AI / Automation / Dashboard Health
- semantic tinted card backgrounds
- semantic accent line on every status card
- status cards change visual tone based on runtime state

HEALTH CENTER
- cleaner Dashboard Manager hierarchy
- larger manager card with more breathing room
- compact visible-count badge
- subtle separator between filters and actions
- Health Summary button now has a real icon
- filter/action row spacing refined

GALLERY
- new Screenshot Gallery title/subtitle
- root path moved into its own rounded card
- Albums + Retention grouped into a dedicated left card
- Screenshots + Preview grouped into a dedicated media card
- bounded preview retained
- cleaner visual grouping without changing capture/gallery logic

No ELK, AI, scheduler, capture, retention, Health, Field Verify or credential
logic was removed.


========================================================
AGHRAB Sentinel Pro v6.8.1 - Gallery Media Browser
========================================================

This is a major Gallery visual redesign.

Before:
Screenshots were shown as a traditional horizontal row/list and Preview was
stacked underneath.

Now:
- Screenshot browser uses a real visual thumbnail grid
- 160x90 high-quality thumbnails
- screenshots appear side-by-side like a media library
- compact capture time under every thumbnail
- newest screenshot selected automatically
- dedicated Preview card on the right
- preview metadata shown as Album / Captured / Size / File
- selected album name displayed in Gallery header
- capture count displayed beside album name
- thumbnail browser scrolls vertically
- double-click still opens the original PNG
- existing Open / Delete / Refresh / Retention behavior preserved

This version intentionally changes the visual structure of Gallery instead of
only changing borders and spacing.


========================================================
AGHRAB Sentinel Pro v6.9 - Analyze V2
========================================================

Analyze tab visual redesign:
- new "AI Visual Analysis" page title and subtitle
- album / threshold / Pixel Compare moved into one clean control card
- dedicated Local Vision AI card with model and visual status badge
- Before and Latest are now bounded media cards with BASELINE / LATEST badges
- visible AI Analyze Latest and AI Compare Last 2 actions placed close to previews
- six visual AI summary KPI cards:
  Overall / Dashboard Loaded / Empty Panels / With Data / Errors / AI Confidence
- KPI cards use semantic color/tint based on current analysis result
- structured Analysis Report card
- improved No Data Inspector surface
- Copy Report button
- Save Report TXT button
- bounded layout preserved; no giant expanding fields

Existing Pixel Compare, Local AI, No Data detection and AI analysis backends are preserved.


========================================================
AGHRAB Sentinel Pro v6.9.1 - Analyze Layout Fix
========================================================

Analyze V2 cleanup:
- removed visible Test AI button
- removed visible Folder button
- Start AI / Stop AI remain
- AI Status card is the visible readiness indicator
- AI Analyze Latest / AI Compare Last 2 moved into the Local Vision AI card
- AI buttons are wider, text-only and no longer overlap/wrap
- Local Vision AI card is taller with a dedicated ANALYSIS ACTIONS row
- Before / Latest cards moved down and slightly shortened
- KPI strip and Analysis Report moved down consistently
- resize handler no longer repositions the AI action buttons incorrectly

Hidden compatibility controls for Test/Folder remain only so existing backend event
wiring does not break; they are not visible in the interface.


========================================================
AGHRAB Sentinel Pro v6.9.2 - Field Verification Button Fix
========================================================

ELK Profiles -> Connection card cleanup:
- Field Verify renamed to "Field Verification"
- Field Verification moved beside Save Profile
- Login Browser stays on the same top action row
- Session status moved to the second row beside Kibana URL
- Kibana URL width adjusted so Session status has a proper visible area
- Field Verification button enlarged to 118x32
- tooltip added explaining profile-level verification settings

New top row:
Profile name | Save Profile | Field Verification | Login Browser

Second row:
Kibana URL | Session status

No Field Verification logic was changed.


========================================================
AGHRAB Sentinel Pro v6.9.3 - Elasticsearch URL Placeholder
========================================================

Field Verification dialog:
- Elasticsearch URL now shows a light visual hint when the field is empty:
  https://ELASTICSEARCH-IP:9200
- The hint disappears on focus/typing.
- It returns if the field remains empty.
- Existing saved URLs are shown normally.
- The hint is visual only and is never saved as a real URL.


========================================================
AGHRAB Sentinel Pro v6.9.4 - API Key Help
========================================================

Field Verification UX:
- API Key field now has a light placeholder:
  Paste encoded Elasticsearch API Key
- API Help button added next to the API Key field.

API Help window:
- opens as a separate dialog
- Persian step-by-step explanation
- shows the Kibana Dev Tools API Key creation command
- Copy Command button
- explains how to adjust index/data stream patterns
- explains that only the "encoded" value should be pasted into AGHRAB
- uses the normal title-bar X button for closing

The generated API Key example is read-only:
- index privileges: read, view_index_metadata
- cluster privileges: none


========================================================
AGHRAB Sentinel Pro v6.9.5 - Dashboard Field Help
========================================================

Per-dashboard Field Verification UX:
- ES Index placeholder: e.g. logs-suricata-*
- Expected Fields placeholder:
  e.g. source.ip, destination.ip, event.action
- placeholders are visual only and are never saved
- Field Help button added inside the Dashboards card

Dashboard Field Help popup:
- separate Persian help window
- explains ES Index / Data Stream
- explains Expected Fields
- clarifies that Kibana dashboard URL / saved object ID are not used here
- provides DNS, Suricata and Firewall examples
- explains that profile-level Elasticsearch URL + API Key are configured once
- window closes with the standard title-bar X


========================================================
AGHRAB Sentinel Pro v6.9.6 - Beginner Field Help
========================================================

Dashboard Field Help rewritten for first-time users.

The popup now explains the process in 4 simple steps:
1) Configure Elasticsearch URL + API Key once for the Profile.
2) Find the real ES Index/Data Stream from Kibana Dev Tools.
3) Pick 3-8 important Expected Fields from a real event in Discover.
4) Enter them in the dashboard editor and click Add / Update.

Added:
- commands to find Data Streams / Indices
- Copy Commands button
- warning not to paste Kibana dashboard URL as ES Index
- DNS / Suricata / Firewall field examples
- one complete DNS example
- Copy Example button
- plain-language explanation of what AGHRAB does with the values


========================================================
AGHRAB Sentinel Pro v6.10 - Health Correlation UX
========================================================

Next stage: make Field Verification results understandable in Health Center.

Health cards:
- second badge now shows a short verification/correlation result:
  Data-side issue / Dashboard-side / Field gap / Fields active / Verify error / Verify off
- avoids exposing raw internal FieldSummary text on the card

Selected dashboard details:
- "Expected Field Health" renamed to "Field Verification"
- "Correlation" renamed to "Diagnosis / Correlation"
- Field Verification box now starts with:
  Verification state
  ES Index
  Verification window
- individual fields are shown as:
  [OK] field.name — Active (count)
  [NO DATA] field.name — No recent data (0)

Diagnosis box now explains correlation in plain English:
- DATA-SIDE SIGNAL -> likely source/ingestion/parsing/mapping issue
- DASHBOARD-SIDE SIGNAL -> data exists; check Data View/KQL/filter/time range
- FIELD GAP -> some expected fields are not populated
- FIELDS ACTIVE -> expected fields have recent data
- VERIFY ERROR/OFF/NOT READY -> configuration guidance

No capture, AI or Field Verification backend logic was changed.


========================================================
AGHRAB Sentinel Pro v6.11 - Verify Fields Now
========================================================

New manual verification workflow in ELK Profiles > Dashboards.

Button:
- Verify Fields Now

Behavior:
- uses the values currently visible in ES Index and Expected Fields
- does NOT require Add / Update first
- connects directly to Elasticsearch
- does NOT open Kibana
- does NOT capture screenshots
- does NOT start Local AI

Checks:
1) Elasticsearch/API Key authentication
2) ES Index / Data Stream match
3) Field mapping existence via Field Caps
4) Recent field data in the configured verification window

Field result states:
- ACTIVE
  Field exists and has recent data.
- NO DATA
  Field exists in mapping but no recent document contains a value.
- NOT FOUND
  Field is not present in the resolved mappings.

Overall states:
- FIELDS ACTIVE
- FIELD GAP
- INDEX NOT FOUND
- CONNECTION ERROR
- CONFIG ERROR
- FIELD CHECK ERROR

Result dialog:
- Dashboard
- Index/Data Stream
- Window and time field
- Connection result
- Index result
- per-field status/count/explanation
- Copy Result button

Manual verification is intentionally allowed even if automatic
Field Verification is currently disabled, so the user can test the
configuration before enabling it.


========================================================
AGHRAB Sentinel Pro v6.12 - Auto Suggest Fields
========================================================

New button in ELK Profiles > Dashboards:
- Suggest Fields

Workflow:
1) Enter ES Index / Data Stream.
2) Click Suggest Fields.
3) AGHRAB authenticates directly to Elasticsearch.
4) It samples up to 5 real documents from the configured verification window.
5) If there are no recent documents, it falls back to a historical sample.
6) It discovers leaf fields that are actually present in the sampled data.
7) Common SOC/ECS fields are ranked first.
8) User checks the desired fields and clicks Use Selected Fields.
9) Expected Fields textbox is filled automatically.

Suggested Fields dialog:
- Index
- sample source (recent/historical)
- sampled document count
- recent document count
- checkbox field list
- Recommended button
- Select All (up to 20)
- Clear
- Use Selected Fields

Guardrails:
- Suggestions are based on fields observed in real sampled documents.
- Internal/noisy metadata fields are filtered.
- Recommended defaults prefer common SOC/ECS fields.
- Existing configured Expected Fields are pre-selected when present.
- Nothing is saved automatically; Add / Update and Save Profile are still required.
- Existing Field Verification, Capture and AI logic is unchanged.


========================================================
AGHRAB Sentinel Pro v7.0 - Commercial Foundation
========================================================

این نسخه اولین نمونه تجاری‌سازی پروژه است.

License Center:
Settings > License

نمایش:
- Status
- Customer
- Edition
- License ID
- Expiration
- Days Left
- Machine ID

دکمه‌ها:
- Copy Machine ID
- Import License
- License Folder
- Refresh

وضعیت‌های قابل تشخیص:
- UNLICENSED
- LICENSED
- EXPIRED
- INVALID
- MACHINE MISMATCH

مدل لایسنس:
- Offline
- RSA-2048
- SHA-256 digital signature
- Optional Machine Binding
- Trial / Professional
- Expiring or Perpetual

Private Key داخل این بسته مشتری وجود ندارد.
این نسخه فقط Public Key را برای Verify کردن License دارد.

Public Key Fingerprint:
59:08:80:D0:C3:0D:DF:3A:E3:2F:A5:0E:D7:1B:06:9A

نکته v7.0:
در این مرحله Licensing به صورت Soft Enforcement است.
یعنی وضعیت License کاملاً اعتبارسنجی و نمایش داده می‌شود، اما هنوز Featureها
به خاطر UNLICENSED/EXPIRED غیرفعال نمی‌شوند.
این تصمیم برای تست امن Commercial Foundation است.
در مرحله بعد می‌توان Trial/Expiration Enforcement را اضافه کرد.


========================================================
AGHRAB Sentinel Pro v7.0.1 - Startup Fix
========================================================

این نسخه برای رفع مشکل اجرا نشدن Run-Portable ساخته شد.

تغییرات:
- License runtime ساده‌تر و سازگارتر با Windows PowerShell 5.1 شد.
- Public Key از کد اصلی خارج و به payload\license-public-key.xml منتقل شد.
- Machine ID ساده‌تر و پایدارتر شد.
- Run-Portable اکنون وجود فایل‌های لازم را چک می‌کند.
- Start-AGHRAB.ps1 اضافه شد.
- خطای Startup در payload\aghrab-startup-error.log ثبت می‌شود.
- Run-Portable-Debug.bat اضافه شد تا خطا در Console دیده شود.

اگر Run-Portable باز نشد:
Run-Portable-Debug.bat را اجرا کن و متن خطا یا فایل
payload\aghrab-startup-error.log
را ارسال کن.


========================================================
AGHRAB Sentinel Pro v7.0.2 - PowerShell Parser Fix
========================================================

رفع خطای Startup گزارش‌شده در v7.0.1.

علت اصلی:
در بخش Suggest Fields کوتیشن انتهای عبارت زیر جا افتاده بود:
Selected: x / 20

به همین دلیل Windows PowerShell ادامه فایل را اشتباه Parse می‌کرد و
خطاهای ظاهراً نامرتبط مثل Recommended، علامت & در URL و Fields:
نمایش داده می‌شدند.

تغییرات:
- کوتیشن جاافتاده اصلاح شد.
- Start-AGHRAB.ps1 قبل از اجرای برنامه کل ScreenshotTool.ps1 را با
  Parser خود Windows PowerShell بررسی می‌کند.
- اگر در آینده Syntax Error وجود داشته باشد، شماره Line و Char داخل
  payload\aghrab-startup-error.log ثبت می‌شود.

License Maker v1.0 قبلی با v7.0.2 سازگار است.


========================================================
AGHRAB Sentinel Pro v7.0.3 - C# Compatibility Fix
========================================================

رفع خطای Startup گزارش‌شده روی Windows PowerShell / CodeDOM compiler.

خطای قبلی:
Invalid token '=' in class, struct, or interface member declaration

علت:
Custom AghrabProgressBar با این Syntax ساخته شده بود:
public Color BorderColor { get; set; } = Color.FromArgb(...);

Auto-property initializer متعلق به C# جدیدتر است و بعضی Windows PowerShell 5.1
ها Add-Type را با کامپایلر قدیمی اجرا می‌کنند.

رفع:
- auto-property initializer حذف شد.
- BorderColor با private field قدیمی و سازگار پیاده‌سازی شد.
- مقدار BorderColor داخل constructor تنظیم می‌شود.
- هیچ قابلیت ظاهری ProgressBar حذف نشده است.

این تغییر به Licensing مربوط نبود؛ فقط Compatibility اجرای برنامه روی
Windows PowerShell قدیمی‌تر است.

License Maker v1.0 قبلی همچنان با v7.0.3 سازگار است.


========================================================
AGHRAB Sentinel Pro v7.0.4 - No C# Startup Fix
========================================================

رفع خطای:
The type or namespace name 'Forms' does not exist in the namespace 'System.Windows'

علت:
کنترل سفارشی AghrabProgressBar هنگام Startup با Add-Type و C# کامپایل می‌شد.
روی بعضی Windows PowerShell / .NET Framework ها CodeDOM هنگام Compile،
System.Windows.Forms را به صورت خودکار Reference نمی‌کند.

رفع قطعی:
- کل C# / Add-Type سفارشی AghrabProgressBar حذف شد.
- از ProgressBar استاندارد خود Windows Forms استفاده می‌شود.
- دیگر برای Startup هیچ C# سفارشی Compile نمی‌شود.
- قابلیت اصلی Progress/Percentage حفظ شده است.
- Licensing دست نخورده است.
- License Maker v1.0 همچنان سازگار است.

این تغییر عمداً به جای ادامه Patch کردن Compiler، وابستگی مشکل‌دار را
کلاً حذف می‌کند تا Portable build روی Windowsهای بیشتری اجرا شود.


========================================================
AGHRAB Sentinel Pro v7.0.5 - Runtime Line Fix
========================================================

رفع خطای Runtime:
A positional parameter cannot be found that accepts argument
'System.Windows.Forms.Label, Text: FILTERS.Font'

علت:
در بخش Health Center، دو رشته literal زیر به اشتباه داخل کد قرار گرفته بودند:
`r`n

بنابراین سه دستور مربوط به:
- Size
- Font
- Tag

به جای سه خط جدا، توسط Windows PowerShell مثل یک دستور واحد اجرا می‌شدند.

رفع:
- سه دستور به سه خط واقعی جدا شدند.
- کل ScreenshotTool.ps1 اسکن شد تا هیچ literal `r`n دیگری خارج از String باقی نماند.
- C# custom startup compilation همچنان حذف است.
- Licensing تغییری نکرده است.
- License Maker v1.0 همچنان سازگار است.


========================================================
AGHRAB Sentinel Pro v7.1 - Trial & Expiry Enforcement
========================================================

Commercial Licensing مرحله دوم:

License states:
- LICENSED
- UNLICENSED
- EXPIRED
- INVALID
- MACHINE MISMATCH

Edition:
- Trial
- Professional

Trial:
- توسط License Maker v1.1 به صورت 30 روزه صادر می‌شود.
- تا وقتی Trial معتبر است، AI و Automatic Capture فعال هستند.
- در 7 روز آخر، هشدار تعداد روز باقی‌مانده در License Center و Header نمایش داده می‌شود.
- بعد از Expire شدن Trial:
  Local AI و Automatic Capture غیرفعال می‌شوند.

Professional:
- Expiring یا Perpetual
- تا وقتی License معتبر است Full Access دارد.
- اگر License تاریخ‌دار باشد، در 14 روز آخر هشدار Renewal نمایش داده می‌شود.

Enforcement:
- AI Analyze Latest
- AI Compare Last 2
- Start Local AI
- Automatic Capture scheduler
- Automatic Capture Run Now

مواردی که عمداً باز می‌مانند:
- Manual dashboard capture
- Gallery
- Health Center
- ELK Profiles
- Field Verification
- Settings / License Import
- Dashboard-specific Health Recheck

هدف این است که برنامه بعد از Expire کاملاً از کار نیفتد؛
اما قابلیت‌های تجاری اصلی نیازمند License معتبر باشند.

License Center حالا Access را نیز نمایش می‌دهد:
- FULL ACCESS
- TRIAL ACCESS
- LIMITED - AI and Automatic Capture disabled

همان Key Pair قبلی استفاده شده و Licenseهای Professional قبلی سازگار هستند.


========================================================
AGHRAB Sentinel Pro v7.1.1 - Annual License Model
========================================================

مدل اصلی تجاری به Annual تغییر کرد.

مدل پیشنهادی:
- Professional
- مدت اعتبار پیش‌فرض: 1 سال از Issue Date
- پس از Expire شدن: AI و Automatic Capture غیرفعال می‌شوند.
- سایر بخش‌های اصلی برای مشاهده/تنظیم و تمدید License باز می‌مانند.
- Header برای License تاریخ‌دار تعداد روز باقی‌مانده را نشان می‌دهد.
- هشدار تمدید برای Professional در 30 روز پایانی توصیه می‌شود.

Licenseهای قبلی همچنان قابل Verify هستند چون Key Pair تغییر نکرده است.


========================================================
AGHRAB Sentinel Pro v7.1.2 - Commercial License Header
========================================================

Header license display redesigned for a cleaner commercial look.

Top-right header now shows:
- v7.1.2
- LICENSED / EXPIRED / UNLICENSED / INVALID / MACHINE MISMATCH
- 365 days left (dynamic)

Design:
- Version is separate and subtle.
- LICENSED is shown as a green status chip.
- Remaining days are displayed on a dedicated second line.
- Expired is red.
- Invalid / Machine Mismatch are warning state.
- No more long "v... • LICENSED • 365 DAYS" text floating near Dashboard Health.

License Maker v1.2 remains compatible and does not need to be rebuilt.


========================================================
AGHRAB Sentinel Pro v7.2 - Product Info & Support Package
========================================================

Commercial Product & Support stage.

Settings > Product & Support:

1) About AGHRAB
Shows:
- Product name
- Version / Commercial Build
- License status
- Licensed customer
- Edition
- License ID
- Expiration
- Days remaining
- Machine ID

2) Export Support Package
Creates a sanitized ZIP for customer support.

Support package may contain:
- system-info.json
- license-summary.json
- profiles-summary.json
- settings-summary.json
- automatic-capture-summary.json
- runtime-summary.json
- recent Health History
- recent Security Audit
- startup-error.log if present
- recent llama-server stdout/stderr logs if present

Security / privacy:
The package intentionally does NOT include:
- saved passwords
- DPAPI credential files
- Elasticsearch API Key values
- original elk-profiles.json
- browser profile/session folders or cookies
- signed .lic file
- screenshots
- AI model files

Bounded log tails are passed through a redaction function before packaging.

License Maker v1.2 remains compatible; no new license is needed.


========================================================
AGHRAB Sentinel Pro v7.3 - 7-Day Full Trial + Lock Mode
========================================================

مدل تجاری جدید:

1) اولین اجرای واقعی برنامه:
- Trial هفت روزه خودکار شروع می‌شود.
- در Trial همه قابلیت‌ها کاملاً باز هستند:
  Health Center
  ELK Profiles
  Manual Capture
  Automatic Capture
  Gallery
  Analyze / Local AI
  Field Verification
  Security
  Settings

2) Header:
- وضعیت TRIAL را نشان می‌دهد.
- تعداد روز باقی‌مانده را نمایش می‌دهد.

3) پایان 7 روز:
- وضعیت TRIAL EXPIRED می‌شود.
- بخش‌های عملیاتی قفل می‌شوند.
- فقط موارد زیر باز می‌مانند:
  Gallery
  Settings > License Activation
  About AGHRAB / Export Support Package

4) Professional License:
- License یک‌ساله معتبر بلافاصله Full Access را برمی‌گرداند.
- License Maker v1.2 همچنان سازگار است.

Trial persistence / anti-reset:
- Trial به Machine ID متصل است.
- Trial state با Windows DPAPI برای Current User محافظت می‌شود.
- state در سه محل mirror می‌شود:
  %APPDATA%\aghrab\trial-state.dat
  %LOCALAPPDATA%\aghrab\trial-state.dat
  HKCU\Software\AGHRAB\SentinelPro
- اگر یکی از mirrorها حذف شود، از mirror سالم بازسازی می‌شود.
- earliest start time و latest last-seen time استفاده می‌شود.
- عقب بردن محسوس ساعت سیستم باعث TRIAL INVALID و نیاز به Activation می‌شود.
- نصب مجدد ساده برنامه Trial جدید ایجاد نمی‌کند، چون state خارج از پوشه نصب نگهداری می‌شود.

نکته:
این یک کنترل آفلاین تجاری با مقاومت مناسب در برابر reset ساده است،
نه DRM غیرقابل‌شکست.

License Maker v1.2:
بدون تغییر و سازگار با v7.3.


========================================================
AGHRAB Sentinel Pro v7.4 - Profile / Dashboard Import & Export
========================================================

ELK Profiles > Import / Export

قابلیت‌های انتقال:

1) Export Selected Profile
- پروفایل انتخاب‌شده را به فایل Portable JSON تبدیل می‌کند.
- تمام Dashboardهای داخل همان Profile نیز منتقل می‌شوند.

2) Export All Profiles
- همه Profileها و Dashboardهای آن‌ها را در یک فایل منتقل می‌کند.

3) Import Profile(s)
- فایل Export شده را روی سیستم دیگر Import می‌کند.
- اگر نام Profile از قبل وجود داشته باشد، اطلاعات قبلی Overwrite نمی‌شود.
  نام جدید به صورت (Imported) ساخته می‌شود.

4) Export Selected Dashboard
- فقط Dashboard انتخاب‌شده را Export می‌کند.

5) Import Dashboard into Selected Profile
- Dashboard را داخل Profile مقصد انتخاب‌شده اضافه می‌کند.
- Conflict نام Dashboard نیز با (Imported) مدیریت می‌شود.

امنیت انتقال:
این موارد هرگز Export نمی‌شوند:
- Auto Login Password
- DPAPI Credential
- Elasticsearch API Key
- Browser Cookies / Sessions

دلیل:
Credentialهای AGHRAB به Windows User / Machine مبدا متصل هستند
و نباید به سیستم دیگر منتقل شوند.

بعد از Import:
- Username می‌تواند منتقل شود.
- Kibana URL و Elasticsearch URL منتقل می‌شوند.
- Auto Login به صورت امن OFF است تا Password جدید وارد شود.
- Field Verification به صورت امن OFF است تا API Key جدید وارد شود.
- Dashboard URL, Time Range, Index Pattern و Expected Fields منتقل می‌شوند.

فرمت فایل:
AGHRAB-PORTABLE-TRANSFER
format_version = 1

License Maker v1.2 همچنان سازگار است.


========================================================
AGHRAB Sentinel Pro v7.4.1 - Transfer Center UX Fix
========================================================

اصلاح Import / Export Center:

- پنجره به دو بخش واضح تقسیم شد:
  PROFILE TRANSFER
  DASHBOARD TRANSFER

- Selected Profile به صورت واضح نمایش داده می‌شود.
- Selected Dashboard به صورت واضح نمایش داده می‌شود.
- اگر Profile یا Dashboard انتخاب نشده باشد، Export مربوطه Disabled است.

Import Dashboard:
- دیگر به Profile انتخاب‌شده پشت پنجره وابسته نیست.
- Destination Profile داخل خود Transfer Center دارای ComboBox است.
- کاربر دقیقاً Profile مقصد را قبل از Import انتخاب می‌کند.
- نتیجه Import نام Dashboard و Profile مقصد را در Status نمایش می‌دهد.

Conflict Policy:
- هیچ Profile یا Dashboard موجودی Overwrite نمی‌شود.
- در صورت تداخل نام، نسخه جدید با (Imported) ساخته می‌شود.

Security:
- Password
- Elasticsearch API Key
- DPAPI Credential
- Browser Cookie / Session
همچنان Export نمی‌شوند.


========================================================
AGHRAB Sentinel Pro v7.4.2 - Transfer Center Self-Contained
========================================================

اصلاح اصلی:
Transfer Center دیگر به انتخاب Profile/Dashboard در صفحه پشت پنجره وابسته نیست.

PROFILE TRANSFER:
- Profile دارای ComboBox مستقل است.
- Export Profile بر اساس همان ComboBox انجام می‌شود.
- Export All Profiles و Import Profile(s) کنار آن قرار دارند.

DASHBOARD TRANSFER:
- Source Profile دارای ComboBox مستقل است.
- Dashboard دارای ComboBox مستقل است.
- با تغییر Source Profile، Dashboard list خودکار Refresh می‌شود.
- Export Dashboard بر اساس دو ComboBox بالا انجام می‌شود.
- Destination Profile دارای ComboBox مستقل برای Import است.

نتیجه:
- دیگر وضعیت گیج‌کننده "None selected" به خاطر انتخاب پشت پنجره نداریم.
- کاربر همیشه داخل خود Transfer Center مشخص می‌کند:
  چه Profileای Export شود،
  چه Dashboardای Export شود،
  Dashboard Import شده وارد کدام Profile شود.

Layout:
- پنجره کمی بزرگ‌تر شد.
- Footer و Close button پایین پنجره دیگر Cut نمی‌شوند.
- Button disabled با ظاهر خط ناقص حذف شد؛ Dashboard selector کنترل اصلی انتخاب است.

Security و Conflict Policy بدون تغییر:
- Password/API Key/session export نمی‌شوند.
- Existing item overwrite نمی‌شود.


========================================================
AGHRAB Sentinel Pro v7.4.3 - Export / Import All Dashboards
========================================================

Dashboard Transfer تکمیل شد.

در بخش DASHBOARD TRANSFER:

1) Export Dashboard
فقط Dashboard انتخاب‌شده را از Source Profile خروجی می‌گیرد.

2) Export All Dashboards
تمام Dashboardهای Source Profile انتخاب‌شده را در یک فایل Portable خروجی می‌گیرد.

فایل All Dashboards:
- kind = dashboards
- source_profile = نام Profile مبدا
- dashboards = لیست کامل Dashboardها

3) Import Dashboard(s)
هم فایل یک Dashboard و هم فایل All Dashboards را قبول می‌کند.
تمام Dashboardهای موجود در فایل به Destination Profile انتخاب‌شده اضافه می‌شوند.

Conflict:
اگر Dashboard هم‌نام از قبل وجود داشته باشد،
نسخه موجود Overwrite نمی‌شود و نام (Imported) ساخته می‌شود.

Security:
Password / API Key / DPAPI Credential / Browser Session
در فایل Dashboard Transfer وجود ندارند.


========================================================
AGHRAB Sentinel Pro v7.4.4 - Multi Dashboard Selection
========================================================

Dashboard Transfer اکنون سه حالت Export دارد:

1) چند Dashboard خاص:
- Source Profile را انتخاب کن.
- Dashboardها در Checked List نمایش داده می‌شوند.
- هر تعداد Dashboard که لازم است تیک بزن.
- Export Selected Dashboards را بزن.

2) همه Dashboardها:
- Export All Dashboards

3) هیچ موردی:
- اگر Dashboard تیک نخورده باشد Export Selected اجرا نمی‌شود.

کنترل‌های جدید:
- Select All
- Clear
- Checked Dashboard List
- Export Selected Dashboards
- Export All Dashboards

Import Dashboard(s) بدون تغییر:
- فایل یک Dashboard
- فایل چند Dashboard انتخابی
- فایل همه Dashboardها
هر سه را قبول می‌کند.

Conflict و Security:
- مورد موجود Overwrite نمی‌شود.
- Password/API Key/DPAPI/Browser Session منتقل نمی‌شوند.


========================================================
AGHRAB Sentinel Pro v7.5 - Installer / Upgrade Release Candidate
========================================================

هدف این نسخه:
نصب و Upgrade درجا بدون از بین رفتن اطلاعات مشتری.

Installer:
- نصب قبلی AGHRAB را تشخیص می‌دهد.
- در صورت وجود نسخه قبلی، INSTALL به UPDATE تبدیل می‌شود.
- نسخه Installed -> New در Setup نمایش داده می‌شود.
- قبل از Update از فایل‌های اصلی برنامه Backup موقت می‌گیرد.
- اگر Update خطا بدهد، فایل‌های قبلی Application Restore می‌شوند.
- بعد از Update برنامه از Start-AGHRAB.ps1 اجرا می‌شود تا Parser/Startup
  Error Handling فعال باشد.

مواردی که Upgrade دست نمی‌زند و حفظ می‌شوند:
- %APPDATA%\aghrab\elk-profiles.json
- Settings
- License
- 7-Day Trial state
- Credentials
- Browser sessions
- Health history
- Security audit
- Gallery / Screenshot output
- Existing AI Pack

AI:
- هنگام Upgrade فایل‌های AI موجود Overwrite نمی‌شوند.
- اگر Full Offline Package فایل AI جدیدی داشته باشد و آن فایل روی سیستم
  وجود نداشته باشد، اضافه می‌شود.

Installer bug fixes:
- Start-AGHRAB.ps1 اکنون داخل Setup نصب می‌شود.
- license-public-key.xml اکنون داخل Setup نصب می‌شود.
- Embedded VBS Launcher با فایل واقعی package یکسان است و Start-AGHRAB.ps1
  را اجرا می‌کند.
- Shortcut رسمی:
  AGHRAB Sentinel Pro
- Shortcut قدیمی aghrab.lnk حذف می‌شود.
- Publisher در Add/Remove Programs به AGHRAB تغییر کرد.

Uninstall:
- خود Application و AI folder نصب‌شده حذف می‌شوند.
- اطلاعات مشتری در AppData حفظ می‌شود.
- License / Trial state عمداً حفظ می‌شود تا Uninstall باعث Reset Trial نشود.
- نصب مجدد می‌تواند Profileها و تنظیمات قبلی را دوباره استفاده کند.

Upgrade History:
%APPDATA%\aghrab\upgrade-history.log

Manual fallback:
Install-Without-Setup.bat نیز Start wrapper، Public Key، Icons و Shortcutهای
صحیح را نصب/به‌روزرسانی می‌کند.


========================================================
AGHRAB Sentinel Pro v7.6 - English / Persian + RTL
========================================================

Language:
Settings -> Appearance & Theme -> Language

گزینه‌ها:
- English
- فارسی

رفتار:
- English = چیدمان Left-to-Right
- فارسی = چیدمان Right-to-Left
- تغییر زبان از داخل Settings توسط کاربر انجام می‌شود.
- انتخاب زبان بلافاصله روی UI اعمال می‌شود.
- Save Settings زبان را در:
  %APPDATA%\aghrab\settings.json
  ذخیره می‌کند.
- در اجرای بعدی همان زبان قبلی باز می‌شود.

RTL:
- Sidebar، کارت‌ها، Labelها، CheckBoxها و فرم‌ها برای فارسی آینه می‌شوند.
- جهت متن‌های فنی مثل URL، IP، Machine ID، Password و TextBoxها LTR باقی
  می‌ماند تا مقادیر خراب یا ناخوانا نشوند.
- با برگشت به English، Layout دوباره LTR می‌شود.

Localization:
- Navigation
- Capture
- ELK Profiles
- Health Center
- Automatic Capture
- Gallery
- Analyze / Local AI
- Security
- Settings
- License
- Profile/Dashboard Import/Export
- بخش مهمی از Dialogهای WinForms
به صورت دو زبانه پشتیبانی می‌شوند.

Trial:
حتی بعد از پایان Trial، Language selector فعال باقی می‌ماند.
Theme controls همچنان طبق محدودیت Trial مدیریت می‌شوند.

نکته:
مقادیر فنی، نام Profile/Dashboard، URL، Index Pattern، API Key و داده‌های
کاربر ترجمه نمی‌شوند.


========================================================
AGHRAB Sentinel Pro v7.6.1 - Startup Syntax Fix
========================================================

رفع مشکل Startup نسخه v7.6:

علت:
در جدول ترجمه فارسی PowerShell دو کلید تکراری با تفاوت حروف بزرگ/کوچک وجود داشت:
- Ready / READY
- MACHINE MISMATCH / Machine mismatch

Hashtable در PowerShell نسبت به بزرگ/کوچک بودن حروف حساس نیست.
به همین دلیل Parser قبل از اجرای برنامه خطا می‌داد و Start-AGHRAB.ps1 پیام:
PowerShell syntax validation failed
نمایش می‌داد.

اصلاح:
- کلیدهای تکراری حذف شدند.
- ترجمه همچنان برای همان متن‌ها کار می‌کند چون Hashtable case-insensitive است.
- کلید متن چندخطی Sidebar نیز اصلاح شد.
- Startup Error dialog اکنون در خطاهای احتمالی آینده اولین خط Parser Error
  را مستقیماً داخل پنجره خطا نمایش می‌دهد.

هیچ تغییری در License keypair یا Trial state ایجاد نشده است.


========================================================
AGHRAB Sentinel Pro v7.6.2 - Safe Persian / RTL Fix
========================================================

رفع Crash هنگام تغییر زبان به فارسی:

در v7.6.1 موتور RTL تمام Controlهای WinForms را در لحظه با تغییر X/Anchor
آینه می‌کرد. این روش برای UI بزرگ AGHRAB بیش از حد تهاجمی بود و می‌توانست
هنگام تغییر زنده زبان باعث ناپایداری WinForms شود.

در v7.6.2:
- آینه‌کردن دستی تمام Coordinateهای Controlها حذف شد.
- فقط دو ستون اصلی Workspace به شکل کنترل‌شده جابه‌جا می‌شوند:
  Sidebar -> سمت راست
  Main Workspace -> سمت چپ
- داخل Cardها Coordinateها دستکاری نمی‌شوند.
- Captionها و جهت متن فارسی RTL می‌شوند.
- URL/IP/API Key/Password/Machine ID و ComboBoxهای فنی LTR باقی می‌مانند.
- Language engine دارای Re-entry Guard شد.
- تغییر اولیه زبان فقط بعد از Form.Shown انجام می‌شود.
- Timer دیگر هر 2 ثانیه کل UI را از نو بازنویسی نمی‌کند؛ فقط Dialog جدید
  را یک بار Localize می‌کند.
- اگر Language Apply خطا بدهد، برنامه باید باز بماند و به English برگردد.
- خطاهای زبان در فایل زیر ثبت می‌شوند:
  %APPDATA%\aghrab\language-error.log

این نسخه settings.json قبلی را می‌خواند؛ اگر v7.6.1 روی Persian ذخیره شده باشد
v7.6.2 باید با موتور RTL امن جدید بالا بیاید.


========================================================
AGHRAB Sentinel Pro v7.6.3 - Stable Language Mode
========================================================

این نسخه برای رفع کامل بسته‌شدن برنامه هنگام فارسی‌کردن ساخته شده است.

تغییر معماری Language:
- هیچ RightToLeft سراسری روی Form اعمال نمی‌شود.
- هیچ Control به صورت Recursive جابه‌جا نمی‌شود.
- هیچ Timer برای ترجمه مجدد کل UI وجود ندارد.
- تغییر Language فقط با دکمه Apply یا Save Settings انجام می‌شود.
- متن‌های ثابت با Queue یک بار پردازش می‌شوند، نه Recursive.
- فقط دو بخش اصلی جابه‌جا می‌شوند:
  Sidebar
  Main Workspace
- TextBox / ComboBox / URL / IP / API Key / Password / Machine ID همیشه LTR هستند.

Startup Safety:
- برنامه همیشه ابتدا English/LTR باز می‌شود.
- اگر در settings.json زبان Persian ذخیره شده باشد، انتخاب Persian داخل Settings
  دیده می‌شود اما تا وقتی کاربر Apply یا Save Settings نزند روی UI اعمال نمی‌شود.
- این کار از Crash Loop جلوگیری می‌کند.

Recovery:
فایل جدید:
Safe-Start-English.bat

اگر هر زمان Language باعث مشکل شد:
Safe-Start-English.bat
را اجرا کن.
فقط Language را English می‌کند و Profile/License/Trial/Settings دیگر را پاک نمی‌کند.

Diagnostic:
%APPDATA%\aghrab\language-error.log


========================================================
AGHRAB Sentinel Pro v7.6.3.1 - Persian Font Choice
========================================================

این نسخه مستقیماً از v7.6.3 Stable ساخته شده است.

Settings -> Appearance & Theme:
Persian font:
- Tahoma
- B Koodak

Tahoma:
- گزینه پایدار و پیش‌فرض
- روی Windows به صورت استاندارد در دسترس است

B Koodak:
- فقط اگر روی Windows نصب باشد استفاده می‌شود
- اگر نصب نباشد AGHRAB بدون خطا از Tahoma استفاده می‌کند
- برای کاهش احتمال Cut/Overlap اندازه B Koodak حدود 1pt کمتر از اندازه
  اصلی Control استفاده می‌شود

ایمنی Layout:
- هیچ Width / Height / Location به خاطر Font تغییر نمی‌کند
- TextBox / ComboBox / ListView / Grid / URL / IP / Password / API Key
  دست‌نخورده می‌مانند
- فقط Captionهای رابط فارسی Font انتخابی می‌گیرند
- با برگشت به English فونت اصلی Control Restore می‌شود

PersianFont در settings.json ذخیره می‌شود.
هیچ فایل Font داخل AGHRAB توزیع نشده است.


========================================================
AGHRAB Sentinel Pro v7.6.3.2 - Persian UI Polish
========================================================

Base:
v7.6.3.1 / هندسه پایدار v7.6.3

این نسخه هیچ Responsive/Scaling سراسری اضافه نمی‌کند.

رفع مشکلات مشاهده‌شده:
- ترجمه و کوتاه‌سازی متن‌های Health / ELK / Gallery / Analyze / Settings
- Runtime statusهای AI / Health / License بعد از Refresh انگلیسی نمی‌شوند
- Header Statusها کوتاه و فارسی می‌شوند و AutoEllipsis دارند
- Health dashboard cardهای داینامیک فارسی می‌شوند
- All Profiles / All Statuses با زبان UI هماهنگ می‌شوند
- ستون‌های ELK Dashboard فارسی می‌شوند
- Gallery root label دیگر روی Path نمی‌افتد
- Current images / captures فارسی می‌شوند
- Analyze AI Status فضای بیشتری دارد و Actionها کوتاه شده‌اند
- License title کوتاه‌تر/عریض‌تر شده و Runtime text فارسی باقی می‌ماند
- AutoScroll روی تمام Workspaceها فعال است تا پایین صفحه در DPI/ارتفاع کم Cut نشود
- Tahoma / B Koodak choice نسخه قبل حفظ شده است

هدف:
اصلاح ظاهر فارسی بدون دست‌زدن به معماری Layout پایدار v7.6.3.


========================================================
RAQEB Sentinel Pro v7.6.3.3 - Rebrand
========================================================

نام تجاری قابل مشاهده برنامه از:
AGHRAB Sentinel Pro
به:
RAQEB Sentinel Pro / راقب
تغییر کرده است.

موارد تغییرکرده:
- عنوان اصلی برنامه
- Header و Sidebar
- About / Product & Support
- Import / Export dialogs
- Health reports / Security dialogs
- Activation Center
- Setup / Update UI
- Desktop و Start Menu shortcut
- Support package naming
- پیام‌های Startup / Uninstall

برای حفظ کامل سازگاری، موارد داخلی زیر عمداً تغییر نکرده‌اند:
- %APPDATA%\aghrab
- %LOCALAPPDATA%\Programs\aghrab
- Registry Trial state قبلی
- license-public-key.xml
- product داخلی License = AGHRAB Sentinel Pro
- فرمت داخلی AGHRAB-PORTABLE-TRANSFER
- پوشه _AGHRAB_Health
- نام فایل‌های داخلی Start-AGHRAB.ps1 / aghrab.ico

این کار باعث می‌شود:
- Licenseهای فعلی همچنان معتبر بمانند.
- Trial از اول شروع نشود.
- Profileها / Settings / Gallery / Health History قبلی گم نشوند.
- فایل‌های Import/Export قبلی همچنان قابل استفاده باشند.

ظاهر تجاری برای کاربر RAQEB / راقب است؛ شناسه‌های قدیمی فقط برای
Backward Compatibility در داخل برنامه باقی مانده‌اند.


========================================================
RAQEB Sentinel Pro v7.6.3.4 - Security Hardening
========================================================

UI پایدار تغییر نکرده است.

- VBS launcher حذف شد.
- نسخه نصب‌شده از RAQEB.exe استفاده می‌کند.
- Installed launcher از ExecutionPolicy RemoteSigned استفاده می‌کند.
- Run-Portable فقط برای ZIP/MOTW همچنان Bypass دارد.
- Installer دیگر Payloadها را Base64 String نگه نمی‌دارد و از .NET Manifest Resources استفاده می‌کند.
- taskkill.exe از Stop AI حذف شد و Process.Kill() استفاده می‌شود.
- Prepare-AI-Pack همه Downloadها را با SHA256 ثابت Verify می‌کند.
- Runtime manifest پس از Verify شدن ZIP رسمی llama.cpp ساخته می‌شود.
- RAQEB قبل از Start AI مدل/mmproj/runtime را Verify می‌کند.
- Security-Preflight.bat و Security-Preflight-Defender.bat اضافه شدند.

Pinned hashes:
llama.cpp ZIP: 917f39c076402c421224824607397af20f53625a60defc20e8dd22446bf4c5d7
model: d02fe9b69ad8cadbbd228e387667af66612c44bed29ffc8eb1e7caf9ac486c12
mmproj: 980c9b2f78c04e6cff93d277ada09e768394f112d75db3b4e9dea8a69f9fb904

License / Trial / Profile / Gallery / UI و Public Key تغییر نکرده‌اند.


========================================================
RAQEB Sentinel Pro v7.6.3.6 - CAPTCHA Session Workflow
========================================================

Base: v7.6.3.4 STABLE + Security Hardening
UI اصلی تغییر نکرده است.

CAPTCHA:
- هیچ CAPTCHA به شکل خودکار حل یا دور زده نمی‌شود.
- هنگام تشخیص CAPTCHA، Login/Capture روی PAUSED می‌رود.
- Browser باز می‌ماند.
- کاربر CAPTCHA را دستی حل می‌کند.
- سپس Continue CAPTCHA را در RAQEB می‌زند.
- همان Browser Session بررسی و عملیات ادامه داده می‌شود.

Automatic Capture:
- CAPTCHA به عنوان Failed Dashboard ثبت نمی‌شود.
- Scheduler وضعیت PAUSED - CAPTCHA می‌گیرد.
- Next Run موقتاً PAUSED می‌شود.
- Login تکراری در زمان انتظار ایجاد نمی‌شود.
- Desktop notification نمایش داده می‌شود.
- بعد از Continue CAPTCHA همان Cycle ادامه پیدا می‌کند.

Session reuse:
- Browser Profile برای هر ELK Profile persistent است.
- Cookie/Session تا زمانی که سایت آن را معتبر بداند reuse می‌شود.
- بعد از Restart برنامه هم Session قابل استفاده است.
- اگر سایت Session را expire کند، Login دوباره انجام می‌شود.
- اگر دوباره CAPTCHA بیاید، دوباره Pause می‌شود.

پاکسازی Session:
Security -> Clear Saved Sessions

Security Hardening نسخه v7.6.3.4 حفظ شده است.

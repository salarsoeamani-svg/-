@echo off
setlocal
cd /d "%~dp0"

echo.
echo ===============================================
echo  aghrab Full Offline AI Package Builder
echo ===============================================
echo.
echo This will download the AI files and then create
echo one large FULL OFFLINE ZIP automatically.
echo.
echo Internet is required only on THIS computer.
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Build-Full-Offline-Package.ps1"

if errorlevel 1 (
    echo.
    echo Build failed.
    pause
    exit /b 1
)

endlocal

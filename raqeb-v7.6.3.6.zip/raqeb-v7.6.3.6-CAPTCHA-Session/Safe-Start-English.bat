@echo off
setlocal
echo ============================================
echo   AGHRAB - Safe Start in English
echo ============================================
echo.
echo This will set only the UI language to English.
echo Profiles, dashboards, license, Trial and other settings are preserved.
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
 "$p=Join-Path $env:APPDATA 'aghrab\settings.json'; if(Test-Path -LiteralPath $p){ try{$o=Get-Content -LiteralPath $p -Raw -Encoding UTF8 ^| ConvertFrom-Json}catch{$o=$null}; if($null -eq $o){$o=[pscustomobject]@{Theme='Light';Language='English'}}; $o ^| Add-Member -NotePropertyName Language -NotePropertyValue 'English' -Force; $o ^| ConvertTo-Json -Depth 10 ^| Set-Content -LiteralPath $p -Encoding UTF8 -Force }"

echo Language reset to English.
echo Starting AGHRAB...
echo.
call "%~dp0Run-Portable.bat"

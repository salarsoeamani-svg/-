@echo off
cd /d "%~dp0payload"
echo.
echo AGHRAB Sentinel Pro v7.0.1 - Debug Startup
echo -------------------------------------------
echo If an error occurs, keep this window open and send the red error text or:
echo payload\aghrab-startup-error.log
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0payload\Start-AGHRAB.ps1"
echo.
echo AGHRAB process ended.
pause

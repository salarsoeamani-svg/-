
using System;
using System.IO;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Win32;
using System.Diagnostics;
using System.Reflection;
using System.Text;

namespace AghrabSentinelInstaller
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new InstallerForm());
        }
    }

    public class InstallerForm : Form
    {
        const string AppName = "RAQEB Sentinel Pro";
        const string AppId = "aghrab";
        const string Version = "7.6.3.6";
        readonly string AppDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "Programs", "aghrab");

        CheckBox desktopShortcut;
        Button installButton;
        Label statusLabel;

        bool isUpgrade;
        string installedVersion;






public InstallerForm()
        {
            installedVersion = GetInstalledVersion();
            isUpgrade = Directory.Exists(AppDir) &&
                        File.Exists(Path.Combine(AppDir, "ScreenshotTool.ps1"));

            Text = isUpgrade ?
                "RAQEB Sentinel Pro Update" :
                "RAQEB Sentinel Pro Setup";
            Width = 650;
            Height = 480;
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = true;
            BackColor = Color.White;

            try
            {
                byte[] ico = ReadResourceBytes("aghrab.ico");
                using (var ms = new MemoryStream(ico))
                    Icon = new Icon(ms);
            }
            catch { }

            var header = new Panel {
                Left = 0, Top = 0, Width = 650, Height = 170,
                BackColor = Color.White
            };

            var logo = new PictureBox {
                Left = 25, Top = 15, Width = 585, Height = 135,
                SizeMode = PictureBoxSizeMode.Zoom
            };
            try
            {
                byte[] data = ReadResourceBytes("aghrab-icon.png");
                logo.Image = Image.FromStream(new MemoryStream(data));
            }
            catch { }
            header.Controls.Add(logo);
            Controls.Add(header);

            var line = new Panel {
                Left = 0, Top = 170, Width = 650, Height = 3,
                BackColor = Color.FromArgb(0,142,224)
            };
            Controls.Add(line);

            var title = new Label {
                Left = 32, Top = 195, AutoSize = true,
                Text = isUpgrade ? "Update RAQEB Sentinel Pro" : "Install RAQEB Sentinel Pro",
                Font = new Font("Segoe UI", 15, FontStyle.Bold),
                ForeColor = Color.FromArgb(0,31,63)
            };
            Controls.Add(title);

            var desc = new Label {
                Left = 35, Top = 237, Width = 560, Height = 54,
                Text = isUpgrade ?
                       "Update the installed RAQEB Sentinel Pro application.\r\n" +
                       "Profiles, dashboards, settings, license, Trial state and existing AI Pack are preserved." :
                       "Install RAQEB Sentinel Pro - Visual SOC Operations Platform.\r\n" +
                       "Python is not required. Edge, Chrome, Brave or Chromium can be used.",
                Font = new Font("Segoe UI", 9.5f),
                ForeColor = Color.DimGray
            };
            Controls.Add(desc);

            desktopShortcut = new CheckBox {
                Left = 35, Top = 302, Width = 250, Height = 28,
                Text = "Create Desktop shortcut",
                Checked = true,
                Font = new Font("Segoe UI", 9.5f)
            };
            Controls.Add(desktopShortcut);

            var versionLabel = new Label {
                Left = 35, Top = 336, Width = 280, Height = 24,
                Text = isUpgrade ?
                       "Installed " + installedVersion + "  ->  New " + Version + "  |  Safe in-place update" :
                       "Version " + Version + "  |  Per-user installation",
                Font = new Font("Segoe UI", 9),
                ForeColor = Color.Gray
            };
            Controls.Add(versionLabel);

            installButton = new Button {
                Left = 420, Top = 300, Width = 175, Height = 48,
                Text = isUpgrade ? "UPDATE" : "INSTALL",
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(0,142,224),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 11, FontStyle.Bold)
            };
            installButton.FlatAppearance.BorderSize = 0;
            installButton.Click += InstallButton_Click;
            Controls.Add(installButton);

            statusLabel = new Label {
                Left = 35, Top = 385, Width = 560, Height = 30,
                Text = isUpgrade ? "Ready to update - customer data will be preserved" : "Ready to install",
                Font = new Font("Segoe UI", 9),
                ForeColor = Color.FromArgb(0,31,63)
            };
            Controls.Add(statusLabel);
        }

        string GetInstalledVersion()
        {
            try
            {
                string keyPath = @"Software\Microsoft\Windows\CurrentVersion\Uninstall\" + AppId;
                using (RegistryKey key = Registry.CurrentUser.OpenSubKey(keyPath))
                {
                    if (key != null)
                    {
                        object value = key.GetValue("DisplayVersion");
                        if (value != null && !String.IsNullOrWhiteSpace(value.ToString()))
                            return value.ToString();
                    }
                }
            }
            catch { }

            return "existing";
        }

        byte[] ReadResourceBytes(string resourceName)
        {
            Assembly asm = Assembly.GetExecutingAssembly();
            using (Stream input = asm.GetManifestResourceStream(resourceName))
            {
                if (input == null)
                    throw new InvalidOperationException("Installer resource not found: " + resourceName);
                using (MemoryStream output = new MemoryStream())
                {
                    input.CopyTo(output);
                    return output.ToArray();
                }
            }
        }

        void WriteResource(string fileName, string resourceName)
        {
            File.WriteAllBytes(Path.Combine(AppDir, fileName), ReadResourceBytes(resourceName));
        }

        void CreateShortcut(string shortcutPath)
        {
            Type t = Type.GetTypeFromProgID("WScript.Shell");
            dynamic shell = Activator.CreateInstance(t);
            dynamic sc = shell.CreateShortcut(shortcutPath);
            sc.TargetPath = Path.Combine(AppDir, "RAQEB.exe");
            sc.Arguments = "";
            sc.WorkingDirectory = AppDir;
            sc.IconLocation = Path.Combine(AppDir, "aghrab.ico") + ",0";
            sc.Description = AppName;
            sc.Save();
        }

        void DeleteOldShortcuts()
        {
            string desktop = Environment.GetFolderPath(
                Environment.SpecialFolder.DesktopDirectory);
            string startMenu = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                @"Microsoft\Windows\Start Menu\Programs");

            foreach (string p in new string[] {
                Path.Combine(desktop, "aghrab.lnk"),
                Path.Combine(startMenu, "aghrab.lnk")
            })
            {
                try
                {
                    if (File.Exists(p))
                        File.Delete(p);
                }
                catch { }
            }
        }

        void RegisterUninstall()
        {
            string keyPath = @"Software\Microsoft\Windows\CurrentVersion\Uninstall\" + AppId;

            using (RegistryKey key = Registry.CurrentUser.CreateSubKey(keyPath))
            {
                key.SetValue("DisplayName", AppName);
                key.SetValue("DisplayVersion", Version);
                key.SetValue("Publisher", "RAQEB");
                key.SetValue("InstallLocation", AppDir);
                key.SetValue("DisplayIcon", Path.Combine(AppDir, "aghrab.ico"));
                key.SetValue("NoModify", 1, RegistryValueKind.DWord);
                key.SetValue("NoRepair", 1, RegistryValueKind.DWord);

                string ps = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.System),
                    @"WindowsPowerShell\v1.0\powershell.exe");

                if (!File.Exists(ps))
                    ps = "powershell.exe";

                string uninst = "\"" + ps +
                                "\" -NoProfile -ExecutionPolicy RemoteSigned -File \"" +
                                Path.Combine(AppDir, "Uninstall.ps1") + "\"";

                key.SetValue("UninstallString", uninst);
                key.SetValue("QuietUninstallString", uninst);
            }
        }

        void CopyDirectory(string sourceDir, string destinationDir, bool overwrite)
        {
            Directory.CreateDirectory(destinationDir);

            foreach (string file in Directory.GetFiles(sourceDir))
            {
                string target = Path.Combine(destinationDir, Path.GetFileName(file));

                if (!overwrite && File.Exists(target))
                    continue;

                File.Copy(file, target, true);
            }

            foreach (string directory in Directory.GetDirectories(sourceDir))
            {
                string target = Path.Combine(destinationDir, Path.GetFileName(directory));
                CopyDirectory(directory, target, overwrite);
            }
        }

        string CreateUpgradeBackup()
        {
            if (!isUpgrade || !Directory.Exists(AppDir))
                return null;

            string backupDir = Path.Combine(
                Path.GetTempPath(),
                "RAQEB-Upgrade-" + Guid.NewGuid().ToString("N"));

            Directory.CreateDirectory(backupDir);

            foreach (string fileName in new string[] {
                "ScreenshotTool.ps1",
                "Start-AGHRAB.ps1",
                "RAQEB.exe",
                "Uninstall.ps1",
                "aghrab.ico",
                "aghrab-icon.png",
                "license-public-key.xml"
            })
            {
                string source = Path.Combine(AppDir, fileName);

                if (File.Exists(source))
                    File.Copy(source, Path.Combine(backupDir, fileName), true);
            }

            string icons = Path.Combine(AppDir, "icons");
            if (Directory.Exists(icons))
                CopyDirectory(icons, Path.Combine(backupDir, "icons"), true);

            return backupDir;
        }

        void RestoreUpgradeBackup(string backupDir)
        {
            if (String.IsNullOrWhiteSpace(backupDir) ||
                !Directory.Exists(backupDir))
                return;

            foreach (string file in Directory.GetFiles(backupDir))
            {
                string target = Path.Combine(AppDir, Path.GetFileName(file));
                File.Copy(file, target, true);
            }

            string icons = Path.Combine(backupDir, "icons");
            if (Directory.Exists(icons))
                CopyDirectory(icons, Path.Combine(AppDir, "icons"), true);
        }

        void WriteUpgradeHistory()
        {
            try
            {
                string dataDir = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                    "aghrab");

                Directory.CreateDirectory(dataDir);

                string log = Path.Combine(dataDir, "upgrade-history.log");
                string action = isUpgrade ? "UPDATE" : "INSTALL";

                File.AppendAllText(
                    log,
                    DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") +
                    " | " + action +
                    " | from=" + installedVersion +
                    " | to=" + Version +
                    Environment.NewLine,
                    Encoding.UTF8);
            }
            catch { }
        }

        void InstallButton_Click(object sender, EventArgs e)
        {
            string backupDir = null;

            try
            {
                if (isUpgrade)
                {
                    DialogResult answer = MessageBox.Show(
                        "RAQEB will be updated in place.\r\n\r\n" +
                        "Please close the running RAQEB window before continuing.\r\n\r\n" +
                        "The update preserves:\r\n" +
                        "- ELK profiles and dashboards\r\n" +
                        "- Application settings\r\n" +
                        "- License and Trial state\r\n" +
                        "- Credentials stored in the user profile\r\n" +
                        "- Health / security history\r\n" +
                        "- Existing AI Pack\r\n\r\n" +
                        "Continue with the update?",
                        "RAQEB Sentinel Pro Update",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Information);

                    if (answer != DialogResult.Yes)
                        return;
                }

                installButton.Enabled = false;
                statusLabel.Text = isUpgrade ?
                    "Creating safe update backup..." :
                    "Installing...";
                Application.DoEvents();

                Directory.CreateDirectory(AppDir);
                backupDir = CreateUpgradeBackup();

                statusLabel.Text = isUpgrade ?
                    "Updating application files..." :
                    "Installing application files...";
                Application.DoEvents();

                WriteResource("ScreenshotTool.ps1", "ScreenshotTool.ps1");
                WriteResource("Start-AGHRAB.ps1", "Start-AGHRAB.ps1");
                WriteResource("RAQEB.exe", "RAQEB.exe");
                WriteResource("Uninstall.ps1", "Uninstall.ps1");
                WriteResource("aghrab.ico", "aghrab.ico");
                WriteResource("aghrab-icon.png", "aghrab-icon.png");
                WriteResource("license-public-key.xml", "license-public-key.xml");

                try
                {
                    string oldVbs = Path.Combine(AppDir, "Launch-ScreenshotTool.vbs");
                    if (File.Exists(oldVbs)) File.Delete(oldVbs);
                }
                catch { }

                string setupDir = AppDomain.CurrentDomain.BaseDirectory;

                string iconsSource = Path.Combine(setupDir, "payload", "icons");
                if (Directory.Exists(iconsSource))
                {
                    statusLabel.Text = "Updating UI icon pack...";
                    Application.DoEvents();
                    CopyDirectory(
                        iconsSource,
                        Path.Combine(AppDir, "icons"),
                        true);
                }

                // Preserve the installed AI runtime/model during normal updates.
                // Missing AI files from a Full Offline package are added, while
                // existing multi-GB model/runtime files are not overwritten.
                string aiSource = Path.Combine(setupDir, "payload", "AI");
                if (Directory.Exists(aiSource))
                {
                    statusLabel.Text = "Checking existing AI Pack...";
                    Application.DoEvents();
                    CopyDirectory(
                        aiSource,
                        Path.Combine(AppDir, "AI"),
                        false);
                }

                statusLabel.Text = "Refreshing shortcuts and registration...";
                Application.DoEvents();

                DeleteOldShortcuts();

                string startMenu = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                    @"Microsoft\Windows\Start Menu\Programs\RAQEB Sentinel Pro.lnk");

                CreateShortcut(startMenu);

                string desktop = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),
                    "RAQEB Sentinel Pro.lnk");

                if (desktopShortcut.Checked)
                {
                    CreateShortcut(desktop);
                }
                else
                {
                    try
                    {
                        if (File.Exists(desktop))
                            File.Delete(desktop);
                    }
                    catch { }
                }

                RegisterUninstall();
                WriteUpgradeHistory();

                if (!String.IsNullOrWhiteSpace(backupDir) &&
                    Directory.Exists(backupDir))
                {
                    try { Directory.Delete(backupDir, true); }
                    catch { }
                    backupDir = null;
                }

                statusLabel.Text = isUpgrade ?
                    "Update completed successfully." :
                    "Installation completed.";

                MessageBox.Show(
                    isUpgrade ?
                        "RAQEB Sentinel Pro was updated successfully.\r\n\r\n" +
                        "Your profiles, dashboards, settings, license, Trial state " +
                        "and existing AI Pack were preserved." :
                        "RAQEB Sentinel Pro was installed successfully.",
                    isUpgrade ? "Update complete" : "Installation complete",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                Process.Start(new ProcessStartInfo {
                    FileName = Path.Combine(AppDir, "RAQEB.exe"),
                    WorkingDirectory = AppDir,
                    UseShellExecute = true
                });

                Close();
            }
            catch (Exception ex)
            {
                if (isUpgrade && !String.IsNullOrWhiteSpace(backupDir))
                {
                    statusLabel.Text = "Update failed - restoring previous version...";
                    Application.DoEvents();

                    try
                    {
                        RestoreUpgradeBackup(backupDir);
                    }
                    catch { }
                }

                try
                {
                    if (!String.IsNullOrWhiteSpace(backupDir) &&
                        Directory.Exists(backupDir))
                        Directory.Delete(backupDir, true);
                }
                catch { }

                installButton.Enabled = true;
                statusLabel.Text = isUpgrade ?
                    "Update failed. Previous application files were restored." :
                    "Installation failed.";

                MessageBox.Show(
                    (isUpgrade ?
                        "Update failed. RAQEB attempted to restore the previous application files." :
                        "Installation failed.") +
                    "\r\n\r\n" + ex.Message,
                    "RAQEB Sentinel Pro Setup",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }
    }
}

﻿param([switch]$DefenderScan,[switch]$NoPause)
$ErrorActionPreference="Stop"
$Root=Split-Path -Parent $MyInvocation.MyCommand.Path
$Payload=Join-Path $Root "payload"
$Runtime=Join-Path $Payload "AI\runtime"
$Models=Join-Path $Payload "AI\models"
$Report=Join-Path $Root "RAQEB-Security-Preflight.txt"
$ExpectedModel="d02fe9b69ad8cadbbd228e387667af66612c44bed29ffc8eb1e7caf9ac486c12"
$ExpectedMmproj="980c9b2f78c04e6cff93d277ada09e768394f112d75db3b4e9dea8a69f9fb904"
$ExpectedRuntimeArchive="917f39c076402c421224824607397af20f53625a60defc20e8dd22446bf4c5d7"
$lines=New-Object System.Collections.Generic.List[string]
function Add-Line([string]$Text){ $lines.Add($Text); Write-Host $Text }
function Check-Hash([string]$Name,[string]$Path,[string]$Expected){
 if(-not(Test-Path -LiteralPath $Path -PathType Leaf)){Add-Line("MISSING | "+$Name+" | "+$Path);return $false}
 $actual=(Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
 if($actual -eq $Expected.ToLowerInvariant()){Add-Line("OK      | "+$Name+" | SHA256 "+$actual);return $true}
 Add-Line("FAILED  | "+$Name+" | expected "+$Expected+" | actual "+$actual);return $false
}
Add-Line "RAQEB Sentinel Pro - Security Preflight"
Add-Line ("Time: "+(Get-Date -Format "yyyy-MM-dd HH:mm:ss zzz"))
Add-Line ("Root: "+$Root)
Add-Line ""
foreach($name in @("ScreenshotTool.ps1","Start-AGHRAB.ps1","Uninstall.ps1","license-public-key.xml")){
 $path=Join-Path $Payload $name
 if(Test-Path -LiteralPath $path -PathType Leaf){$hash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant();Add-Line("PRESENT | "+$name+" | SHA256 "+$hash)}else{Add-Line("MISSING | "+$name)}
}
Add-Line "";Add-Line "AI pinned artifacts:"
$model=Join-Path $Models "Qwen2.5-VL-3B-Instruct-Q4_K_M.gguf"
$mmproj=Join-Path $Models "mmproj-Qwen2.5-VL-3B-Instruct-Q8_0.gguf"
if(Test-Path -LiteralPath $model){[void](Check-Hash "Qwen model" $model $ExpectedModel)}else{Add-Line "INFO    | Qwen model not installed."}
if(Test-Path -LiteralPath $mmproj){[void](Check-Hash "Qwen mmproj" $mmproj $ExpectedMmproj)}else{Add-Line "INFO    | Qwen mmproj not installed."}
$manifestPath=Join-Path $Runtime "runtime-sha256.json"
if(Test-Path -LiteralPath $manifestPath -PathType Leaf){
 try{$manifest=Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8|ConvertFrom-Json -ErrorAction Stop
  if(([string]$manifest.source_archive_sha256).ToLowerInvariant() -ne $ExpectedRuntimeArchive){Add-Line "FAILED  | runtime manifest is not tied to the pinned llama.cpp archive."}else{
   Add-Line("OK      | runtime source archive SHA256 "+$ExpectedRuntimeArchive)
   foreach($item in @($manifest.files)){$file=Join-Path $Runtime ([string]$item.name);[void](Check-Hash ("runtime/"+[string]$item.name) $file ([string]$item.sha256))}
  }
 }catch{Add-Line("FAILED  | runtime manifest parse error: "+$_.Exception.Message)}
}elseif(Test-Path -LiteralPath (Join-Path $Runtime "llama-server.exe")){Add-Line "WARNING | legacy llama.cpp runtime has no runtime-sha256.json.";Add-Line "          Re-run Prepare-AI-Pack.bat to enable verified runtime hashes."}else{Add-Line "INFO    | llama.cpp runtime not installed."}
Add-Line ""
try{$mp=Get-MpComputerStatus -ErrorAction Stop;Add-Line("DEFENDER | AntivirusEnabled="+$mp.AntivirusEnabled+" RealTimeProtectionEnabled="+$mp.RealTimeProtectionEnabled)}catch{Add-Line "DEFENDER | Microsoft Defender status cmdlets are unavailable."}
if($DefenderScan){Add-Line "";Add-Line "Starting Microsoft Defender custom scan of the RAQEB package...";try{Start-MpScan -ScanType CustomScan -ScanPath $Root -ErrorAction Stop;Add-Line "DEFENDER | Custom scan command completed."}catch{Add-Line("DEFENDER | Scan could not be started: "+$_.Exception.Message)}}
$lines|Set-Content -LiteralPath $Report -Encoding UTF8 -Force
Write-Host "";Write-Host("Report: "+$Report)
if(-not $NoPause){Read-Host "Press Enter to close"}
